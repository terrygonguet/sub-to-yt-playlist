function ce() {
}
function ct(e, t) {
  for (const i in t)
    e[i] = t[i];
  return e;
}
function Zw(e) {
  return e && typeof e == "object" && typeof e.then == "function";
}
function J2(e) {
  return e();
}
function v5() {
  return /* @__PURE__ */ Object.create(null);
}
function vr(e) {
  e.forEach(J2);
}
function K1(e) {
  return typeof e == "function";
}
function Nt(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
let ba;
function g5(e, t) {
  return ba || (ba = document.createElement("a")), ba.href = t, e === ba.href;
}
function Qw(e) {
  return Object.keys(e).length === 0;
}
function e3(e, ...t) {
  if (e == null)
    return ce;
  const i = e.subscribe(...t);
  return i.unsubscribe ? () => i.unsubscribe() : i;
}
function Bn(e, t, i) {
  e.$$.on_destroy.push(e3(t, i));
}
function y5(e, t, i, n) {
  if (e) {
    const s = Z2(e, t, i, n);
    return e[0](s);
  }
}
function Z2(e, t, i, n) {
  return e[1] && n ? ct(i.ctx.slice(), e[1](n(t))) : i.ctx;
}
function _5(e, t, i, n) {
  if (e[2] && n) {
    const s = e[2](n(i));
    if (t.dirty === void 0)
      return s;
    if (typeof s == "object") {
      const r = [], a = Math.max(t.dirty.length, s.length);
      for (let u = 0; u < a; u += 1)
        r[u] = t.dirty[u] | s[u];
      return r;
    }
    return t.dirty | s;
  }
  return t.dirty;
}
function b5(e, t, i, n, s, r) {
  if (s) {
    const a = Z2(t, i, n, r);
    e.p(a, s);
  }
}
function w5(e) {
  if (e.ctx.length > 32) {
    const t = [], i = e.ctx.length / 32;
    for (let n = 0; n < i; n++)
      t[n] = -1;
    return t;
  }
  return -1;
}
function Vi(e) {
  const t = {};
  for (const i in e)
    i[0] !== "$" && (t[i] = e[i]);
  return t;
}
function Vo(e, t, i) {
  return e.set(i), t;
}
function Y(e, t) {
  e.appendChild(t);
}
function ln(e, t, i) {
  const n = t3(e);
  if (!n.getElementById(t)) {
    const s = le("style");
    s.id = t, s.textContent = i, i3(n, s);
  }
}
function t3(e) {
  if (!e)
    return document;
  const t = e.getRootNode ? e.getRootNode() : e.ownerDocument;
  return t && t.host ? t : e.ownerDocument;
}
function i3(e, t) {
  return Y(e.head || e, t), t.sheet;
}
function Ie(e, t, i) {
  e.insertBefore(t, i || null);
}
function ke(e) {
  e.parentNode.removeChild(e);
}
function n3(e, t) {
  for (let i = 0; i < e.length; i += 1)
    e[i] && e[i].d(t);
}
function le(e) {
  return document.createElement(e);
}
function On(e) {
  return document.createElementNS("http://www.w3.org/2000/svg", e);
}
function Xe(e) {
  return document.createTextNode(e);
}
function wt() {
  return Xe(" ");
}
function Ql() {
  return Xe("");
}
function ti(e, t, i, n) {
  return e.addEventListener(t, i, n), () => e.removeEventListener(t, i, n);
}
function Nc(e) {
  return function(t) {
    return t.preventDefault(), e.call(this, t);
  };
}
function O(e, t, i) {
  i == null ? e.removeAttribute(t) : e.getAttribute(t) !== i && e.setAttribute(t, i);
}
function Ui(e, t) {
  for (const i in t)
    O(e, i, t[i]);
}
function s3(e) {
  return Array.from(e.childNodes);
}
function _s(e, t) {
  t = "" + t, e.wholeText !== t && (e.data = t);
}
function wa(e, t, i) {
  e.classList[i ? "add" : "remove"](t);
}
function r3(e, t, { bubbles: i = !1, cancelable: n = !1 } = {}) {
  const s = document.createEvent("CustomEvent");
  return s.initCustomEvent(e, i, n, t), s;
}
let Uo;
function tn(e) {
  Uo = e;
}
function Q2() {
  if (!Uo)
    throw new Error("Function called outside component initialization");
  return Uo;
}
function o3() {
  const e = Q2();
  return (t, i, { cancelable: n = !1 } = {}) => {
    const s = e.$$.callbacks[t];
    if (s) {
      const r = r3(t, i, { cancelable: n });
      return s.slice().forEach((a) => {
        a.call(e, r);
      }), !r.defaultPrevented;
    }
    return !0;
  };
}
function e9(e, t) {
  const i = e.$$.callbacks[t.type];
  i && i.slice().forEach((n) => n.call(this, t));
}
const Ur = [], xl = [], Ha = [], z1 = [], a3 = Promise.resolve();
let Y1 = !1;
function l3() {
  Y1 || (Y1 = !0, a3.then(at));
}
function X1(e) {
  Ha.push(e);
}
function u3(e) {
  z1.push(e);
}
const a1 = /* @__PURE__ */ new Set();
let Sa = 0;
function at() {
  const e = Uo;
  do {
    for (; Sa < Ur.length; ) {
      const t = Ur[Sa];
      Sa++, tn(t), c3(t.$$);
    }
    for (tn(null), Ur.length = 0, Sa = 0; xl.length; )
      xl.pop()();
    for (let t = 0; t < Ha.length; t += 1) {
      const i = Ha[t];
      a1.has(i) || (a1.add(i), i());
    }
    Ha.length = 0;
  } while (Ur.length);
  for (; z1.length; )
    z1.pop()();
  Y1 = !1, a1.clear(), tn(e);
}
function c3(e) {
  if (e.fragment !== null) {
    e.update(), vr(e.before_update);
    const t = e.dirty;
    e.dirty = [-1], e.fragment && e.fragment.p(e.ctx, t), e.after_update.forEach(X1);
  }
}
const Wa = /* @__PURE__ */ new Set();
let ps;
function ws() {
  ps = {
    r: 0,
    c: [],
    p: ps
  };
}
function Ss() {
  ps.r || vr(ps.c), ps = ps.p;
}
function Ee(e, t) {
  e && e.i && (Wa.delete(e), e.i(t));
}
function Re(e, t, i, n) {
  if (e && e.o) {
    if (Wa.has(e))
      return;
    Wa.add(e), ps.c.push(() => {
      Wa.delete(e), n && (i && e.d(1), n());
    }), e.o(t);
  } else
    n && n();
}
function El(e, t) {
  const i = t.token = {};
  function n(s, r, a, u) {
    if (t.token !== i)
      return;
    t.resolved = u;
    let c = t.ctx;
    a !== void 0 && (c = c.slice(), c[a] = u);
    const h = s && (t.current = s)(c);
    let p = !1;
    t.block && (t.blocks ? t.blocks.forEach((f, _) => {
      _ !== r && f && (ws(), Re(f, 1, 1, () => {
        t.blocks[_] === f && (t.blocks[_] = null);
      }), Ss());
    }) : t.block.d(1), h.c(), Ee(h, 1), h.m(t.mount(), t.anchor), p = !0), t.block = h, t.blocks && (t.blocks[r] = h), p && at();
  }
  if (Zw(e)) {
    const s = Q2();
    if (e.then((r) => {
      tn(s), n(t.then, 1, t.value, r), tn(null);
    }, (r) => {
      if (tn(s), n(t.catch, 2, t.error, r), tn(null), !t.hasCatch)
        throw r;
    }), t.current !== t.pending)
      return n(t.pending, 0), !0;
  } else {
    if (t.current !== t.then)
      return n(t.then, 1, t.value, e), !0;
    t.resolved = e;
  }
}
function t9(e, t, i) {
  const n = t.slice(), { resolved: s } = e;
  e.current === e.then && (n[e.value] = s), e.current === e.catch && (n[e.error] = s), e.block.p(n, i);
}
function i9(e, t) {
  Re(e, 1, 1, () => {
    t.delete(e.key);
  });
}
function n9(e, t, i, n, s, r, a, u, c, h, p, f) {
  let _ = e.length, C = r.length, E = _;
  const P = {};
  for (; E--; )
    P[e[E].key] = E;
  const A = [], F = /* @__PURE__ */ new Map(), M = /* @__PURE__ */ new Map();
  for (E = C; E--; ) {
    const v = f(s, r, E), U = i(v);
    let Z = a.get(U);
    Z ? n && Z.p(v, t) : (Z = h(U, v), Z.c()), F.set(U, A[E] = Z), U in P && M.set(U, Math.abs(E - P[U]));
  }
  const j = /* @__PURE__ */ new Set(), z = /* @__PURE__ */ new Set();
  function D(v) {
    Ee(v, 1), v.m(u, p), a.set(v.key, v), p = v.first, C--;
  }
  for (; _ && C; ) {
    const v = A[C - 1], U = e[_ - 1], Z = v.key, he = U.key;
    v === U ? (p = v.first, _--, C--) : F.has(he) ? !a.has(Z) || j.has(Z) ? D(v) : z.has(he) ? _-- : M.get(Z) > M.get(he) ? (z.add(Z), D(v)) : (j.add(he), _--) : (c(U, a), _--);
  }
  for (; _--; ) {
    const v = e[_];
    F.has(v.key) || c(v, a);
  }
  for (; C; )
    D(A[C - 1]);
  return A;
}
function Gn(e, t) {
  const i = {}, n = {}, s = { $$scope: 1 };
  let r = e.length;
  for (; r--; ) {
    const a = e[r], u = t[r];
    if (u) {
      for (const c in a)
        c in u || (n[c] = 1);
      for (const c in u)
        s[c] || (i[c] = u[c], s[c] = 1);
      e[r] = u;
    } else
      for (const c in a)
        s[c] = 1;
  }
  for (const a in n)
    a in i || (i[a] = void 0);
  return i;
}
function Rc(e) {
  return typeof e == "object" && e !== null ? e : {};
}
function h3(e, t, i) {
  const n = e.$$.props[t];
  n !== void 0 && (e.$$.bound[n] = i, i(e.$$.ctx[n]));
}
function Pt(e) {
  e && e.c();
}
function Ct(e, t, i, n) {
  const { fragment: s, on_mount: r, on_destroy: a, after_update: u } = e.$$;
  s && s.m(t, i), n || X1(() => {
    const c = r.map(J2).filter(K1);
    a ? a.push(...c) : vr(c), e.$$.on_mount = [];
  }), u.forEach(X1);
}
function Tt(e, t) {
  const i = e.$$;
  i.fragment !== null && (vr(i.on_destroy), i.fragment && i.fragment.d(t), i.on_destroy = i.fragment = null, i.ctx = []);
}
function d3(e, t) {
  e.$$.dirty[0] === -1 && (Ur.push(e), l3(), e.$$.dirty.fill(0)), e.$$.dirty[t / 31 | 0] |= 1 << t % 31;
}
function Ht(e, t, i, n, s, r, a, u = [-1]) {
  const c = Uo;
  tn(e);
  const h = e.$$ = {
    fragment: null,
    ctx: null,
    props: r,
    update: ce,
    not_equal: s,
    bound: v5(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(t.context || (c ? c.$$.context : [])),
    callbacks: v5(),
    dirty: u,
    skip_bound: !1,
    root: t.target || c.$$.root
  };
  a && a(h.root);
  let p = !1;
  if (h.ctx = i ? i(e, t.props || {}, (f, _, ...C) => {
    const E = C.length ? C[0] : _;
    return h.ctx && s(h.ctx[f], h.ctx[f] = E) && (!h.skip_bound && h.bound[f] && h.bound[f](E), p && d3(e, f)), _;
  }) : [], h.update(), p = !0, vr(h.before_update), h.fragment = n ? n(h.ctx) : !1, t.target) {
    if (t.hydrate) {
      const f = s3(t.target);
      h.fragment && h.fragment.l(f), f.forEach(ke);
    } else
      h.fragment && h.fragment.c();
    t.intro && Ee(e.$$.fragment), Ct(e, t.target, t.anchor, t.customElement), at();
  }
  tn(c);
}
class Wt {
  $destroy() {
    Tt(this, 1), this.$destroy = ce;
  }
  $on(t, i) {
    const n = this.$$.callbacks[t] || (this.$$.callbacks[t] = []);
    return n.push(i), () => {
      const s = n.indexOf(i);
      s !== -1 && n.splice(s, 1);
    };
  }
  $set(t) {
    this.$$set && !Qw(t) && (this.$$.skip_bound = !0, this.$$set(t), this.$$.skip_bound = !1);
  }
}
var p3 = Object.create, Xo = Object.defineProperty, f3 = Object.defineProperties, m3 = Object.getOwnPropertyDescriptor, v3 = Object.getOwnPropertyDescriptors, s9 = Object.getOwnPropertyNames, S5 = Object.getOwnPropertySymbols, g3 = Object.getPrototypeOf, r9 = Object.prototype.hasOwnProperty, y3 = Object.prototype.propertyIsEnumerable, C5 = (e, t, i) => t in e ? Xo(e, t, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[t] = i, xo = (e, t) => {
  for (var i in t || (t = {}))
    r9.call(t, i) && C5(e, i, t[i]);
  if (S5)
    for (var i of S5(t))
      y3.call(t, i) && C5(e, i, t[i]);
  return e;
}, T5 = (e, t) => f3(e, v3(t)), l = (e, t) => Xo(e, "name", { value: t, configurable: !0 }), o9 = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, {
  get: (t, i) => (typeof require < "u" ? require : t)[i]
}) : e)(function(e) {
  if (typeof require < "u")
    return require.apply(this, arguments);
  throw new Error('Dynamic require of "' + e + '" is not supported');
}), J = (e, t) => function() {
  return t || (0, e[s9(e)[0]])((t = { exports: {} }).exports, t), t.exports;
}, Jo = (e, t) => {
  for (var i in t)
    Xo(e, i, { get: t[i], enumerable: !0 });
}, _3 = (e, t, i, n) => {
  if (t && typeof t == "object" || typeof t == "function")
    for (let s of s9(t))
      !r9.call(e, s) && s !== i && Xo(e, s, { get: () => t[s], enumerable: !(n = m3(t, s)) || n.enumerable });
  return e;
}, Wi = (e, t, i) => (i = e != null ? p3(g3(e)) : {}, _3(t || !e || !e.__esModule ? Xo(i, "default", { value: e, enumerable: !0 }) : i, e)), b3 = J({
  "node_modules/jintr/dist/src/nodes/ArrayExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return i.elements.map((s) => n.visitNode(s));
      }
    };
    l(t, "ArrayExpression"), e.default = t;
  }
}), w3 = J({
  "node_modules/jintr/dist/src/nodes/AssignmentExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator, r = n.visitNode(i.right);
        switch (s) {
          case "=":
            if (i.left.computed) {
              const a = n.visitNode(i.left.object), u = n.visitNode(i.left.property);
              return a[u] = r;
            }
            return n.scope.set(i.left.name, r), n.scope.get(i.left.name);
          case "+=":
            return n.scope.set(i.left.name, n.scope.get(i.left.name) + r), n.scope.get(i.left.name);
          case "-=":
            return n.scope.set(i.left.name, n.scope.get(i.left.name) - r), n.scope.get(i.left.name);
          default:
            console.warn("Operator not implemented:", s);
        }
      }
    };
    l(t, "AssignmentExpression"), e.default = t;
  }
}), S3 = J({
  "node_modules/jintr/dist/src/nodes/BinaryExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator, r = n.visitNode(i.left), a = n.visitNode(i.right);
        switch (s) {
          case "+":
            return r + a;
          case "-":
            return r - a;
          case "/":
            return r / a;
          case "%":
            return r % a;
          case "*":
            return r * a;
          case "==":
            return r == a;
          case "===":
            return r === a;
          case "!==":
            return r !== a;
          case "!=":
            return r != a;
          case ">":
            return r > a;
          case "<":
            return r < a;
          case "<<":
            return r << a;
          case ">>":
            return r >> a;
          case ">>>":
            return r >>> a;
          case ">=":
            return r >= a;
          case "<=":
            return r <= a;
          case "|":
            return r | a;
          case "&":
            return r & a;
          case "^":
            return r ^ a;
          case "in":
            return r in a;
          case "instanceof":
            return r instanceof a;
          default:
            console.warn("Unsupported binary operator: ", s);
        }
      }
    };
    l(t, "BinaryExpression"), e.default = t;
  }
}), C3 = J({
  "node_modules/jintr/dist/src/nodes/BlockStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (const s of i.body) {
          const r = n.visitNode(s);
          if (s.type === "ReturnStatement" || r === "break" || r === "continue" || (s.type === "WhileStatement" || s.type === "IfStatement" || s.type === "ForStatement" || s.type === "TryStatement") && !!r)
            return r;
        }
      }
    };
    l(t, "BlockStatement"), e.default = t;
  }
}), T3 = J({
  "node_modules/jintr/dist/src/nodes/BreakStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return "break";
      }
    };
    l(t, "BreakStatement"), e.default = t;
  }
}), x3 = J({
  "node_modules/jintr/dist/src/nodes/CallExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        var s, r;
        const a = (s = i.callee.object) === null || s === void 0 ? void 0 : s.name, u = i.callee.name || ((r = i.callee.property) === null || r === void 0 ? void 0 : r.name);
        if (n.listeners[a]) {
          const h = n.listeners[a](i, n);
          if (h !== "proceed")
            return h;
        }
        if (n.listeners[u]) {
          const h = n.listeners[u](i, n);
          if (h !== "proceed")
            return h;
        }
        switch (u) {
          case "print": {
            const h = i.arguments.map((p) => n.visitNode(p));
            console.log(...h);
            return;
          }
          case "push": {
            const h = i.arguments.map((f) => n.visitNode(f)), p = n.visitNode(i.callee.object);
            for (const f of h)
              p.push(f);
            return;
          }
          case "join": {
            const h = i.arguments.map((f) => n.visitNode(f));
            return n.visitNode(i.callee.object).join(h?.[0] || "");
          }
          case "splice": {
            const h = i.arguments.map((f) => n.visitNode(f));
            return n.visitNode(i.callee.object).splice(...h);
          }
          case "reverse":
            return i.arguments.map((p) => n.visitNode(p)), n.visitNode(i.callee.object).reverse();
          case "unshift": {
            const h = i.arguments.map((f) => n.visitNode(f));
            return n.visitNode(i.callee.object).unshift(...h);
          }
          case "split": {
            const h = i.arguments.map((f) => n.visitNode(f));
            return n.visitNode(i.callee.object).split(...h);
          }
          case "indexOf": {
            const h = i.arguments.map((f) => n.visitNode(f));
            return n.visitNode(i.callee.object).indexOf(...h);
          }
          case "pop":
            return i.arguments.map((p) => n.visitNode(p)), n.visitNode(i.callee.object).pop();
          case "forEach": {
            const h = i.arguments.map((_) => n.visitNode(_)), p = n.visitNode(i.callee.object);
            h.length > 1 && n.scope.set("_this", h.slice(-1)[0]);
            let f = 0;
            for (const _ of p)
              h[0]([_, f++, p]);
            return;
          }
        }
        const c = n.visitNode(i.callee);
        if (typeof c != "function")
          throw i.callee.object ? new Error(`${n.visitNode(i.callee.object)}.${n.visitNode(i.callee.property)}(...) is not a function`) : new Error(`${c} is not a function`);
        {
          const h = i.arguments.map((p) => n.visitNode(p));
          return c.toString().includes("[native code]") ? n.visitNode(i.callee.object)[i.callee.property.name]() : c(h);
        }
      }
    };
    l(t, "CallExpression"), e.default = t;
  }
}), E3 = J({
  "node_modules/jintr/dist/src/nodes/ConditionalExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const { test: s, consequent: r, alternate: a } = i;
        return s.operator, n.visitNode(s) ? n.visitNode(r) : n.visitNode(a);
      }
    };
    l(t, "ConditionalExpression"), e.default = t;
  }
}), k3 = J({
  "node_modules/jintr/dist/src/nodes/ContinueStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return "continue";
      }
    };
    l(t, "ContinueStatement"), e.default = t;
  }
}), A3 = J({
  "node_modules/jintr/dist/src/nodes/ExpressionStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.visitNode(i.expression);
      }
    };
    l(t, "ExpressionStatement"), e.default = t;
  }
}), I3 = J({
  "node_modules/jintr/dist/src/nodes/ForStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        i.init && n.visitNode(i.init);
        const s = /* @__PURE__ */ l(() => i.test ? n.visitNode(i.test) : !0, "test");
        for (; s(); ) {
          const a = n.visitNode(i.body);
          if (a !== "continue") {
            if (a === "break")
              break;
            if (i.update && n.visitNode(i.update), a && i.body.type !== "ExpressionStatement")
              return a;
          }
        }
      }
    };
    l(t, "ForStatement"), e.default = t;
  }
}), P3 = J({
  "node_modules/jintr/dist/src/nodes/FunctionDeclaration.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = /* @__PURE__ */ l((h, p) => Object.defineProperty(p, "name", { value: h }), "nameFunction"), { params: r, body: a } = i, u = n.visitNode(i.id), c = s(u, (h) => {
          for (let p = 0; p < r.length; p++)
            n.visitNode(r[p]), n.scope.set(r[p].name, h[p]);
          return n.visitNode(a);
        });
        n.scope.set(u, c);
      }
    };
    l(t, "FunctionDeclaration"), e.default = t;
  }
}), M3 = J({
  "node_modules/jintr/dist/src/nodes/FunctionExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = /* @__PURE__ */ l((c, h) => Object.defineProperty(h, "name", { value: c }), "nameFunction"), { params: r, body: a } = i;
        return s("anonymous function", (c) => {
          for (let h = 0; h < r.length; h++)
            n.visitNode(r[h]), n.scope.set(r[h].name, c[h]);
          return n.visitNode(a);
        });
      }
    };
    l(t, "FunctionExpression"), e.default = t;
  }
}), N3 = J({
  "node_modules/jintr/dist/src/nodes/Identifier.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        if (n.listeners[i.name]) {
          const s = n.listeners[i.name](i, n);
          if (s !== "proceed")
            return s;
        }
        return n.scope.has(i.name) ? n.scope.get(i.name) : i.name;
      }
    };
    l(t, "Identifier"), e.default = t;
  }
}), R3 = J({
  "node_modules/jintr/dist/src/nodes/IfStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        if (n.visitNode(i.test))
          return n.visitNode(i.consequent);
        if (i.alternate)
          return n.visitNode(i.alternate);
      }
    };
    l(t, "IfStatement"), e.default = t;
  }
}), L3 = J({
  "node_modules/jintr/dist/src/nodes/Literal.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return i.value;
      }
    };
    l(t, "Literal"), e.default = t;
  }
}), D3 = J({
  "node_modules/jintr/dist/src/nodes/LogicalExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (s) {
          case "&&": {
            const r = n.visitNode(i.left);
            return r === !0 ? n.visitNode(i.right) : r;
          }
          case "||":
            return n.visitNode(i.left) || n.visitNode(i.right);
          default:
            throw Error(`Unsupported logical operator: ${s}`);
        }
      }
    };
    l(t, "LogicalExpression"), e.default = t;
  }
}), B3 = J({
  "node_modules/jintr/dist/src/nodes/MemberExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const { object: s, property: r, computed: a } = i, u = n.visitNode(s), c = a ? n.visitNode(r) : r.name;
        if (c === "length")
          return u.length;
        if (n.listeners[c]) {
          const h = n.listeners[c](i, n);
          if (h !== "proceed")
            return h;
        }
        return u?.[c];
      }
    };
    l(t, "MemberExpression"), e.default = t;
  }
}), O3 = J({
  "node_modules/jintr/dist/src/nodes/NewExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = n.visitNode(i.callee), r = i.arguments.map((a) => n.visitNode(a));
        return new s(r);
      }
    };
    l(t, "NewExpression"), e.default = t;
  }
}), F3 = J({
  "node_modules/jintr/dist/src/nodes/ObjectExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = {};
        for (const r of i.properties) {
          const a = n.visitNode(r.key), u = n.visitNode(r.value);
          s[a] = u;
        }
        return s;
      }
    };
    l(t, "ObjectExpression"), e.default = t;
  }
}), V3 = J({
  "node_modules/jintr/dist/src/nodes/ReturnStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.visitNode(i.argument);
      }
    };
    l(t, "ReturnStatement"), e.default = t;
  }
}), U3 = J({
  "node_modules/jintr/dist/src/nodes/SequenceExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        let s;
        for (const r of i.expressions)
          s = n.visitNode(r);
        return s;
      }
    };
    l(t, "SequenceExpression"), e.default = t;
  }
}), j3 = J({
  "node_modules/jintr/dist/src/nodes/SwitchCase.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (const s of i.consequent) {
          const r = n.visitNode(s);
          if (s.type === "ContinueStatement")
            return r;
          if (s.type === "BreakStatement")
            return r;
        }
      }
    };
    l(t, "SwitchCase"), e.default = t;
  }
}), H3 = J({
  "node_modules/jintr/dist/src/nodes/SwitchStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = n.visitNode(i.discriminant);
        let r = !1, a = -1, u = 0;
        for (; ; ) {
          const c = i.cases[u];
          if (r) {
            const h = n.visitNode(c);
            if (h === "break")
              break;
            if (h === "continue")
              return h;
            if (++u, u >= i.cases.length) {
              u = 0;
              break;
            } else
              continue;
          }
          if (r = c && s === n.visitNode(c.test), r === void 0 && u > i.cases.length)
            break;
          if (c && !r && !c.test) {
            a = u, u += 1;
            continue;
          }
          if (!c && !r && a !== -1) {
            r = !0, u = a;
            continue;
          }
          r || ++u;
        }
      }
    };
    l(t, "SwitchStatement"), e.default = t;
  }
}), W3 = J({
  "node_modules/jintr/dist/src/nodes/ThisExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.scope.get("_this");
      }
    };
    l(t, "ThisExpression"), e.default = t;
  }
}), $3 = J({
  "node_modules/jintr/dist/src/nodes/ThrowStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        throw n.visitNode(i.argument);
      }
    };
    l(t, "ThrowStatement"), e.default = t;
  }
}), G3 = J({
  "node_modules/jintr/dist/src/nodes/TryStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        try {
          return n.visitNode(i.block);
        } catch (s) {
          return n.scope.set(i.handler.param.name, s), n.visitNode(i.handler.body);
        } finally {
          n.visitNode(i.finalizer);
        }
      }
    };
    l(t, "TryStatement"), e.default = t;
  }
}), q3 = J({
  "node_modules/jintr/dist/src/nodes/UnaryExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (s) {
          case "-":
            return -n.visitNode(i.argument);
          case "void": {
            n.visitNode(i.argument);
            return;
          }
          case "typeof":
            return typeof n.visitNode(i.argument);
          default:
            console.warn("Unsupported unary operator: ", s);
        }
      }
    };
    l(t, "UnaryExpression"), e.default = t;
  }
}), K3 = J({
  "node_modules/jintr/dist/src/nodes/UpdateExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (n.visitNode(i.argument), s) {
          case "++": {
            if (i.argument.object) {
              const a = n.visitNode(i.argument.object);
              return a[n.visitNode(i.argument.property)]++;
            }
            let r = n.visitNode(i.argument);
            return n.scope.set(i.argument.name, r + 1), i.prefix ? ++r : r;
          }
          case "--": {
            if (i.argument.object) {
              const a = n.visitNode(i.argument.object);
              return a[n.visitNode(i.argument.property)]--;
            }
            let r = n.visitNode(i.argument);
            return n.scope.set(i.argument.name, r - 1), i.prefix ? --r : r;
          }
          default:
            console.warn("Unsupported operator: ", s);
        }
      }
    };
    l(t, "UpdateExpression"), e.default = t;
  }
}), z3 = J({
  "node_modules/jintr/dist/src/nodes/VariableDeclaration.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        i.declarations.forEach((s) => {
          const { id: r, init: a } = s, u = r.name, c = a ? n.visitNode(a) : void 0;
          n.scope.set(u, c);
        });
      }
    };
    l(t, "VariableDeclaration"), e.default = t;
  }
}), Y3 = J({
  "node_modules/jintr/dist/src/nodes/WhileStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (; n.visitNode(i.test); ) {
          const s = n.visitNode(i.body);
          if (s === "break")
            break;
          if (s !== "continue" && s)
            return s;
        }
      }
    };
    l(t, "WhileStatement"), e.default = t;
  }
}), X3 = J({
  "node_modules/jintr/dist/src/map.js"(e) {
    var t = e && e.__importDefault || function(Ve) {
      return Ve && Ve.__esModule ? Ve : { default: Ve };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(b3()), n = t(w3()), s = t(S3()), r = t(C3()), a = t(T3()), u = t(x3()), c = t(E3()), h = t(k3()), p = t(A3()), f = t(I3()), _ = t(P3()), C = t(M3()), E = t(N3()), P = t(R3()), A = t(L3()), F = t(D3()), M = t(B3()), j = t(O3()), z = t(F3()), D = t(V3()), v = t(U3()), U = t(j3()), Z = t(H3()), he = t(W3()), te = t($3()), Je = t(G3()), Q = t(q3()), ie = t(K3()), ye = t(z3()), Ze = t(Y3()), Te = {
      ArrayExpression: i.default,
      AssignmentExpression: n.default,
      BinaryExpression: s.default,
      BlockStatement: r.default,
      BreakStatement: a.default,
      CallExpression: u.default,
      ConditionalExpression: c.default,
      ContinueStatement: h.default,
      ExpressionStatement: p.default,
      ForStatement: f.default,
      FunctionDeclaration: _.default,
      FunctionExpression: C.default,
      Identifier: E.default,
      IfStatement: P.default,
      Literal: A.default,
      LogicalExpression: F.default,
      MemberExpression: M.default,
      NewExpression: j.default,
      ObjectExpression: z.default,
      ReturnStatement: D.default,
      SequenceExpression: v.default,
      SwitchCase: U.default,
      SwitchStatement: Z.default,
      ThisExpression: he.default,
      ThrowStatement: te.default,
      TryStatement: Je.default,
      UnaryExpression: Q.default,
      UpdateExpression: ie.default,
      VariableDeclaration: ye.default,
      WhileStatement: Ze.default
    };
    function st(Ve) {
      const fe = Te[Ve];
      if (!fe) {
        const Et = new Error(`Module not found: ${Ve}`);
        throw Et.code = "MODULE_NOT_FOUND", Et;
      }
      return fe;
    }
    l(st, "getNode"), e.default = st;
  }
}), J3 = J({
  "node_modules/jintr/dist/src/visitor.js"(e) {
    var t = e && e.__importDefault || function(s) {
      return s && s.__esModule ? s : { default: s };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(X3()), n = class {
      constructor(s) {
        this.scope = /* @__PURE__ */ new Map(), this.listeners = {}, this.ast = s;
      }
      run() {
        let s;
        for (const r of this.ast)
          s = this.visitNode(r);
        return s;
      }
      visitNode(s) {
        if (!s)
          return null;
        try {
          return (0, i.default)(s.type).visit(s, this);
        } catch (r) {
          if (r.code === "MODULE_NOT_FOUND")
            console.warn("Node not implemented:", s);
          else
            throw r;
        }
      }
      on(s, r) {
        this.listeners[s] = r;
      }
    };
    l(n, "Visitor"), e.default = n;
  }
}), Z3 = J({
  "node_modules/acorn/dist/acorn.js"(e, t) {
    (function(i, n) {
      typeof e == "object" && typeof t < "u" ? n(e) : typeof define == "function" && define.amd ? define(["exports"], n) : (i = typeof globalThis < "u" ? globalThis : i || self, n(i.acorn = {}));
    })(e, function(i) {
      var n = [509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 574, 3, 9, 9, 370, 1, 154, 10, 50, 3, 123, 2, 54, 14, 32, 10, 3, 1, 11, 3, 46, 10, 8, 0, 46, 9, 7, 2, 37, 13, 2, 9, 6, 1, 45, 0, 13, 2, 49, 13, 9, 3, 2, 11, 83, 11, 7, 0, 161, 11, 6, 9, 7, 3, 56, 1, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 193, 17, 10, 9, 5, 0, 82, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 84, 14, 5, 9, 243, 14, 166, 9, 71, 5, 2, 1, 3, 3, 2, 0, 2, 1, 13, 9, 120, 6, 3, 6, 4, 0, 29, 9, 41, 6, 2, 3, 9, 0, 10, 10, 47, 15, 406, 7, 2, 7, 17, 9, 57, 21, 2, 13, 123, 5, 4, 0, 2, 1, 2, 6, 2, 0, 9, 9, 49, 4, 2, 1, 2, 4, 9, 9, 330, 3, 19306, 9, 87, 9, 39, 4, 60, 6, 26, 9, 1014, 0, 2, 54, 8, 3, 82, 0, 12, 1, 19628, 1, 4706, 45, 3, 22, 543, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 262, 6, 10, 9, 357, 0, 62, 13, 1495, 6, 110, 6, 6, 9, 4759, 9, 787719, 239], s = [0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 14, 29, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 13, 10, 2, 14, 2, 6, 2, 1, 2, 10, 2, 14, 2, 6, 2, 1, 68, 310, 10, 21, 11, 7, 25, 5, 2, 41, 2, 8, 70, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 28, 43, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 14, 35, 349, 41, 7, 1, 79, 28, 11, 0, 9, 21, 43, 17, 47, 20, 28, 22, 13, 52, 58, 1, 3, 0, 14, 44, 33, 24, 27, 35, 30, 0, 3, 0, 9, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 85, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 159, 52, 19, 3, 21, 2, 31, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 14, 0, 72, 26, 38, 6, 186, 43, 117, 63, 32, 7, 3, 0, 3, 7, 2, 1, 2, 23, 16, 0, 2, 0, 95, 7, 3, 38, 17, 0, 2, 0, 29, 0, 11, 39, 8, 0, 22, 0, 12, 45, 20, 0, 19, 72, 264, 8, 2, 36, 18, 0, 50, 29, 113, 6, 2, 1, 2, 37, 22, 0, 26, 5, 2, 1, 2, 31, 15, 0, 328, 18, 190, 0, 80, 921, 103, 110, 18, 195, 2637, 96, 16, 1070, 4050, 582, 8634, 568, 8, 30, 18, 78, 18, 29, 19, 47, 17, 3, 32, 20, 6, 18, 689, 63, 129, 74, 6, 0, 67, 12, 65, 1, 2, 0, 29, 6135, 9, 1237, 43, 8, 8936, 3, 2, 6, 2, 1, 2, 290, 46, 2, 18, 3, 9, 395, 2309, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 1845, 30, 482, 44, 11, 6, 17, 0, 322, 29, 19, 43, 1269, 6, 2, 3, 2, 1, 2, 14, 2, 196, 60, 67, 8, 0, 1205, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42719, 33, 4152, 8, 221, 3, 5761, 15, 7472, 3104, 541, 1507, 4938], r = "\u200C\u200D\xB7\u0300-\u036F\u0387\u0483-\u0487\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u0669\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u06F0-\u06F9\u0711\u0730-\u074A\u07A6-\u07B0\u07C0-\u07C9\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u0898-\u089F\u08CA-\u08E1\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0966-\u096F\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09E6-\u09EF\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A66-\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AE6-\u0AEF\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B62\u0B63\u0B66-\u0B6F\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0BE6-\u0BEF\u0C00-\u0C04\u0C3C\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0CE6-\u0CEF\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D66-\u0D6F\u0D81-\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0E50-\u0E59\u0EB1\u0EB4-\u0EBC\u0EC8-\u0ECD\u0ED0-\u0ED9\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1040-\u1049\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F-\u109D\u135D-\u135F\u1369-\u1371\u1712-\u1715\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u17E0-\u17E9\u180B-\u180D\u180F-\u1819\u18A9\u1920-\u192B\u1930-\u193B\u1946-\u194F\u19D0-\u19DA\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AB0-\u1ABD\u1ABF-\u1ACE\u1B00-\u1B04\u1B34-\u1B44\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BB0-\u1BB9\u1BE6-\u1BF3\u1C24-\u1C37\u1C40-\u1C49\u1C50-\u1C59\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DFF\u203F\u2040\u2054\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA620-\uA629\uA66F\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA82C\uA880\uA881\uA8B4-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F1\uA8FF-\uA909\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9D0-\uA9D9\uA9E5\uA9F0-\uA9F9\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA50-\uAA59\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uABF0-\uABF9\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFF10-\uFF19\uFF3F", a = "\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC", u = {
        3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
        5: "class enum extends super const export import",
        6: "enum",
        strict: "implements interface let package private protected public static yield",
        strictBind: "eval arguments"
      }, c = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this", h = {
        5: c,
        "5module": c + " export import",
        6: c + " const class extends export import super"
      }, p = /^in(stanceof)?$/, f = new RegExp("[" + a + "]"), _ = new RegExp("[" + a + r + "]");
      function C(o, d) {
        for (var m = 65536, g = 0; g < d.length; g += 2) {
          if (m += d[g], m > o)
            return !1;
          if (m += d[g + 1], m >= o)
            return !0;
        }
      }
      l(C, "isInAstralSet");
      function E(o, d) {
        return o < 65 ? o === 36 : o < 91 ? !0 : o < 97 ? o === 95 : o < 123 ? !0 : o <= 65535 ? o >= 170 && f.test(String.fromCharCode(o)) : d === !1 ? !1 : C(o, s);
      }
      l(E, "isIdentifierStart");
      function P(o, d) {
        return o < 48 ? o === 36 : o < 58 ? !0 : o < 65 ? !1 : o < 91 ? !0 : o < 97 ? o === 95 : o < 123 ? !0 : o <= 65535 ? o >= 170 && _.test(String.fromCharCode(o)) : d === !1 ? !1 : C(o, s) || C(o, n);
      }
      l(P, "isIdentifierChar");
      var A = /* @__PURE__ */ l(function(d, m) {
        m === void 0 && (m = {}), this.label = d, this.keyword = m.keyword, this.beforeExpr = !!m.beforeExpr, this.startsExpr = !!m.startsExpr, this.isLoop = !!m.isLoop, this.isAssign = !!m.isAssign, this.prefix = !!m.prefix, this.postfix = !!m.postfix, this.binop = m.binop || null, this.updateContext = null;
      }, "TokenType");
      function F(o, d) {
        return new A(o, { beforeExpr: !0, binop: d });
      }
      l(F, "binop");
      var M = { beforeExpr: !0 }, j = { startsExpr: !0 }, z = {};
      function D(o, d) {
        return d === void 0 && (d = {}), d.keyword = o, z[o] = new A(o, d);
      }
      l(D, "kw");
      var v = {
        num: new A("num", j),
        regexp: new A("regexp", j),
        string: new A("string", j),
        name: new A("name", j),
        privateId: new A("privateId", j),
        eof: new A("eof"),
        bracketL: new A("[", { beforeExpr: !0, startsExpr: !0 }),
        bracketR: new A("]"),
        braceL: new A("{", { beforeExpr: !0, startsExpr: !0 }),
        braceR: new A("}"),
        parenL: new A("(", { beforeExpr: !0, startsExpr: !0 }),
        parenR: new A(")"),
        comma: new A(",", M),
        semi: new A(";", M),
        colon: new A(":", M),
        dot: new A("."),
        question: new A("?", M),
        questionDot: new A("?."),
        arrow: new A("=>", M),
        template: new A("template"),
        invalidTemplate: new A("invalidTemplate"),
        ellipsis: new A("...", M),
        backQuote: new A("`", j),
        dollarBraceL: new A("${", { beforeExpr: !0, startsExpr: !0 }),
        eq: new A("=", { beforeExpr: !0, isAssign: !0 }),
        assign: new A("_=", { beforeExpr: !0, isAssign: !0 }),
        incDec: new A("++/--", { prefix: !0, postfix: !0, startsExpr: !0 }),
        prefix: new A("!/~", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        logicalOR: F("||", 1),
        logicalAND: F("&&", 2),
        bitwiseOR: F("|", 3),
        bitwiseXOR: F("^", 4),
        bitwiseAND: F("&", 5),
        equality: F("==/!=/===/!==", 6),
        relational: F("</>/<=/>=", 7),
        bitShift: F("<</>>/>>>", 8),
        plusMin: new A("+/-", { beforeExpr: !0, binop: 9, prefix: !0, startsExpr: !0 }),
        modulo: F("%", 10),
        star: F("*", 10),
        slash: F("/", 10),
        starstar: new A("**", { beforeExpr: !0 }),
        coalesce: F("??", 1),
        _break: D("break"),
        _case: D("case", M),
        _catch: D("catch"),
        _continue: D("continue"),
        _debugger: D("debugger"),
        _default: D("default", M),
        _do: D("do", { isLoop: !0, beforeExpr: !0 }),
        _else: D("else", M),
        _finally: D("finally"),
        _for: D("for", { isLoop: !0 }),
        _function: D("function", j),
        _if: D("if"),
        _return: D("return", M),
        _switch: D("switch"),
        _throw: D("throw", M),
        _try: D("try"),
        _var: D("var"),
        _const: D("const"),
        _while: D("while", { isLoop: !0 }),
        _with: D("with"),
        _new: D("new", { beforeExpr: !0, startsExpr: !0 }),
        _this: D("this", j),
        _super: D("super", j),
        _class: D("class", j),
        _extends: D("extends", M),
        _export: D("export"),
        _import: D("import", j),
        _null: D("null", j),
        _true: D("true", j),
        _false: D("false", j),
        _in: D("in", { beforeExpr: !0, binop: 7 }),
        _instanceof: D("instanceof", { beforeExpr: !0, binop: 7 }),
        _typeof: D("typeof", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _void: D("void", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _delete: D("delete", { beforeExpr: !0, prefix: !0, startsExpr: !0 })
      }, U = /\r\n?|\n|\u2028|\u2029/, Z = new RegExp(U.source, "g");
      function he(o) {
        return o === 10 || o === 13 || o === 8232 || o === 8233;
      }
      l(he, "isNewLine");
      function te(o, d, m) {
        m === void 0 && (m = o.length);
        for (var g = d; g < m; g++) {
          var S = o.charCodeAt(g);
          if (he(S))
            return g < m - 1 && S === 13 && o.charCodeAt(g + 1) === 10 ? g + 2 : g + 1;
        }
        return -1;
      }
      l(te, "nextLineBreak");
      var Je = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/, Q = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g, ie = Object.prototype, ye = ie.hasOwnProperty, Ze = ie.toString, Te = Object.hasOwn || function(o, d) {
        return ye.call(o, d);
      }, st = Array.isArray || function(o) {
        return Ze.call(o) === "[object Array]";
      };
      function Ve(o) {
        return new RegExp("^(?:" + o.replace(/ /g, "|") + ")$");
      }
      l(Ve, "wordsRegexp");
      function fe(o) {
        return o <= 65535 ? String.fromCharCode(o) : (o -= 65536, String.fromCharCode((o >> 10) + 55296, (o & 1023) + 56320));
      }
      l(fe, "codePointToString");
      var Et = /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/, qt = /* @__PURE__ */ l(function(d, m) {
        this.line = d, this.column = m;
      }, "Position");
      qt.prototype.offset = /* @__PURE__ */ l(function(d) {
        return new qt(this.line, this.column + d);
      }, "offset");
      var ci = /* @__PURE__ */ l(function(d, m, g) {
        this.start = m, this.end = g, d.sourceFile !== null && (this.source = d.sourceFile);
      }, "SourceLocation");
      function un(o, d) {
        for (var m = 1, g = 0; ; ) {
          var S = te(o, g, d);
          if (S < 0)
            return new qt(m, d - g);
          ++m, g = S;
        }
      }
      l(un, "getLineInfo");
      var Lt = {
        ecmaVersion: null,
        sourceType: "script",
        onInsertedSemicolon: null,
        onTrailingComma: null,
        allowReserved: null,
        allowReturnOutsideFunction: !1,
        allowImportExportEverywhere: !1,
        allowAwaitOutsideFunction: null,
        allowSuperOutsideMethod: null,
        allowHashBang: !1,
        locations: !1,
        onToken: null,
        onComment: null,
        ranges: !1,
        program: null,
        sourceFile: null,
        directSourceFile: null,
        preserveParens: !1
      }, Ms = !1;
      function Bv(o) {
        var d = {};
        for (var m in Lt)
          d[m] = o && Te(o, m) ? o[m] : Lt[m];
        if (d.ecmaVersion === "latest" ? d.ecmaVersion = 1e8 : d.ecmaVersion == null ? (!Ms && typeof console == "object" && console.warn && (Ms = !0, console.warn(`Since Acorn 8.0.0, options.ecmaVersion is required.
Defaulting to 2020, but this will stop working in the future.`)), d.ecmaVersion = 11) : d.ecmaVersion >= 2015 && (d.ecmaVersion -= 2009), d.allowReserved == null && (d.allowReserved = d.ecmaVersion < 5), o.allowHashBang == null && (d.allowHashBang = d.ecmaVersion >= 14), st(d.onToken)) {
          var g = d.onToken;
          d.onToken = function(S) {
            return g.push(S);
          };
        }
        return st(d.onComment) && (d.onComment = Ov(d, d.onComment)), d;
      }
      l(Bv, "getOptions");
      function Ov(o, d) {
        return function(m, g, S, T, I, V) {
          var H = {
            type: m ? "Block" : "Line",
            value: g,
            start: S,
            end: T
          };
          o.locations && (H.loc = new ci(this, I, V)), o.ranges && (H.range = [S, T]), d.push(H);
        };
      }
      l(Ov, "pushComment");
      var Tr = 1, Ns = 2, Gu = 4, Fv = 8, Vv = 16, Uv = 32, qu = 64, jv = 128, xr = 256, Ku = Tr | Ns | xr;
      function fa(o, d) {
        return Ns | (o ? Gu : 0) | (d ? Fv : 0);
      }
      l(fa, "functionFlags");
      var ma = 0, zu = 1, $i = 2, Hv = 3, Wv = 4, $v = 5, Ye = /* @__PURE__ */ l(function(d, m, g) {
        this.options = d = Bv(d), this.sourceFile = d.sourceFile, this.keywords = Ve(h[d.ecmaVersion >= 6 ? 6 : d.sourceType === "module" ? "5module" : 5]);
        var S = "";
        d.allowReserved !== !0 && (S = u[d.ecmaVersion >= 6 ? 6 : d.ecmaVersion === 5 ? 5 : 3], d.sourceType === "module" && (S += " await")), this.reservedWords = Ve(S);
        var T = (S ? S + " " : "") + u.strict;
        this.reservedWordsStrict = Ve(T), this.reservedWordsStrictBind = Ve(T + " " + u.strictBind), this.input = String(m), this.containsEsc = !1, g ? (this.pos = g, this.lineStart = this.input.lastIndexOf(`
`, g - 1) + 1, this.curLine = this.input.slice(0, this.lineStart).split(U).length) : (this.pos = this.lineStart = 0, this.curLine = 1), this.type = v.eof, this.value = null, this.start = this.end = this.pos, this.startLoc = this.endLoc = this.curPosition(), this.lastTokEndLoc = this.lastTokStartLoc = null, this.lastTokStart = this.lastTokEnd = this.pos, this.context = this.initialContext(), this.exprAllowed = !0, this.inModule = d.sourceType === "module", this.strict = this.inModule || this.strictDirective(this.pos), this.potentialArrowAt = -1, this.potentialArrowInForAwait = !1, this.yieldPos = this.awaitPos = this.awaitIdentPos = 0, this.labels = [], this.undefinedExports = /* @__PURE__ */ Object.create(null), this.pos === 0 && d.allowHashBang && this.input.slice(0, 2) === "#!" && this.skipLineComment(2), this.scopeStack = [], this.enterScope(Tr), this.regexpState = null, this.privateNameStack = [];
      }, "Parser"), Si = { inFunction: { configurable: !0 }, inGenerator: { configurable: !0 }, inAsync: { configurable: !0 }, canAwait: { configurable: !0 }, allowSuper: { configurable: !0 }, allowDirectSuper: { configurable: !0 }, treatFunctionsAsVar: { configurable: !0 }, allowNewDotTarget: { configurable: !0 }, inClassStaticBlock: { configurable: !0 } };
      Ye.prototype.parse = /* @__PURE__ */ l(function() {
        var d = this.options.program || this.startNode();
        return this.nextToken(), this.parseTopLevel(d);
      }, "parse"), Si.inFunction.get = function() {
        return (this.currentVarScope().flags & Ns) > 0;
      }, Si.inGenerator.get = function() {
        return (this.currentVarScope().flags & Fv) > 0 && !this.currentVarScope().inClassFieldInit;
      }, Si.inAsync.get = function() {
        return (this.currentVarScope().flags & Gu) > 0 && !this.currentVarScope().inClassFieldInit;
      }, Si.canAwait.get = function() {
        for (var o = this.scopeStack.length - 1; o >= 0; o--) {
          var d = this.scopeStack[o];
          if (d.inClassFieldInit || d.flags & xr)
            return !1;
          if (d.flags & Ns)
            return (d.flags & Gu) > 0;
        }
        return this.inModule && this.options.ecmaVersion >= 13 || this.options.allowAwaitOutsideFunction;
      }, Si.allowSuper.get = function() {
        var o = this.currentThisScope(), d = o.flags, m = o.inClassFieldInit;
        return (d & qu) > 0 || m || this.options.allowSuperOutsideMethod;
      }, Si.allowDirectSuper.get = function() {
        return (this.currentThisScope().flags & jv) > 0;
      }, Si.treatFunctionsAsVar.get = function() {
        return this.treatFunctionsAsVarInScope(this.currentScope());
      }, Si.allowNewDotTarget.get = function() {
        var o = this.currentThisScope(), d = o.flags, m = o.inClassFieldInit;
        return (d & (Ns | xr)) > 0 || m;
      }, Si.inClassStaticBlock.get = function() {
        return (this.currentVarScope().flags & xr) > 0;
      }, Ye.extend = /* @__PURE__ */ l(function() {
        for (var d = [], m = arguments.length; m--; )
          d[m] = arguments[m];
        for (var g = this, S = 0; S < d.length; S++)
          g = d[S](g);
        return g;
      }, "extend"), Ye.parse = /* @__PURE__ */ l(function(d, m) {
        return new this(m, d).parse();
      }, "parse"), Ye.parseExpressionAt = /* @__PURE__ */ l(function(d, m, g) {
        var S = new this(g, d, m);
        return S.nextToken(), S.parseExpression();
      }, "parseExpressionAt"), Ye.tokenizer = /* @__PURE__ */ l(function(d, m) {
        return new this(m, d);
      }, "tokenizer"), Object.defineProperties(Ye.prototype, Si);
      var kt = Ye.prototype, Hw = /^(?:'((?:\\.|[^'\\])*?)'|"((?:\\.|[^"\\])*?)")/;
      kt.strictDirective = function(o) {
        if (this.options.ecmaVersion < 5)
          return !1;
        for (; ; ) {
          Q.lastIndex = o, o += Q.exec(this.input)[0].length;
          var d = Hw.exec(this.input.slice(o));
          if (!d)
            return !1;
          if ((d[1] || d[2]) === "use strict") {
            Q.lastIndex = o + d[0].length;
            var m = Q.exec(this.input), g = m.index + m[0].length, S = this.input.charAt(g);
            return S === ";" || S === "}" || U.test(m[0]) && !(/[(`.[+\-/*%<>=,?^&]/.test(S) || S === "!" && this.input.charAt(g + 1) === "=");
          }
          o += d[0].length, Q.lastIndex = o, o += Q.exec(this.input)[0].length, this.input[o] === ";" && o++;
        }
      }, kt.eat = function(o) {
        return this.type === o ? (this.next(), !0) : !1;
      }, kt.isContextual = function(o) {
        return this.type === v.name && this.value === o && !this.containsEsc;
      }, kt.eatContextual = function(o) {
        return this.isContextual(o) ? (this.next(), !0) : !1;
      }, kt.expectContextual = function(o) {
        this.eatContextual(o) || this.unexpected();
      }, kt.canInsertSemicolon = function() {
        return this.type === v.eof || this.type === v.braceR || U.test(this.input.slice(this.lastTokEnd, this.start));
      }, kt.insertSemicolon = function() {
        if (this.canInsertSemicolon())
          return this.options.onInsertedSemicolon && this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc), !0;
      }, kt.semicolon = function() {
        !this.eat(v.semi) && !this.insertSemicolon() && this.unexpected();
      }, kt.afterTrailingComma = function(o, d) {
        if (this.type === o)
          return this.options.onTrailingComma && this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc), d || this.next(), !0;
      }, kt.expect = function(o) {
        this.eat(o) || this.unexpected();
      }, kt.unexpected = function(o) {
        this.raise(o ?? this.start, "Unexpected token");
      };
      var va = /* @__PURE__ */ l(function() {
        this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = this.doubleProto = -1;
      }, "DestructuringErrors");
      kt.checkPatternErrors = function(o, d) {
        if (!!o) {
          o.trailingComma > -1 && this.raiseRecoverable(o.trailingComma, "Comma is not permitted after the rest element");
          var m = d ? o.parenthesizedAssign : o.parenthesizedBind;
          m > -1 && this.raiseRecoverable(m, d ? "Assigning to rvalue" : "Parenthesized pattern");
        }
      }, kt.checkExpressionErrors = function(o, d) {
        if (!o)
          return !1;
        var m = o.shorthandAssign, g = o.doubleProto;
        if (!d)
          return m >= 0 || g >= 0;
        m >= 0 && this.raise(m, "Shorthand property assignments are valid only in destructuring patterns"), g >= 0 && this.raiseRecoverable(g, "Redefinition of __proto__ property");
      }, kt.checkYieldAwaitInDefaultParams = function() {
        this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos) && this.raise(this.yieldPos, "Yield expression cannot be a default value"), this.awaitPos && this.raise(this.awaitPos, "Await expression cannot be a default value");
      }, kt.isSimpleAssignTarget = function(o) {
        return o.type === "ParenthesizedExpression" ? this.isSimpleAssignTarget(o.expression) : o.type === "Identifier" || o.type === "MemberExpression";
      };
      var ne = Ye.prototype;
      ne.parseTopLevel = function(o) {
        var d = /* @__PURE__ */ Object.create(null);
        for (o.body || (o.body = []); this.type !== v.eof; ) {
          var m = this.parseStatement(null, !0, d);
          o.body.push(m);
        }
        if (this.inModule)
          for (var g = 0, S = Object.keys(this.undefinedExports); g < S.length; g += 1) {
            var T = S[g];
            this.raiseRecoverable(this.undefinedExports[T].start, "Export '" + T + "' is not defined");
          }
        return this.adaptDirectivePrologue(o.body), this.next(), o.sourceType = this.options.sourceType, this.finishNode(o, "Program");
      };
      var Yu = { kind: "loop" }, Ww = { kind: "switch" };
      ne.isLet = function(o) {
        if (this.options.ecmaVersion < 6 || !this.isContextual("let"))
          return !1;
        Q.lastIndex = this.pos;
        var d = Q.exec(this.input), m = this.pos + d[0].length, g = this.input.charCodeAt(m);
        if (g === 91 || g === 92 || g > 55295 && g < 56320)
          return !0;
        if (o)
          return !1;
        if (g === 123)
          return !0;
        if (E(g, !0)) {
          for (var S = m + 1; P(g = this.input.charCodeAt(S), !0); )
            ++S;
          if (g === 92 || g > 55295 && g < 56320)
            return !0;
          var T = this.input.slice(m, S);
          if (!p.test(T))
            return !0;
        }
        return !1;
      }, ne.isAsyncFunction = function() {
        if (this.options.ecmaVersion < 8 || !this.isContextual("async"))
          return !1;
        Q.lastIndex = this.pos;
        var o = Q.exec(this.input), d = this.pos + o[0].length, m;
        return !U.test(this.input.slice(this.pos, d)) && this.input.slice(d, d + 8) === "function" && (d + 8 === this.input.length || !(P(m = this.input.charCodeAt(d + 8)) || m > 55295 && m < 56320));
      }, ne.parseStatement = function(o, d, m) {
        var g = this.type, S = this.startNode(), T;
        switch (this.isLet(o) && (g = v._var, T = "let"), g) {
          case v._break:
          case v._continue:
            return this.parseBreakContinueStatement(S, g.keyword);
          case v._debugger:
            return this.parseDebuggerStatement(S);
          case v._do:
            return this.parseDoStatement(S);
          case v._for:
            return this.parseForStatement(S);
          case v._function:
            return o && (this.strict || o !== "if" && o !== "label") && this.options.ecmaVersion >= 6 && this.unexpected(), this.parseFunctionStatement(S, !1, !o);
          case v._class:
            return o && this.unexpected(), this.parseClass(S, !0);
          case v._if:
            return this.parseIfStatement(S);
          case v._return:
            return this.parseReturnStatement(S);
          case v._switch:
            return this.parseSwitchStatement(S);
          case v._throw:
            return this.parseThrowStatement(S);
          case v._try:
            return this.parseTryStatement(S);
          case v._const:
          case v._var:
            return T = T || this.value, o && T !== "var" && this.unexpected(), this.parseVarStatement(S, T);
          case v._while:
            return this.parseWhileStatement(S);
          case v._with:
            return this.parseWithStatement(S);
          case v.braceL:
            return this.parseBlock(!0, S);
          case v.semi:
            return this.parseEmptyStatement(S);
          case v._export:
          case v._import:
            if (this.options.ecmaVersion > 10 && g === v._import) {
              Q.lastIndex = this.pos;
              var I = Q.exec(this.input), V = this.pos + I[0].length, H = this.input.charCodeAt(V);
              if (H === 40 || H === 46)
                return this.parseExpressionStatement(S, this.parseExpression());
            }
            return this.options.allowImportExportEverywhere || (d || this.raise(this.start, "'import' and 'export' may only appear at the top level"), this.inModule || this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'")), g === v._import ? this.parseImport(S) : this.parseExport(S, m);
          default:
            if (this.isAsyncFunction())
              return o && this.unexpected(), this.next(), this.parseFunctionStatement(S, !0, !o);
            var pe = this.value, _e = this.parseExpression();
            return g === v.name && _e.type === "Identifier" && this.eat(v.colon) ? this.parseLabeledStatement(S, pe, _e, o) : this.parseExpressionStatement(S, _e);
        }
      }, ne.parseBreakContinueStatement = function(o, d) {
        var m = d === "break";
        this.next(), this.eat(v.semi) || this.insertSemicolon() ? o.label = null : this.type !== v.name ? this.unexpected() : (o.label = this.parseIdent(), this.semicolon());
        for (var g = 0; g < this.labels.length; ++g) {
          var S = this.labels[g];
          if ((o.label == null || S.name === o.label.name) && (S.kind != null && (m || S.kind === "loop") || o.label && m))
            break;
        }
        return g === this.labels.length && this.raise(o.start, "Unsyntactic " + d), this.finishNode(o, m ? "BreakStatement" : "ContinueStatement");
      }, ne.parseDebuggerStatement = function(o) {
        return this.next(), this.semicolon(), this.finishNode(o, "DebuggerStatement");
      }, ne.parseDoStatement = function(o) {
        return this.next(), this.labels.push(Yu), o.body = this.parseStatement("do"), this.labels.pop(), this.expect(v._while), o.test = this.parseParenExpression(), this.options.ecmaVersion >= 6 ? this.eat(v.semi) : this.semicolon(), this.finishNode(o, "DoWhileStatement");
      }, ne.parseForStatement = function(o) {
        this.next();
        var d = this.options.ecmaVersion >= 9 && this.canAwait && this.eatContextual("await") ? this.lastTokStart : -1;
        if (this.labels.push(Yu), this.enterScope(0), this.expect(v.parenL), this.type === v.semi)
          return d > -1 && this.unexpected(d), this.parseFor(o, null);
        var m = this.isLet();
        if (this.type === v._var || this.type === v._const || m) {
          var g = this.startNode(), S = m ? "let" : this.value;
          return this.next(), this.parseVar(g, !0, S), this.finishNode(g, "VariableDeclaration"), (this.type === v._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) && g.declarations.length === 1 ? (this.options.ecmaVersion >= 9 && (this.type === v._in ? d > -1 && this.unexpected(d) : o.await = d > -1), this.parseForIn(o, g)) : (d > -1 && this.unexpected(d), this.parseFor(o, g));
        }
        var T = this.isContextual("let"), I = !1, V = new va(), H = this.parseExpression(d > -1 ? "await" : !0, V);
        return this.type === v._in || (I = this.options.ecmaVersion >= 6 && this.isContextual("of")) ? (this.options.ecmaVersion >= 9 && (this.type === v._in ? d > -1 && this.unexpected(d) : o.await = d > -1), T && I && this.raise(H.start, "The left-hand side of a for-of loop may not start with 'let'."), this.toAssignable(H, !1, V), this.checkLValPattern(H), this.parseForIn(o, H)) : (this.checkExpressionErrors(V, !0), d > -1 && this.unexpected(d), this.parseFor(o, H));
      }, ne.parseFunctionStatement = function(o, d, m) {
        return this.next(), this.parseFunction(o, Er | (m ? 0 : Xu), !1, d);
      }, ne.parseIfStatement = function(o) {
        return this.next(), o.test = this.parseParenExpression(), o.consequent = this.parseStatement("if"), o.alternate = this.eat(v._else) ? this.parseStatement("if") : null, this.finishNode(o, "IfStatement");
      }, ne.parseReturnStatement = function(o) {
        return !this.inFunction && !this.options.allowReturnOutsideFunction && this.raise(this.start, "'return' outside of function"), this.next(), this.eat(v.semi) || this.insertSemicolon() ? o.argument = null : (o.argument = this.parseExpression(), this.semicolon()), this.finishNode(o, "ReturnStatement");
      }, ne.parseSwitchStatement = function(o) {
        this.next(), o.discriminant = this.parseParenExpression(), o.cases = [], this.expect(v.braceL), this.labels.push(Ww), this.enterScope(0);
        for (var d, m = !1; this.type !== v.braceR; )
          if (this.type === v._case || this.type === v._default) {
            var g = this.type === v._case;
            d && this.finishNode(d, "SwitchCase"), o.cases.push(d = this.startNode()), d.consequent = [], this.next(), g ? d.test = this.parseExpression() : (m && this.raiseRecoverable(this.lastTokStart, "Multiple default clauses"), m = !0, d.test = null), this.expect(v.colon);
          } else
            d || this.unexpected(), d.consequent.push(this.parseStatement(null));
        return this.exitScope(), d && this.finishNode(d, "SwitchCase"), this.next(), this.labels.pop(), this.finishNode(o, "SwitchStatement");
      }, ne.parseThrowStatement = function(o) {
        return this.next(), U.test(this.input.slice(this.lastTokEnd, this.start)) && this.raise(this.lastTokEnd, "Illegal newline after throw"), o.argument = this.parseExpression(), this.semicolon(), this.finishNode(o, "ThrowStatement");
      };
      var $w = [];
      ne.parseTryStatement = function(o) {
        if (this.next(), o.block = this.parseBlock(), o.handler = null, this.type === v._catch) {
          var d = this.startNode();
          if (this.next(), this.eat(v.parenL)) {
            d.param = this.parseBindingAtom();
            var m = d.param.type === "Identifier";
            this.enterScope(m ? Uv : 0), this.checkLValPattern(d.param, m ? Wv : $i), this.expect(v.parenR);
          } else
            this.options.ecmaVersion < 10 && this.unexpected(), d.param = null, this.enterScope(0);
          d.body = this.parseBlock(!1), this.exitScope(), o.handler = this.finishNode(d, "CatchClause");
        }
        return o.finalizer = this.eat(v._finally) ? this.parseBlock() : null, !o.handler && !o.finalizer && this.raise(o.start, "Missing catch or finally clause"), this.finishNode(o, "TryStatement");
      }, ne.parseVarStatement = function(o, d) {
        return this.next(), this.parseVar(o, !1, d), this.semicolon(), this.finishNode(o, "VariableDeclaration");
      }, ne.parseWhileStatement = function(o) {
        return this.next(), o.test = this.parseParenExpression(), this.labels.push(Yu), o.body = this.parseStatement("while"), this.labels.pop(), this.finishNode(o, "WhileStatement");
      }, ne.parseWithStatement = function(o) {
        return this.strict && this.raise(this.start, "'with' in strict mode"), this.next(), o.object = this.parseParenExpression(), o.body = this.parseStatement("with"), this.finishNode(o, "WithStatement");
      }, ne.parseEmptyStatement = function(o) {
        return this.next(), this.finishNode(o, "EmptyStatement");
      }, ne.parseLabeledStatement = function(o, d, m, g) {
        for (var S = 0, T = this.labels; S < T.length; S += 1) {
          var I = T[S];
          I.name === d && this.raise(m.start, "Label '" + d + "' is already declared");
        }
        for (var V = this.type.isLoop ? "loop" : this.type === v._switch ? "switch" : null, H = this.labels.length - 1; H >= 0; H--) {
          var pe = this.labels[H];
          if (pe.statementStart === o.start)
            pe.statementStart = this.start, pe.kind = V;
          else
            break;
        }
        return this.labels.push({ name: d, kind: V, statementStart: this.start }), o.body = this.parseStatement(g ? g.indexOf("label") === -1 ? g + "label" : g : "label"), this.labels.pop(), o.label = m, this.finishNode(o, "LabeledStatement");
      }, ne.parseExpressionStatement = function(o, d) {
        return o.expression = d, this.semicolon(), this.finishNode(o, "ExpressionStatement");
      }, ne.parseBlock = function(o, d, m) {
        for (o === void 0 && (o = !0), d === void 0 && (d = this.startNode()), d.body = [], this.expect(v.braceL), o && this.enterScope(0); this.type !== v.braceR; ) {
          var g = this.parseStatement(null);
          d.body.push(g);
        }
        return m && (this.strict = !1), this.next(), o && this.exitScope(), this.finishNode(d, "BlockStatement");
      }, ne.parseFor = function(o, d) {
        return o.init = d, this.expect(v.semi), o.test = this.type === v.semi ? null : this.parseExpression(), this.expect(v.semi), o.update = this.type === v.parenR ? null : this.parseExpression(), this.expect(v.parenR), o.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(o, "ForStatement");
      }, ne.parseForIn = function(o, d) {
        var m = this.type === v._in;
        return this.next(), d.type === "VariableDeclaration" && d.declarations[0].init != null && (!m || this.options.ecmaVersion < 8 || this.strict || d.kind !== "var" || d.declarations[0].id.type !== "Identifier") && this.raise(d.start, (m ? "for-in" : "for-of") + " loop variable declaration may not have an initializer"), o.left = d, o.right = m ? this.parseExpression() : this.parseMaybeAssign(), this.expect(v.parenR), o.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(o, m ? "ForInStatement" : "ForOfStatement");
      }, ne.parseVar = function(o, d, m) {
        for (o.declarations = [], o.kind = m; ; ) {
          var g = this.startNode();
          if (this.parseVarId(g, m), this.eat(v.eq) ? g.init = this.parseMaybeAssign(d) : m === "const" && !(this.type === v._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) ? this.unexpected() : g.id.type !== "Identifier" && !(d && (this.type === v._in || this.isContextual("of"))) ? this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value") : g.init = null, o.declarations.push(this.finishNode(g, "VariableDeclarator")), !this.eat(v.comma))
            break;
        }
        return o;
      }, ne.parseVarId = function(o, d) {
        o.id = this.parseBindingAtom(), this.checkLValPattern(o.id, d === "var" ? zu : $i, !1);
      };
      var Er = 1, Xu = 2, Gv = 4;
      ne.parseFunction = function(o, d, m, g, S) {
        this.initFunction(o), (this.options.ecmaVersion >= 9 || this.options.ecmaVersion >= 6 && !g) && (this.type === v.star && d & Xu && this.unexpected(), o.generator = this.eat(v.star)), this.options.ecmaVersion >= 8 && (o.async = !!g), d & Er && (o.id = d & Gv && this.type !== v.name ? null : this.parseIdent(), o.id && !(d & Xu) && this.checkLValSimple(o.id, this.strict || o.generator || o.async ? this.treatFunctionsAsVar ? zu : $i : Hv));
        var T = this.yieldPos, I = this.awaitPos, V = this.awaitIdentPos;
        return this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(fa(o.async, o.generator)), d & Er || (o.id = this.type === v.name ? this.parseIdent() : null), this.parseFunctionParams(o), this.parseFunctionBody(o, m, !1, S), this.yieldPos = T, this.awaitPos = I, this.awaitIdentPos = V, this.finishNode(o, d & Er ? "FunctionDeclaration" : "FunctionExpression");
      }, ne.parseFunctionParams = function(o) {
        this.expect(v.parenL), o.params = this.parseBindingList(v.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams();
      }, ne.parseClass = function(o, d) {
        this.next();
        var m = this.strict;
        this.strict = !0, this.parseClassId(o, d), this.parseClassSuper(o);
        var g = this.enterClassBody(), S = this.startNode(), T = !1;
        for (S.body = [], this.expect(v.braceL); this.type !== v.braceR; ) {
          var I = this.parseClassElement(o.superClass !== null);
          I && (S.body.push(I), I.type === "MethodDefinition" && I.kind === "constructor" ? (T && this.raise(I.start, "Duplicate constructor in the same class"), T = !0) : I.key && I.key.type === "PrivateIdentifier" && qv(g, I) && this.raiseRecoverable(I.key.start, "Identifier '#" + I.key.name + "' has already been declared"));
        }
        return this.strict = m, this.next(), o.body = this.finishNode(S, "ClassBody"), this.exitClassBody(), this.finishNode(o, d ? "ClassDeclaration" : "ClassExpression");
      }, ne.parseClassElement = function(o) {
        if (this.eat(v.semi))
          return null;
        var d = this.options.ecmaVersion, m = this.startNode(), g = "", S = !1, T = !1, I = "method", V = !1;
        if (this.eatContextual("static")) {
          if (d >= 13 && this.eat(v.braceL))
            return this.parseClassStaticBlock(m), m;
          this.isClassElementNameStart() || this.type === v.star ? V = !0 : g = "static";
        }
        if (m.static = V, !g && d >= 8 && this.eatContextual("async") && ((this.isClassElementNameStart() || this.type === v.star) && !this.canInsertSemicolon() ? T = !0 : g = "async"), !g && (d >= 9 || !T) && this.eat(v.star) && (S = !0), !g && !T && !S) {
          var H = this.value;
          (this.eatContextual("get") || this.eatContextual("set")) && (this.isClassElementNameStart() ? I = H : g = H);
        }
        if (g ? (m.computed = !1, m.key = this.startNodeAt(this.lastTokStart, this.lastTokStartLoc), m.key.name = g, this.finishNode(m.key, "Identifier")) : this.parseClassElementName(m), d < 13 || this.type === v.parenL || I !== "method" || S || T) {
          var pe = !m.static && kr(m, "constructor"), _e = pe && o;
          pe && I !== "method" && this.raise(m.key.start, "Constructor can't have get/set modifier"), m.kind = pe ? "constructor" : I, this.parseClassMethod(m, S, T, _e);
        } else
          this.parseClassField(m);
        return m;
      }, ne.isClassElementNameStart = function() {
        return this.type === v.name || this.type === v.privateId || this.type === v.num || this.type === v.string || this.type === v.bracketL || this.type.keyword;
      }, ne.parseClassElementName = function(o) {
        this.type === v.privateId ? (this.value === "constructor" && this.raise(this.start, "Classes can't have an element named '#constructor'"), o.computed = !1, o.key = this.parsePrivateIdent()) : this.parsePropertyName(o);
      }, ne.parseClassMethod = function(o, d, m, g) {
        var S = o.key;
        o.kind === "constructor" ? (d && this.raise(S.start, "Constructor can't be a generator"), m && this.raise(S.start, "Constructor can't be an async method")) : o.static && kr(o, "prototype") && this.raise(S.start, "Classes may not have a static property named prototype");
        var T = o.value = this.parseMethod(d, m, g);
        return o.kind === "get" && T.params.length !== 0 && this.raiseRecoverable(T.start, "getter should have no params"), o.kind === "set" && T.params.length !== 1 && this.raiseRecoverable(T.start, "setter should have exactly one param"), o.kind === "set" && T.params[0].type === "RestElement" && this.raiseRecoverable(T.params[0].start, "Setter cannot use rest params"), this.finishNode(o, "MethodDefinition");
      }, ne.parseClassField = function(o) {
        if (kr(o, "constructor") ? this.raise(o.key.start, "Classes can't have a field named 'constructor'") : o.static && kr(o, "prototype") && this.raise(o.key.start, "Classes can't have a static field named 'prototype'"), this.eat(v.eq)) {
          var d = this.currentThisScope(), m = d.inClassFieldInit;
          d.inClassFieldInit = !0, o.value = this.parseMaybeAssign(), d.inClassFieldInit = m;
        } else
          o.value = null;
        return this.semicolon(), this.finishNode(o, "PropertyDefinition");
      }, ne.parseClassStaticBlock = function(o) {
        o.body = [];
        var d = this.labels;
        for (this.labels = [], this.enterScope(xr | qu); this.type !== v.braceR; ) {
          var m = this.parseStatement(null);
          o.body.push(m);
        }
        return this.next(), this.exitScope(), this.labels = d, this.finishNode(o, "StaticBlock");
      }, ne.parseClassId = function(o, d) {
        this.type === v.name ? (o.id = this.parseIdent(), d && this.checkLValSimple(o.id, $i, !1)) : (d === !0 && this.unexpected(), o.id = null);
      }, ne.parseClassSuper = function(o) {
        o.superClass = this.eat(v._extends) ? this.parseExprSubscripts(!1) : null;
      }, ne.enterClassBody = function() {
        var o = { declared: /* @__PURE__ */ Object.create(null), used: [] };
        return this.privateNameStack.push(o), o.declared;
      }, ne.exitClassBody = function() {
        for (var o = this.privateNameStack.pop(), d = o.declared, m = o.used, g = this.privateNameStack.length, S = g === 0 ? null : this.privateNameStack[g - 1], T = 0; T < m.length; ++T) {
          var I = m[T];
          Te(d, I.name) || (S ? S.used.push(I) : this.raiseRecoverable(I.start, "Private field '#" + I.name + "' must be declared in an enclosing class"));
        }
      };
      function qv(o, d) {
        var m = d.key.name, g = o[m], S = "true";
        return d.type === "MethodDefinition" && (d.kind === "get" || d.kind === "set") && (S = (d.static ? "s" : "i") + d.kind), g === "iget" && S === "iset" || g === "iset" && S === "iget" || g === "sget" && S === "sset" || g === "sset" && S === "sget" ? (o[m] = "true", !1) : g ? !0 : (o[m] = S, !1);
      }
      l(qv, "isPrivateNameConflicted");
      function kr(o, d) {
        var m = o.computed, g = o.key;
        return !m && (g.type === "Identifier" && g.name === d || g.type === "Literal" && g.value === d);
      }
      l(kr, "checkKeyName"), ne.parseExport = function(o, d) {
        if (this.next(), this.eat(v.star))
          return this.options.ecmaVersion >= 11 && (this.eatContextual("as") ? (o.exported = this.parseModuleExportName(), this.checkExport(d, o.exported, this.lastTokStart)) : o.exported = null), this.expectContextual("from"), this.type !== v.string && this.unexpected(), o.source = this.parseExprAtom(), this.semicolon(), this.finishNode(o, "ExportAllDeclaration");
        if (this.eat(v._default)) {
          this.checkExport(d, "default", this.lastTokStart);
          var m;
          if (this.type === v._function || (m = this.isAsyncFunction())) {
            var g = this.startNode();
            this.next(), m && this.next(), o.declaration = this.parseFunction(g, Er | Gv, !1, m);
          } else if (this.type === v._class) {
            var S = this.startNode();
            o.declaration = this.parseClass(S, "nullableID");
          } else
            o.declaration = this.parseMaybeAssign(), this.semicolon();
          return this.finishNode(o, "ExportDefaultDeclaration");
        }
        if (this.shouldParseExportStatement())
          o.declaration = this.parseStatement(null), o.declaration.type === "VariableDeclaration" ? this.checkVariableExport(d, o.declaration.declarations) : this.checkExport(d, o.declaration.id, o.declaration.id.start), o.specifiers = [], o.source = null;
        else {
          if (o.declaration = null, o.specifiers = this.parseExportSpecifiers(d), this.eatContextual("from"))
            this.type !== v.string && this.unexpected(), o.source = this.parseExprAtom();
          else {
            for (var T = 0, I = o.specifiers; T < I.length; T += 1) {
              var V = I[T];
              this.checkUnreserved(V.local), this.checkLocalExport(V.local), V.local.type === "Literal" && this.raise(V.local.start, "A string literal cannot be used as an exported binding without `from`.");
            }
            o.source = null;
          }
          this.semicolon();
        }
        return this.finishNode(o, "ExportNamedDeclaration");
      }, ne.checkExport = function(o, d, m) {
        !o || (typeof d != "string" && (d = d.type === "Identifier" ? d.name : d.value), Te(o, d) && this.raiseRecoverable(m, "Duplicate export '" + d + "'"), o[d] = !0);
      }, ne.checkPatternExport = function(o, d) {
        var m = d.type;
        if (m === "Identifier")
          this.checkExport(o, d, d.start);
        else if (m === "ObjectPattern")
          for (var g = 0, S = d.properties; g < S.length; g += 1) {
            var T = S[g];
            this.checkPatternExport(o, T);
          }
        else if (m === "ArrayPattern")
          for (var I = 0, V = d.elements; I < V.length; I += 1) {
            var H = V[I];
            H && this.checkPatternExport(o, H);
          }
        else
          m === "Property" ? this.checkPatternExport(o, d.value) : m === "AssignmentPattern" ? this.checkPatternExport(o, d.left) : m === "RestElement" ? this.checkPatternExport(o, d.argument) : m === "ParenthesizedExpression" && this.checkPatternExport(o, d.expression);
      }, ne.checkVariableExport = function(o, d) {
        if (!!o)
          for (var m = 0, g = d; m < g.length; m += 1) {
            var S = g[m];
            this.checkPatternExport(o, S.id);
          }
      }, ne.shouldParseExportStatement = function() {
        return this.type.keyword === "var" || this.type.keyword === "const" || this.type.keyword === "class" || this.type.keyword === "function" || this.isLet() || this.isAsyncFunction();
      }, ne.parseExportSpecifiers = function(o) {
        var d = [], m = !0;
        for (this.expect(v.braceL); !this.eat(v.braceR); ) {
          if (m)
            m = !1;
          else if (this.expect(v.comma), this.afterTrailingComma(v.braceR))
            break;
          var g = this.startNode();
          g.local = this.parseModuleExportName(), g.exported = this.eatContextual("as") ? this.parseModuleExportName() : g.local, this.checkExport(o, g.exported, g.exported.start), d.push(this.finishNode(g, "ExportSpecifier"));
        }
        return d;
      }, ne.parseImport = function(o) {
        return this.next(), this.type === v.string ? (o.specifiers = $w, o.source = this.parseExprAtom()) : (o.specifiers = this.parseImportSpecifiers(), this.expectContextual("from"), o.source = this.type === v.string ? this.parseExprAtom() : this.unexpected()), this.semicolon(), this.finishNode(o, "ImportDeclaration");
      }, ne.parseImportSpecifiers = function() {
        var o = [], d = !0;
        if (this.type === v.name) {
          var m = this.startNode();
          if (m.local = this.parseIdent(), this.checkLValSimple(m.local, $i), o.push(this.finishNode(m, "ImportDefaultSpecifier")), !this.eat(v.comma))
            return o;
        }
        if (this.type === v.star) {
          var g = this.startNode();
          return this.next(), this.expectContextual("as"), g.local = this.parseIdent(), this.checkLValSimple(g.local, $i), o.push(this.finishNode(g, "ImportNamespaceSpecifier")), o;
        }
        for (this.expect(v.braceL); !this.eat(v.braceR); ) {
          if (d)
            d = !1;
          else if (this.expect(v.comma), this.afterTrailingComma(v.braceR))
            break;
          var S = this.startNode();
          S.imported = this.parseModuleExportName(), this.eatContextual("as") ? S.local = this.parseIdent() : (this.checkUnreserved(S.imported), S.local = S.imported), this.checkLValSimple(S.local, $i), o.push(this.finishNode(S, "ImportSpecifier"));
        }
        return o;
      }, ne.parseModuleExportName = function() {
        if (this.options.ecmaVersion >= 13 && this.type === v.string) {
          var o = this.parseLiteral(this.value);
          return Et.test(o.value) && this.raise(o.start, "An export name cannot include a lone surrogate."), o;
        }
        return this.parseIdent(!0);
      }, ne.adaptDirectivePrologue = function(o) {
        for (var d = 0; d < o.length && this.isDirectiveCandidate(o[d]); ++d)
          o[d].directive = o[d].expression.raw.slice(1, -1);
      }, ne.isDirectiveCandidate = function(o) {
        return this.options.ecmaVersion >= 5 && o.type === "ExpressionStatement" && o.expression.type === "Literal" && typeof o.expression.value == "string" && (this.input[o.start] === '"' || this.input[o.start] === "'");
      };
      var hi = Ye.prototype;
      hi.toAssignable = function(o, d, m) {
        if (this.options.ecmaVersion >= 6 && o)
          switch (o.type) {
            case "Identifier":
              this.inAsync && o.name === "await" && this.raise(o.start, "Cannot use 'await' as identifier inside an async function");
              break;
            case "ObjectPattern":
            case "ArrayPattern":
            case "AssignmentPattern":
            case "RestElement":
              break;
            case "ObjectExpression":
              o.type = "ObjectPattern", m && this.checkPatternErrors(m, !0);
              for (var g = 0, S = o.properties; g < S.length; g += 1) {
                var T = S[g];
                this.toAssignable(T, d), T.type === "RestElement" && (T.argument.type === "ArrayPattern" || T.argument.type === "ObjectPattern") && this.raise(T.argument.start, "Unexpected token");
              }
              break;
            case "Property":
              o.kind !== "init" && this.raise(o.key.start, "Object pattern can't contain getter or setter"), this.toAssignable(o.value, d);
              break;
            case "ArrayExpression":
              o.type = "ArrayPattern", m && this.checkPatternErrors(m, !0), this.toAssignableList(o.elements, d);
              break;
            case "SpreadElement":
              o.type = "RestElement", this.toAssignable(o.argument, d), o.argument.type === "AssignmentPattern" && this.raise(o.argument.start, "Rest elements cannot have a default value");
              break;
            case "AssignmentExpression":
              o.operator !== "=" && this.raise(o.left.end, "Only '=' operator can be used for specifying default value."), o.type = "AssignmentPattern", delete o.operator, this.toAssignable(o.left, d);
              break;
            case "ParenthesizedExpression":
              this.toAssignable(o.expression, d, m);
              break;
            case "ChainExpression":
              this.raiseRecoverable(o.start, "Optional chaining cannot appear in left-hand side");
              break;
            case "MemberExpression":
              if (!d)
                break;
            default:
              this.raise(o.start, "Assigning to rvalue");
          }
        else
          m && this.checkPatternErrors(m, !0);
        return o;
      }, hi.toAssignableList = function(o, d) {
        for (var m = o.length, g = 0; g < m; g++) {
          var S = o[g];
          S && this.toAssignable(S, d);
        }
        if (m) {
          var T = o[m - 1];
          this.options.ecmaVersion === 6 && d && T && T.type === "RestElement" && T.argument.type !== "Identifier" && this.unexpected(T.argument.start);
        }
        return o;
      }, hi.parseSpread = function(o) {
        var d = this.startNode();
        return this.next(), d.argument = this.parseMaybeAssign(!1, o), this.finishNode(d, "SpreadElement");
      }, hi.parseRestBinding = function() {
        var o = this.startNode();
        return this.next(), this.options.ecmaVersion === 6 && this.type !== v.name && this.unexpected(), o.argument = this.parseBindingAtom(), this.finishNode(o, "RestElement");
      }, hi.parseBindingAtom = function() {
        if (this.options.ecmaVersion >= 6)
          switch (this.type) {
            case v.bracketL:
              var o = this.startNode();
              return this.next(), o.elements = this.parseBindingList(v.bracketR, !0, !0), this.finishNode(o, "ArrayPattern");
            case v.braceL:
              return this.parseObj(!0);
          }
        return this.parseIdent();
      }, hi.parseBindingList = function(o, d, m) {
        for (var g = [], S = !0; !this.eat(o); )
          if (S ? S = !1 : this.expect(v.comma), d && this.type === v.comma)
            g.push(null);
          else {
            if (m && this.afterTrailingComma(o))
              break;
            if (this.type === v.ellipsis) {
              var T = this.parseRestBinding();
              this.parseBindingListItem(T), g.push(T), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element"), this.expect(o);
              break;
            } else {
              var I = this.parseMaybeDefault(this.start, this.startLoc);
              this.parseBindingListItem(I), g.push(I);
            }
          }
        return g;
      }, hi.parseBindingListItem = function(o) {
        return o;
      }, hi.parseMaybeDefault = function(o, d, m) {
        if (m = m || this.parseBindingAtom(), this.options.ecmaVersion < 6 || !this.eat(v.eq))
          return m;
        var g = this.startNodeAt(o, d);
        return g.left = m, g.right = this.parseMaybeAssign(), this.finishNode(g, "AssignmentPattern");
      }, hi.checkLValSimple = function(o, d, m) {
        d === void 0 && (d = ma);
        var g = d !== ma;
        switch (o.type) {
          case "Identifier":
            this.strict && this.reservedWordsStrictBind.test(o.name) && this.raiseRecoverable(o.start, (g ? "Binding " : "Assigning to ") + o.name + " in strict mode"), g && (d === $i && o.name === "let" && this.raiseRecoverable(o.start, "let is disallowed as a lexically bound name"), m && (Te(m, o.name) && this.raiseRecoverable(o.start, "Argument name clash"), m[o.name] = !0), d !== $v && this.declareName(o.name, d, o.start));
            break;
          case "ChainExpression":
            this.raiseRecoverable(o.start, "Optional chaining cannot appear in left-hand side");
            break;
          case "MemberExpression":
            g && this.raiseRecoverable(o.start, "Binding member expression");
            break;
          case "ParenthesizedExpression":
            return g && this.raiseRecoverable(o.start, "Binding parenthesized expression"), this.checkLValSimple(o.expression, d, m);
          default:
            this.raise(o.start, (g ? "Binding" : "Assigning to") + " rvalue");
        }
      }, hi.checkLValPattern = function(o, d, m) {
        switch (d === void 0 && (d = ma), o.type) {
          case "ObjectPattern":
            for (var g = 0, S = o.properties; g < S.length; g += 1) {
              var T = S[g];
              this.checkLValInnerPattern(T, d, m);
            }
            break;
          case "ArrayPattern":
            for (var I = 0, V = o.elements; I < V.length; I += 1) {
              var H = V[I];
              H && this.checkLValInnerPattern(H, d, m);
            }
            break;
          default:
            this.checkLValSimple(o, d, m);
        }
      }, hi.checkLValInnerPattern = function(o, d, m) {
        switch (d === void 0 && (d = ma), o.type) {
          case "Property":
            this.checkLValInnerPattern(o.value, d, m);
            break;
          case "AssignmentPattern":
            this.checkLValPattern(o.left, d, m);
            break;
          case "RestElement":
            this.checkLValPattern(o.argument, d, m);
            break;
          default:
            this.checkLValPattern(o, d, m);
        }
      };
      var ni = /* @__PURE__ */ l(function(d, m, g, S, T) {
        this.token = d, this.isExpr = !!m, this.preserveSpace = !!g, this.override = S, this.generator = !!T;
      }, "TokContext"), We = {
        b_stat: new ni("{", !1),
        b_expr: new ni("{", !0),
        b_tmpl: new ni("${", !1),
        p_stat: new ni("(", !1),
        p_expr: new ni("(", !0),
        q_tmpl: new ni("`", !0, !0, function(o) {
          return o.tryReadTemplateToken();
        }),
        f_stat: new ni("function", !1),
        f_expr: new ni("function", !0),
        f_expr_gen: new ni("function", !0, !1, null, !0),
        f_gen: new ni("function", !1, !1, null, !0)
      }, Rs = Ye.prototype;
      Rs.initialContext = function() {
        return [We.b_stat];
      }, Rs.curContext = function() {
        return this.context[this.context.length - 1];
      }, Rs.braceIsBlock = function(o) {
        var d = this.curContext();
        return d === We.f_expr || d === We.f_stat ? !0 : o === v.colon && (d === We.b_stat || d === We.b_expr) ? !d.isExpr : o === v._return || o === v.name && this.exprAllowed ? U.test(this.input.slice(this.lastTokEnd, this.start)) : o === v._else || o === v.semi || o === v.eof || o === v.parenR || o === v.arrow ? !0 : o === v.braceL ? d === We.b_stat : o === v._var || o === v._const || o === v.name ? !1 : !this.exprAllowed;
      }, Rs.inGeneratorContext = function() {
        for (var o = this.context.length - 1; o >= 1; o--) {
          var d = this.context[o];
          if (d.token === "function")
            return d.generator;
        }
        return !1;
      }, Rs.updateContext = function(o) {
        var d, m = this.type;
        m.keyword && o === v.dot ? this.exprAllowed = !1 : (d = m.updateContext) ? d.call(this, o) : this.exprAllowed = m.beforeExpr;
      }, Rs.overrideContext = function(o) {
        this.curContext() !== o && (this.context[this.context.length - 1] = o);
      }, v.parenR.updateContext = v.braceR.updateContext = function() {
        if (this.context.length === 1) {
          this.exprAllowed = !0;
          return;
        }
        var o = this.context.pop();
        o === We.b_stat && this.curContext().token === "function" && (o = this.context.pop()), this.exprAllowed = !o.isExpr;
      }, v.braceL.updateContext = function(o) {
        this.context.push(this.braceIsBlock(o) ? We.b_stat : We.b_expr), this.exprAllowed = !0;
      }, v.dollarBraceL.updateContext = function() {
        this.context.push(We.b_tmpl), this.exprAllowed = !0;
      }, v.parenL.updateContext = function(o) {
        var d = o === v._if || o === v._for || o === v._with || o === v._while;
        this.context.push(d ? We.p_stat : We.p_expr), this.exprAllowed = !0;
      }, v.incDec.updateContext = function() {
      }, v._function.updateContext = v._class.updateContext = function(o) {
        o.beforeExpr && o !== v._else && !(o === v.semi && this.curContext() !== We.p_stat) && !(o === v._return && U.test(this.input.slice(this.lastTokEnd, this.start))) && !((o === v.colon || o === v.braceL) && this.curContext() === We.b_stat) ? this.context.push(We.f_expr) : this.context.push(We.f_stat), this.exprAllowed = !1;
      }, v.backQuote.updateContext = function() {
        this.curContext() === We.q_tmpl ? this.context.pop() : this.context.push(We.q_tmpl), this.exprAllowed = !1;
      }, v.star.updateContext = function(o) {
        if (o === v._function) {
          var d = this.context.length - 1;
          this.context[d] === We.f_expr ? this.context[d] = We.f_expr_gen : this.context[d] = We.f_gen;
        }
        this.exprAllowed = !0;
      }, v.name.updateContext = function(o) {
        var d = !1;
        this.options.ecmaVersion >= 6 && o !== v.dot && (this.value === "of" && !this.exprAllowed || this.value === "yield" && this.inGeneratorContext()) && (d = !0), this.exprAllowed = d;
      };
      var me = Ye.prototype;
      me.checkPropClash = function(o, d, m) {
        if (!(this.options.ecmaVersion >= 9 && o.type === "SpreadElement") && !(this.options.ecmaVersion >= 6 && (o.computed || o.method || o.shorthand))) {
          var g = o.key, S;
          switch (g.type) {
            case "Identifier":
              S = g.name;
              break;
            case "Literal":
              S = String(g.value);
              break;
            default:
              return;
          }
          var T = o.kind;
          if (this.options.ecmaVersion >= 6) {
            S === "__proto__" && T === "init" && (d.proto && (m ? m.doubleProto < 0 && (m.doubleProto = g.start) : this.raiseRecoverable(g.start, "Redefinition of __proto__ property")), d.proto = !0);
            return;
          }
          S = "$" + S;
          var I = d[S];
          if (I) {
            var V;
            T === "init" ? V = this.strict && I.init || I.get || I.set : V = I.init || I[T], V && this.raiseRecoverable(g.start, "Redefinition of property");
          } else
            I = d[S] = {
              init: !1,
              get: !1,
              set: !1
            };
          I[T] = !0;
        }
      }, me.parseExpression = function(o, d) {
        var m = this.start, g = this.startLoc, S = this.parseMaybeAssign(o, d);
        if (this.type === v.comma) {
          var T = this.startNodeAt(m, g);
          for (T.expressions = [S]; this.eat(v.comma); )
            T.expressions.push(this.parseMaybeAssign(o, d));
          return this.finishNode(T, "SequenceExpression");
        }
        return S;
      }, me.parseMaybeAssign = function(o, d, m) {
        if (this.isContextual("yield")) {
          if (this.inGenerator)
            return this.parseYield(o);
          this.exprAllowed = !1;
        }
        var g = !1, S = -1, T = -1, I = -1;
        d ? (S = d.parenthesizedAssign, T = d.trailingComma, I = d.doubleProto, d.parenthesizedAssign = d.trailingComma = -1) : (d = new va(), g = !0);
        var V = this.start, H = this.startLoc;
        (this.type === v.parenL || this.type === v.name) && (this.potentialArrowAt = this.start, this.potentialArrowInForAwait = o === "await");
        var pe = this.parseMaybeConditional(o, d);
        if (m && (pe = m.call(this, pe, V, H)), this.type.isAssign) {
          var _e = this.startNodeAt(V, H);
          return _e.operator = this.value, this.type === v.eq && (pe = this.toAssignable(pe, !1, d)), g || (d.parenthesizedAssign = d.trailingComma = d.doubleProto = -1), d.shorthandAssign >= pe.start && (d.shorthandAssign = -1), this.type === v.eq ? this.checkLValPattern(pe) : this.checkLValSimple(pe), _e.left = pe, this.next(), _e.right = this.parseMaybeAssign(o), I > -1 && (d.doubleProto = I), this.finishNode(_e, "AssignmentExpression");
        } else
          g && this.checkExpressionErrors(d, !0);
        return S > -1 && (d.parenthesizedAssign = S), T > -1 && (d.trailingComma = T), pe;
      }, me.parseMaybeConditional = function(o, d) {
        var m = this.start, g = this.startLoc, S = this.parseExprOps(o, d);
        if (this.checkExpressionErrors(d))
          return S;
        if (this.eat(v.question)) {
          var T = this.startNodeAt(m, g);
          return T.test = S, T.consequent = this.parseMaybeAssign(), this.expect(v.colon), T.alternate = this.parseMaybeAssign(o), this.finishNode(T, "ConditionalExpression");
        }
        return S;
      }, me.parseExprOps = function(o, d) {
        var m = this.start, g = this.startLoc, S = this.parseMaybeUnary(d, !1, !1, o);
        return this.checkExpressionErrors(d) || S.start === m && S.type === "ArrowFunctionExpression" ? S : this.parseExprOp(S, m, g, -1, o);
      }, me.parseExprOp = function(o, d, m, g, S) {
        var T = this.type.binop;
        if (T != null && (!S || this.type !== v._in) && T > g) {
          var I = this.type === v.logicalOR || this.type === v.logicalAND, V = this.type === v.coalesce;
          V && (T = v.logicalAND.binop);
          var H = this.value;
          this.next();
          var pe = this.start, _e = this.startLoc, gt = this.parseExprOp(this.parseMaybeUnary(null, !1, !1, S), pe, _e, T, S), Kn = this.buildBinary(d, m, o, gt, H, I || V);
          return (I && this.type === v.coalesce || V && (this.type === v.logicalOR || this.type === v.logicalAND)) && this.raiseRecoverable(this.start, "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"), this.parseExprOp(Kn, d, m, g, S);
        }
        return o;
      }, me.buildBinary = function(o, d, m, g, S, T) {
        g.type === "PrivateIdentifier" && this.raise(g.start, "Private identifier can only be left side of binary expression");
        var I = this.startNodeAt(o, d);
        return I.left = m, I.operator = S, I.right = g, this.finishNode(I, T ? "LogicalExpression" : "BinaryExpression");
      }, me.parseMaybeUnary = function(o, d, m, g) {
        var S = this.start, T = this.startLoc, I;
        if (this.isContextual("await") && this.canAwait)
          I = this.parseAwait(g), d = !0;
        else if (this.type.prefix) {
          var V = this.startNode(), H = this.type === v.incDec;
          V.operator = this.value, V.prefix = !0, this.next(), V.argument = this.parseMaybeUnary(null, !0, H, g), this.checkExpressionErrors(o, !0), H ? this.checkLValSimple(V.argument) : this.strict && V.operator === "delete" && V.argument.type === "Identifier" ? this.raiseRecoverable(V.start, "Deleting local variable in strict mode") : V.operator === "delete" && Ju(V.argument) ? this.raiseRecoverable(V.start, "Private fields can not be deleted") : d = !0, I = this.finishNode(V, H ? "UpdateExpression" : "UnaryExpression");
        } else if (!d && this.type === v.privateId)
          (g || this.privateNameStack.length === 0) && this.unexpected(), I = this.parsePrivateIdent(), this.type !== v._in && this.unexpected();
        else {
          if (I = this.parseExprSubscripts(o, g), this.checkExpressionErrors(o))
            return I;
          for (; this.type.postfix && !this.canInsertSemicolon(); ) {
            var pe = this.startNodeAt(S, T);
            pe.operator = this.value, pe.prefix = !1, pe.argument = I, this.checkLValSimple(I), this.next(), I = this.finishNode(pe, "UpdateExpression");
          }
        }
        if (!m && this.eat(v.starstar))
          if (d)
            this.unexpected(this.lastTokStart);
          else
            return this.buildBinary(S, T, I, this.parseMaybeUnary(null, !1, !1, g), "**", !1);
        else
          return I;
      };
      function Ju(o) {
        return o.type === "MemberExpression" && o.property.type === "PrivateIdentifier" || o.type === "ChainExpression" && Ju(o.expression);
      }
      l(Ju, "isPrivateFieldAccess"), me.parseExprSubscripts = function(o, d) {
        var m = this.start, g = this.startLoc, S = this.parseExprAtom(o, d);
        if (S.type === "ArrowFunctionExpression" && this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")")
          return S;
        var T = this.parseSubscripts(S, m, g, !1, d);
        return o && T.type === "MemberExpression" && (o.parenthesizedAssign >= T.start && (o.parenthesizedAssign = -1), o.parenthesizedBind >= T.start && (o.parenthesizedBind = -1), o.trailingComma >= T.start && (o.trailingComma = -1)), T;
      }, me.parseSubscripts = function(o, d, m, g, S) {
        for (var T = this.options.ecmaVersion >= 8 && o.type === "Identifier" && o.name === "async" && this.lastTokEnd === o.end && !this.canInsertSemicolon() && o.end - o.start === 5 && this.potentialArrowAt === o.start, I = !1; ; ) {
          var V = this.parseSubscript(o, d, m, g, T, I, S);
          if (V.optional && (I = !0), V === o || V.type === "ArrowFunctionExpression") {
            if (I) {
              var H = this.startNodeAt(d, m);
              H.expression = V, V = this.finishNode(H, "ChainExpression");
            }
            return V;
          }
          o = V;
        }
      }, me.parseSubscript = function(o, d, m, g, S, T, I) {
        var V = this.options.ecmaVersion >= 11, H = V && this.eat(v.questionDot);
        g && H && this.raise(this.lastTokStart, "Optional chaining cannot appear in the callee of new expressions");
        var pe = this.eat(v.bracketL);
        if (pe || H && this.type !== v.parenL && this.type !== v.backQuote || this.eat(v.dot)) {
          var _e = this.startNodeAt(d, m);
          _e.object = o, pe ? (_e.property = this.parseExpression(), this.expect(v.bracketR)) : this.type === v.privateId && o.type !== "Super" ? _e.property = this.parsePrivateIdent() : _e.property = this.parseIdent(this.options.allowReserved !== "never"), _e.computed = !!pe, V && (_e.optional = H), o = this.finishNode(_e, "MemberExpression");
        } else if (!g && this.eat(v.parenL)) {
          var gt = new va(), Kn = this.yieldPos, Mr = this.awaitPos, Ls = this.awaitIdentPos;
          this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0;
          var _a = this.parseExprList(v.parenR, this.options.ecmaVersion >= 8, !1, gt);
          if (S && !H && !this.canInsertSemicolon() && this.eat(v.arrow))
            return this.checkPatternErrors(gt, !1), this.checkYieldAwaitInDefaultParams(), this.awaitIdentPos > 0 && this.raise(this.awaitIdentPos, "Cannot use 'await' as identifier inside an async function"), this.yieldPos = Kn, this.awaitPos = Mr, this.awaitIdentPos = Ls, this.parseArrowExpression(this.startNodeAt(d, m), _a, !0, I);
          this.checkExpressionErrors(gt, !0), this.yieldPos = Kn || this.yieldPos, this.awaitPos = Mr || this.awaitPos, this.awaitIdentPos = Ls || this.awaitIdentPos;
          var Ds = this.startNodeAt(d, m);
          Ds.callee = o, Ds.arguments = _a, V && (Ds.optional = H), o = this.finishNode(Ds, "CallExpression");
        } else if (this.type === v.backQuote) {
          (H || T) && this.raise(this.start, "Optional chaining cannot appear in the tag of tagged template expressions");
          var Bs = this.startNodeAt(d, m);
          Bs.tag = o, Bs.quasi = this.parseTemplate({ isTagged: !0 }), o = this.finishNode(Bs, "TaggedTemplateExpression");
        }
        return o;
      }, me.parseExprAtom = function(o, d) {
        this.type === v.slash && this.readRegexp();
        var m, g = this.potentialArrowAt === this.start;
        switch (this.type) {
          case v._super:
            return this.allowSuper || this.raise(this.start, "'super' keyword outside a method"), m = this.startNode(), this.next(), this.type === v.parenL && !this.allowDirectSuper && this.raise(m.start, "super() call outside constructor of a subclass"), this.type !== v.dot && this.type !== v.bracketL && this.type !== v.parenL && this.unexpected(), this.finishNode(m, "Super");
          case v._this:
            return m = this.startNode(), this.next(), this.finishNode(m, "ThisExpression");
          case v.name:
            var S = this.start, T = this.startLoc, I = this.containsEsc, V = this.parseIdent(!1);
            if (this.options.ecmaVersion >= 8 && !I && V.name === "async" && !this.canInsertSemicolon() && this.eat(v._function))
              return this.overrideContext(We.f_expr), this.parseFunction(this.startNodeAt(S, T), 0, !1, !0, d);
            if (g && !this.canInsertSemicolon()) {
              if (this.eat(v.arrow))
                return this.parseArrowExpression(this.startNodeAt(S, T), [V], !1, d);
              if (this.options.ecmaVersion >= 8 && V.name === "async" && this.type === v.name && !I && (!this.potentialArrowInForAwait || this.value !== "of" || this.containsEsc))
                return V = this.parseIdent(!1), (this.canInsertSemicolon() || !this.eat(v.arrow)) && this.unexpected(), this.parseArrowExpression(this.startNodeAt(S, T), [V], !0, d);
            }
            return V;
          case v.regexp:
            var H = this.value;
            return m = this.parseLiteral(H.value), m.regex = { pattern: H.pattern, flags: H.flags }, m;
          case v.num:
          case v.string:
            return this.parseLiteral(this.value);
          case v._null:
          case v._true:
          case v._false:
            return m = this.startNode(), m.value = this.type === v._null ? null : this.type === v._true, m.raw = this.type.keyword, this.next(), this.finishNode(m, "Literal");
          case v.parenL:
            var pe = this.start, _e = this.parseParenAndDistinguishExpression(g, d);
            return o && (o.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(_e) && (o.parenthesizedAssign = pe), o.parenthesizedBind < 0 && (o.parenthesizedBind = pe)), _e;
          case v.bracketL:
            return m = this.startNode(), this.next(), m.elements = this.parseExprList(v.bracketR, !0, !0, o), this.finishNode(m, "ArrayExpression");
          case v.braceL:
            return this.overrideContext(We.b_expr), this.parseObj(!1, o);
          case v._function:
            return m = this.startNode(), this.next(), this.parseFunction(m, 0);
          case v._class:
            return this.parseClass(this.startNode(), !1);
          case v._new:
            return this.parseNew();
          case v.backQuote:
            return this.parseTemplate();
          case v._import:
            return this.options.ecmaVersion >= 11 ? this.parseExprImport() : this.unexpected();
          default:
            this.unexpected();
        }
      }, me.parseExprImport = function() {
        var o = this.startNode();
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword import");
        var d = this.parseIdent(!0);
        switch (this.type) {
          case v.parenL:
            return this.parseDynamicImport(o);
          case v.dot:
            return o.meta = d, this.parseImportMeta(o);
          default:
            this.unexpected();
        }
      }, me.parseDynamicImport = function(o) {
        if (this.next(), o.source = this.parseMaybeAssign(), !this.eat(v.parenR)) {
          var d = this.start;
          this.eat(v.comma) && this.eat(v.parenR) ? this.raiseRecoverable(d, "Trailing comma is not allowed in import()") : this.unexpected(d);
        }
        return this.finishNode(o, "ImportExpression");
      }, me.parseImportMeta = function(o) {
        this.next();
        var d = this.containsEsc;
        return o.property = this.parseIdent(!0), o.property.name !== "meta" && this.raiseRecoverable(o.property.start, "The only valid meta property for import is 'import.meta'"), d && this.raiseRecoverable(o.start, "'import.meta' must not contain escaped characters"), this.options.sourceType !== "module" && !this.options.allowImportExportEverywhere && this.raiseRecoverable(o.start, "Cannot use 'import.meta' outside a module"), this.finishNode(o, "MetaProperty");
      }, me.parseLiteral = function(o) {
        var d = this.startNode();
        return d.value = o, d.raw = this.input.slice(this.start, this.end), d.raw.charCodeAt(d.raw.length - 1) === 110 && (d.bigint = d.raw.slice(0, -1).replace(/_/g, "")), this.next(), this.finishNode(d, "Literal");
      }, me.parseParenExpression = function() {
        this.expect(v.parenL);
        var o = this.parseExpression();
        return this.expect(v.parenR), o;
      }, me.parseParenAndDistinguishExpression = function(o, d) {
        var m = this.start, g = this.startLoc, S, T = this.options.ecmaVersion >= 8;
        if (this.options.ecmaVersion >= 6) {
          this.next();
          var I = this.start, V = this.startLoc, H = [], pe = !0, _e = !1, gt = new va(), Kn = this.yieldPos, Mr = this.awaitPos, Ls;
          for (this.yieldPos = 0, this.awaitPos = 0; this.type !== v.parenR; )
            if (pe ? pe = !1 : this.expect(v.comma), T && this.afterTrailingComma(v.parenR, !0)) {
              _e = !0;
              break;
            } else if (this.type === v.ellipsis) {
              Ls = this.start, H.push(this.parseParenItem(this.parseRestBinding())), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element");
              break;
            } else
              H.push(this.parseMaybeAssign(!1, gt, this.parseParenItem));
          var _a = this.lastTokEnd, Ds = this.lastTokEndLoc;
          if (this.expect(v.parenR), o && !this.canInsertSemicolon() && this.eat(v.arrow))
            return this.checkPatternErrors(gt, !1), this.checkYieldAwaitInDefaultParams(), this.yieldPos = Kn, this.awaitPos = Mr, this.parseParenArrowList(m, g, H, d);
          (!H.length || _e) && this.unexpected(this.lastTokStart), Ls && this.unexpected(Ls), this.checkExpressionErrors(gt, !0), this.yieldPos = Kn || this.yieldPos, this.awaitPos = Mr || this.awaitPos, H.length > 1 ? (S = this.startNodeAt(I, V), S.expressions = H, this.finishNodeAt(S, "SequenceExpression", _a, Ds)) : S = H[0];
        } else
          S = this.parseParenExpression();
        if (this.options.preserveParens) {
          var Bs = this.startNodeAt(m, g);
          return Bs.expression = S, this.finishNode(Bs, "ParenthesizedExpression");
        } else
          return S;
      }, me.parseParenItem = function(o) {
        return o;
      }, me.parseParenArrowList = function(o, d, m, g) {
        return this.parseArrowExpression(this.startNodeAt(o, d), m, !1, g);
      };
      var Gw = [];
      me.parseNew = function() {
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword new");
        var o = this.startNode(), d = this.parseIdent(!0);
        if (this.options.ecmaVersion >= 6 && this.eat(v.dot)) {
          o.meta = d;
          var m = this.containsEsc;
          return o.property = this.parseIdent(!0), o.property.name !== "target" && this.raiseRecoverable(o.property.start, "The only valid meta property for new is 'new.target'"), m && this.raiseRecoverable(o.start, "'new.target' must not contain escaped characters"), this.allowNewDotTarget || this.raiseRecoverable(o.start, "'new.target' can only be used in functions and class static block"), this.finishNode(o, "MetaProperty");
        }
        var g = this.start, S = this.startLoc, T = this.type === v._import;
        return o.callee = this.parseSubscripts(this.parseExprAtom(), g, S, !0, !1), T && o.callee.type === "ImportExpression" && this.raise(g, "Cannot use new with import()"), this.eat(v.parenL) ? o.arguments = this.parseExprList(v.parenR, this.options.ecmaVersion >= 8, !1) : o.arguments = Gw, this.finishNode(o, "NewExpression");
      }, me.parseTemplateElement = function(o) {
        var d = o.isTagged, m = this.startNode();
        return this.type === v.invalidTemplate ? (d || this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal"), m.value = {
          raw: this.value,
          cooked: null
        }) : m.value = {
          raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, `
`),
          cooked: this.value
        }, this.next(), m.tail = this.type === v.backQuote, this.finishNode(m, "TemplateElement");
      }, me.parseTemplate = function(o) {
        o === void 0 && (o = {});
        var d = o.isTagged;
        d === void 0 && (d = !1);
        var m = this.startNode();
        this.next(), m.expressions = [];
        var g = this.parseTemplateElement({ isTagged: d });
        for (m.quasis = [g]; !g.tail; )
          this.type === v.eof && this.raise(this.pos, "Unterminated template literal"), this.expect(v.dollarBraceL), m.expressions.push(this.parseExpression()), this.expect(v.braceR), m.quasis.push(g = this.parseTemplateElement({ isTagged: d }));
        return this.next(), this.finishNode(m, "TemplateLiteral");
      }, me.isAsyncProp = function(o) {
        return !o.computed && o.key.type === "Identifier" && o.key.name === "async" && (this.type === v.name || this.type === v.num || this.type === v.string || this.type === v.bracketL || this.type.keyword || this.options.ecmaVersion >= 9 && this.type === v.star) && !U.test(this.input.slice(this.lastTokEnd, this.start));
      }, me.parseObj = function(o, d) {
        var m = this.startNode(), g = !0, S = {};
        for (m.properties = [], this.next(); !this.eat(v.braceR); ) {
          if (g)
            g = !1;
          else if (this.expect(v.comma), this.options.ecmaVersion >= 5 && this.afterTrailingComma(v.braceR))
            break;
          var T = this.parseProperty(o, d);
          o || this.checkPropClash(T, S, d), m.properties.push(T);
        }
        return this.finishNode(m, o ? "ObjectPattern" : "ObjectExpression");
      }, me.parseProperty = function(o, d) {
        var m = this.startNode(), g, S, T, I;
        if (this.options.ecmaVersion >= 9 && this.eat(v.ellipsis))
          return o ? (m.argument = this.parseIdent(!1), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element"), this.finishNode(m, "RestElement")) : (m.argument = this.parseMaybeAssign(!1, d), this.type === v.comma && d && d.trailingComma < 0 && (d.trailingComma = this.start), this.finishNode(m, "SpreadElement"));
        this.options.ecmaVersion >= 6 && (m.method = !1, m.shorthand = !1, (o || d) && (T = this.start, I = this.startLoc), o || (g = this.eat(v.star)));
        var V = this.containsEsc;
        return this.parsePropertyName(m), !o && !V && this.options.ecmaVersion >= 8 && !g && this.isAsyncProp(m) ? (S = !0, g = this.options.ecmaVersion >= 9 && this.eat(v.star), this.parsePropertyName(m, d)) : S = !1, this.parsePropertyValue(m, o, g, S, T, I, d, V), this.finishNode(m, "Property");
      }, me.parsePropertyValue = function(o, d, m, g, S, T, I, V) {
        if ((m || g) && this.type === v.colon && this.unexpected(), this.eat(v.colon))
          o.value = d ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(!1, I), o.kind = "init";
        else if (this.options.ecmaVersion >= 6 && this.type === v.parenL)
          d && this.unexpected(), o.kind = "init", o.method = !0, o.value = this.parseMethod(m, g);
        else if (!d && !V && this.options.ecmaVersion >= 5 && !o.computed && o.key.type === "Identifier" && (o.key.name === "get" || o.key.name === "set") && this.type !== v.comma && this.type !== v.braceR && this.type !== v.eq) {
          (m || g) && this.unexpected(), o.kind = o.key.name, this.parsePropertyName(o), o.value = this.parseMethod(!1);
          var H = o.kind === "get" ? 0 : 1;
          if (o.value.params.length !== H) {
            var pe = o.value.start;
            o.kind === "get" ? this.raiseRecoverable(pe, "getter should have no params") : this.raiseRecoverable(pe, "setter should have exactly one param");
          } else
            o.kind === "set" && o.value.params[0].type === "RestElement" && this.raiseRecoverable(o.value.params[0].start, "Setter cannot use rest params");
        } else
          this.options.ecmaVersion >= 6 && !o.computed && o.key.type === "Identifier" ? ((m || g) && this.unexpected(), this.checkUnreserved(o.key), o.key.name === "await" && !this.awaitIdentPos && (this.awaitIdentPos = S), o.kind = "init", d ? o.value = this.parseMaybeDefault(S, T, this.copyNode(o.key)) : this.type === v.eq && I ? (I.shorthandAssign < 0 && (I.shorthandAssign = this.start), o.value = this.parseMaybeDefault(S, T, this.copyNode(o.key))) : o.value = this.copyNode(o.key), o.shorthand = !0) : this.unexpected();
      }, me.parsePropertyName = function(o) {
        if (this.options.ecmaVersion >= 6) {
          if (this.eat(v.bracketL))
            return o.computed = !0, o.key = this.parseMaybeAssign(), this.expect(v.bracketR), o.key;
          o.computed = !1;
        }
        return o.key = this.type === v.num || this.type === v.string ? this.parseExprAtom() : this.parseIdent(this.options.allowReserved !== "never");
      }, me.initFunction = function(o) {
        o.id = null, this.options.ecmaVersion >= 6 && (o.generator = o.expression = !1), this.options.ecmaVersion >= 8 && (o.async = !1);
      }, me.parseMethod = function(o, d, m) {
        var g = this.startNode(), S = this.yieldPos, T = this.awaitPos, I = this.awaitIdentPos;
        return this.initFunction(g), this.options.ecmaVersion >= 6 && (g.generator = o), this.options.ecmaVersion >= 8 && (g.async = !!d), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(fa(d, g.generator) | qu | (m ? jv : 0)), this.expect(v.parenL), g.params = this.parseBindingList(v.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams(), this.parseFunctionBody(g, !1, !0, !1), this.yieldPos = S, this.awaitPos = T, this.awaitIdentPos = I, this.finishNode(g, "FunctionExpression");
      }, me.parseArrowExpression = function(o, d, m, g) {
        var S = this.yieldPos, T = this.awaitPos, I = this.awaitIdentPos;
        return this.enterScope(fa(m, !1) | Vv), this.initFunction(o), this.options.ecmaVersion >= 8 && (o.async = !!m), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, o.params = this.toAssignableList(d, !0), this.parseFunctionBody(o, !0, !1, g), this.yieldPos = S, this.awaitPos = T, this.awaitIdentPos = I, this.finishNode(o, "ArrowFunctionExpression");
      }, me.parseFunctionBody = function(o, d, m, g) {
        var S = d && this.type !== v.braceL, T = this.strict, I = !1;
        if (S)
          o.body = this.parseMaybeAssign(g), o.expression = !0, this.checkParams(o, !1);
        else {
          var V = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(o.params);
          (!T || V) && (I = this.strictDirective(this.end), I && V && this.raiseRecoverable(o.start, "Illegal 'use strict' directive in function with non-simple parameter list"));
          var H = this.labels;
          this.labels = [], I && (this.strict = !0), this.checkParams(o, !T && !I && !d && !m && this.isSimpleParamList(o.params)), this.strict && o.id && this.checkLValSimple(o.id, $v), o.body = this.parseBlock(!1, void 0, I && !T), o.expression = !1, this.adaptDirectivePrologue(o.body.body), this.labels = H;
        }
        this.exitScope();
      }, me.isSimpleParamList = function(o) {
        for (var d = 0, m = o; d < m.length; d += 1) {
          var g = m[d];
          if (g.type !== "Identifier")
            return !1;
        }
        return !0;
      }, me.checkParams = function(o, d) {
        for (var m = /* @__PURE__ */ Object.create(null), g = 0, S = o.params; g < S.length; g += 1) {
          var T = S[g];
          this.checkLValInnerPattern(T, zu, d ? null : m);
        }
      }, me.parseExprList = function(o, d, m, g) {
        for (var S = [], T = !0; !this.eat(o); ) {
          if (T)
            T = !1;
          else if (this.expect(v.comma), d && this.afterTrailingComma(o))
            break;
          var I = void 0;
          m && this.type === v.comma ? I = null : this.type === v.ellipsis ? (I = this.parseSpread(g), g && this.type === v.comma && g.trailingComma < 0 && (g.trailingComma = this.start)) : I = this.parseMaybeAssign(!1, g), S.push(I);
        }
        return S;
      }, me.checkUnreserved = function(o) {
        var d = o.start, m = o.end, g = o.name;
        if (this.inGenerator && g === "yield" && this.raiseRecoverable(d, "Cannot use 'yield' as identifier inside a generator"), this.inAsync && g === "await" && this.raiseRecoverable(d, "Cannot use 'await' as identifier inside an async function"), this.currentThisScope().inClassFieldInit && g === "arguments" && this.raiseRecoverable(d, "Cannot use 'arguments' in class field initializer"), this.inClassStaticBlock && (g === "arguments" || g === "await") && this.raise(d, "Cannot use " + g + " in class static initialization block"), this.keywords.test(g) && this.raise(d, "Unexpected keyword '" + g + "'"), !(this.options.ecmaVersion < 6 && this.input.slice(d, m).indexOf("\\") !== -1)) {
          var S = this.strict ? this.reservedWordsStrict : this.reservedWords;
          S.test(g) && (!this.inAsync && g === "await" && this.raiseRecoverable(d, "Cannot use keyword 'await' outside an async function"), this.raiseRecoverable(d, "The keyword '" + g + "' is reserved"));
        }
      }, me.parseIdent = function(o, d) {
        var m = this.startNode();
        return this.type === v.name ? m.name = this.value : this.type.keyword ? (m.name = this.type.keyword, (m.name === "class" || m.name === "function") && (this.lastTokEnd !== this.lastTokStart + 1 || this.input.charCodeAt(this.lastTokStart) !== 46) && this.context.pop()) : this.unexpected(), this.next(!!o), this.finishNode(m, "Identifier"), o || (this.checkUnreserved(m), m.name === "await" && !this.awaitIdentPos && (this.awaitIdentPos = m.start)), m;
      }, me.parsePrivateIdent = function() {
        var o = this.startNode();
        return this.type === v.privateId ? o.name = this.value : this.unexpected(), this.next(), this.finishNode(o, "PrivateIdentifier"), this.privateNameStack.length === 0 ? this.raise(o.start, "Private field '#" + o.name + "' must be declared in an enclosing class") : this.privateNameStack[this.privateNameStack.length - 1].used.push(o), o;
      }, me.parseYield = function(o) {
        this.yieldPos || (this.yieldPos = this.start);
        var d = this.startNode();
        return this.next(), this.type === v.semi || this.canInsertSemicolon() || this.type !== v.star && !this.type.startsExpr ? (d.delegate = !1, d.argument = null) : (d.delegate = this.eat(v.star), d.argument = this.parseMaybeAssign(o)), this.finishNode(d, "YieldExpression");
      }, me.parseAwait = function(o) {
        this.awaitPos || (this.awaitPos = this.start);
        var d = this.startNode();
        return this.next(), d.argument = this.parseMaybeUnary(null, !0, !1, o), this.finishNode(d, "AwaitExpression");
      };
      var ga = Ye.prototype;
      ga.raise = function(o, d) {
        var m = un(this.input, o);
        d += " (" + m.line + ":" + m.column + ")";
        var g = new SyntaxError(d);
        throw g.pos = o, g.loc = m, g.raisedAt = this.pos, g;
      }, ga.raiseRecoverable = ga.raise, ga.curPosition = function() {
        if (this.options.locations)
          return new qt(this.curLine, this.pos - this.lineStart);
      };
      var cn = Ye.prototype, qw = /* @__PURE__ */ l(function(d) {
        this.flags = d, this.var = [], this.lexical = [], this.functions = [], this.inClassFieldInit = !1;
      }, "Scope");
      cn.enterScope = function(o) {
        this.scopeStack.push(new qw(o));
      }, cn.exitScope = function() {
        this.scopeStack.pop();
      }, cn.treatFunctionsAsVarInScope = function(o) {
        return o.flags & Ns || !this.inModule && o.flags & Tr;
      }, cn.declareName = function(o, d, m) {
        var g = !1;
        if (d === $i) {
          var S = this.currentScope();
          g = S.lexical.indexOf(o) > -1 || S.functions.indexOf(o) > -1 || S.var.indexOf(o) > -1, S.lexical.push(o), this.inModule && S.flags & Tr && delete this.undefinedExports[o];
        } else if (d === Wv) {
          var T = this.currentScope();
          T.lexical.push(o);
        } else if (d === Hv) {
          var I = this.currentScope();
          this.treatFunctionsAsVar ? g = I.lexical.indexOf(o) > -1 : g = I.lexical.indexOf(o) > -1 || I.var.indexOf(o) > -1, I.functions.push(o);
        } else
          for (var V = this.scopeStack.length - 1; V >= 0; --V) {
            var H = this.scopeStack[V];
            if (H.lexical.indexOf(o) > -1 && !(H.flags & Uv && H.lexical[0] === o) || !this.treatFunctionsAsVarInScope(H) && H.functions.indexOf(o) > -1) {
              g = !0;
              break;
            }
            if (H.var.push(o), this.inModule && H.flags & Tr && delete this.undefinedExports[o], H.flags & Ku)
              break;
          }
        g && this.raiseRecoverable(m, "Identifier '" + o + "' has already been declared");
      }, cn.checkLocalExport = function(o) {
        this.scopeStack[0].lexical.indexOf(o.name) === -1 && this.scopeStack[0].var.indexOf(o.name) === -1 && (this.undefinedExports[o.name] = o);
      }, cn.currentScope = function() {
        return this.scopeStack[this.scopeStack.length - 1];
      }, cn.currentVarScope = function() {
        for (var o = this.scopeStack.length - 1; ; o--) {
          var d = this.scopeStack[o];
          if (d.flags & Ku)
            return d;
        }
      }, cn.currentThisScope = function() {
        for (var o = this.scopeStack.length - 1; ; o--) {
          var d = this.scopeStack[o];
          if (d.flags & Ku && !(d.flags & Vv))
            return d;
        }
      };
      var Ar = /* @__PURE__ */ l(function(d, m, g) {
        this.type = "", this.start = m, this.end = 0, d.options.locations && (this.loc = new ci(d, g)), d.options.directSourceFile && (this.sourceFile = d.options.directSourceFile), d.options.ranges && (this.range = [m, 0]);
      }, "Node"), Ir = Ye.prototype;
      Ir.startNode = function() {
        return new Ar(this, this.start, this.startLoc);
      }, Ir.startNodeAt = function(o, d) {
        return new Ar(this, o, d);
      };
      function Zu(o, d, m, g) {
        return o.type = d, o.end = m, this.options.locations && (o.loc.end = g), this.options.ranges && (o.range[1] = m), o;
      }
      l(Zu, "finishNodeAt"), Ir.finishNode = function(o, d) {
        return Zu.call(this, o, d, this.lastTokEnd, this.lastTokEndLoc);
      }, Ir.finishNodeAt = function(o, d, m, g) {
        return Zu.call(this, o, d, m, g);
      }, Ir.copyNode = function(o) {
        var d = new Ar(this, o.start, this.startLoc);
        for (var m in o)
          d[m] = o[m];
        return d;
      };
      var Kv = "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS", zv = Kv + " Extended_Pictographic", Yv = zv, Xv = Yv + " EBase EComp EMod EPres ExtPict", Kw = Xv, zw = {
        9: Kv,
        10: zv,
        11: Yv,
        12: Xv,
        13: Kw
      }, Jv = "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu", Zv = "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb", Qv = Zv + " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd", e5 = Qv + " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho", t5 = e5 + " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi", Yw = t5 + " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith", Xw = {
        9: Zv,
        10: Qv,
        11: e5,
        12: t5,
        13: Yw
      }, i5 = {};
      function n5(o) {
        var d = i5[o] = {
          binary: Ve(zw[o] + " " + Jv),
          nonBinary: {
            General_Category: Ve(Jv),
            Script: Ve(Xw[o])
          }
        };
        d.nonBinary.Script_Extensions = d.nonBinary.Script, d.nonBinary.gc = d.nonBinary.General_Category, d.nonBinary.sc = d.nonBinary.Script, d.nonBinary.scx = d.nonBinary.Script_Extensions;
      }
      l(n5, "buildUnicodeData");
      for (var Qu = 0, s5 = [9, 10, 11, 12, 13]; Qu < s5.length; Qu += 1) {
        var Jw = s5[Qu];
        n5(Jw);
      }
      var ee = Ye.prototype, Gi = /* @__PURE__ */ l(function(d) {
        this.parser = d, this.validFlags = "gim" + (d.options.ecmaVersion >= 6 ? "uy" : "") + (d.options.ecmaVersion >= 9 ? "s" : "") + (d.options.ecmaVersion >= 13 ? "d" : ""), this.unicodeProperties = i5[d.options.ecmaVersion >= 13 ? 13 : d.options.ecmaVersion], this.source = "", this.flags = "", this.start = 0, this.switchU = !1, this.switchN = !1, this.pos = 0, this.lastIntValue = 0, this.lastStringValue = "", this.lastAssertionIsQuantifiable = !1, this.numCapturingParens = 0, this.maxBackReference = 0, this.groupNames = [], this.backReferenceNames = [];
      }, "RegExpValidationState");
      Gi.prototype.reset = /* @__PURE__ */ l(function(d, m, g) {
        var S = g.indexOf("u") !== -1;
        this.start = d | 0, this.source = m + "", this.flags = g, this.switchU = S && this.parser.options.ecmaVersion >= 6, this.switchN = S && this.parser.options.ecmaVersion >= 9;
      }, "reset"), Gi.prototype.raise = /* @__PURE__ */ l(function(d) {
        this.parser.raiseRecoverable(this.start, "Invalid regular expression: /" + this.source + "/: " + d);
      }, "raise"), Gi.prototype.at = /* @__PURE__ */ l(function(d, m) {
        m === void 0 && (m = !1);
        var g = this.source, S = g.length;
        if (d >= S)
          return -1;
        var T = g.charCodeAt(d);
        if (!(m || this.switchU) || T <= 55295 || T >= 57344 || d + 1 >= S)
          return T;
        var I = g.charCodeAt(d + 1);
        return I >= 56320 && I <= 57343 ? (T << 10) + I - 56613888 : T;
      }, "at"), Gi.prototype.nextIndex = /* @__PURE__ */ l(function(d, m) {
        m === void 0 && (m = !1);
        var g = this.source, S = g.length;
        if (d >= S)
          return S;
        var T = g.charCodeAt(d), I;
        return !(m || this.switchU) || T <= 55295 || T >= 57344 || d + 1 >= S || (I = g.charCodeAt(d + 1)) < 56320 || I > 57343 ? d + 1 : d + 2;
      }, "nextIndex"), Gi.prototype.current = /* @__PURE__ */ l(function(d) {
        return d === void 0 && (d = !1), this.at(this.pos, d);
      }, "current"), Gi.prototype.lookahead = /* @__PURE__ */ l(function(d) {
        return d === void 0 && (d = !1), this.at(this.nextIndex(this.pos, d), d);
      }, "lookahead"), Gi.prototype.advance = /* @__PURE__ */ l(function(d) {
        d === void 0 && (d = !1), this.pos = this.nextIndex(this.pos, d);
      }, "advance"), Gi.prototype.eat = /* @__PURE__ */ l(function(d, m) {
        return m === void 0 && (m = !1), this.current(m) === d ? (this.advance(m), !0) : !1;
      }, "eat"), ee.validateRegExpFlags = function(o) {
        for (var d = o.validFlags, m = o.flags, g = 0; g < m.length; g++) {
          var S = m.charAt(g);
          d.indexOf(S) === -1 && this.raise(o.start, "Invalid regular expression flag"), m.indexOf(S, g + 1) > -1 && this.raise(o.start, "Duplicate regular expression flag");
        }
      }, ee.validateRegExpPattern = function(o) {
        this.regexp_pattern(o), !o.switchN && this.options.ecmaVersion >= 9 && o.groupNames.length > 0 && (o.switchN = !0, this.regexp_pattern(o));
      }, ee.regexp_pattern = function(o) {
        o.pos = 0, o.lastIntValue = 0, o.lastStringValue = "", o.lastAssertionIsQuantifiable = !1, o.numCapturingParens = 0, o.maxBackReference = 0, o.groupNames.length = 0, o.backReferenceNames.length = 0, this.regexp_disjunction(o), o.pos !== o.source.length && (o.eat(41) && o.raise("Unmatched ')'"), (o.eat(93) || o.eat(125)) && o.raise("Lone quantifier brackets")), o.maxBackReference > o.numCapturingParens && o.raise("Invalid escape");
        for (var d = 0, m = o.backReferenceNames; d < m.length; d += 1) {
          var g = m[d];
          o.groupNames.indexOf(g) === -1 && o.raise("Invalid named capture referenced");
        }
      }, ee.regexp_disjunction = function(o) {
        for (this.regexp_alternative(o); o.eat(124); )
          this.regexp_alternative(o);
        this.regexp_eatQuantifier(o, !0) && o.raise("Nothing to repeat"), o.eat(123) && o.raise("Lone quantifier brackets");
      }, ee.regexp_alternative = function(o) {
        for (; o.pos < o.source.length && this.regexp_eatTerm(o); )
          ;
      }, ee.regexp_eatTerm = function(o) {
        return this.regexp_eatAssertion(o) ? (o.lastAssertionIsQuantifiable && this.regexp_eatQuantifier(o) && o.switchU && o.raise("Invalid quantifier"), !0) : (o.switchU ? this.regexp_eatAtom(o) : this.regexp_eatExtendedAtom(o)) ? (this.regexp_eatQuantifier(o), !0) : !1;
      }, ee.regexp_eatAssertion = function(o) {
        var d = o.pos;
        if (o.lastAssertionIsQuantifiable = !1, o.eat(94) || o.eat(36))
          return !0;
        if (o.eat(92)) {
          if (o.eat(66) || o.eat(98))
            return !0;
          o.pos = d;
        }
        if (o.eat(40) && o.eat(63)) {
          var m = !1;
          if (this.options.ecmaVersion >= 9 && (m = o.eat(60)), o.eat(61) || o.eat(33))
            return this.regexp_disjunction(o), o.eat(41) || o.raise("Unterminated group"), o.lastAssertionIsQuantifiable = !m, !0;
        }
        return o.pos = d, !1;
      }, ee.regexp_eatQuantifier = function(o, d) {
        return d === void 0 && (d = !1), this.regexp_eatQuantifierPrefix(o, d) ? (o.eat(63), !0) : !1;
      }, ee.regexp_eatQuantifierPrefix = function(o, d) {
        return o.eat(42) || o.eat(43) || o.eat(63) || this.regexp_eatBracedQuantifier(o, d);
      }, ee.regexp_eatBracedQuantifier = function(o, d) {
        var m = o.pos;
        if (o.eat(123)) {
          var g = 0, S = -1;
          if (this.regexp_eatDecimalDigits(o) && (g = o.lastIntValue, o.eat(44) && this.regexp_eatDecimalDigits(o) && (S = o.lastIntValue), o.eat(125)))
            return S !== -1 && S < g && !d && o.raise("numbers out of order in {} quantifier"), !0;
          o.switchU && !d && o.raise("Incomplete quantifier"), o.pos = m;
        }
        return !1;
      }, ee.regexp_eatAtom = function(o) {
        return this.regexp_eatPatternCharacters(o) || o.eat(46) || this.regexp_eatReverseSolidusAtomEscape(o) || this.regexp_eatCharacterClass(o) || this.regexp_eatUncapturingGroup(o) || this.regexp_eatCapturingGroup(o);
      }, ee.regexp_eatReverseSolidusAtomEscape = function(o) {
        var d = o.pos;
        if (o.eat(92)) {
          if (this.regexp_eatAtomEscape(o))
            return !0;
          o.pos = d;
        }
        return !1;
      }, ee.regexp_eatUncapturingGroup = function(o) {
        var d = o.pos;
        if (o.eat(40)) {
          if (o.eat(63) && o.eat(58)) {
            if (this.regexp_disjunction(o), o.eat(41))
              return !0;
            o.raise("Unterminated group");
          }
          o.pos = d;
        }
        return !1;
      }, ee.regexp_eatCapturingGroup = function(o) {
        if (o.eat(40)) {
          if (this.options.ecmaVersion >= 9 ? this.regexp_groupSpecifier(o) : o.current() === 63 && o.raise("Invalid group"), this.regexp_disjunction(o), o.eat(41))
            return o.numCapturingParens += 1, !0;
          o.raise("Unterminated group");
        }
        return !1;
      }, ee.regexp_eatExtendedAtom = function(o) {
        return o.eat(46) || this.regexp_eatReverseSolidusAtomEscape(o) || this.regexp_eatCharacterClass(o) || this.regexp_eatUncapturingGroup(o) || this.regexp_eatCapturingGroup(o) || this.regexp_eatInvalidBracedQuantifier(o) || this.regexp_eatExtendedPatternCharacter(o);
      }, ee.regexp_eatInvalidBracedQuantifier = function(o) {
        return this.regexp_eatBracedQuantifier(o, !0) && o.raise("Nothing to repeat"), !1;
      }, ee.regexp_eatSyntaxCharacter = function(o) {
        var d = o.current();
        return e1(d) ? (o.lastIntValue = d, o.advance(), !0) : !1;
      };
      function e1(o) {
        return o === 36 || o >= 40 && o <= 43 || o === 46 || o === 63 || o >= 91 && o <= 94 || o >= 123 && o <= 125;
      }
      l(e1, "isSyntaxCharacter"), ee.regexp_eatPatternCharacters = function(o) {
        for (var d = o.pos, m = 0; (m = o.current()) !== -1 && !e1(m); )
          o.advance();
        return o.pos !== d;
      }, ee.regexp_eatExtendedPatternCharacter = function(o) {
        var d = o.current();
        return d !== -1 && d !== 36 && !(d >= 40 && d <= 43) && d !== 46 && d !== 63 && d !== 91 && d !== 94 && d !== 124 ? (o.advance(), !0) : !1;
      }, ee.regexp_groupSpecifier = function(o) {
        if (o.eat(63)) {
          if (this.regexp_eatGroupName(o)) {
            o.groupNames.indexOf(o.lastStringValue) !== -1 && o.raise("Duplicate capture group name"), o.groupNames.push(o.lastStringValue);
            return;
          }
          o.raise("Invalid group");
        }
      }, ee.regexp_eatGroupName = function(o) {
        if (o.lastStringValue = "", o.eat(60)) {
          if (this.regexp_eatRegExpIdentifierName(o) && o.eat(62))
            return !0;
          o.raise("Invalid capture group name");
        }
        return !1;
      }, ee.regexp_eatRegExpIdentifierName = function(o) {
        if (o.lastStringValue = "", this.regexp_eatRegExpIdentifierStart(o)) {
          for (o.lastStringValue += fe(o.lastIntValue); this.regexp_eatRegExpIdentifierPart(o); )
            o.lastStringValue += fe(o.lastIntValue);
          return !0;
        }
        return !1;
      }, ee.regexp_eatRegExpIdentifierStart = function(o) {
        var d = o.pos, m = this.options.ecmaVersion >= 11, g = o.current(m);
        return o.advance(m), g === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(o, m) && (g = o.lastIntValue), r5(g) ? (o.lastIntValue = g, !0) : (o.pos = d, !1);
      };
      function r5(o) {
        return E(o, !0) || o === 36 || o === 95;
      }
      l(r5, "isRegExpIdentifierStart"), ee.regexp_eatRegExpIdentifierPart = function(o) {
        var d = o.pos, m = this.options.ecmaVersion >= 11, g = o.current(m);
        return o.advance(m), g === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(o, m) && (g = o.lastIntValue), o5(g) ? (o.lastIntValue = g, !0) : (o.pos = d, !1);
      };
      function o5(o) {
        return P(o, !0) || o === 36 || o === 95 || o === 8204 || o === 8205;
      }
      l(o5, "isRegExpIdentifierPart"), ee.regexp_eatAtomEscape = function(o) {
        return this.regexp_eatBackReference(o) || this.regexp_eatCharacterClassEscape(o) || this.regexp_eatCharacterEscape(o) || o.switchN && this.regexp_eatKGroupName(o) ? !0 : (o.switchU && (o.current() === 99 && o.raise("Invalid unicode escape"), o.raise("Invalid escape")), !1);
      }, ee.regexp_eatBackReference = function(o) {
        var d = o.pos;
        if (this.regexp_eatDecimalEscape(o)) {
          var m = o.lastIntValue;
          if (o.switchU)
            return m > o.maxBackReference && (o.maxBackReference = m), !0;
          if (m <= o.numCapturingParens)
            return !0;
          o.pos = d;
        }
        return !1;
      }, ee.regexp_eatKGroupName = function(o) {
        if (o.eat(107)) {
          if (this.regexp_eatGroupName(o))
            return o.backReferenceNames.push(o.lastStringValue), !0;
          o.raise("Invalid named reference");
        }
        return !1;
      }, ee.regexp_eatCharacterEscape = function(o) {
        return this.regexp_eatControlEscape(o) || this.regexp_eatCControlLetter(o) || this.regexp_eatZero(o) || this.regexp_eatHexEscapeSequence(o) || this.regexp_eatRegExpUnicodeEscapeSequence(o, !1) || !o.switchU && this.regexp_eatLegacyOctalEscapeSequence(o) || this.regexp_eatIdentityEscape(o);
      }, ee.regexp_eatCControlLetter = function(o) {
        var d = o.pos;
        if (o.eat(99)) {
          if (this.regexp_eatControlLetter(o))
            return !0;
          o.pos = d;
        }
        return !1;
      }, ee.regexp_eatZero = function(o) {
        return o.current() === 48 && !Pr(o.lookahead()) ? (o.lastIntValue = 0, o.advance(), !0) : !1;
      }, ee.regexp_eatControlEscape = function(o) {
        var d = o.current();
        return d === 116 ? (o.lastIntValue = 9, o.advance(), !0) : d === 110 ? (o.lastIntValue = 10, o.advance(), !0) : d === 118 ? (o.lastIntValue = 11, o.advance(), !0) : d === 102 ? (o.lastIntValue = 12, o.advance(), !0) : d === 114 ? (o.lastIntValue = 13, o.advance(), !0) : !1;
      }, ee.regexp_eatControlLetter = function(o) {
        var d = o.current();
        return t1(d) ? (o.lastIntValue = d % 32, o.advance(), !0) : !1;
      };
      function t1(o) {
        return o >= 65 && o <= 90 || o >= 97 && o <= 122;
      }
      l(t1, "isControlLetter"), ee.regexp_eatRegExpUnicodeEscapeSequence = function(o, d) {
        d === void 0 && (d = !1);
        var m = o.pos, g = d || o.switchU;
        if (o.eat(117)) {
          if (this.regexp_eatFixedHexDigits(o, 4)) {
            var S = o.lastIntValue;
            if (g && S >= 55296 && S <= 56319) {
              var T = o.pos;
              if (o.eat(92) && o.eat(117) && this.regexp_eatFixedHexDigits(o, 4)) {
                var I = o.lastIntValue;
                if (I >= 56320 && I <= 57343)
                  return o.lastIntValue = (S - 55296) * 1024 + (I - 56320) + 65536, !0;
              }
              o.pos = T, o.lastIntValue = S;
            }
            return !0;
          }
          if (g && o.eat(123) && this.regexp_eatHexDigits(o) && o.eat(125) && a5(o.lastIntValue))
            return !0;
          g && o.raise("Invalid unicode escape"), o.pos = m;
        }
        return !1;
      };
      function a5(o) {
        return o >= 0 && o <= 1114111;
      }
      l(a5, "isValidUnicode"), ee.regexp_eatIdentityEscape = function(o) {
        if (o.switchU)
          return this.regexp_eatSyntaxCharacter(o) ? !0 : o.eat(47) ? (o.lastIntValue = 47, !0) : !1;
        var d = o.current();
        return d !== 99 && (!o.switchN || d !== 107) ? (o.lastIntValue = d, o.advance(), !0) : !1;
      }, ee.regexp_eatDecimalEscape = function(o) {
        o.lastIntValue = 0;
        var d = o.current();
        if (d >= 49 && d <= 57) {
          do
            o.lastIntValue = 10 * o.lastIntValue + (d - 48), o.advance();
          while ((d = o.current()) >= 48 && d <= 57);
          return !0;
        }
        return !1;
      }, ee.regexp_eatCharacterClassEscape = function(o) {
        var d = o.current();
        if (l5(d))
          return o.lastIntValue = -1, o.advance(), !0;
        if (o.switchU && this.options.ecmaVersion >= 9 && (d === 80 || d === 112)) {
          if (o.lastIntValue = -1, o.advance(), o.eat(123) && this.regexp_eatUnicodePropertyValueExpression(o) && o.eat(125))
            return !0;
          o.raise("Invalid property name");
        }
        return !1;
      };
      function l5(o) {
        return o === 100 || o === 68 || o === 115 || o === 83 || o === 119 || o === 87;
      }
      l(l5, "isCharacterClassEscape"), ee.regexp_eatUnicodePropertyValueExpression = function(o) {
        var d = o.pos;
        if (this.regexp_eatUnicodePropertyName(o) && o.eat(61)) {
          var m = o.lastStringValue;
          if (this.regexp_eatUnicodePropertyValue(o)) {
            var g = o.lastStringValue;
            return this.regexp_validateUnicodePropertyNameAndValue(o, m, g), !0;
          }
        }
        if (o.pos = d, this.regexp_eatLoneUnicodePropertyNameOrValue(o)) {
          var S = o.lastStringValue;
          return this.regexp_validateUnicodePropertyNameOrValue(o, S), !0;
        }
        return !1;
      }, ee.regexp_validateUnicodePropertyNameAndValue = function(o, d, m) {
        Te(o.unicodeProperties.nonBinary, d) || o.raise("Invalid property name"), o.unicodeProperties.nonBinary[d].test(m) || o.raise("Invalid property value");
      }, ee.regexp_validateUnicodePropertyNameOrValue = function(o, d) {
        o.unicodeProperties.binary.test(d) || o.raise("Invalid property name");
      }, ee.regexp_eatUnicodePropertyName = function(o) {
        var d = 0;
        for (o.lastStringValue = ""; i1(d = o.current()); )
          o.lastStringValue += fe(d), o.advance();
        return o.lastStringValue !== "";
      };
      function i1(o) {
        return t1(o) || o === 95;
      }
      l(i1, "isUnicodePropertyNameCharacter"), ee.regexp_eatUnicodePropertyValue = function(o) {
        var d = 0;
        for (o.lastStringValue = ""; u5(d = o.current()); )
          o.lastStringValue += fe(d), o.advance();
        return o.lastStringValue !== "";
      };
      function u5(o) {
        return i1(o) || Pr(o);
      }
      l(u5, "isUnicodePropertyValueCharacter"), ee.regexp_eatLoneUnicodePropertyNameOrValue = function(o) {
        return this.regexp_eatUnicodePropertyValue(o);
      }, ee.regexp_eatCharacterClass = function(o) {
        if (o.eat(91)) {
          if (o.eat(94), this.regexp_classRanges(o), o.eat(93))
            return !0;
          o.raise("Unterminated character class");
        }
        return !1;
      }, ee.regexp_classRanges = function(o) {
        for (; this.regexp_eatClassAtom(o); ) {
          var d = o.lastIntValue;
          if (o.eat(45) && this.regexp_eatClassAtom(o)) {
            var m = o.lastIntValue;
            o.switchU && (d === -1 || m === -1) && o.raise("Invalid character class"), d !== -1 && m !== -1 && d > m && o.raise("Range out of order in character class");
          }
        }
      }, ee.regexp_eatClassAtom = function(o) {
        var d = o.pos;
        if (o.eat(92)) {
          if (this.regexp_eatClassEscape(o))
            return !0;
          if (o.switchU) {
            var m = o.current();
            (m === 99 || r1(m)) && o.raise("Invalid class escape"), o.raise("Invalid escape");
          }
          o.pos = d;
        }
        var g = o.current();
        return g !== 93 ? (o.lastIntValue = g, o.advance(), !0) : !1;
      }, ee.regexp_eatClassEscape = function(o) {
        var d = o.pos;
        if (o.eat(98))
          return o.lastIntValue = 8, !0;
        if (o.switchU && o.eat(45))
          return o.lastIntValue = 45, !0;
        if (!o.switchU && o.eat(99)) {
          if (this.regexp_eatClassControlLetter(o))
            return !0;
          o.pos = d;
        }
        return this.regexp_eatCharacterClassEscape(o) || this.regexp_eatCharacterEscape(o);
      }, ee.regexp_eatClassControlLetter = function(o) {
        var d = o.current();
        return Pr(d) || d === 95 ? (o.lastIntValue = d % 32, o.advance(), !0) : !1;
      }, ee.regexp_eatHexEscapeSequence = function(o) {
        var d = o.pos;
        if (o.eat(120)) {
          if (this.regexp_eatFixedHexDigits(o, 2))
            return !0;
          o.switchU && o.raise("Invalid escape"), o.pos = d;
        }
        return !1;
      }, ee.regexp_eatDecimalDigits = function(o) {
        var d = o.pos, m = 0;
        for (o.lastIntValue = 0; Pr(m = o.current()); )
          o.lastIntValue = 10 * o.lastIntValue + (m - 48), o.advance();
        return o.pos !== d;
      };
      function Pr(o) {
        return o >= 48 && o <= 57;
      }
      l(Pr, "isDecimalDigit"), ee.regexp_eatHexDigits = function(o) {
        var d = o.pos, m = 0;
        for (o.lastIntValue = 0; n1(m = o.current()); )
          o.lastIntValue = 16 * o.lastIntValue + s1(m), o.advance();
        return o.pos !== d;
      };
      function n1(o) {
        return o >= 48 && o <= 57 || o >= 65 && o <= 70 || o >= 97 && o <= 102;
      }
      l(n1, "isHexDigit");
      function s1(o) {
        return o >= 65 && o <= 70 ? 10 + (o - 65) : o >= 97 && o <= 102 ? 10 + (o - 97) : o - 48;
      }
      l(s1, "hexToInt"), ee.regexp_eatLegacyOctalEscapeSequence = function(o) {
        if (this.regexp_eatOctalDigit(o)) {
          var d = o.lastIntValue;
          if (this.regexp_eatOctalDigit(o)) {
            var m = o.lastIntValue;
            d <= 3 && this.regexp_eatOctalDigit(o) ? o.lastIntValue = d * 64 + m * 8 + o.lastIntValue : o.lastIntValue = d * 8 + m;
          } else
            o.lastIntValue = d;
          return !0;
        }
        return !1;
      }, ee.regexp_eatOctalDigit = function(o) {
        var d = o.current();
        return r1(d) ? (o.lastIntValue = d - 48, o.advance(), !0) : (o.lastIntValue = 0, !1);
      };
      function r1(o) {
        return o >= 48 && o <= 55;
      }
      l(r1, "isOctalDigit"), ee.regexp_eatFixedHexDigits = function(o, d) {
        var m = o.pos;
        o.lastIntValue = 0;
        for (var g = 0; g < d; ++g) {
          var S = o.current();
          if (!n1(S))
            return o.pos = m, !1;
          o.lastIntValue = 16 * o.lastIntValue + s1(S), o.advance();
        }
        return !0;
      };
      var ya = /* @__PURE__ */ l(function(d) {
        this.type = d.type, this.value = d.value, this.start = d.start, this.end = d.end, d.options.locations && (this.loc = new ci(d, d.startLoc, d.endLoc)), d.options.ranges && (this.range = [d.start, d.end]);
      }, "Token"), Se = Ye.prototype;
      Se.next = function(o) {
        !o && this.type.keyword && this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword " + this.type.keyword), this.options.onToken && this.options.onToken(new ya(this)), this.lastTokEnd = this.end, this.lastTokStart = this.start, this.lastTokEndLoc = this.endLoc, this.lastTokStartLoc = this.startLoc, this.nextToken();
      }, Se.getToken = function() {
        return this.next(), new ya(this);
      }, typeof Symbol < "u" && (Se[Symbol.iterator] = function() {
        var o = this;
        return {
          next: function() {
            var d = o.getToken();
            return {
              done: d.type === v.eof,
              value: d
            };
          }
        };
      }), Se.nextToken = function() {
        var o = this.curContext();
        if ((!o || !o.preserveSpace) && this.skipSpace(), this.start = this.pos, this.options.locations && (this.startLoc = this.curPosition()), this.pos >= this.input.length)
          return this.finishToken(v.eof);
        if (o.override)
          return o.override(this);
        this.readToken(this.fullCharCodeAtPos());
      }, Se.readToken = function(o) {
        return E(o, this.options.ecmaVersion >= 6) || o === 92 ? this.readWord() : this.getTokenFromCode(o);
      }, Se.fullCharCodeAtPos = function() {
        var o = this.input.charCodeAt(this.pos);
        if (o <= 55295 || o >= 56320)
          return o;
        var d = this.input.charCodeAt(this.pos + 1);
        return d <= 56319 || d >= 57344 ? o : (o << 10) + d - 56613888;
      }, Se.skipBlockComment = function() {
        var o = this.options.onComment && this.curPosition(), d = this.pos, m = this.input.indexOf("*/", this.pos += 2);
        if (m === -1 && this.raise(this.pos - 2, "Unterminated comment"), this.pos = m + 2, this.options.locations)
          for (var g = void 0, S = d; (g = te(this.input, S, this.pos)) > -1; )
            ++this.curLine, S = this.lineStart = g;
        this.options.onComment && this.options.onComment(!0, this.input.slice(d + 2, m), d, this.pos, o, this.curPosition());
      }, Se.skipLineComment = function(o) {
        for (var d = this.pos, m = this.options.onComment && this.curPosition(), g = this.input.charCodeAt(this.pos += o); this.pos < this.input.length && !he(g); )
          g = this.input.charCodeAt(++this.pos);
        this.options.onComment && this.options.onComment(!1, this.input.slice(d + o, this.pos), d, this.pos, m, this.curPosition());
      }, Se.skipSpace = function() {
        e:
          for (; this.pos < this.input.length; ) {
            var o = this.input.charCodeAt(this.pos);
            switch (o) {
              case 32:
              case 160:
                ++this.pos;
                break;
              case 13:
                this.input.charCodeAt(this.pos + 1) === 10 && ++this.pos;
              case 10:
              case 8232:
              case 8233:
                ++this.pos, this.options.locations && (++this.curLine, this.lineStart = this.pos);
                break;
              case 47:
                switch (this.input.charCodeAt(this.pos + 1)) {
                  case 42:
                    this.skipBlockComment();
                    break;
                  case 47:
                    this.skipLineComment(2);
                    break;
                  default:
                    break e;
                }
                break;
              default:
                if (o > 8 && o < 14 || o >= 5760 && Je.test(String.fromCharCode(o)))
                  ++this.pos;
                else
                  break e;
            }
          }
      }, Se.finishToken = function(o, d) {
        this.end = this.pos, this.options.locations && (this.endLoc = this.curPosition());
        var m = this.type;
        this.type = o, this.value = d, this.updateContext(m);
      }, Se.readToken_dot = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        if (o >= 48 && o <= 57)
          return this.readNumber(!0);
        var d = this.input.charCodeAt(this.pos + 2);
        return this.options.ecmaVersion >= 6 && o === 46 && d === 46 ? (this.pos += 3, this.finishToken(v.ellipsis)) : (++this.pos, this.finishToken(v.dot));
      }, Se.readToken_slash = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        return this.exprAllowed ? (++this.pos, this.readRegexp()) : o === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.slash, 1);
      }, Se.readToken_mult_modulo_exp = function(o) {
        var d = this.input.charCodeAt(this.pos + 1), m = 1, g = o === 42 ? v.star : v.modulo;
        return this.options.ecmaVersion >= 7 && o === 42 && d === 42 && (++m, g = v.starstar, d = this.input.charCodeAt(this.pos + 2)), d === 61 ? this.finishOp(v.assign, m + 1) : this.finishOp(g, m);
      }, Se.readToken_pipe_amp = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        if (d === o) {
          if (this.options.ecmaVersion >= 12) {
            var m = this.input.charCodeAt(this.pos + 2);
            if (m === 61)
              return this.finishOp(v.assign, 3);
          }
          return this.finishOp(o === 124 ? v.logicalOR : v.logicalAND, 2);
        }
        return d === 61 ? this.finishOp(v.assign, 2) : this.finishOp(o === 124 ? v.bitwiseOR : v.bitwiseAND, 1);
      }, Se.readToken_caret = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        return o === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.bitwiseXOR, 1);
      }, Se.readToken_plus_min = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        return d === o ? d === 45 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 62 && (this.lastTokEnd === 0 || U.test(this.input.slice(this.lastTokEnd, this.pos))) ? (this.skipLineComment(3), this.skipSpace(), this.nextToken()) : this.finishOp(v.incDec, 2) : d === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.plusMin, 1);
      }, Se.readToken_lt_gt = function(o) {
        var d = this.input.charCodeAt(this.pos + 1), m = 1;
        return d === o ? (m = o === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2, this.input.charCodeAt(this.pos + m) === 61 ? this.finishOp(v.assign, m + 1) : this.finishOp(v.bitShift, m)) : d === 33 && o === 60 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 45 && this.input.charCodeAt(this.pos + 3) === 45 ? (this.skipLineComment(4), this.skipSpace(), this.nextToken()) : (d === 61 && (m = 2), this.finishOp(v.relational, m));
      }, Se.readToken_eq_excl = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        return d === 61 ? this.finishOp(v.equality, this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2) : o === 61 && d === 62 && this.options.ecmaVersion >= 6 ? (this.pos += 2, this.finishToken(v.arrow)) : this.finishOp(o === 61 ? v.eq : v.prefix, 1);
      }, Se.readToken_question = function() {
        var o = this.options.ecmaVersion;
        if (o >= 11) {
          var d = this.input.charCodeAt(this.pos + 1);
          if (d === 46) {
            var m = this.input.charCodeAt(this.pos + 2);
            if (m < 48 || m > 57)
              return this.finishOp(v.questionDot, 2);
          }
          if (d === 63) {
            if (o >= 12) {
              var g = this.input.charCodeAt(this.pos + 2);
              if (g === 61)
                return this.finishOp(v.assign, 3);
            }
            return this.finishOp(v.coalesce, 2);
          }
        }
        return this.finishOp(v.question, 1);
      }, Se.readToken_numberSign = function() {
        var o = this.options.ecmaVersion, d = 35;
        if (o >= 13 && (++this.pos, d = this.fullCharCodeAtPos(), E(d, !0) || d === 92))
          return this.finishToken(v.privateId, this.readWord1());
        this.raise(this.pos, "Unexpected character '" + fe(d) + "'");
      }, Se.getTokenFromCode = function(o) {
        switch (o) {
          case 46:
            return this.readToken_dot();
          case 40:
            return ++this.pos, this.finishToken(v.parenL);
          case 41:
            return ++this.pos, this.finishToken(v.parenR);
          case 59:
            return ++this.pos, this.finishToken(v.semi);
          case 44:
            return ++this.pos, this.finishToken(v.comma);
          case 91:
            return ++this.pos, this.finishToken(v.bracketL);
          case 93:
            return ++this.pos, this.finishToken(v.bracketR);
          case 123:
            return ++this.pos, this.finishToken(v.braceL);
          case 125:
            return ++this.pos, this.finishToken(v.braceR);
          case 58:
            return ++this.pos, this.finishToken(v.colon);
          case 96:
            if (this.options.ecmaVersion < 6)
              break;
            return ++this.pos, this.finishToken(v.backQuote);
          case 48:
            var d = this.input.charCodeAt(this.pos + 1);
            if (d === 120 || d === 88)
              return this.readRadixNumber(16);
            if (this.options.ecmaVersion >= 6) {
              if (d === 111 || d === 79)
                return this.readRadixNumber(8);
              if (d === 98 || d === 66)
                return this.readRadixNumber(2);
            }
          case 49:
          case 50:
          case 51:
          case 52:
          case 53:
          case 54:
          case 55:
          case 56:
          case 57:
            return this.readNumber(!1);
          case 34:
          case 39:
            return this.readString(o);
          case 47:
            return this.readToken_slash();
          case 37:
          case 42:
            return this.readToken_mult_modulo_exp(o);
          case 124:
          case 38:
            return this.readToken_pipe_amp(o);
          case 94:
            return this.readToken_caret();
          case 43:
          case 45:
            return this.readToken_plus_min(o);
          case 60:
          case 62:
            return this.readToken_lt_gt(o);
          case 61:
          case 33:
            return this.readToken_eq_excl(o);
          case 63:
            return this.readToken_question();
          case 126:
            return this.finishOp(v.prefix, 1);
          case 35:
            return this.readToken_numberSign();
        }
        this.raise(this.pos, "Unexpected character '" + fe(o) + "'");
      }, Se.finishOp = function(o, d) {
        var m = this.input.slice(this.pos, this.pos + d);
        return this.pos += d, this.finishToken(o, m);
      }, Se.readRegexp = function() {
        for (var o, d, m = this.pos; ; ) {
          this.pos >= this.input.length && this.raise(m, "Unterminated regular expression");
          var g = this.input.charAt(this.pos);
          if (U.test(g) && this.raise(m, "Unterminated regular expression"), o)
            o = !1;
          else {
            if (g === "[")
              d = !0;
            else if (g === "]" && d)
              d = !1;
            else if (g === "/" && !d)
              break;
            o = g === "\\";
          }
          ++this.pos;
        }
        var S = this.input.slice(m, this.pos);
        ++this.pos;
        var T = this.pos, I = this.readWord1();
        this.containsEsc && this.unexpected(T);
        var V = this.regexpState || (this.regexpState = new Gi(this));
        V.reset(m, S, I), this.validateRegExpFlags(V), this.validateRegExpPattern(V);
        var H = null;
        try {
          H = new RegExp(S, I);
        } catch {
        }
        return this.finishToken(v.regexp, { pattern: S, flags: I, value: H });
      }, Se.readInt = function(o, d, m) {
        for (var g = this.options.ecmaVersion >= 12 && d === void 0, S = m && this.input.charCodeAt(this.pos) === 48, T = this.pos, I = 0, V = 0, H = 0, pe = d ?? 1 / 0; H < pe; ++H, ++this.pos) {
          var _e = this.input.charCodeAt(this.pos), gt = void 0;
          if (g && _e === 95) {
            S && this.raiseRecoverable(this.pos, "Numeric separator is not allowed in legacy octal numeric literals"), V === 95 && this.raiseRecoverable(this.pos, "Numeric separator must be exactly one underscore"), H === 0 && this.raiseRecoverable(this.pos, "Numeric separator is not allowed at the first of digits"), V = _e;
            continue;
          }
          if (_e >= 97 ? gt = _e - 97 + 10 : _e >= 65 ? gt = _e - 65 + 10 : _e >= 48 && _e <= 57 ? gt = _e - 48 : gt = 1 / 0, gt >= o)
            break;
          V = _e, I = I * o + gt;
        }
        return g && V === 95 && this.raiseRecoverable(this.pos - 1, "Numeric separator is not allowed at the last of digits"), this.pos === T || d != null && this.pos - T !== d ? null : I;
      };
      function c5(o, d) {
        return d ? parseInt(o, 8) : parseFloat(o.replace(/_/g, ""));
      }
      l(c5, "stringToNumber");
      function o1(o) {
        return typeof BigInt != "function" ? null : BigInt(o.replace(/_/g, ""));
      }
      l(o1, "stringToBigInt"), Se.readRadixNumber = function(o) {
        var d = this.pos;
        this.pos += 2;
        var m = this.readInt(o);
        return m == null && this.raise(this.start + 2, "Expected number in radix " + o), this.options.ecmaVersion >= 11 && this.input.charCodeAt(this.pos) === 110 ? (m = o1(this.input.slice(d, this.pos)), ++this.pos) : E(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(v.num, m);
      }, Se.readNumber = function(o) {
        var d = this.pos;
        !o && this.readInt(10, void 0, !0) === null && this.raise(d, "Invalid number");
        var m = this.pos - d >= 2 && this.input.charCodeAt(d) === 48;
        m && this.strict && this.raise(d, "Invalid number");
        var g = this.input.charCodeAt(this.pos);
        if (!m && !o && this.options.ecmaVersion >= 11 && g === 110) {
          var S = o1(this.input.slice(d, this.pos));
          return ++this.pos, E(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(v.num, S);
        }
        m && /[89]/.test(this.input.slice(d, this.pos)) && (m = !1), g === 46 && !m && (++this.pos, this.readInt(10), g = this.input.charCodeAt(this.pos)), (g === 69 || g === 101) && !m && (g = this.input.charCodeAt(++this.pos), (g === 43 || g === 45) && ++this.pos, this.readInt(10) === null && this.raise(d, "Invalid number")), E(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number");
        var T = c5(this.input.slice(d, this.pos), m);
        return this.finishToken(v.num, T);
      }, Se.readCodePoint = function() {
        var o = this.input.charCodeAt(this.pos), d;
        if (o === 123) {
          this.options.ecmaVersion < 6 && this.unexpected();
          var m = ++this.pos;
          d = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos), ++this.pos, d > 1114111 && this.invalidStringToken(m, "Code point out of bounds");
        } else
          d = this.readHexChar(4);
        return d;
      }, Se.readString = function(o) {
        for (var d = "", m = ++this.pos; ; ) {
          this.pos >= this.input.length && this.raise(this.start, "Unterminated string constant");
          var g = this.input.charCodeAt(this.pos);
          if (g === o)
            break;
          g === 92 ? (d += this.input.slice(m, this.pos), d += this.readEscapedChar(!1), m = this.pos) : g === 8232 || g === 8233 ? (this.options.ecmaVersion < 10 && this.raise(this.start, "Unterminated string constant"), ++this.pos, this.options.locations && (this.curLine++, this.lineStart = this.pos)) : (he(g) && this.raise(this.start, "Unterminated string constant"), ++this.pos);
        }
        return d += this.input.slice(m, this.pos++), this.finishToken(v.string, d);
      };
      var h5 = {};
      Se.tryReadTemplateToken = function() {
        this.inTemplateElement = !0;
        try {
          this.readTmplToken();
        } catch (o) {
          if (o === h5)
            this.readInvalidTemplateToken();
          else
            throw o;
        }
        this.inTemplateElement = !1;
      }, Se.invalidStringToken = function(o, d) {
        if (this.inTemplateElement && this.options.ecmaVersion >= 9)
          throw h5;
        this.raise(o, d);
      }, Se.readTmplToken = function() {
        for (var o = "", d = this.pos; ; ) {
          this.pos >= this.input.length && this.raise(this.start, "Unterminated template");
          var m = this.input.charCodeAt(this.pos);
          if (m === 96 || m === 36 && this.input.charCodeAt(this.pos + 1) === 123)
            return this.pos === this.start && (this.type === v.template || this.type === v.invalidTemplate) ? m === 36 ? (this.pos += 2, this.finishToken(v.dollarBraceL)) : (++this.pos, this.finishToken(v.backQuote)) : (o += this.input.slice(d, this.pos), this.finishToken(v.template, o));
          if (m === 92)
            o += this.input.slice(d, this.pos), o += this.readEscapedChar(!0), d = this.pos;
          else if (he(m)) {
            switch (o += this.input.slice(d, this.pos), ++this.pos, m) {
              case 13:
                this.input.charCodeAt(this.pos) === 10 && ++this.pos;
              case 10:
                o += `
`;
                break;
              default:
                o += String.fromCharCode(m);
                break;
            }
            this.options.locations && (++this.curLine, this.lineStart = this.pos), d = this.pos;
          } else
            ++this.pos;
        }
      }, Se.readInvalidTemplateToken = function() {
        for (; this.pos < this.input.length; this.pos++)
          switch (this.input[this.pos]) {
            case "\\":
              ++this.pos;
              break;
            case "$":
              if (this.input[this.pos + 1] !== "{")
                break;
            case "`":
              return this.finishToken(v.invalidTemplate, this.input.slice(this.start, this.pos));
          }
        this.raise(this.start, "Unterminated template");
      }, Se.readEscapedChar = function(o) {
        var d = this.input.charCodeAt(++this.pos);
        switch (++this.pos, d) {
          case 110:
            return `
`;
          case 114:
            return "\r";
          case 120:
            return String.fromCharCode(this.readHexChar(2));
          case 117:
            return fe(this.readCodePoint());
          case 116:
            return "	";
          case 98:
            return "\b";
          case 118:
            return "\v";
          case 102:
            return "\f";
          case 13:
            this.input.charCodeAt(this.pos) === 10 && ++this.pos;
          case 10:
            return this.options.locations && (this.lineStart = this.pos, ++this.curLine), "";
          case 56:
          case 57:
            if (this.strict && this.invalidStringToken(this.pos - 1, "Invalid escape sequence"), o) {
              var m = this.pos - 1;
              return this.invalidStringToken(m, "Invalid escape sequence in template string"), null;
            }
          default:
            if (d >= 48 && d <= 55) {
              var g = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0], S = parseInt(g, 8);
              return S > 255 && (g = g.slice(0, -1), S = parseInt(g, 8)), this.pos += g.length - 1, d = this.input.charCodeAt(this.pos), (g !== "0" || d === 56 || d === 57) && (this.strict || o) && this.invalidStringToken(this.pos - 1 - g.length, o ? "Octal literal in template string" : "Octal literal in strict mode"), String.fromCharCode(S);
            }
            return he(d) ? "" : String.fromCharCode(d);
        }
      }, Se.readHexChar = function(o) {
        var d = this.pos, m = this.readInt(16, o);
        return m === null && this.invalidStringToken(d, "Bad character escape sequence"), m;
      }, Se.readWord1 = function() {
        this.containsEsc = !1;
        for (var o = "", d = !0, m = this.pos, g = this.options.ecmaVersion >= 6; this.pos < this.input.length; ) {
          var S = this.fullCharCodeAtPos();
          if (P(S, g))
            this.pos += S <= 65535 ? 1 : 2;
          else if (S === 92) {
            this.containsEsc = !0, o += this.input.slice(m, this.pos);
            var T = this.pos;
            this.input.charCodeAt(++this.pos) !== 117 && this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX"), ++this.pos;
            var I = this.readCodePoint();
            (d ? E : P)(I, g) || this.invalidStringToken(T, "Invalid Unicode escape"), o += fe(I), m = this.pos;
          } else
            break;
          d = !1;
        }
        return o + this.input.slice(m, this.pos);
      }, Se.readWord = function() {
        var o = this.readWord1(), d = v.name;
        return this.keywords.test(o) && (d = z[o]), this.finishToken(d, o);
      };
      var d5 = "8.8.0";
      Ye.acorn = {
        Parser: Ye,
        version: d5,
        defaultOptions: Lt,
        Position: qt,
        SourceLocation: ci,
        getLineInfo: un,
        Node: Ar,
        TokenType: A,
        tokTypes: v,
        keywordTypes: z,
        TokContext: ni,
        tokContexts: We,
        isIdentifierChar: P,
        isIdentifierStart: E,
        Token: ya,
        isNewLine: he,
        lineBreak: U,
        lineBreakG: Z,
        nonASCIIwhitespace: Je
      };
      function p5(o, d) {
        return Ye.parse(o, d);
      }
      l(p5, "parse");
      function f5(o, d, m) {
        return Ye.parseExpressionAt(o, d, m);
      }
      l(f5, "parseExpressionAt");
      function m5(o, d) {
        return Ye.tokenizer(o, d);
      }
      l(m5, "tokenizer"), i.Node = Ar, i.Parser = Ye, i.Position = qt, i.SourceLocation = ci, i.TokContext = ni, i.Token = ya, i.TokenType = A, i.defaultOptions = Lt, i.getLineInfo = un, i.isIdentifierChar = P, i.isIdentifierStart = E, i.isNewLine = he, i.keywordTypes = z, i.lineBreak = U, i.lineBreakG = Z, i.nonASCIIwhitespace = Je, i.parse = p5, i.parseExpressionAt = f5, i.tokContexts = We, i.tokTypes = v, i.tokenizer = m5, i.version = d5, Object.defineProperty(i, "__esModule", { value: !0 });
    });
  }
}), Q3 = J({
  "node_modules/jintr/dist/src/main.js"(e) {
    var t = e && e.__importDefault || function(r) {
      return r && r.__esModule ? r : { default: r };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(J3()), n = Z3(), s = class {
      constructor(r) {
        const a = (0, n.parse)(r, { ecmaVersion: 2020 });
        this.ast = a.body, this.visitor = new i.default(this.ast), this.scope = this.visitor.scope, this.visitor.on("console", (u, c) => {
          if (u.type === "Identifier")
            return console;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((_) => c.visitNode(_)), f = console[h];
          return f ? f(...p) : "proceed";
        }), this.visitor.on("Math", (u, c) => {
          if (u.type === "Identifier")
            return Math;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((_) => c.visitNode(_)), f = Math[h];
          return f ? f(...p) : "proceed";
        }), this.visitor.on("String", (u, c) => {
          if (u.type === "Identifier")
            return String;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((_) => c.visitNode(_)), f = String[h];
          return f ? f(p) : "proceed";
        }), this.visitor.on("Date", (u) => {
          if (u.type === "Identifier")
            return Date;
        });
      }
      interpret() {
        return this.visitor.run();
      }
    };
    l(s, "Jinter"), e.default = s;
  }
}), e7 = J({
  "node_modules/jintr/dist/index.js"(e) {
    var t = e && e.__importDefault || function(n) {
      return n && n.__esModule ? n : { default: n };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(Q3());
    e.default = i.default;
  }
}), t7 = J({
  "node_modules/linkedom/commonjs/perf_hooks.cjs"(e) {
    try {
      const { performance: t } = o9("perf_hooks");
      e.performance = t;
    } catch {
      e.performance = { now() {
        return +new Date();
      } };
    }
  }
}), gr = J({
  "node_modules/boolbase/index.js"(e, t) {
    t.exports = {
      trueFunc: /* @__PURE__ */ l(function() {
        return !0;
      }, "trueFunc"),
      falseFunc: /* @__PURE__ */ l(function() {
        return !1;
      }, "falseFunc")
    };
  }
}), a9 = J({
  "node_modules/cssom/lib/StyleSheet.js"(e) {
    var t = {};
    t.StyleSheet = /* @__PURE__ */ l(function() {
      this.parentStyleSheet = null;
    }, "StyleSheet"), e.StyleSheet = t.StyleSheet;
  }
}), ii = J({
  "node_modules/cssom/lib/CSSRule.js"(e) {
    var t = {};
    t.CSSRule = /* @__PURE__ */ l(function() {
      this.parentRule = null, this.parentStyleSheet = null;
    }, "CSSRule"), t.CSSRule.UNKNOWN_RULE = 0, t.CSSRule.STYLE_RULE = 1, t.CSSRule.CHARSET_RULE = 2, t.CSSRule.IMPORT_RULE = 3, t.CSSRule.MEDIA_RULE = 4, t.CSSRule.FONT_FACE_RULE = 5, t.CSSRule.PAGE_RULE = 6, t.CSSRule.KEYFRAMES_RULE = 7, t.CSSRule.KEYFRAME_RULE = 8, t.CSSRule.MARGIN_RULE = 9, t.CSSRule.NAMESPACE_RULE = 10, t.CSSRule.COUNTER_STYLE_RULE = 11, t.CSSRule.SUPPORTS_RULE = 12, t.CSSRule.DOCUMENT_RULE = 13, t.CSSRule.FONT_FEATURE_VALUES_RULE = 14, t.CSSRule.VIEWPORT_RULE = 15, t.CSSRule.REGION_STYLE_RULE = 16, t.CSSRule.prototype = {
      constructor: t.CSSRule
    }, e.CSSRule = t.CSSRule;
  }
}), eu = J({
  "node_modules/cssom/lib/CSSStyleRule.js"(e) {
    var t = {
      CSSStyleDeclaration: _r().CSSStyleDeclaration,
      CSSRule: ii().CSSRule
    };
    t.CSSStyleRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.selectorText = "", this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSStyleRule"), t.CSSStyleRule.prototype = new t.CSSRule(), t.CSSStyleRule.prototype.constructor = t.CSSStyleRule, t.CSSStyleRule.prototype.type = 1, Object.defineProperty(t.CSSStyleRule.prototype, "cssText", {
      get: function() {
        var i;
        return this.selectorText ? i = this.selectorText + " {" + this.style.cssText + "}" : i = "", i;
      },
      set: function(i) {
        var n = t.CSSStyleRule.parse(i);
        this.style = n.style, this.selectorText = n.selectorText;
      }
    }), t.CSSStyleRule.parse = function(i) {
      for (var n = 0, s = "selector", r, a = n, u = "", c = {
        selector: !0,
        value: !0
      }, h = new t.CSSStyleRule(), p, f = "", _; _ = i.charAt(n); n++)
        switch (_) {
          case " ":
          case "	":
          case "\r":
          case `
`:
          case "\f":
            if (c[s])
              switch (i.charAt(n - 1)) {
                case " ":
                case "	":
                case "\r":
                case `
`:
                case "\f":
                  break;
                default:
                  u += " ";
                  break;
              }
            break;
          case '"':
            if (a = n + 1, r = i.indexOf('"', a) + 1, !r)
              throw '" is missing';
            u += i.slice(n, r), n = r - 1;
            break;
          case "'":
            if (a = n + 1, r = i.indexOf("'", a) + 1, !r)
              throw "' is missing";
            u += i.slice(n, r), n = r - 1;
            break;
          case "/":
            if (i.charAt(n + 1) === "*") {
              if (n += 2, r = i.indexOf("*/", n), r === -1)
                throw new SyntaxError("Missing */");
              n = r + 1;
            } else
              u += _;
            break;
          case "{":
            s === "selector" && (h.selectorText = u.trim(), u = "", s = "name");
            break;
          case ":":
            s === "name" ? (p = u.trim(), u = "", s = "value") : u += _;
            break;
          case "!":
            s === "value" && i.indexOf("!important", n) === n ? (f = "important", n += 9) : u += _;
            break;
          case ";":
            s === "value" ? (h.style.setProperty(p, u.trim(), f), f = "", u = "", s = "name") : u += _;
            break;
          case "}":
            if (s === "value")
              h.style.setProperty(p, u.trim(), f), f = "", u = "";
            else {
              if (s === "name")
                break;
              u += _;
            }
            s = "selector";
            break;
          default:
            u += _;
            break;
        }
      return h;
    }, e.CSSStyleRule = t.CSSStyleRule;
  }
}), tu = J({
  "node_modules/cssom/lib/CSSStyleSheet.js"(e) {
    var t = {
      StyleSheet: a9().StyleSheet,
      CSSStyleRule: eu().CSSStyleRule
    };
    t.CSSStyleSheet = /* @__PURE__ */ l(function() {
      t.StyleSheet.call(this), this.cssRules = [];
    }, "CSSStyleSheet"), t.CSSStyleSheet.prototype = new t.StyleSheet(), t.CSSStyleSheet.prototype.constructor = t.CSSStyleSheet, t.CSSStyleSheet.prototype.insertRule = function(i, n) {
      if (n < 0 || n > this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      var s = t.parse(i).cssRules[0];
      return s.parentStyleSheet = this, this.cssRules.splice(n, 0, s), n;
    }, t.CSSStyleSheet.prototype.deleteRule = function(i) {
      if (i < 0 || i >= this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      this.cssRules.splice(i, 1);
    }, t.CSSStyleSheet.prototype.toString = function() {
      for (var i = "", n = this.cssRules, s = 0; s < n.length; s++)
        i += n[s].cssText + `
`;
      return i;
    }, e.CSSStyleSheet = t.CSSStyleSheet, t.parse = Vc().parse;
  }
}), Lc = J({
  "node_modules/cssom/lib/MediaList.js"(e) {
    var t = {};
    t.MediaList = /* @__PURE__ */ l(function() {
      this.length = 0;
    }, "MediaList"), t.MediaList.prototype = {
      constructor: t.MediaList,
      get mediaText() {
        return Array.prototype.join.call(this, ", ");
      },
      set mediaText(i) {
        for (var n = i.split(","), s = this.length = n.length, r = 0; r < s; r++)
          this[r] = n[r].trim();
      },
      appendMedium: function(i) {
        Array.prototype.indexOf.call(this, i) === -1 && (this[this.length] = i, this.length++);
      },
      deleteMedium: function(i) {
        var n = Array.prototype.indexOf.call(this, i);
        n !== -1 && Array.prototype.splice.call(this, n, 1);
      }
    }, e.MediaList = t.MediaList;
  }
}), l9 = J({
  "node_modules/cssom/lib/CSSImportRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      CSSStyleSheet: tu().CSSStyleSheet,
      MediaList: Lc().MediaList
    };
    t.CSSImportRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.href = "", this.media = new t.MediaList(), this.styleSheet = new t.CSSStyleSheet();
    }, "CSSImportRule"), t.CSSImportRule.prototype = new t.CSSRule(), t.CSSImportRule.prototype.constructor = t.CSSImportRule, t.CSSImportRule.prototype.type = 3, Object.defineProperty(t.CSSImportRule.prototype, "cssText", {
      get: function() {
        var i = this.media.mediaText;
        return "@import url(" + this.href + ")" + (i ? " " + i : "") + ";";
      },
      set: function(i) {
        for (var n = 0, s = "", r = "", a, u; u = i.charAt(n); n++)
          switch (u) {
            case " ":
            case "	":
            case "\r":
            case `
`:
            case "\f":
              s === "after-import" ? s = "url" : r += u;
              break;
            case "@":
              !s && i.indexOf("@import", n) === n && (s = "after-import", n += 6, r = "");
              break;
            case "u":
              if (s === "url" && i.indexOf("url(", n) === n) {
                if (a = i.indexOf(")", n + 1), a === -1)
                  throw n + ': ")" not found';
                n += 4;
                var c = i.slice(n, a);
                c[0] === c[c.length - 1] && (c[0] === '"' || c[0] === "'") && (c = c.slice(1, -1)), this.href = c, n = a, s = "media";
              }
              break;
            case '"':
              if (s === "url") {
                if (a = i.indexOf('"', n + 1), !a)
                  throw n + `: '"' not found`;
                this.href = i.slice(n + 1, a), n = a, s = "media";
              }
              break;
            case "'":
              if (s === "url") {
                if (a = i.indexOf("'", n + 1), !a)
                  throw n + `: "'" not found`;
                this.href = i.slice(n + 1, a), n = a, s = "media";
              }
              break;
            case ";":
              s === "media" && r && (this.media.mediaText = r.trim());
              break;
            default:
              s === "media" && (r += u);
              break;
          }
      }
    }), e.CSSImportRule = t.CSSImportRule;
  }
}), yr = J({
  "node_modules/cssom/lib/CSSGroupingRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule
    };
    t.CSSGroupingRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.cssRules = [];
    }, "CSSGroupingRule"), t.CSSGroupingRule.prototype = new t.CSSRule(), t.CSSGroupingRule.prototype.constructor = t.CSSGroupingRule, t.CSSGroupingRule.prototype.insertRule = /* @__PURE__ */ l(function(n, s) {
      if (s < 0 || s > this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      var r = t.parse(n).cssRules[0];
      return r.parentRule = this, this.cssRules.splice(s, 0, r), s;
    }, "insertRule"), t.CSSGroupingRule.prototype.deleteRule = /* @__PURE__ */ l(function(n) {
      if (n < 0 || n >= this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      this.cssRules.splice(n, 1)[0].parentRule = null;
    }, "deleteRule"), e.CSSGroupingRule = t.CSSGroupingRule;
  }
}), Zo = J({
  "node_modules/cssom/lib/CSSConditionRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      CSSGroupingRule: yr().CSSGroupingRule
    };
    t.CSSConditionRule = /* @__PURE__ */ l(function() {
      t.CSSGroupingRule.call(this), this.cssRules = [];
    }, "CSSConditionRule"), t.CSSConditionRule.prototype = new t.CSSGroupingRule(), t.CSSConditionRule.prototype.constructor = t.CSSConditionRule, t.CSSConditionRule.prototype.conditionText = "", t.CSSConditionRule.prototype.cssText = "", e.CSSConditionRule = t.CSSConditionRule;
  }
}), Dc = J({
  "node_modules/cssom/lib/CSSMediaRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      CSSGroupingRule: yr().CSSGroupingRule,
      CSSConditionRule: Zo().CSSConditionRule,
      MediaList: Lc().MediaList
    };
    t.CSSMediaRule = /* @__PURE__ */ l(function() {
      t.CSSConditionRule.call(this), this.media = new t.MediaList();
    }, "CSSMediaRule"), t.CSSMediaRule.prototype = new t.CSSConditionRule(), t.CSSMediaRule.prototype.constructor = t.CSSMediaRule, t.CSSMediaRule.prototype.type = 4, Object.defineProperties(t.CSSMediaRule.prototype, {
      conditionText: {
        get: function() {
          return this.media.mediaText;
        },
        set: function(i) {
          this.media.mediaText = i;
        },
        configurable: !0,
        enumerable: !0
      },
      cssText: {
        get: function() {
          for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
            i.push(this.cssRules[n].cssText);
          return "@media " + this.media.mediaText + " {" + i.join("") + "}";
        },
        configurable: !0,
        enumerable: !0
      }
    }), e.CSSMediaRule = t.CSSMediaRule;
  }
}), Bc = J({
  "node_modules/cssom/lib/CSSSupportsRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      CSSGroupingRule: yr().CSSGroupingRule,
      CSSConditionRule: Zo().CSSConditionRule
    };
    t.CSSSupportsRule = /* @__PURE__ */ l(function() {
      t.CSSConditionRule.call(this);
    }, "CSSSupportsRule"), t.CSSSupportsRule.prototype = new t.CSSConditionRule(), t.CSSSupportsRule.prototype.constructor = t.CSSSupportsRule, t.CSSSupportsRule.prototype.type = 12, Object.defineProperty(t.CSSSupportsRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@supports " + this.conditionText + " {" + i.join("") + "}";
      }
    }), e.CSSSupportsRule = t.CSSSupportsRule;
  }
}), u9 = J({
  "node_modules/cssom/lib/CSSFontFaceRule.js"(e) {
    var t = {
      CSSStyleDeclaration: _r().CSSStyleDeclaration,
      CSSRule: ii().CSSRule
    };
    t.CSSFontFaceRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSFontFaceRule"), t.CSSFontFaceRule.prototype = new t.CSSRule(), t.CSSFontFaceRule.prototype.constructor = t.CSSFontFaceRule, t.CSSFontFaceRule.prototype.type = 5, Object.defineProperty(t.CSSFontFaceRule.prototype, "cssText", {
      get: function() {
        return "@font-face {" + this.style.cssText + "}";
      }
    }), e.CSSFontFaceRule = t.CSSFontFaceRule;
  }
}), c9 = J({
  "node_modules/cssom/lib/CSSHostRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule
    };
    t.CSSHostRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.cssRules = [];
    }, "CSSHostRule"), t.CSSHostRule.prototype = new t.CSSRule(), t.CSSHostRule.prototype.constructor = t.CSSHostRule, t.CSSHostRule.prototype.type = 1001, Object.defineProperty(t.CSSHostRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@host {" + i.join("") + "}";
      }
    }), e.CSSHostRule = t.CSSHostRule;
  }
}), Oc = J({
  "node_modules/cssom/lib/CSSKeyframeRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      CSSStyleDeclaration: _r().CSSStyleDeclaration
    };
    t.CSSKeyframeRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.keyText = "", this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSKeyframeRule"), t.CSSKeyframeRule.prototype = new t.CSSRule(), t.CSSKeyframeRule.prototype.constructor = t.CSSKeyframeRule, t.CSSKeyframeRule.prototype.type = 8, Object.defineProperty(t.CSSKeyframeRule.prototype, "cssText", {
      get: function() {
        return this.keyText + " {" + this.style.cssText + "} ";
      }
    }), e.CSSKeyframeRule = t.CSSKeyframeRule;
  }
}), Fc = J({
  "node_modules/cssom/lib/CSSKeyframesRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule
    };
    t.CSSKeyframesRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.name = "", this.cssRules = [];
    }, "CSSKeyframesRule"), t.CSSKeyframesRule.prototype = new t.CSSRule(), t.CSSKeyframesRule.prototype.constructor = t.CSSKeyframesRule, t.CSSKeyframesRule.prototype.type = 7, Object.defineProperty(t.CSSKeyframesRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push("  " + this.cssRules[n].cssText);
        return "@" + (this._vendorPrefix || "") + "keyframes " + this.name + ` { 
` + i.join(`
`) + `
}`;
      }
    }), e.CSSKeyframesRule = t.CSSKeyframesRule;
  }
}), h9 = J({
  "node_modules/cssom/lib/CSSValue.js"(e) {
    var t = {};
    t.CSSValue = /* @__PURE__ */ l(function() {
    }, "CSSValue"), t.CSSValue.prototype = {
      constructor: t.CSSValue,
      set cssText(i) {
        var n = this._getConstructorName();
        throw new Error('DOMException: property "cssText" of "' + n + '" is readonly and can not be replaced with "' + i + '"!');
      },
      get cssText() {
        var i = this._getConstructorName();
        throw new Error('getter "cssText" of "' + i + '" is not implemented!');
      },
      _getConstructorName: function() {
        var i = this.constructor.toString(), n = i.match(/function\s([^\(]+)/), s = n[1];
        return s;
      }
    }, e.CSSValue = t.CSSValue;
  }
}), d9 = J({
  "node_modules/cssom/lib/CSSValueExpression.js"(e) {
    var t = {
      CSSValue: h9().CSSValue
    };
    t.CSSValueExpression = /* @__PURE__ */ l(function(n, s) {
      this._token = n, this._idx = s;
    }, "CSSValueExpression"), t.CSSValueExpression.prototype = new t.CSSValue(), t.CSSValueExpression.prototype.constructor = t.CSSValueExpression, t.CSSValueExpression.prototype.parse = function() {
      for (var i = this._token, n = this._idx, s = "", r = "", a = "", u, c = []; ; ++n) {
        if (s = i.charAt(n), s === "") {
          a = "css expression error: unfinished expression!";
          break;
        }
        switch (s) {
          case "(":
            c.push(s), r += s;
            break;
          case ")":
            c.pop(s), r += s;
            break;
          case "/":
            (u = this._parseJSComment(i, n)) ? u.error ? a = "css expression error: unfinished comment in expression!" : n = u.idx : (u = this._parseJSRexExp(i, n)) ? (n = u.idx, r += u.text) : r += s;
            break;
          case "'":
          case '"':
            u = this._parseJSString(i, n, s), u ? (n = u.idx, r += u.text) : r += s;
            break;
          default:
            r += s;
            break;
        }
        if (a || c.length === 0)
          break;
      }
      var h;
      return a ? h = {
        error: a
      } : h = {
        idx: n,
        expression: r
      }, h;
    }, t.CSSValueExpression.prototype._parseJSComment = function(i, n) {
      var s = i.charAt(n + 1), r;
      if (s === "/" || s === "*") {
        var a = n, u, c;
        if (s === "/" ? c = `
` : s === "*" && (c = "*/"), u = i.indexOf(c, a + 1 + 1), u !== -1)
          return u = u + c.length - 1, r = i.substring(n, u + 1), {
            idx: u,
            text: r
          };
        var h = "css expression error: unfinished comment in expression!";
        return {
          error: h
        };
      } else
        return !1;
    }, t.CSSValueExpression.prototype._parseJSString = function(i, n, s) {
      var r = this._findMatchedIdx(i, n, s), a;
      return r === -1 ? !1 : (a = i.substring(n, r + s.length), {
        idx: r,
        text: a
      });
    }, t.CSSValueExpression.prototype._parseJSRexExp = function(i, n) {
      var s = i.substring(0, n).replace(/\s+$/, ""), r = [
        /^$/,
        /\($/,
        /\[$/,
        /\!$/,
        /\+$/,
        /\-$/,
        /\*$/,
        /\/\s+/,
        /\%$/,
        /\=$/,
        /\>$/,
        /<$/,
        /\&$/,
        /\|$/,
        /\^$/,
        /\~$/,
        /\?$/,
        /\,$/,
        /delete$/,
        /in$/,
        /instanceof$/,
        /new$/,
        /typeof$/,
        /void$/
      ], a = r.some(function(c) {
        return c.test(s);
      });
      if (a) {
        var u = "/";
        return this._parseJSString(i, n, u);
      } else
        return !1;
    }, t.CSSValueExpression.prototype._findMatchedIdx = function(i, n, s) {
      for (var r = n, a, u = -1; ; )
        if (a = i.indexOf(s, r + 1), a === -1) {
          a = u;
          break;
        } else {
          var c = i.substring(n + 1, a), h = c.match(/\\+$/);
          if (!h || h[0] % 2 === 0)
            break;
          r = a;
        }
      var p = i.indexOf(`
`, n + 1);
      return p < a && (a = u), a;
    }, e.CSSValueExpression = t.CSSValueExpression;
  }
}), p9 = J({
  "node_modules/cssom/lib/MatcherList.js"(e) {
    var t = {};
    t.MatcherList = /* @__PURE__ */ l(function() {
      this.length = 0;
    }, "MatcherList"), t.MatcherList.prototype = {
      constructor: t.MatcherList,
      get matcherText() {
        return Array.prototype.join.call(this, ", ");
      },
      set matcherText(i) {
        for (var n = i.split(","), s = this.length = n.length, r = 0; r < s; r++)
          this[r] = n[r].trim();
      },
      appendMatcher: function(i) {
        Array.prototype.indexOf.call(this, i) === -1 && (this[this.length] = i, this.length++);
      },
      deleteMatcher: function(i) {
        var n = Array.prototype.indexOf.call(this, i);
        n !== -1 && Array.prototype.splice.call(this, n, 1);
      }
    }, e.MatcherList = t.MatcherList;
  }
}), f9 = J({
  "node_modules/cssom/lib/CSSDocumentRule.js"(e) {
    var t = {
      CSSRule: ii().CSSRule,
      MatcherList: p9().MatcherList
    };
    t.CSSDocumentRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.matcher = new t.MatcherList(), this.cssRules = [];
    }, "CSSDocumentRule"), t.CSSDocumentRule.prototype = new t.CSSRule(), t.CSSDocumentRule.prototype.constructor = t.CSSDocumentRule, t.CSSDocumentRule.prototype.type = 10, Object.defineProperty(t.CSSDocumentRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@-moz-document " + this.matcher.matcherText + " {" + i.join("") + "}";
      }
    }), e.CSSDocumentRule = t.CSSDocumentRule;
  }
}), Vc = J({
  "node_modules/cssom/lib/parse.js"(e) {
    var t = {};
    t.parse = /* @__PURE__ */ l(function(n) {
      for (var s = 0, r = "before-selector", a, u = "", c = 0, h = {
        selector: !0,
        value: !0,
        "value-parenthesis": !0,
        atRule: !0,
        "importRule-begin": !0,
        importRule: !0,
        atBlock: !0,
        conditionBlock: !0,
        "documentRule-begin": !0
      }, p = new t.CSSStyleSheet(), f = p, _, C = [], E = !1, P, A, F = "", M, j, z, D, v, U, Z, he, te = /@(-(?:\w+-)+)?keyframes/g, Je = /* @__PURE__ */ l(function(Ze) {
        var Te = n.substring(0, s).split(`
`), st = Te.length, Ve = Te.pop().length + 1, fe = new Error(Ze + " (line " + st + ", char " + Ve + ")");
        throw fe.line = st, fe.char = Ve, fe.styleSheet = p, fe;
      }, "parseError"), Q; Q = n.charAt(s); s++)
        switch (Q) {
          case " ":
          case "	":
          case "\r":
          case `
`:
          case "\f":
            h[r] && (u += Q);
            break;
          case '"':
            a = s + 1;
            do
              a = n.indexOf('"', a) + 1, a || Je('Unmatched "');
            while (n[a - 2] === "\\");
            switch (u += n.slice(s, a), s = a - 1, r) {
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            break;
          case "'":
            a = s + 1;
            do
              a = n.indexOf("'", a) + 1, a || Je("Unmatched '");
            while (n[a - 2] === "\\");
            switch (u += n.slice(s, a), s = a - 1, r) {
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            break;
          case "/":
            n.charAt(s + 1) === "*" ? (s += 2, a = n.indexOf("*/", s), a === -1 ? Je("Missing */") : s = a + 1) : u += Q, r === "importRule-begin" && (u += " ", r = "importRule");
            break;
          case "@":
            if (n.indexOf("@-moz-document", s) === s) {
              r = "documentRule-begin", Z = new t.CSSDocumentRule(), Z.__starts = s, s += 13, u = "";
              break;
            } else if (n.indexOf("@media", s) === s) {
              r = "atBlock", j = new t.CSSMediaRule(), j.__starts = s, s += 5, u = "";
              break;
            } else if (n.indexOf("@supports", s) === s) {
              r = "conditionBlock", z = new t.CSSSupportsRule(), z.__starts = s, s += 8, u = "";
              break;
            } else if (n.indexOf("@host", s) === s) {
              r = "hostRule-begin", s += 4, he = new t.CSSHostRule(), he.__starts = s, u = "";
              break;
            } else if (n.indexOf("@import", s) === s) {
              r = "importRule-begin", s += 6, u += "@import";
              break;
            } else if (n.indexOf("@font-face", s) === s) {
              r = "fontFaceRule-begin", s += 9, v = new t.CSSFontFaceRule(), v.__starts = s, u = "";
              break;
            } else {
              te.lastIndex = s;
              var ie = te.exec(n);
              if (ie && ie.index === s) {
                r = "keyframesRule-begin", U = new t.CSSKeyframesRule(), U.__starts = s, U._vendorPrefix = ie[1], s += ie[0].length - 1, u = "";
                break;
              } else
                r === "selector" && (r = "atRule");
            }
            u += Q;
            break;
          case "{":
            r === "selector" || r === "atRule" ? (M.selectorText = u.trim(), M.style.__starts = s, u = "", r = "before-name") : r === "atBlock" ? (j.media.mediaText = u.trim(), _ && C.push(_), f = _ = j, j.parentStyleSheet = p, u = "", r = "before-selector") : r === "conditionBlock" ? (z.conditionText = u.trim(), _ && C.push(_), f = _ = z, z.parentStyleSheet = p, u = "", r = "before-selector") : r === "hostRule-begin" ? (_ && C.push(_), f = _ = he, he.parentStyleSheet = p, u = "", r = "before-selector") : r === "fontFaceRule-begin" ? (_ && (v.parentRule = _), v.parentStyleSheet = p, M = v, u = "", r = "before-name") : r === "keyframesRule-begin" ? (U.name = u.trim(), _ && (C.push(_), U.parentRule = _), U.parentStyleSheet = p, f = _ = U, u = "", r = "keyframeRule-begin") : r === "keyframeRule-begin" ? (M = new t.CSSKeyframeRule(), M.keyText = u.trim(), M.__starts = s, u = "", r = "before-name") : r === "documentRule-begin" && (Z.matcher.matcherText = u.trim(), _ && (C.push(_), Z.parentRule = _), f = _ = Z, Z.parentStyleSheet = p, u = "", r = "before-selector");
            break;
          case ":":
            r === "name" ? (A = u.trim(), u = "", r = "before-value") : u += Q;
            break;
          case "(":
            if (r === "value")
              if (u.trim() === "expression") {
                var ye = new t.CSSValueExpression(n, s).parse();
                ye.error ? Je(ye.error) : (u += ye.expression, s = ye.idx);
              } else
                r = "value-parenthesis", c = 1, u += Q;
            else
              r === "value-parenthesis" && c++, u += Q;
            break;
          case ")":
            r === "value-parenthesis" && (c--, c === 0 && (r = "value")), u += Q;
            break;
          case "!":
            r === "value" && n.indexOf("!important", s) === s ? (F = "important", s += 9) : u += Q;
            break;
          case ";":
            switch (r) {
              case "value":
                M.style.setProperty(A, u.trim(), F), F = "", u = "", r = "before-name";
                break;
              case "atRule":
                u = "", r = "before-selector";
                break;
              case "importRule":
                D = new t.CSSImportRule(), D.parentStyleSheet = D.styleSheet.parentStyleSheet = p, D.cssText = u + Q, p.cssRules.push(D), u = "", r = "before-selector";
                break;
              default:
                u += Q;
                break;
            }
            break;
          case "}":
            switch (r) {
              case "value":
                M.style.setProperty(A, u.trim(), F), F = "";
              case "before-name":
              case "name":
                M.__ends = s + 1, _ && (M.parentRule = _), M.parentStyleSheet = p, f.cssRules.push(M), u = "", f.constructor === t.CSSKeyframesRule ? r = "keyframeRule-begin" : r = "before-selector";
                break;
              case "keyframeRule-begin":
              case "before-selector":
              case "selector":
                for (_ || Je("Unexpected }"), E = C.length > 0; C.length > 0; ) {
                  if (_ = C.pop(), _.constructor.name === "CSSMediaRule" || _.constructor.name === "CSSSupportsRule") {
                    P = f, f = _, f.cssRules.push(P);
                    break;
                  }
                  C.length === 0 && (E = !1);
                }
                E || (f.__ends = s + 1, p.cssRules.push(f), f = p, _ = null), u = "", r = "before-selector";
                break;
            }
            break;
          default:
            switch (r) {
              case "before-selector":
                r = "selector", M = new t.CSSStyleRule(), M.__starts = s;
                break;
              case "before-name":
                r = "name";
                break;
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            u += Q;
            break;
        }
      return p;
    }, "parse"), e.parse = t.parse, t.CSSStyleSheet = tu().CSSStyleSheet, t.CSSStyleRule = eu().CSSStyleRule, t.CSSImportRule = l9().CSSImportRule, t.CSSGroupingRule = yr().CSSGroupingRule, t.CSSMediaRule = Dc().CSSMediaRule, t.CSSConditionRule = Zo().CSSConditionRule, t.CSSSupportsRule = Bc().CSSSupportsRule, t.CSSFontFaceRule = u9().CSSFontFaceRule, t.CSSHostRule = c9().CSSHostRule, t.CSSStyleDeclaration = _r().CSSStyleDeclaration, t.CSSKeyframeRule = Oc().CSSKeyframeRule, t.CSSKeyframesRule = Fc().CSSKeyframesRule, t.CSSValueExpression = d9().CSSValueExpression, t.CSSDocumentRule = f9().CSSDocumentRule;
  }
}), _r = J({
  "node_modules/cssom/lib/CSSStyleDeclaration.js"(e) {
    var t = {};
    t.CSSStyleDeclaration = /* @__PURE__ */ l(function() {
      this.length = 0, this.parentRule = null, this._importants = {};
    }, "CSSStyleDeclaration"), t.CSSStyleDeclaration.prototype = {
      constructor: t.CSSStyleDeclaration,
      getPropertyValue: function(i) {
        return this[i] || "";
      },
      setProperty: function(i, n, s) {
        if (this[i]) {
          var r = Array.prototype.indexOf.call(this, i);
          r < 0 && (this[this.length] = i, this.length++);
        } else
          this[this.length] = i, this.length++;
        this[i] = n + "", this._importants[i] = s;
      },
      removeProperty: function(i) {
        if (!(i in this))
          return "";
        var n = Array.prototype.indexOf.call(this, i);
        if (n < 0)
          return "";
        var s = this[i];
        return this[i] = "", Array.prototype.splice.call(this, n, 1), s;
      },
      getPropertyCSSValue: function() {
      },
      getPropertyPriority: function(i) {
        return this._importants[i] || "";
      },
      getPropertyShorthand: function() {
      },
      isPropertyImplicit: function() {
      },
      get cssText() {
        for (var i = [], n = 0, s = this.length; n < s; ++n) {
          var r = this[n], a = this.getPropertyValue(r), u = this.getPropertyPriority(r);
          u && (u = " !" + u), i[n] = r + ": " + a + u + ";";
        }
        return i.join(" ");
      },
      set cssText(i) {
        var n, s;
        for (n = this.length; n--; )
          s = this[n], this[s] = "";
        Array.prototype.splice.call(this, 0, this.length), this._importants = {};
        var r = t.parse("#bogus{" + i + "}").cssRules[0].style, a = r.length;
        for (n = 0; n < a; ++n)
          s = r[n], this.setProperty(r[n], r.getPropertyValue(s), r.getPropertyPriority(s));
      }
    }, e.CSSStyleDeclaration = t.CSSStyleDeclaration, t.parse = Vc().parse;
  }
}), i7 = J({
  "node_modules/cssom/lib/clone.js"(e) {
    var t = {
      CSSStyleSheet: tu().CSSStyleSheet,
      CSSRule: ii().CSSRule,
      CSSStyleRule: eu().CSSStyleRule,
      CSSGroupingRule: yr().CSSGroupingRule,
      CSSConditionRule: Zo().CSSConditionRule,
      CSSMediaRule: Dc().CSSMediaRule,
      CSSSupportsRule: Bc().CSSSupportsRule,
      CSSStyleDeclaration: _r().CSSStyleDeclaration,
      CSSKeyframeRule: Oc().CSSKeyframeRule,
      CSSKeyframesRule: Fc().CSSKeyframesRule
    };
    t.clone = /* @__PURE__ */ l(function i(n) {
      var s = new t.CSSStyleSheet(), r = n.cssRules;
      if (!r)
        return s;
      for (var a = 0, u = r.length; a < u; a++) {
        var c = r[a], h = s.cssRules[a] = new c.constructor(), p = c.style;
        if (p) {
          for (var f = h.style = new t.CSSStyleDeclaration(), _ = 0, C = p.length; _ < C; _++) {
            var E = f[_] = p[_];
            f[E] = p[E], f._importants[E] = p.getPropertyPriority(E);
          }
          f.length = p.length;
        }
        c.hasOwnProperty("keyText") && (h.keyText = c.keyText), c.hasOwnProperty("selectorText") && (h.selectorText = c.selectorText), c.hasOwnProperty("mediaText") && (h.mediaText = c.mediaText), c.hasOwnProperty("conditionText") && (h.conditionText = c.conditionText), c.hasOwnProperty("cssRules") && (h.cssRules = i(c).cssRules);
      }
      return s;
    }, "clone"), e.clone = t.clone;
  }
}), n7 = J({
  "node_modules/cssom/lib/index.js"(e) {
    e.CSSStyleDeclaration = _r().CSSStyleDeclaration, e.CSSRule = ii().CSSRule, e.CSSGroupingRule = yr().CSSGroupingRule, e.CSSConditionRule = Zo().CSSConditionRule, e.CSSStyleRule = eu().CSSStyleRule, e.MediaList = Lc().MediaList, e.CSSMediaRule = Dc().CSSMediaRule, e.CSSSupportsRule = Bc().CSSSupportsRule, e.CSSImportRule = l9().CSSImportRule, e.CSSFontFaceRule = u9().CSSFontFaceRule, e.CSSHostRule = c9().CSSHostRule, e.StyleSheet = a9().StyleSheet, e.CSSStyleSheet = tu().CSSStyleSheet, e.CSSKeyframesRule = Fc().CSSKeyframesRule, e.CSSKeyframeRule = Oc().CSSKeyframeRule, e.MatcherList = p9().MatcherList, e.CSSDocumentRule = f9().CSSDocumentRule, e.CSSValue = h9().CSSValue, e.CSSValueExpression = d9().CSSValueExpression, e.parse = Vc().parse, e.clone = i7().clone;
  }
}), s7 = J({
  "node_modules/linkedom/commonjs/canvas.cjs"(e, t) {
    try {
      t.exports = o9("canvas");
    } catch {
      class n {
        constructor(r, a) {
          this.width = r, this.height = a;
        }
        getContext() {
          return null;
        }
        toDataURL() {
          return "";
        }
      }
      l(n, "Canvas"), t.exports = {
        createCanvas: (s, r) => new n(s, r)
      };
    }
  }
}), r7 = {};
Jo(r7, {
  DownloadError: () => v9,
  InnertubeError: () => x,
  MissingParamError: () => mi,
  NoStreamingDataError: () => y9,
  OAuthError: () => ls,
  ParsingError: () => nn,
  PlayerError: () => En,
  SessionError: () => Uc,
  UnavailableContentError: () => g9,
  debugFetch: () => l7,
  deepCompare: () => kl,
  escapeStringRegexp: () => Al,
  generateRandomString: () => Cs,
  generateSidAuth: () => Hc,
  getRandomUserAgent: () => Qo,
  getRuntime: () => _i,
  getStringBetweenStrings: () => Li,
  hasKeys: () => Xi,
  isServer: () => Wc,
  sha1Hash: () => jc,
  streamToIterable: () => $c,
  throwIfMissing: () => Ue,
  timeToSeconds: () => ji,
  u8ToBase64: () => Ft,
  uuidv4: () => hr
});
var jr = {
  name: "youtubei.js",
  version: "2.2.3",
  description: "Full-featured wrapper around YouTube's private API.",
  main: "./dist/index.js",
  browser: "./bundle/browser.js",
  types: "./dist",
  author: "LuanRT <luan.lrt4@gmail.com> (https://github.com/LuanRT)",
  funding: [
    "https://github.com/sponsors/LuanRT"
  ],
  contributors: [
    "Wykerd (https://github.com/wykerd/)",
    "MasterOfBob777 (https://github.com/MasterOfBob777)",
    "patrickkfkan (https://github.com/patrickkfkan)"
  ],
  directories: {
    test: "./test",
    examples: "./examples",
    dist: "./dist"
  },
  scripts: {
    test: "npx jest --verbose",
    lint: "npx eslint ./src",
    "lint:fix": "npx eslint --fix ./src",
    build: "npm run build:parser-map && npm run build:proto && npm run bundle:browser && npm run bundle:browser:prod && npm run build:node",
    "build:node": "npx tsc",
    "bundle:browser": 'npx tsc --module esnext && npx esbuild ./dist/browser.js --banner:js="/* eslint-disable */" --bundle --target=chrome58 --keep-names --format=esm --sourcemap --define:global=globalThis --outfile=./bundle/browser.js --platform=browser',
    "bundle:browser:prod": "npm run bundle:browser -- --outfile=./bundle/browser.min.js --minify",
    "build:parser-map": "node ./scripts/build-parser-map.js",
    "build:proto": "npx protoc --ts_out ./src/proto --proto_path ./src/proto ./src/proto/youtube.proto",
    prepare: "npm run build",
    watch: "npx tsc --watch"
  },
  repository: {
    type: "git",
    url: "git+https://github.com/LuanRT/YouTube.js.git"
  },
  license: "MIT",
  dependencies: {
    "@protobuf-ts/runtime": "^2.7.0",
    jintr: "^0.3.1",
    linkedom: "^0.14.12",
    undici: "^5.7.0"
  },
  devDependencies: {
    "@protobuf-ts/plugin": "^2.7.0",
    "@types/jest": "^28.1.7",
    "@types/node": "^17.0.45",
    "@typescript-eslint/eslint-plugin": "^5.30.6",
    "@typescript-eslint/parser": "^5.30.6",
    esbuild: "^0.14.49",
    eslint: "^8.19.0",
    "eslint-plugin-tsdoc": "^0.2.16",
    glob: "^8.0.3",
    jest: "^28.1.3",
    "ts-jest": "^28.0.8",
    typescript: "^4.7.4"
  },
  bugs: {
    url: "https://github.com/LuanRT/YouTube.js/issues"
  },
  homepage: "https://github.com/LuanRT/YouTube.js#readme",
  keywords: [
    "yt",
    "dl",
    "ytdl",
    "youtube",
    "youtubedl",
    "youtube-dl",
    "youtube-downloader",
    "youtube-music",
    "innertubeapi",
    "innertube",
    "unofficial",
    "downloader",
    "livechat",
    "studio",
    "upload",
    "ytmusic",
    "search",
    "comment",
    "music",
    "api"
  ]
}, o7 = {
  desktop: [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.62",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.53 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.49",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36"
  ],
  mobile: [
    "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/17.0 Chrome/96.0.4664.104 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G781B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; arm_64; Android 12; RMX3081) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.148 YaBrowser/22.7.3.82.00 SA/3 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; GM1900) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0675.117 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; 21061119BI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; HarmonyOS; TEL-AN10; HMSCore 6.6.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.321 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiBrowser/10.1.1",
    "Mozilla/5.0 (Linux; Android 12; IN2013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; Redmi Note 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 9; moto e6s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; ONEPLUS A6013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G986B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.25 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 7.1.2; Redmi Note 5A Prime) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1"
  ]
}, m9 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, or = function(e) {
  return this instanceof or ? (this.v = e, this) : new or(e);
}, a7 = function(e, t, i) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var n = i.apply(e, t || []), s, r = [];
  return s = {}, a("next"), a("throw"), a("return"), s[Symbol.asyncIterator] = function() {
    return this;
  }, s;
  function a(_) {
    n[_] && (s[_] = function(C) {
      return new Promise(function(E, P) {
        r.push([_, C, E, P]) > 1 || u(_, C);
      });
    });
  }
  function u(_, C) {
    try {
      c(n[_](C));
    } catch (E) {
      f(r[0][3], E);
    }
  }
  function c(_) {
    _.value instanceof or ? Promise.resolve(_.value.v).then(h, p) : f(r[0][2], _);
  }
  function h(_) {
    u("next", _);
  }
  function p(_) {
    u("throw", _);
  }
  function f(_, C) {
    _(C), r.shift(), r.length && u(r[0][0], r[0][1]);
  }
}, x = class extends Error {
  constructor(e, t) {
    super(e), t && (this.info = t), this.date = new Date(), this.version = jr.version;
  }
};
l(x, "InnertubeError");
var nn = class extends x {
};
l(nn, "ParsingError");
var v9 = class extends x {
};
l(v9, "DownloadError");
var mi = class extends x {
};
l(mi, "MissingParamError");
var g9 = class extends x {
};
l(g9, "UnavailableContentError");
var y9 = class extends x {
};
l(y9, "NoStreamingDataError");
var ls = class extends x {
};
l(ls, "OAuthError");
var En = class extends Error {
};
l(En, "PlayerError");
var Uc = class extends Error {
};
l(Uc, "SessionError");
function kl(e, t) {
  return Reflect.ownKeys(e).some((n) => {
    var s;
    const r = ((s = t[n]) === null || s === void 0 ? void 0 : s.constructor.name) === "Text";
    return !r && typeof t[n] == "object" ? JSON.stringify(e[n]) === JSON.stringify(t[n]) : e[n] === (r ? t[n].toString() : t[n]);
  });
}
l(kl, "deepCompare");
function Li(e, t, i) {
  const n = new RegExp(`${Al(t)}(.*?)${Al(i)}`, "s"), s = e.match(n);
  return s ? s[1] : void 0;
}
l(Li, "getStringBetweenStrings");
function Al(e) {
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
l(Al, "escapeStringRegexp");
function Qo(e) {
  const t = o7[e], i = Math.floor(Math.random() * t.length);
  return t[i];
}
l(Qo, "getRandomUserAgent");
function jc(e) {
  return m9(this, void 0, void 0, function* () {
    const t = _i() === "node" ? Reflect.get(module, "require")("crypto").webcrypto.subtle : window.crypto.subtle, i = [
      "00",
      "01",
      "02",
      "03",
      "04",
      "05",
      "06",
      "07",
      "08",
      "09",
      "0a",
      "0b",
      "0c",
      "0d",
      "0e",
      "0f",
      "10",
      "11",
      "12",
      "13",
      "14",
      "15",
      "16",
      "17",
      "18",
      "19",
      "1a",
      "1b",
      "1c",
      "1d",
      "1e",
      "1f",
      "20",
      "21",
      "22",
      "23",
      "24",
      "25",
      "26",
      "27",
      "28",
      "29",
      "2a",
      "2b",
      "2c",
      "2d",
      "2e",
      "2f",
      "30",
      "31",
      "32",
      "33",
      "34",
      "35",
      "36",
      "37",
      "38",
      "39",
      "3a",
      "3b",
      "3c",
      "3d",
      "3e",
      "3f",
      "40",
      "41",
      "42",
      "43",
      "44",
      "45",
      "46",
      "47",
      "48",
      "49",
      "4a",
      "4b",
      "4c",
      "4d",
      "4e",
      "4f",
      "50",
      "51",
      "52",
      "53",
      "54",
      "55",
      "56",
      "57",
      "58",
      "59",
      "5a",
      "5b",
      "5c",
      "5d",
      "5e",
      "5f",
      "60",
      "61",
      "62",
      "63",
      "64",
      "65",
      "66",
      "67",
      "68",
      "69",
      "6a",
      "6b",
      "6c",
      "6d",
      "6e",
      "6f",
      "70",
      "71",
      "72",
      "73",
      "74",
      "75",
      "76",
      "77",
      "78",
      "79",
      "7a",
      "7b",
      "7c",
      "7d",
      "7e",
      "7f",
      "80",
      "81",
      "82",
      "83",
      "84",
      "85",
      "86",
      "87",
      "88",
      "89",
      "8a",
      "8b",
      "8c",
      "8d",
      "8e",
      "8f",
      "90",
      "91",
      "92",
      "93",
      "94",
      "95",
      "96",
      "97",
      "98",
      "99",
      "9a",
      "9b",
      "9c",
      "9d",
      "9e",
      "9f",
      "a0",
      "a1",
      "a2",
      "a3",
      "a4",
      "a5",
      "a6",
      "a7",
      "a8",
      "a9",
      "aa",
      "ab",
      "ac",
      "ad",
      "ae",
      "af",
      "b0",
      "b1",
      "b2",
      "b3",
      "b4",
      "b5",
      "b6",
      "b7",
      "b8",
      "b9",
      "ba",
      "bb",
      "bc",
      "bd",
      "be",
      "bf",
      "c0",
      "c1",
      "c2",
      "c3",
      "c4",
      "c5",
      "c6",
      "c7",
      "c8",
      "c9",
      "ca",
      "cb",
      "cc",
      "cd",
      "ce",
      "cf",
      "d0",
      "d1",
      "d2",
      "d3",
      "d4",
      "d5",
      "d6",
      "d7",
      "d8",
      "d9",
      "da",
      "db",
      "dc",
      "dd",
      "de",
      "df",
      "e0",
      "e1",
      "e2",
      "e3",
      "e4",
      "e5",
      "e6",
      "e7",
      "e8",
      "e9",
      "ea",
      "eb",
      "ec",
      "ed",
      "ee",
      "ef",
      "f0",
      "f1",
      "f2",
      "f3",
      "f4",
      "f5",
      "f6",
      "f7",
      "f8",
      "f9",
      "fa",
      "fb",
      "fc",
      "fd",
      "fe",
      "ff"
    ];
    function n(s) {
      const r = new Uint8Array(s), a = [];
      for (let u = 0; u < r.length; ++u)
        a.push(i[r[u]]);
      return a.join("");
    }
    return l(n, "hex"), n(yield t.digest("SHA-1", new TextEncoder().encode(e)));
  });
}
l(jc, "sha1Hash");
function Hc(e) {
  return m9(this, void 0, void 0, function* () {
    const t = "https://www.youtube.com", i = Math.floor(new Date().getTime() / 1e3), n = [i, e, t].join(" "), s = yield jc(n);
    return ["SAPISIDHASH", [i, s].join("_")].join(" ");
  });
}
l(Hc, "generateSidAuth");
function Cs(e) {
  const t = [], i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  for (let n = 0; n < e; n++)
    t.push(i.charAt(Math.floor(Math.random() * i.length)));
  return t.join("");
}
l(Cs, "generateRandomString");
function ji(e) {
  const t = e.split(":").map((i) => parseInt(i));
  switch (t.length) {
    case 1:
      return t[0];
    case 2:
      return t[0] * 60 + t[1];
    case 3:
      return t[0] * 3600 + t[1] * 60 + t[2];
    default:
      throw new Error("Invalid time string");
  }
}
l(ji, "timeToSeconds");
function Ue(e) {
  for (const [t, i] of Object.entries(e))
    if (!i)
      throw new mi(`${t} is missing`);
}
l(Ue, "throwIfMissing");
function Xi(e, ...t) {
  for (const i of t)
    if (!Reflect.has(e, i) || e[i] === void 0)
      return !1;
  return !0;
}
l(Xi, "hasKeys");
function hr() {
  var e;
  return _i() === "node" ? Reflect.get(module, "require")("crypto").webcrypto.randomUUID() : !((e = globalThis.crypto) === null || e === void 0) && e.randomUUID() ? globalThis.crypto.randomUUID() : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (t) => {
    const i = parseInt(t);
    return (i ^ window.crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> i / 4).toString(16);
  });
}
l(hr, "uuidv4");
function _i() {
  var e;
  return typeof process < "u" && ((e = process == null ? void 0 : process.versions) === null || e === void 0 ? void 0 : e.node) ? "node" : Reflect.has(globalThis, "Deno") ? "deno" : "browser";
}
l(_i, "getRuntime");
function Wc() {
  return ["node", "deno"].includes(_i());
}
l(Wc, "isServer");
function $c(e) {
  return a7(this, arguments, /* @__PURE__ */ l(function* () {
    const i = e.getReader();
    try {
      for (; ; ) {
        const { done: n, value: s } = yield or(i.read());
        if (n)
          return yield or(void 0);
        yield yield or(s);
      }
    } finally {
      i.releaseLock();
    }
  }, "streamToIterable_1"));
}
l($c, "streamToIterable");
var l7 = /* @__PURE__ */ l((e, t) => {
  const i = typeof e == "string" ? new URL(e) : e instanceof URL ? e : new URL(e.url), n = t?.headers ? new Headers(t.headers) : e instanceof Request ? e.headers : new Headers(), s = [...n], r = t?.body ? typeof t.body == "string" ? n.get("content-type") === "application/json" ? JSON.stringify(JSON.parse(t.body), null, 2) : t.body : "    <binary>" : "    (none)", a = s.length > 0 ? `${s.map(([u, c]) => `    ${u}: ${c}`).join(`
`)}` : "    (none)";
  return console.log(`YouTube.js Fetch:
  url: ${i.toString()}
  method: ${t?.method || "GET"}
  headers:
${a}
' + 
    '  body:
${r}`), globalThis.fetch(e, t);
}, "debugFetch");
function Ft(e) {
  return btoa(String.fromCharCode.apply(null, Array.from(e)));
}
l(Ft, "u8ToBase64");
var _9 = {};
Jo(_9, {
  CLIENTS: () => Il,
  INNERTUBE_HEADERS_BASE: () => C9,
  OAUTH: () => w9,
  STREAM_HEADERS: () => S9,
  URLS: () => b9,
  default: () => ve
});
var b9 = Object.freeze({
  YT_BASE: "https://www.youtube.com",
  YT_MUSIC_BASE: "https://music.youtube.com",
  YT_SUGGESTIONS: "https://suggestqueries.google.com/complete/",
  YT_UPLOAD: "https://upload.youtube.com/",
  API: Object.freeze({
    BASE: "https://youtubei.googleapis.com",
    PRODUCTION_1: "https://www.youtube.com/youtubei/",
    PRODUCTION_2: "https://youtubei.googleapis.com/youtubei/",
    STAGING: "https://green-youtubei.sandbox.googleapis.com/youtubei/",
    RELEASE: "https://release-youtubei.sandbox.googleapis.com/youtubei/",
    TEST: "https://test-youtubei.sandbox.googleapis.com/youtubei/",
    CAMI: "http://cami-youtubei.sandbox.googleapis.com/youtubei/",
    UYTFE: "https://uytfe.sandbox.google.com/youtubei/"
  })
}), w9 = Object.freeze({
  SCOPE: "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content",
  GRANT_TYPE: "http://oauth.net/grant_type/device/1.0",
  MODEL_NAME: "ytlr::",
  HEADERS: Object.freeze({
    accept: "*/*",
    origin: "https://www.youtube.com",
    "user-agent": "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
    "content-type": "application/json",
    referer: "https://www.youtube.com/tv",
    "accept-language": "en-US"
  }),
  REGEX: Object.freeze({
    AUTH_SCRIPT: /<script id="base-js" src="(.*?)" nonce=".*?"><\/script>/,
    CLIENT_IDENTITY: new RegExp('.+?={};var .+?={clientId:"(?<client_id>.+?)",.+?:"(?<client_secret>.+?)"},')
  })
}), Il = Object.freeze({
  WEB: {
    NAME: "WEB",
    VERSION: "2.20220902.01.00"
  },
  YTMUSIC: {
    NAME: "WEB_REMIX",
    VERSION: "1.20211213.00.00"
  },
  ANDROID: {
    NAME: "ANDROID",
    VERSION: "17.17.32",
    SDK_VERSION: "29"
  },
  YTMUSIC_ANDROID: {
    NAME: "ANDROID_MUSIC",
    VERSION: "5.17.51"
  },
  TV_EMBEDDED: {
    NAME: "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
    VERSION: "2.0"
  }
}), S9 = Object.freeze({
  accept: "*/*",
  origin: "https://www.youtube.com",
  referer: "https://www.youtube.com",
  DNT: "?1"
}), C9 = Object.freeze({
  accept: "*/*",
  "accept-encoding": "gzip, deflate",
  "content-type": "application/json"
}), ve = {
  URLS: b9,
  OAUTH: w9,
  CLIENTS: Il,
  STREAM_HEADERS: S9,
  INNERTUBE_HEADERS_BASE: C9
}, x5 = Wi(e7()), Ca = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ta = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ci = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Hs, Ws, Hr, Wr, kn = class {
  constructor(e, t, i, n) {
    Hs.set(this, void 0), Ws.set(this, void 0), Hr.set(this, void 0), Wr.set(this, void 0), Ta(this, Hs, i, "f"), Ta(this, Ws, t, "f"), Ta(this, Hr, e, "f"), Ta(this, Wr, n, "f");
  }
  static create(e, t = globalThis.fetch) {
    return Ca(this, void 0, void 0, function* () {
      const i = new URL("/iframe_api", ve.URLS.YT_BASE), n = yield t(i);
      if (n.status !== 200)
        throw new En("Failed to request player id");
      const s = yield n.text(), r = Li(s, "player\\/", "\\/");
      if (!r)
        throw new En("Failed to get player id");
      if (e) {
        const _ = yield kn.fromCache(e, r);
        if (_)
          return _;
      }
      const a = new URL(`/s/player/${r}/player_ias.vflset/en_US/base.js`, ve.URLS.YT_BASE), u = yield t(a, {
        headers: {
          "user-agent": Qo("desktop")
        }
      });
      if (!u.ok)
        throw new En(`Failed to get player data: ${u.status}`);
      const c = yield u.text(), h = this.extractSigTimestamp(c), p = this.extractSigSourceCode(c), f = this.extractNSigSourceCode(c);
      return yield kn.fromSource(e, h, p, f, r);
    });
  }
  decipher(e, t, i) {
    if (e = e || t || i, !e)
      throw new En("No valid URL to decipher");
    const n = new URLSearchParams(e), s = new URL(n.get("url") || e);
    if (s.searchParams.set("ratebypass", "yes"), t || i) {
      const a = new x5.default(Ci(this, Ws, "f"));
      a.scope.set("sig", n.get("s"));
      const u = a.interpret(), c = n.get("sp");
      c ? s.searchParams.set(c, u) : s.searchParams.set("signature", u);
    }
    const r = s.searchParams.get("n");
    if (r) {
      const a = new x5.default(Ci(this, Hs, "f"));
      a.scope.set("nsig", r);
      const u = a.interpret();
      u.startsWith("enhanced_except_") && console.warn(`Warning:
Could not transform nsig, download may be throttled.
Changing the InnerTube client to "ANDROID" might help!`), s.searchParams.set("n", u);
    }
    return s.toString();
  }
  static fromCache(e, t) {
    return Ca(this, void 0, void 0, function* () {
      const i = yield e.get(t);
      if (!i)
        return null;
      const n = new DataView(i);
      if (n.getUint32(0, !0) !== kn.LIBRARY_VERSION)
        return null;
      const r = n.getUint32(4, !0), a = n.getUint32(8, !0), u = i.slice(12, 12 + a), c = i.slice(12 + a), h = new TextDecoder(), p = h.decode(u), f = h.decode(c);
      return new kn(r, p, f, t);
    });
  }
  static fromSource(e, t, i, n, s) {
    return Ca(this, void 0, void 0, function* () {
      const r = new kn(t, i, n, s);
      return yield r.cache(e), r;
    });
  }
  cache(e) {
    return Ca(this, void 0, void 0, function* () {
      if (!e)
        return;
      const t = new TextEncoder(), i = t.encode(Ci(this, Ws, "f")), n = t.encode(Ci(this, Hs, "f")), s = new ArrayBuffer(12 + i.byteLength + n.byteLength), r = new DataView(s);
      r.setUint32(0, kn.LIBRARY_VERSION, !0), r.setUint32(4, Ci(this, Hr, "f"), !0), r.setUint32(8, i.byteLength, !0), new Uint8Array(s).set(i, 12), new Uint8Array(s).set(n, 12 + i.byteLength), yield e.set(Ci(this, Wr, "f"), new Uint8Array(s));
    });
  }
  static extractSigTimestamp(e) {
    return parseInt(Li(e, "signatureTimestamp:", ",") || "0");
  }
  static extractSigSourceCode(e) {
    var t, i;
    const n = Li(e, 'function(a){a=a.split("")', 'return a.join("")}'), s = (i = (t = n?.split(".")) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.replace(";", ""), r = Li(e, `var ${s}=`, "};");
    return (!r || !n) && console.warn(new En("Failed to extract signature decipher algorithm")), `function descramble_sig(a) { a = a.split(""); let ${s}=${r}}${n} return a.join("") } descramble_sig(sig);`;
  }
  static extractNSigSourceCode(e) {
    const t = `function descramble_nsig(a) { let b=a.split("")${Li(e, 'b=a.split("")', '}return b.join("")}')}} return b.join(""); } descramble_nsig(nsig)`;
    return t || console.warn(new En("Failed to extract n-token decipher algorithm")), t;
  }
  get url() {
    return new URL(`/s/player/${Ci(this, Wr, "f")}/player_ias.vflset/en_US/base.js`, ve.URLS.YT_BASE).toString();
  }
  get sts() {
    return Ci(this, Hr, "f");
  }
  get nsig_sc() {
    return Ci(this, Hs, "f");
  }
  get sig_sc() {
    return Ci(this, Ws, "f");
  }
  static get LIBRARY_VERSION() {
    return 2;
  }
};
l(kn, "Player");
Hs = /* @__PURE__ */ new WeakMap(), Ws = /* @__PURE__ */ new WeakMap(), Hr = /* @__PURE__ */ new WeakMap(), Wr = /* @__PURE__ */ new WeakMap();
function Gc(e) {
  let t = typeof e;
  if (t == "object") {
    if (Array.isArray(e))
      return "array";
    if (e === null)
      return "null";
  }
  return t;
}
l(Gc, "typeofJsonValue");
function T9(e) {
  return e !== null && typeof e == "object" && !Array.isArray(e);
}
l(T9, "isJsonObject");
var Zi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), iu = [];
for (let e = 0; e < Zi.length; e++)
  iu[Zi[e].charCodeAt(0)] = e;
iu["-".charCodeAt(0)] = Zi.indexOf("+");
iu["_".charCodeAt(0)] = Zi.indexOf("/");
function x9(e) {
  let t = e.length * 3 / 4;
  e[e.length - 2] == "=" ? t -= 2 : e[e.length - 1] == "=" && (t -= 1);
  let i = new Uint8Array(t), n = 0, s = 0, r, a = 0;
  for (let u = 0; u < e.length; u++) {
    if (r = iu[e.charCodeAt(u)], r === void 0)
      switch (e[u]) {
        case "=":
          s = 0;
        case `
`:
        case "\r":
        case "	":
        case " ":
          continue;
        default:
          throw Error("invalid base64 string.");
      }
    switch (s) {
      case 0:
        a = r, s = 1;
        break;
      case 1:
        i[n++] = a << 2 | (r & 48) >> 4, a = r, s = 2;
        break;
      case 2:
        i[n++] = (a & 15) << 4 | (r & 60) >> 2, a = r, s = 3;
        break;
      case 3:
        i[n++] = (a & 3) << 6 | r, s = 0;
        break;
    }
  }
  if (s == 1)
    throw Error("invalid base64 string.");
  return i.subarray(0, n);
}
l(x9, "base64decode");
function E9(e) {
  let t = "", i = 0, n, s = 0;
  for (let r = 0; r < e.length; r++)
    switch (n = e[r], i) {
      case 0:
        t += Zi[n >> 2], s = (n & 3) << 4, i = 1;
        break;
      case 1:
        t += Zi[s | n >> 4], s = (n & 15) << 2, i = 2;
        break;
      case 2:
        t += Zi[s | n >> 6], t += Zi[n & 63], i = 0;
        break;
    }
  return i && (t += Zi[s], t += "=", i == 1 && (t += "=")), t;
}
l(E9, "base64encode");
var W;
(function(e) {
  e.symbol = Symbol.for("protobuf-ts/unknown"), e.onRead = (i, n, s, r, a) => {
    (t(n) ? n[e.symbol] : n[e.symbol] = []).push({ no: s, wireType: r, data: a });
  }, e.onWrite = (i, n, s) => {
    for (let { no: r, wireType: a, data: u } of e.list(n))
      s.tag(r, a).raw(u);
  }, e.list = (i, n) => {
    if (t(i)) {
      let s = i[e.symbol];
      return n ? s.filter((r) => r.no == n) : s;
    }
    return [];
  }, e.last = (i, n) => e.list(i, n).slice(-1)[0];
  const t = /* @__PURE__ */ l((i) => i && Array.isArray(i[e.symbol]), "is");
})(W || (W = {}));
var L;
(function(e) {
  e[e.Varint = 0] = "Varint", e[e.Bit64 = 1] = "Bit64", e[e.LengthDelimited = 2] = "LengthDelimited", e[e.StartGroup = 3] = "StartGroup", e[e.EndGroup = 4] = "EndGroup", e[e.Bit32 = 5] = "Bit32";
})(L || (L = {}));
function k9() {
  let e = 0, t = 0;
  for (let n = 0; n < 28; n += 7) {
    let s = this.buf[this.pos++];
    if (e |= (s & 127) << n, (s & 128) == 0)
      return this.assertBounds(), [e, t];
  }
  let i = this.buf[this.pos++];
  if (e |= (i & 15) << 28, t = (i & 112) >> 4, (i & 128) == 0)
    return this.assertBounds(), [e, t];
  for (let n = 3; n <= 31; n += 7) {
    let s = this.buf[this.pos++];
    if (t |= (s & 127) << n, (s & 128) == 0)
      return this.assertBounds(), [e, t];
  }
  throw new Error("invalid varint");
}
l(k9, "varint64read");
function $a(e, t, i) {
  for (let r = 0; r < 28; r = r + 7) {
    const a = e >>> r, u = !(a >>> 7 == 0 && t == 0), c = (u ? a | 128 : a) & 255;
    if (i.push(c), !u)
      return;
  }
  const n = e >>> 28 & 15 | (t & 7) << 4, s = t >> 3 != 0;
  if (i.push((s ? n | 128 : n) & 255), !!s) {
    for (let r = 3; r < 31; r = r + 7) {
      const a = t >>> r, u = a >>> 7 != 0, c = (u ? a | 128 : a) & 255;
      if (i.push(c), !u)
        return;
    }
    i.push(t >>> 31 & 1);
  }
}
l($a, "varint64write");
var Ga = (1 << 16) * (1 << 16);
function qc(e) {
  let t = e[0] == "-";
  t && (e = e.slice(1));
  const i = 1e6;
  let n = 0, s = 0;
  function r(a, u) {
    const c = Number(e.slice(a, u));
    s *= i, n = n * i + c, n >= Ga && (s = s + (n / Ga | 0), n = n % Ga);
  }
  return l(r, "add1e6digit"), r(-24, -18), r(-18, -12), r(-12, -6), r(-6), [t, n, s];
}
l(qc, "int64fromString");
function Pl(e, t) {
  if (t <= 2097151)
    return "" + (Ga * t + e);
  let i = e & 16777215, n = (e >>> 24 | t << 8) >>> 0 & 16777215, s = t >> 16 & 65535, r = i + n * 6777216 + s * 6710656, a = n + s * 8147497, u = s * 2, c = 1e7;
  r >= c && (a += Math.floor(r / c), r %= c), a >= c && (u += Math.floor(a / c), a %= c);
  function h(p, f) {
    let _ = p ? String(p) : "";
    return f ? "0000000".slice(_.length) + _ : _;
  }
  return l(h, "decimalFrom1e7"), h(u, 0) + h(a, u) + h(r, 1);
}
l(Pl, "int64toString");
function J1(e, t) {
  if (e >= 0) {
    for (; e > 127; )
      t.push(e & 127 | 128), e = e >>> 7;
    t.push(e);
  } else {
    for (let i = 0; i < 9; i++)
      t.push(e & 127 | 128), e = e >> 7;
    t.push(1);
  }
}
l(J1, "varint32write");
function A9() {
  let e = this.buf[this.pos++], t = e & 127;
  if ((e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 7, (e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 14, (e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 21, (e & 128) == 0)
    return this.assertBounds(), t;
  e = this.buf[this.pos++], t |= (e & 15) << 28;
  for (let i = 5; (e & 128) !== 0 && i < 10; i++)
    e = this.buf[this.pos++];
  if ((e & 128) != 0)
    throw new Error("invalid varint");
  return this.assertBounds(), t >>> 0;
}
l(A9, "varint32read");
function I9() {
  const e = new DataView(new ArrayBuffer(8));
  return globalThis.BigInt !== void 0 && typeof e.getBigInt64 == "function" && typeof e.getBigUint64 == "function" && typeof e.setBigInt64 == "function" && typeof e.setBigUint64 == "function" ? {
    MIN: BigInt("-9223372036854775808"),
    MAX: BigInt("9223372036854775807"),
    UMIN: BigInt("0"),
    UMAX: BigInt("18446744073709551615"),
    C: BigInt,
    V: e
  } : void 0;
}
l(I9, "detectBi");
var je = I9();
function Kc(e) {
  if (!e)
    throw new Error("BigInt unavailable, see https://github.com/timostamm/protobuf-ts/blob/v1.0.8/MANUAL.md#bigint-support");
}
l(Kc, "assertBi");
var P9 = /^-?[0-9]+$/, Ml = (1 << 16) * (1 << 16), zc = class {
  constructor(e, t) {
    this.lo = e | 0, this.hi = t | 0;
  }
  isZero() {
    return this.lo == 0 && this.hi == 0;
  }
  toNumber() {
    let e = this.hi * Ml + (this.lo >>> 0);
    if (!Number.isSafeInteger(e))
      throw new Error("cannot convert to safe number");
    return e;
  }
};
l(zc, "SharedPbLong");
var xt = class extends zc {
  static from(e) {
    if (je)
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e == "")
            throw new Error("string is no integer");
          e = je.C(e);
        case "number":
          if (e === 0)
            return this.ZERO;
          e = je.C(e);
        case "bigint":
          if (!e)
            return this.ZERO;
          if (e < je.UMIN)
            throw new Error("signed value for ulong");
          if (e > je.UMAX)
            throw new Error("ulong too large");
          return je.V.setBigUint64(0, e, !0), new xt(je.V.getInt32(0, !0), je.V.getInt32(4, !0));
      }
    else
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e = e.trim(), !P9.test(e))
            throw new Error("string is no integer");
          let [t, i, n] = qc(e);
          if (t)
            throw new Error("signed value");
          return new xt(i, n);
        case "number":
          if (e == 0)
            return this.ZERO;
          if (!Number.isSafeInteger(e))
            throw new Error("number is no integer");
          if (e < 0)
            throw new Error("signed value for ulong");
          return new xt(e, e / Ml);
      }
    throw new Error("unknown value " + typeof e);
  }
  toString() {
    return je ? this.toBigInt().toString() : Pl(this.lo, this.hi);
  }
  toBigInt() {
    return Kc(je), je.V.setInt32(0, this.lo, !0), je.V.setInt32(4, this.hi, !0), je.V.getBigUint64(0, !0);
  }
};
l(xt, "PbULong");
xt.ZERO = new xt(0, 0);
var it = class extends zc {
  static from(e) {
    if (je)
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e == "")
            throw new Error("string is no integer");
          e = je.C(e);
        case "number":
          if (e === 0)
            return this.ZERO;
          e = je.C(e);
        case "bigint":
          if (!e)
            return this.ZERO;
          if (e < je.MIN)
            throw new Error("ulong too small");
          if (e > je.MAX)
            throw new Error("ulong too large");
          return je.V.setBigInt64(0, e, !0), new it(je.V.getInt32(0, !0), je.V.getInt32(4, !0));
      }
    else
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e = e.trim(), !P9.test(e))
            throw new Error("string is no integer");
          let [t, i, n] = qc(e), s = new it(i, n);
          return t ? s.negate() : s;
        case "number":
          if (e == 0)
            return this.ZERO;
          if (!Number.isSafeInteger(e))
            throw new Error("number is no integer");
          return e > 0 ? new it(e, e / Ml) : new it(-e, -e / Ml).negate();
      }
    throw new Error("unknown value " + typeof e);
  }
  isNegative() {
    return (this.hi & 2147483648) !== 0;
  }
  negate() {
    let e = ~this.hi, t = this.lo;
    return t ? t = ~t + 1 : e += 1, new it(t, e);
  }
  toString() {
    if (je)
      return this.toBigInt().toString();
    if (this.isNegative()) {
      let e = this.negate();
      return "-" + Pl(e.lo, e.hi);
    }
    return Pl(this.lo, this.hi);
  }
  toBigInt() {
    return Kc(je), je.V.setInt32(0, this.lo, !0), je.V.setInt32(4, this.hi, !0), je.V.getBigInt64(0, !0);
  }
};
l(it, "PbLong");
it.ZERO = new it(0, 0);
var E5 = {
  readUnknownField: !0,
  readerFactory: (e) => new N9(e)
};
function M9(e) {
  return e ? Object.assign(Object.assign({}, E5), e) : E5;
}
l(M9, "binaryReadOptions");
var N9 = class {
  constructor(e, t) {
    this.varint64 = k9, this.uint32 = A9, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.textDecoder = t ?? new TextDecoder("utf-8", {
      fatal: !0
    });
  }
  tag() {
    let e = this.uint32(), t = e >>> 3, i = e & 7;
    if (t <= 0 || i < 0 || i > 5)
      throw new Error("illegal tag: field no " + t + " wire type " + i);
    return [t, i];
  }
  skip(e) {
    let t = this.pos;
    switch (e) {
      case L.Varint:
        for (; this.buf[this.pos++] & 128; )
          ;
        break;
      case L.Bit64:
        this.pos += 4;
      case L.Bit32:
        this.pos += 4;
        break;
      case L.LengthDelimited:
        let i = this.uint32();
        this.pos += i;
        break;
      case L.StartGroup:
        let n;
        for (; (n = this.tag()[1]) !== L.EndGroup; )
          this.skip(n);
        break;
      default:
        throw new Error("cant skip wire type " + e);
    }
    return this.assertBounds(), this.buf.subarray(t, this.pos);
  }
  assertBounds() {
    if (this.pos > this.len)
      throw new RangeError("premature EOF");
  }
  int32() {
    return this.uint32() | 0;
  }
  sint32() {
    let e = this.uint32();
    return e >>> 1 ^ -(e & 1);
  }
  int64() {
    return new it(...this.varint64());
  }
  uint64() {
    return new xt(...this.varint64());
  }
  sint64() {
    let [e, t] = this.varint64(), i = -(e & 1);
    return e = (e >>> 1 | (t & 1) << 31) ^ i, t = t >>> 1 ^ i, new it(e, t);
  }
  bool() {
    let [e, t] = this.varint64();
    return e !== 0 || t !== 0;
  }
  fixed32() {
    return this.view.getUint32((this.pos += 4) - 4, !0);
  }
  sfixed32() {
    return this.view.getInt32((this.pos += 4) - 4, !0);
  }
  fixed64() {
    return new xt(this.sfixed32(), this.sfixed32());
  }
  sfixed64() {
    return new it(this.sfixed32(), this.sfixed32());
  }
  float() {
    return this.view.getFloat32((this.pos += 4) - 4, !0);
  }
  double() {
    return this.view.getFloat64((this.pos += 8) - 8, !0);
  }
  bytes() {
    let e = this.uint32(), t = this.pos;
    return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
  }
  string() {
    return this.textDecoder.decode(this.bytes());
  }
};
l(N9, "BinaryReader");
function Pe(e, t) {
  if (!e)
    throw new Error(t);
}
l(Pe, "assert");
var u7 = 34028234663852886e22, c7 = -34028234663852886e22, h7 = 4294967295, d7 = 2147483647, p7 = -2147483648;
function ar(e) {
  if (typeof e != "number")
    throw new Error("invalid int 32: " + typeof e);
  if (!Number.isInteger(e) || e > d7 || e < p7)
    throw new Error("invalid int 32: " + e);
}
l(ar, "assertInt32");
function jo(e) {
  if (typeof e != "number")
    throw new Error("invalid uint 32: " + typeof e);
  if (!Number.isInteger(e) || e > h7 || e < 0)
    throw new Error("invalid uint 32: " + e);
}
l(jo, "assertUInt32");
function nu(e) {
  if (typeof e != "number")
    throw new Error("invalid float 32: " + typeof e);
  if (!!Number.isFinite(e) && (e > u7 || e < c7))
    throw new Error("invalid float 32: " + e);
}
l(nu, "assertFloat32");
var k5 = {
  writeUnknownFields: !0,
  writerFactory: () => new L9()
};
function R9(e) {
  return e ? Object.assign(Object.assign({}, k5), e) : k5;
}
l(R9, "binaryWriteOptions");
var L9 = class {
  constructor(e) {
    this.stack = [], this.textEncoder = e ?? new TextEncoder(), this.chunks = [], this.buf = [];
  }
  finish() {
    this.chunks.push(new Uint8Array(this.buf));
    let e = 0;
    for (let n = 0; n < this.chunks.length; n++)
      e += this.chunks[n].length;
    let t = new Uint8Array(e), i = 0;
    for (let n = 0; n < this.chunks.length; n++)
      t.set(this.chunks[n], i), i += this.chunks[n].length;
    return this.chunks = [], t;
  }
  fork() {
    return this.stack.push({ chunks: this.chunks, buf: this.buf }), this.chunks = [], this.buf = [], this;
  }
  join() {
    let e = this.finish(), t = this.stack.pop();
    if (!t)
      throw new Error("invalid state, fork stack empty");
    return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
  }
  tag(e, t) {
    return this.uint32((e << 3 | t) >>> 0);
  }
  raw(e) {
    return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
  }
  uint32(e) {
    for (jo(e); e > 127; )
      this.buf.push(e & 127 | 128), e = e >>> 7;
    return this.buf.push(e), this;
  }
  int32(e) {
    return ar(e), J1(e, this.buf), this;
  }
  bool(e) {
    return this.buf.push(e ? 1 : 0), this;
  }
  bytes(e) {
    return this.uint32(e.byteLength), this.raw(e);
  }
  string(e) {
    let t = this.textEncoder.encode(e);
    return this.uint32(t.byteLength), this.raw(t);
  }
  float(e) {
    nu(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
  }
  double(e) {
    let t = new Uint8Array(8);
    return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
  }
  fixed32(e) {
    jo(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
  }
  sfixed32(e) {
    ar(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
  }
  sint32(e) {
    return ar(e), e = (e << 1 ^ e >> 31) >>> 0, J1(e, this.buf), this;
  }
  sfixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), n = it.from(e);
    return i.setInt32(0, n.lo, !0), i.setInt32(4, n.hi, !0), this.raw(t);
  }
  fixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), n = xt.from(e);
    return i.setInt32(0, n.lo, !0), i.setInt32(4, n.hi, !0), this.raw(t);
  }
  int64(e) {
    let t = it.from(e);
    return $a(t.lo, t.hi, this.buf), this;
  }
  sint64(e) {
    let t = it.from(e), i = t.hi >> 31, n = t.lo << 1 ^ i, s = (t.hi << 1 | t.lo >>> 31) ^ i;
    return $a(n, s, this.buf), this;
  }
  uint64(e) {
    let t = xt.from(e);
    return $a(t.lo, t.hi, this.buf), this;
  }
};
l(L9, "BinaryWriter");
var A5 = {
  emitDefaultValues: !1,
  enumAsInteger: !1,
  useProtoFieldName: !1,
  prettySpaces: 0
}, I5 = {
  ignoreUnknownFields: !1
};
function D9(e) {
  return e ? Object.assign(Object.assign({}, I5), e) : I5;
}
l(D9, "jsonReadOptions");
function B9(e) {
  return e ? Object.assign(Object.assign({}, A5), e) : A5;
}
l(B9, "jsonWriteOptions");
var be = Symbol.for("protobuf-ts/message-type");
function Z1(e) {
  let t = !1;
  const i = [];
  for (let n = 0; n < e.length; n++) {
    let s = e.charAt(n);
    s == "_" ? t = !0 : /\d/.test(s) ? (i.push(s), t = !0) : t ? (i.push(s.toUpperCase()), t = !1) : n == 0 ? i.push(s.toLowerCase()) : i.push(s);
  }
  return i.join("");
}
l(Z1, "lowerCamelCase");
var N;
(function(e) {
  e[e.DOUBLE = 1] = "DOUBLE", e[e.FLOAT = 2] = "FLOAT", e[e.INT64 = 3] = "INT64", e[e.UINT64 = 4] = "UINT64", e[e.INT32 = 5] = "INT32", e[e.FIXED64 = 6] = "FIXED64", e[e.FIXED32 = 7] = "FIXED32", e[e.BOOL = 8] = "BOOL", e[e.STRING = 9] = "STRING", e[e.BYTES = 12] = "BYTES", e[e.UINT32 = 13] = "UINT32", e[e.SFIXED32 = 15] = "SFIXED32", e[e.SFIXED64 = 16] = "SFIXED64", e[e.SINT32 = 17] = "SINT32", e[e.SINT64 = 18] = "SINT64";
})(N || (N = {}));
var Oi;
(function(e) {
  e[e.BIGINT = 0] = "BIGINT", e[e.STRING = 1] = "STRING", e[e.NUMBER = 2] = "NUMBER";
})(Oi || (Oi = {}));
var Nl;
(function(e) {
  e[e.NO = 0] = "NO", e[e.PACKED = 1] = "PACKED", e[e.UNPACKED = 2] = "UNPACKED";
})(Nl || (Nl = {}));
function O9(e) {
  var t, i, n, s;
  return e.localName = (t = e.localName) !== null && t !== void 0 ? t : Z1(e.name), e.jsonName = (i = e.jsonName) !== null && i !== void 0 ? i : Z1(e.name), e.repeat = (n = e.repeat) !== null && n !== void 0 ? n : Nl.NO, e.opt = (s = e.opt) !== null && s !== void 0 ? s : e.repeat || e.oneof ? !1 : e.kind == "message", e;
}
l(O9, "normalizeFieldInfo");
function F9(e) {
  if (typeof e != "object" || e === null || !e.hasOwnProperty("oneofKind"))
    return !1;
  switch (typeof e.oneofKind) {
    case "string":
      return e[e.oneofKind] === void 0 ? !1 : Object.keys(e).length == 2;
    case "undefined":
      return Object.keys(e).length == 1;
    default:
      return !1;
  }
}
l(F9, "isOneofGroup");
var V9 = class {
  constructor(e) {
    var t;
    this.fields = (t = e.fields) !== null && t !== void 0 ? t : [];
  }
  prepare() {
    if (this.data)
      return;
    const e = [], t = [], i = [];
    for (let n of this.fields)
      if (n.oneof)
        i.includes(n.oneof) || (i.push(n.oneof), e.push(n.oneof), t.push(n.oneof));
      else
        switch (t.push(n.localName), n.kind) {
          case "scalar":
          case "enum":
            (!n.opt || n.repeat) && e.push(n.localName);
            break;
          case "message":
            n.repeat && e.push(n.localName);
            break;
          case "map":
            e.push(n.localName);
            break;
        }
    this.data = { req: e, known: t, oneofs: Object.values(i) };
  }
  is(e, t, i = !1) {
    if (t < 0)
      return !0;
    if (e == null || typeof e != "object")
      return !1;
    this.prepare();
    let n = Object.keys(e), s = this.data;
    if (n.length < s.req.length || s.req.some((r) => !n.includes(r)) || !i && n.some((r) => !s.known.includes(r)))
      return !1;
    if (t < 1)
      return !0;
    for (const r of s.oneofs) {
      const a = e[r];
      if (!F9(a))
        return !1;
      if (a.oneofKind === void 0)
        continue;
      const u = this.fields.find((c) => c.localName === a.oneofKind);
      if (!u || !this.field(a[a.oneofKind], u, i, t))
        return !1;
    }
    for (const r of this.fields)
      if (r.oneof === void 0 && !this.field(e[r.localName], r, i, t))
        return !1;
    return !0;
  }
  field(e, t, i, n) {
    let s = t.repeat;
    switch (t.kind) {
      case "scalar":
        return e === void 0 ? t.opt : s ? this.scalars(e, t.T, n, t.L) : this.scalar(e, t.T, t.L);
      case "enum":
        return e === void 0 ? t.opt : s ? this.scalars(e, N.INT32, n) : this.scalar(e, N.INT32);
      case "message":
        return e === void 0 ? !0 : s ? this.messages(e, t.T(), i, n) : this.message(e, t.T(), i, n);
      case "map":
        if (typeof e != "object" || e === null)
          return !1;
        if (n < 2)
          return !0;
        if (!this.mapKeys(e, t.K, n))
          return !1;
        switch (t.V.kind) {
          case "scalar":
            return this.scalars(Object.values(e), t.V.T, n, t.V.L);
          case "enum":
            return this.scalars(Object.values(e), N.INT32, n);
          case "message":
            return this.messages(Object.values(e), t.V.T(), i, n);
        }
        break;
    }
    return !0;
  }
  message(e, t, i, n) {
    return i ? t.isAssignable(e, n) : t.is(e, n);
  }
  messages(e, t, i, n) {
    if (!Array.isArray(e))
      return !1;
    if (n < 2)
      return !0;
    if (i) {
      for (let s = 0; s < e.length && s < n; s++)
        if (!t.isAssignable(e[s], n - 1))
          return !1;
    } else
      for (let s = 0; s < e.length && s < n; s++)
        if (!t.is(e[s], n - 1))
          return !1;
    return !0;
  }
  scalar(e, t, i) {
    let n = typeof e;
    switch (t) {
      case N.UINT64:
      case N.FIXED64:
      case N.INT64:
      case N.SFIXED64:
      case N.SINT64:
        switch (i) {
          case Oi.BIGINT:
            return n == "bigint";
          case Oi.NUMBER:
            return n == "number" && !isNaN(e);
          default:
            return n == "string";
        }
      case N.BOOL:
        return n == "boolean";
      case N.STRING:
        return n == "string";
      case N.BYTES:
        return e instanceof Uint8Array;
      case N.DOUBLE:
      case N.FLOAT:
        return n == "number" && !isNaN(e);
      default:
        return n == "number" && Number.isInteger(e);
    }
  }
  scalars(e, t, i, n) {
    if (!Array.isArray(e))
      return !1;
    if (i < 2)
      return !0;
    if (Array.isArray(e)) {
      for (let s = 0; s < e.length && s < i; s++)
        if (!this.scalar(e[s], t, n))
          return !1;
    }
    return !0;
  }
  mapKeys(e, t, i) {
    let n = Object.keys(e);
    switch (t) {
      case N.INT32:
      case N.FIXED32:
      case N.SFIXED32:
      case N.SINT32:
      case N.UINT32:
        return this.scalars(n.slice(0, i).map((s) => parseInt(s)), t, i);
      case N.BOOL:
        return this.scalars(n.slice(0, i).map((s) => s == "true" ? !0 : s == "false" ? !1 : s), t, i);
      default:
        return this.scalars(n, t, i, Oi.STRING);
    }
  }
};
l(V9, "ReflectionTypeCheck");
function li(e, t) {
  switch (t) {
    case Oi.BIGINT:
      return e.toBigInt();
    case Oi.NUMBER:
      return e.toNumber();
    default:
      return e.toString();
  }
}
l(li, "reflectionLongConvert");
var U9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    var e;
    if (this.fMap === void 0) {
      this.fMap = {};
      const t = (e = this.info.fields) !== null && e !== void 0 ? e : [];
      for (const i of t)
        this.fMap[i.name] = i, this.fMap[i.jsonName] = i, this.fMap[i.localName] = i;
    }
  }
  assert(e, t, i) {
    if (!e) {
      let n = Gc(i);
      throw (n == "number" || n == "boolean") && (n = i.toString()), new Error(`Cannot parse JSON ${n} for ${this.info.typeName}#${t}`);
    }
  }
  read(e, t, i) {
    this.prepare();
    const n = [];
    for (const [s, r] of Object.entries(e)) {
      const a = this.fMap[s];
      if (!a) {
        if (!i.ignoreUnknownFields)
          throw new Error(`Found unknown field while reading ${this.info.typeName} from JSON format. JSON key: ${s}`);
        continue;
      }
      const u = a.localName;
      let c;
      if (a.oneof) {
        if (n.includes(a.oneof))
          throw new Error(`Multiple members of the oneof group "${a.oneof}" of ${this.info.typeName} are present in JSON.`);
        n.push(a.oneof), c = t[a.oneof] = {
          oneofKind: u
        };
      } else
        c = t;
      if (a.kind == "map") {
        if (r === null)
          continue;
        this.assert(T9(r), a.name, r);
        const h = c[u];
        for (const [p, f] of Object.entries(r)) {
          this.assert(f !== null, a.name + " map value", null);
          let _;
          switch (a.V.kind) {
            case "message":
              _ = a.V.T().internalJsonRead(f, i);
              break;
            case "enum":
              if (_ = this.enum(a.V.T(), f, a.name, i.ignoreUnknownFields), _ === !1)
                continue;
              break;
            case "scalar":
              _ = this.scalar(f, a.V.T, a.V.L, a.name);
              break;
          }
          this.assert(_ !== void 0, a.name + " map value", f);
          let C = p;
          a.K == N.BOOL && (C = C == "true" ? !0 : C == "false" ? !1 : C), C = this.scalar(C, a.K, Oi.STRING, a.name).toString(), h[C] = _;
        }
      } else if (a.repeat) {
        if (r === null)
          continue;
        this.assert(Array.isArray(r), a.name, r);
        const h = c[u];
        for (const p of r) {
          this.assert(p !== null, a.name, null);
          let f;
          switch (a.kind) {
            case "message":
              f = a.T().internalJsonRead(p, i);
              break;
            case "enum":
              if (f = this.enum(a.T(), p, a.name, i.ignoreUnknownFields), f === !1)
                continue;
              break;
            case "scalar":
              f = this.scalar(p, a.T, a.L, a.name);
              break;
          }
          this.assert(f !== void 0, a.name, r), h.push(f);
        }
      } else
        switch (a.kind) {
          case "message":
            if (r === null && a.T().typeName != "google.protobuf.Value") {
              this.assert(a.oneof === void 0, a.name + " (oneof member)", null);
              continue;
            }
            c[u] = a.T().internalJsonRead(r, i, c[u]);
            break;
          case "enum":
            let h = this.enum(a.T(), r, a.name, i.ignoreUnknownFields);
            if (h === !1)
              continue;
            c[u] = h;
            break;
          case "scalar":
            c[u] = this.scalar(r, a.T, a.L, a.name);
            break;
        }
    }
  }
  enum(e, t, i, n) {
    if (e[0] == "google.protobuf.NullValue" && Pe(t === null, `Unable to parse field ${this.info.typeName}#${i}, enum ${e[0]} only accepts null.`), t === null)
      return 0;
    switch (typeof t) {
      case "number":
        return Pe(Number.isInteger(t), `Unable to parse field ${this.info.typeName}#${i}, enum can only be integral number, got ${t}.`), t;
      case "string":
        let s = t;
        e[2] && t.substring(0, e[2].length) === e[2] && (s = t.substring(e[2].length));
        let r = e[1][s];
        return typeof r > "u" && n ? !1 : (Pe(typeof r == "number", `Unable to parse field ${this.info.typeName}#${i}, enum ${e[0]} has no value for "${t}".`), r);
    }
    Pe(!1, `Unable to parse field ${this.info.typeName}#${i}, cannot parse enum value from ${typeof t}".`);
  }
  scalar(e, t, i, n) {
    let s;
    try {
      switch (t) {
        case N.DOUBLE:
        case N.FLOAT:
          if (e === null)
            return 0;
          if (e === "NaN")
            return Number.NaN;
          if (e === "Infinity")
            return Number.POSITIVE_INFINITY;
          if (e === "-Infinity")
            return Number.NEGATIVE_INFINITY;
          if (e === "") {
            s = "empty string";
            break;
          }
          if (typeof e == "string" && e.trim().length !== e.length) {
            s = "extra whitespace";
            break;
          }
          if (typeof e != "string" && typeof e != "number")
            break;
          let r = Number(e);
          if (Number.isNaN(r)) {
            s = "not a number";
            break;
          }
          if (!Number.isFinite(r)) {
            s = "too large or small";
            break;
          }
          return t == N.FLOAT && nu(r), r;
        case N.INT32:
        case N.FIXED32:
        case N.SFIXED32:
        case N.SINT32:
        case N.UINT32:
          if (e === null)
            return 0;
          let a;
          if (typeof e == "number" ? a = e : e === "" ? s = "empty string" : typeof e == "string" && (e.trim().length !== e.length ? s = "extra whitespace" : a = Number(e)), a === void 0)
            break;
          return t == N.UINT32 ? jo(a) : ar(a), a;
        case N.INT64:
        case N.SFIXED64:
        case N.SINT64:
          if (e === null)
            return li(it.ZERO, i);
          if (typeof e != "number" && typeof e != "string")
            break;
          return li(it.from(e), i);
        case N.FIXED64:
        case N.UINT64:
          if (e === null)
            return li(xt.ZERO, i);
          if (typeof e != "number" && typeof e != "string")
            break;
          return li(xt.from(e), i);
        case N.BOOL:
          if (e === null)
            return !1;
          if (typeof e != "boolean")
            break;
          return e;
        case N.STRING:
          if (e === null)
            return "";
          if (typeof e != "string") {
            s = "extra whitespace";
            break;
          }
          try {
            encodeURIComponent(e);
          } catch (u) {
            u = "invalid UTF8";
            break;
          }
          return e;
        case N.BYTES:
          if (e === null || e === "")
            return new Uint8Array(0);
          if (typeof e != "string")
            break;
          return x9(e);
      }
    } catch (r) {
      s = r.message;
    }
    this.assert(!1, n + (s ? " - " + s : ""), e);
  }
};
l(U9, "ReflectionJsonReader");
var j9 = class {
  constructor(e) {
    var t;
    this.fields = (t = e.fields) !== null && t !== void 0 ? t : [];
  }
  write(e, t) {
    const i = {}, n = e;
    for (const s of this.fields) {
      if (!s.oneof) {
        let c = this.field(s, n[s.localName], t);
        c !== void 0 && (i[t.useProtoFieldName ? s.name : s.jsonName] = c);
        continue;
      }
      const r = n[s.oneof];
      if (r.oneofKind !== s.localName)
        continue;
      const a = s.kind == "scalar" || s.kind == "enum" ? Object.assign(Object.assign({}, t), { emitDefaultValues: !0 }) : t;
      let u = this.field(s, r[s.localName], a);
      Pe(u !== void 0), i[t.useProtoFieldName ? s.name : s.jsonName] = u;
    }
    return i;
  }
  field(e, t, i) {
    let n;
    if (e.kind == "map") {
      Pe(typeof t == "object" && t !== null);
      const s = {};
      switch (e.V.kind) {
        case "scalar":
          for (const [u, c] of Object.entries(t)) {
            const h = this.scalar(e.V.T, c, e.name, !1, !0);
            Pe(h !== void 0), s[u.toString()] = h;
          }
          break;
        case "message":
          const r = e.V.T();
          for (const [u, c] of Object.entries(t)) {
            const h = this.message(r, c, e.name, i);
            Pe(h !== void 0), s[u.toString()] = h;
          }
          break;
        case "enum":
          const a = e.V.T();
          for (const [u, c] of Object.entries(t)) {
            Pe(c === void 0 || typeof c == "number");
            const h = this.enum(a, c, e.name, !1, !0, i.enumAsInteger);
            Pe(h !== void 0), s[u.toString()] = h;
          }
          break;
      }
      (i.emitDefaultValues || Object.keys(s).length > 0) && (n = s);
    } else if (e.repeat) {
      Pe(Array.isArray(t));
      const s = [];
      switch (e.kind) {
        case "scalar":
          for (let u = 0; u < t.length; u++) {
            const c = this.scalar(e.T, t[u], e.name, e.opt, !0);
            Pe(c !== void 0), s.push(c);
          }
          break;
        case "enum":
          const r = e.T();
          for (let u = 0; u < t.length; u++) {
            Pe(t[u] === void 0 || typeof t[u] == "number");
            const c = this.enum(r, t[u], e.name, e.opt, !0, i.enumAsInteger);
            Pe(c !== void 0), s.push(c);
          }
          break;
        case "message":
          const a = e.T();
          for (let u = 0; u < t.length; u++) {
            const c = this.message(a, t[u], e.name, i);
            Pe(c !== void 0), s.push(c);
          }
          break;
      }
      (i.emitDefaultValues || s.length > 0 || i.emitDefaultValues) && (n = s);
    } else
      switch (e.kind) {
        case "scalar":
          n = this.scalar(e.T, t, e.name, e.opt, i.emitDefaultValues);
          break;
        case "enum":
          n = this.enum(e.T(), t, e.name, e.opt, i.emitDefaultValues, i.enumAsInteger);
          break;
        case "message":
          n = this.message(e.T(), t, e.name, i);
          break;
      }
    return n;
  }
  enum(e, t, i, n, s, r) {
    if (e[0] == "google.protobuf.NullValue")
      return null;
    if (t === void 0) {
      Pe(n);
      return;
    }
    if (!(t === 0 && !s && !n))
      return Pe(typeof t == "number"), Pe(Number.isInteger(t)), r || !e[1].hasOwnProperty(t) ? t : e[2] ? e[2] + e[1][t] : e[1][t];
  }
  message(e, t, i, n) {
    return t === void 0 ? n.emitDefaultValues ? null : void 0 : e.internalJsonWrite(t, n);
  }
  scalar(e, t, i, n, s) {
    if (t === void 0) {
      Pe(n);
      return;
    }
    const r = s || n;
    switch (e) {
      case N.INT32:
      case N.SFIXED32:
      case N.SINT32:
        return t === 0 ? r ? 0 : void 0 : (ar(t), t);
      case N.FIXED32:
      case N.UINT32:
        return t === 0 ? r ? 0 : void 0 : (jo(t), t);
      case N.FLOAT:
        nu(t);
      case N.DOUBLE:
        return t === 0 ? r ? 0 : void 0 : (Pe(typeof t == "number"), Number.isNaN(t) ? "NaN" : t === Number.POSITIVE_INFINITY ? "Infinity" : t === Number.NEGATIVE_INFINITY ? "-Infinity" : t);
      case N.STRING:
        return t === "" ? r ? "" : void 0 : (Pe(typeof t == "string"), t);
      case N.BOOL:
        return t === !1 ? r ? !1 : void 0 : (Pe(typeof t == "boolean"), t);
      case N.UINT64:
      case N.FIXED64:
        Pe(typeof t == "number" || typeof t == "string" || typeof t == "bigint");
        let a = xt.from(t);
        return a.isZero() && !r ? void 0 : a.toString();
      case N.INT64:
      case N.SFIXED64:
      case N.SINT64:
        Pe(typeof t == "number" || typeof t == "string" || typeof t == "bigint");
        let u = it.from(t);
        return u.isZero() && !r ? void 0 : u.toString();
      case N.BYTES:
        return Pe(t instanceof Uint8Array), t.byteLength ? E9(t) : r ? "" : void 0;
    }
  }
};
l(j9, "ReflectionJsonWriter");
function Rl(e, t = Oi.STRING) {
  switch (e) {
    case N.BOOL:
      return !1;
    case N.UINT64:
    case N.FIXED64:
      return li(xt.ZERO, t);
    case N.INT64:
    case N.SFIXED64:
    case N.SINT64:
      return li(it.ZERO, t);
    case N.DOUBLE:
    case N.FLOAT:
      return 0;
    case N.BYTES:
      return new Uint8Array(0);
    case N.STRING:
      return "";
    default:
      return 0;
  }
}
l(Rl, "reflectionScalarDefault");
var H9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    var e;
    if (!this.fieldNoToField) {
      const t = (e = this.info.fields) !== null && e !== void 0 ? e : [];
      this.fieldNoToField = new Map(t.map((i) => [i.no, i]));
    }
  }
  read(e, t, i, n) {
    this.prepare();
    const s = n === void 0 ? e.len : e.pos + n;
    for (; e.pos < s; ) {
      const [r, a] = e.tag(), u = this.fieldNoToField.get(r);
      if (!u) {
        let f = i.readUnknownField;
        if (f == "throw")
          throw new Error(`Unknown field ${r} (wire type ${a}) for ${this.info.typeName}`);
        let _ = e.skip(a);
        f !== !1 && (f === !0 ? W.onRead : f)(this.info.typeName, t, r, a, _);
        continue;
      }
      let c = t, h = u.repeat, p = u.localName;
      switch (u.oneof && (c = c[u.oneof], c.oneofKind !== p && (c = t[u.oneof] = {
        oneofKind: p
      })), u.kind) {
        case "scalar":
        case "enum":
          let f = u.kind == "enum" ? N.INT32 : u.T, _ = u.kind == "scalar" ? u.L : void 0;
          if (h) {
            let P = c[p];
            if (a == L.LengthDelimited && f != N.STRING && f != N.BYTES) {
              let A = e.uint32() + e.pos;
              for (; e.pos < A; )
                P.push(this.scalar(e, f, _));
            } else
              P.push(this.scalar(e, f, _));
          } else
            c[p] = this.scalar(e, f, _);
          break;
        case "message":
          if (h) {
            let P = c[p], A = u.T().internalBinaryRead(e, e.uint32(), i);
            P.push(A);
          } else
            c[p] = u.T().internalBinaryRead(e, e.uint32(), i, c[p]);
          break;
        case "map":
          let [C, E] = this.mapEntry(u, e, i);
          c[p][C] = E;
          break;
      }
    }
  }
  mapEntry(e, t, i) {
    let n = t.uint32(), s = t.pos + n, r, a;
    for (; t.pos < s; ) {
      let [u, c] = t.tag();
      switch (u) {
        case 1:
          e.K == N.BOOL ? r = t.bool().toString() : r = this.scalar(t, e.K, Oi.STRING);
          break;
        case 2:
          switch (e.V.kind) {
            case "scalar":
              a = this.scalar(t, e.V.T, e.V.L);
              break;
            case "enum":
              a = t.int32();
              break;
            case "message":
              a = e.V.T().internalBinaryRead(t, t.uint32(), i);
              break;
          }
          break;
        default:
          throw new Error(`Unknown field ${u} (wire type ${c}) in map entry for ${this.info.typeName}#${e.name}`);
      }
    }
    if (r === void 0) {
      let u = Rl(e.K);
      r = e.K == N.BOOL ? u.toString() : u;
    }
    if (a === void 0)
      switch (e.V.kind) {
        case "scalar":
          a = Rl(e.V.T, e.V.L);
          break;
        case "enum":
          a = 0;
          break;
        case "message":
          a = e.V.T().create();
          break;
      }
    return [r, a];
  }
  scalar(e, t, i) {
    switch (t) {
      case N.INT32:
        return e.int32();
      case N.STRING:
        return e.string();
      case N.BOOL:
        return e.bool();
      case N.DOUBLE:
        return e.double();
      case N.FLOAT:
        return e.float();
      case N.INT64:
        return li(e.int64(), i);
      case N.UINT64:
        return li(e.uint64(), i);
      case N.FIXED64:
        return li(e.fixed64(), i);
      case N.FIXED32:
        return e.fixed32();
      case N.BYTES:
        return e.bytes();
      case N.UINT32:
        return e.uint32();
      case N.SFIXED32:
        return e.sfixed32();
      case N.SFIXED64:
        return li(e.sfixed64(), i);
      case N.SINT32:
        return e.sint32();
      case N.SINT64:
        return li(e.sint64(), i);
    }
  }
};
l(H9, "ReflectionBinaryReader");
var W9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    if (!this.fields) {
      const e = this.info.fields ? this.info.fields.concat() : [];
      this.fields = e.sort((t, i) => t.no - i.no);
    }
  }
  write(e, t, i) {
    this.prepare();
    for (const s of this.fields) {
      let r, a, u = s.repeat, c = s.localName;
      if (s.oneof) {
        const h = e[s.oneof];
        if (h.oneofKind !== c)
          continue;
        r = h[c], a = !0;
      } else
        r = e[c], a = !1;
      switch (s.kind) {
        case "scalar":
        case "enum":
          let h = s.kind == "enum" ? N.INT32 : s.T;
          if (u)
            if (Pe(Array.isArray(r)), u == Nl.PACKED)
              this.packed(t, h, s.no, r);
            else
              for (const p of r)
                this.scalar(t, h, s.no, p, !0);
          else
            r === void 0 ? Pe(s.opt) : this.scalar(t, h, s.no, r, a || s.opt);
          break;
        case "message":
          if (u) {
            Pe(Array.isArray(r));
            for (const p of r)
              this.message(t, i, s.T(), s.no, p);
          } else
            this.message(t, i, s.T(), s.no, r);
          break;
        case "map":
          Pe(typeof r == "object" && r !== null);
          for (const [p, f] of Object.entries(r))
            this.mapEntry(t, i, s, p, f);
          break;
      }
    }
    let n = i.writeUnknownFields;
    n !== !1 && (n === !0 ? W.onWrite : n)(this.info.typeName, e, t);
  }
  mapEntry(e, t, i, n, s) {
    e.tag(i.no, L.LengthDelimited), e.fork();
    let r = n;
    switch (i.K) {
      case N.INT32:
      case N.FIXED32:
      case N.UINT32:
      case N.SFIXED32:
      case N.SINT32:
        r = Number.parseInt(n);
        break;
      case N.BOOL:
        Pe(n == "true" || n == "false"), r = n == "true";
        break;
    }
    switch (this.scalar(e, i.K, 1, r, !0), i.V.kind) {
      case "scalar":
        this.scalar(e, i.V.T, 2, s, !0);
        break;
      case "enum":
        this.scalar(e, N.INT32, 2, s, !0);
        break;
      case "message":
        this.message(e, t, i.V.T(), 2, s);
        break;
    }
    e.join();
  }
  message(e, t, i, n, s) {
    s !== void 0 && (i.internalBinaryWrite(s, e.tag(n, L.LengthDelimited).fork(), t), e.join());
  }
  scalar(e, t, i, n, s) {
    let [r, a, u] = this.scalarInfo(t, n);
    (!u || s) && (e.tag(i, r), e[a](n));
  }
  packed(e, t, i, n) {
    if (!n.length)
      return;
    Pe(t !== N.BYTES && t !== N.STRING), e.tag(i, L.LengthDelimited), e.fork();
    let [, s] = this.scalarInfo(t);
    for (let r = 0; r < n.length; r++)
      e[s](n[r]);
    e.join();
  }
  scalarInfo(e, t) {
    let i = L.Varint, n, s = t === void 0, r = t === 0;
    switch (e) {
      case N.INT32:
        n = "int32";
        break;
      case N.STRING:
        r = s || !t.length, i = L.LengthDelimited, n = "string";
        break;
      case N.BOOL:
        r = t === !1, n = "bool";
        break;
      case N.UINT32:
        n = "uint32";
        break;
      case N.DOUBLE:
        i = L.Bit64, n = "double";
        break;
      case N.FLOAT:
        i = L.Bit32, n = "float";
        break;
      case N.INT64:
        r = s || it.from(t).isZero(), n = "int64";
        break;
      case N.UINT64:
        r = s || xt.from(t).isZero(), n = "uint64";
        break;
      case N.FIXED64:
        r = s || xt.from(t).isZero(), i = L.Bit64, n = "fixed64";
        break;
      case N.BYTES:
        r = s || !t.byteLength, i = L.LengthDelimited, n = "bytes";
        break;
      case N.FIXED32:
        i = L.Bit32, n = "fixed32";
        break;
      case N.SFIXED32:
        i = L.Bit32, n = "sfixed32";
        break;
      case N.SFIXED64:
        r = s || it.from(t).isZero(), i = L.Bit64, n = "sfixed64";
        break;
      case N.SINT32:
        n = "sint32";
        break;
      case N.SINT64:
        r = s || it.from(t).isZero(), n = "sint64";
        break;
    }
    return [i, n, s || r];
  }
};
l(W9, "ReflectionBinaryWriter");
function $9(e) {
  const t = {};
  Object.defineProperty(t, be, { enumerable: !1, value: e });
  for (let i of e.fields) {
    let n = i.localName;
    if (!i.opt)
      if (i.oneof)
        t[i.oneof] = { oneofKind: void 0 };
      else if (i.repeat)
        t[n] = [];
      else
        switch (i.kind) {
          case "scalar":
            t[n] = Rl(i.T, i.L);
            break;
          case "enum":
            t[n] = 0;
            break;
          case "map":
            t[n] = {};
            break;
        }
  }
  return t;
}
l($9, "reflectionCreate");
function ge(e, t, i) {
  let n, s = i, r;
  for (let a of e.fields) {
    let u = a.localName;
    if (a.oneof) {
      const c = s[a.oneof];
      if (c == null)
        continue;
      if (n = c[u], r = t[a.oneof], r.oneofKind = c.oneofKind, n == null) {
        delete r[u];
        continue;
      }
    } else if (n = s[u], r = t, n == null)
      continue;
    switch (a.kind) {
      case "scalar":
      case "enum":
        a.repeat ? r[u] = n.concat() : r[u] = n;
        break;
      case "message":
        let c = a.T();
        if (a.repeat)
          for (let h = 0; h < n.length; h++)
            r[u][h] = c.create(n[h]);
        else
          r[u] === void 0 ? r[u] = c.create(n) : c.mergePartial(r[u], n);
        break;
      case "map":
        switch (a.V.kind) {
          case "scalar":
          case "enum":
            Object.assign(r[u], n);
            break;
          case "message":
            let h = a.V.T();
            for (let p of Object.keys(n))
              r[u][p] = h.create(n[p]);
            break;
        }
        break;
    }
  }
}
l(ge, "reflectionMergePartial");
function G9(e, t, i) {
  if (t === i)
    return !0;
  if (!t || !i)
    return !1;
  for (let n of e.fields) {
    let s = n.localName, r = n.oneof ? t[n.oneof][s] : t[s], a = n.oneof ? i[n.oneof][s] : i[s];
    switch (n.kind) {
      case "enum":
      case "scalar":
        let u = n.kind == "enum" ? N.INT32 : n.T;
        if (!(n.repeat ? Q1(u, r, a) : Yc(u, r, a)))
          return !1;
        break;
      case "map":
        if (!(n.V.kind == "message" ? ec(n.V.T(), xa(r), xa(a)) : Q1(n.V.kind == "enum" ? N.INT32 : n.V.T, xa(r), xa(a))))
          return !1;
        break;
      case "message":
        let c = n.T();
        if (!(n.repeat ? ec(c, r, a) : c.equals(r, a)))
          return !1;
        break;
    }
  }
  return !0;
}
l(G9, "reflectionEquals");
var xa = Object.values;
function Yc(e, t, i) {
  if (t === i)
    return !0;
  if (e !== N.BYTES)
    return !1;
  let n = t, s = i;
  if (n.length !== s.length)
    return !1;
  for (let r = 0; r < n.length; r++)
    if (n[r] != s[r])
      return !1;
  return !0;
}
l(Yc, "primitiveEq");
function Q1(e, t, i) {
  if (t.length !== i.length)
    return !1;
  for (let n = 0; n < t.length; n++)
    if (!Yc(e, t[n], i[n]))
      return !1;
  return !0;
}
l(Q1, "repeatedPrimitiveEq");
function ec(e, t, i) {
  if (t.length !== i.length)
    return !1;
  for (let n = 0; n < t.length; n++)
    if (!e.equals(t[n], i[n]))
      return !1;
  return !0;
}
l(ec, "repeatedMsgEq");
var we = class {
  constructor(e, t, i) {
    this.defaultCheckDepth = 16, this.typeName = e, this.fields = t.map(O9), this.options = i ?? {}, this.refTypeCheck = new V9(this), this.refJsonReader = new U9(this), this.refJsonWriter = new j9(this), this.refBinReader = new H9(this), this.refBinWriter = new W9(this);
  }
  create(e) {
    let t = $9(this);
    return e !== void 0 && ge(this, t, e), t;
  }
  clone(e) {
    let t = this.create();
    return ge(this, t, e), t;
  }
  equals(e, t) {
    return G9(this, e, t);
  }
  is(e, t = this.defaultCheckDepth) {
    return this.refTypeCheck.is(e, t, !1);
  }
  isAssignable(e, t = this.defaultCheckDepth) {
    return this.refTypeCheck.is(e, t, !0);
  }
  mergePartial(e, t) {
    ge(this, e, t);
  }
  fromBinary(e, t) {
    let i = M9(t);
    return this.internalBinaryRead(i.readerFactory(e), e.byteLength, i);
  }
  fromJson(e, t) {
    return this.internalJsonRead(e, D9(t));
  }
  fromJsonString(e, t) {
    let i = JSON.parse(e);
    return this.fromJson(i, t);
  }
  toJson(e, t) {
    return this.internalJsonWrite(e, B9(t));
  }
  toJsonString(e, t) {
    var i;
    let n = this.toJson(e, t);
    return JSON.stringify(n, null, (i = t?.prettySpaces) !== null && i !== void 0 ? i : 0);
  }
  toBinary(e, t) {
    let i = R9(t);
    return this.internalBinaryWrite(e, i.writerFactory(), i).finish();
  }
  internalJsonRead(e, t, i) {
    if (e !== null && typeof e == "object" && !Array.isArray(e)) {
      let n = i ?? this.create();
      return this.refJsonReader.read(e, n, t), n;
    }
    throw new Error(`Unable to parse message ${this.typeName} from JSON ${Gc(e)}.`);
  }
  internalJsonWrite(e, t) {
    return this.refJsonWriter.write(e, t);
  }
  internalBinaryWrite(e, t, i) {
    return this.refBinWriter.write(e, t, i), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create();
    return this.refBinReader.read(e, s, i, t), s;
  }
};
l(we, "MessageType");
var q9 = class extends we {
  constructor() {
    super("youtube.VisitorData", [
      { no: 1, name: "id", kind: "scalar", T: 9 },
      { no: 5, name: "timestamp", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { id: "", timestamp: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.id = e.string();
          break;
        case 5:
          s.timestamp = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.id !== "" && t.tag(1, L.LengthDelimited).string(e.id), e.timestamp !== 0 && t.tag(5, L.Varint).int32(e.timestamp);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(q9, "VisitorData$Type");
var f7 = new q9(), K9 = class extends we {
  constructor() {
    super("youtube.ChannelAnalytics", [
      { no: 32, name: "params", kind: "message", T: () => l1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 32:
          s.params = l1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && l1.internalBinaryWrite(e.params, t.tag(32, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(K9, "ChannelAnalytics$Type");
var m7 = new K9(), z9 = class extends we {
  constructor() {
    super("youtube.ChannelAnalytics.Params", [
      { no: 1001, name: "channel_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { channelId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1001:
          s.channelId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1001, L.LengthDelimited).string(e.channelId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(z9, "ChannelAnalytics_Params$Type");
var l1 = new z9(), Y9 = class extends we {
  constructor() {
    super("youtube.InnertubePayload", [
      { no: 1, name: "context", kind: "message", T: () => u1 },
      { no: 2, name: "target", kind: "scalar", opt: !0, T: 9 },
      { no: 20, name: "video_settings", kind: "message", T: () => h1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.context = u1.internalBinaryRead(e, e.uint32(), i, s.context);
          break;
        case 2:
          s.target = e.string();
          break;
        case 20:
          s.videoSettings = h1.internalBinaryRead(e, e.uint32(), i, s.videoSettings);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.context && u1.internalBinaryWrite(e.context, t.tag(1, L.LengthDelimited).fork(), i).join(), e.target !== void 0 && t.tag(2, L.LengthDelimited).string(e.target), e.videoSettings && h1.internalBinaryWrite(e.videoSettings, t.tag(20, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Y9, "InnertubePayload$Type");
var v7 = new Y9(), X9 = class extends we {
  constructor() {
    super("youtube.InnertubePayload.Context", [
      { no: 1, name: "client", kind: "message", T: () => c1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.client = c1.internalBinaryRead(e, e.uint32(), i, s.client);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.client && c1.internalBinaryWrite(e.client, t.tag(1, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(X9, "InnertubePayload_Context$Type");
var u1 = new X9(), J9 = class extends we {
  constructor() {
    super("youtube.InnertubePayload.Context.Client", [
      { no: 16, name: "unkparam", kind: "scalar", T: 5 },
      { no: 17, name: "client_version", kind: "scalar", T: 9 },
      { no: 18, name: "client_name", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { unkparam: 0, clientVersion: "", clientName: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 16:
          s.unkparam = e.int32();
          break;
        case 17:
          s.clientVersion = e.string();
          break;
        case 18:
          s.clientName = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkparam !== 0 && t.tag(16, L.Varint).int32(e.unkparam), e.clientVersion !== "" && t.tag(17, L.LengthDelimited).string(e.clientVersion), e.clientName !== "" && t.tag(18, L.LengthDelimited).string(e.clientName);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(J9, "InnertubePayload_Context_Client$Type");
var c1 = new J9(), Z9 = class extends we {
  constructor() {
    super("youtube.InnertubePayload.VideoSettings", [
      { no: 1, name: "type", kind: "scalar", T: 5 },
      { no: 3, name: "thumbnail", kind: "message", T: () => d1 }
    ]);
  }
  create(e) {
    const t = { type: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.type = e.int32();
          break;
        case 3:
          s.thumbnail = d1.internalBinaryRead(e, e.uint32(), i, s.thumbnail);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type !== 0 && t.tag(1, L.Varint).int32(e.type), e.thumbnail && d1.internalBinaryWrite(e.thumbnail, t.tag(3, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Z9, "InnertubePayload_VideoSettings$Type");
var h1 = new Z9(), Q9 = class extends we {
  constructor() {
    super("youtube.InnertubePayload.VideoSettings.Thumbnail", [
      { no: 1, name: "image_data", kind: "scalar", T: 12 }
    ]);
  }
  create(e) {
    const t = { imageData: new Uint8Array(0) };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.imageData = e.bytes();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.imageData.length && t.tag(1, L.LengthDelimited).bytes(e.imageData);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Q9, "InnertubePayload_VideoSettings_Thumbnail$Type");
var d1 = new Q9(), eg = class extends we {
  constructor() {
    super("youtube.SoundInfoParams", [
      { no: 94, name: "sound", kind: "message", T: () => p1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 94:
          s.sound = p1.internalBinaryRead(e, e.uint32(), i, s.sound);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.sound && p1.internalBinaryWrite(e.sound, t.tag(94, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(eg, "SoundInfoParams$Type");
var g7 = new eg(), tg = class extends we {
  constructor() {
    super("youtube.SoundInfoParams.Sound", [
      { no: 1, name: "params", kind: "message", T: () => f1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.params = f1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && f1.internalBinaryWrite(e.params, t.tag(1, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(tg, "SoundInfoParams_Sound$Type");
var p1 = new tg(), ig = class extends we {
  constructor() {
    super("youtube.SoundInfoParams.Sound.Params", [
      { no: 2, name: "ids", kind: "message", T: () => m1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.ids = m1.internalBinaryRead(e, e.uint32(), i, s.ids);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ids && m1.internalBinaryWrite(e.ids, t.tag(2, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ig, "SoundInfoParams_Sound_Params$Type");
var f1 = new ig(), ng = class extends we {
  constructor() {
    super("youtube.SoundInfoParams.Sound.Params.Ids", [
      { no: 1, name: "id_1", kind: "scalar", T: 9 },
      { no: 2, name: "id_2", kind: "scalar", T: 9 },
      { no: 3, name: "id_3", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { id1: "", id2: "", id3: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.id1 = e.string();
          break;
        case 2:
          s.id2 = e.string();
          break;
        case 3:
          s.id3 = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.id1 !== "" && t.tag(1, L.LengthDelimited).string(e.id1), e.id2 !== "" && t.tag(2, L.LengthDelimited).string(e.id2), e.id3 !== "" && t.tag(3, L.LengthDelimited).string(e.id3);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ng, "SoundInfoParams_Sound_Params_Ids$Type");
var m1 = new ng(), sg = class extends we {
  constructor() {
    super("youtube.NotificationPreferences", [
      { no: 1, name: "channel_id", kind: "scalar", T: 9 },
      { no: 2, name: "pref_id", kind: "message", T: () => v1 },
      { no: 3, name: "number_0", kind: "scalar", opt: !0, T: 5 },
      { no: 4, name: "number_1", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = { channelId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.channelId = e.string();
          break;
        case 2:
          s.prefId = v1.internalBinaryRead(e, e.uint32(), i, s.prefId);
          break;
        case 3:
          s.number0 = e.int32();
          break;
        case 4:
          s.number1 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1, L.LengthDelimited).string(e.channelId), e.prefId && v1.internalBinaryWrite(e.prefId, t.tag(2, L.LengthDelimited).fork(), i).join(), e.number0 !== void 0 && t.tag(3, L.Varint).int32(e.number0), e.number1 !== void 0 && t.tag(4, L.Varint).int32(e.number1);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(sg, "NotificationPreferences$Type");
var y7 = new sg(), rg = class extends we {
  constructor() {
    super("youtube.NotificationPreferences.Preference", [
      { no: 1, name: "index", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { index: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.index = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.index !== 0 && t.tag(1, L.Varint).int32(e.index);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(rg, "NotificationPreferences_Preference$Type");
var v1 = new rg(), og = class extends we {
  constructor() {
    super("youtube.LiveMessageParams", [
      { no: 1, name: "params", kind: "message", T: () => g1 },
      { no: 2, name: "number_0", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "number_1", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.params = g1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 2:
          s.number0 = e.int32();
          break;
        case 3:
          s.number1 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && g1.internalBinaryWrite(e.params, t.tag(1, L.LengthDelimited).fork(), i).join(), e.number0 !== void 0 && t.tag(2, L.Varint).int32(e.number0), e.number1 !== void 0 && t.tag(3, L.Varint).int32(e.number1);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(og, "LiveMessageParams$Type");
var _7 = new og(), ag = class extends we {
  constructor() {
    super("youtube.LiveMessageParams.Params", [
      { no: 5, name: "ids", kind: "message", T: () => y1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 5:
          s.ids = y1.internalBinaryRead(e, e.uint32(), i, s.ids);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ids && y1.internalBinaryWrite(e.ids, t.tag(5, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ag, "LiveMessageParams_Params$Type");
var g1 = new ag(), lg = class extends we {
  constructor() {
    super("youtube.LiveMessageParams.Params.Ids", [
      { no: 1, name: "channel_id", kind: "scalar", T: 9 },
      { no: 2, name: "video_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { channelId: "", videoId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.channelId = e.string();
          break;
        case 2:
          s.videoId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1, L.LengthDelimited).string(e.channelId), e.videoId !== "" && t.tag(2, L.LengthDelimited).string(e.videoId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(lg, "LiveMessageParams_Params_Ids$Type");
var y1 = new lg(), ug = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams", [
      { no: 2, name: "ctx", kind: "message", T: () => _1 },
      { no: 3, name: "unk_param", kind: "scalar", T: 5 },
      { no: 6, name: "params", kind: "message", T: () => b1 }
    ]);
  }
  create(e) {
    const t = { unkParam: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.ctx = _1.internalBinaryRead(e, e.uint32(), i, s.ctx);
          break;
        case 3:
          s.unkParam = e.int32();
          break;
        case 6:
          s.params = b1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ctx && _1.internalBinaryWrite(e.ctx, t.tag(2, L.LengthDelimited).fork(), i).join(), e.unkParam !== 0 && t.tag(3, L.Varint).int32(e.unkParam), e.params && b1.internalBinaryWrite(e.params, t.tag(6, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ug, "GetCommentsSectionParams$Type");
var P5 = new ug(), cg = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams.Context", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { videoId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, L.LengthDelimited).string(e.videoId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(cg, "GetCommentsSectionParams_Context$Type");
var _1 = new cg(), hg = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params", [
      { no: 1, name: "unk_token", kind: "scalar", opt: !0, T: 9 },
      { no: 4, name: "opts", kind: "message", T: () => w1 },
      { no: 3, name: "replies_opts", kind: "message", T: () => S1 },
      { no: 5, name: "page", kind: "scalar", opt: !0, T: 5 },
      { no: 8, name: "target", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { target: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkToken = e.string();
          break;
        case 4:
          s.opts = w1.internalBinaryRead(e, e.uint32(), i, s.opts);
          break;
        case 3:
          s.repliesOpts = S1.internalBinaryRead(e, e.uint32(), i, s.repliesOpts);
          break;
        case 5:
          s.page = e.int32();
          break;
        case 8:
          s.target = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkToken !== void 0 && t.tag(1, L.LengthDelimited).string(e.unkToken), e.opts && w1.internalBinaryWrite(e.opts, t.tag(4, L.LengthDelimited).fork(), i).join(), e.repliesOpts && S1.internalBinaryWrite(e.repliesOpts, t.tag(3, L.LengthDelimited).fork(), i).join(), e.page !== void 0 && t.tag(5, L.Varint).int32(e.page), e.target !== "" && t.tag(8, L.LengthDelimited).string(e.target);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(hg, "GetCommentsSectionParams_Params$Type");
var b1 = new hg(), dg = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.Options", [
      { no: 4, name: "video_id", kind: "scalar", T: 9 },
      { no: 6, name: "sort_by", kind: "scalar", T: 5 },
      { no: 15, name: "type", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", sortBy: 0, type: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 4:
          s.videoId = e.string();
          break;
        case 6:
          s.sortBy = e.int32();
          break;
        case 15:
          s.type = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(4, L.LengthDelimited).string(e.videoId), e.sortBy !== 0 && t.tag(6, L.Varint).int32(e.sortBy), e.type !== 0 && t.tag(15, L.Varint).int32(e.type);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(dg, "GetCommentsSectionParams_Params_Options$Type");
var w1 = new dg(), pg = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.RepliesOptions", [
      { no: 2, name: "comment_id", kind: "scalar", T: 9 },
      { no: 4, name: "unkopts", kind: "message", T: () => C1 },
      { no: 5, name: "channel_id", kind: "scalar", opt: !0, T: 9 },
      { no: 6, name: "video_id", kind: "scalar", T: 9 },
      { no: 8, name: "unk_param_1", kind: "scalar", T: 5 },
      { no: 9, name: "unk_param_2", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { commentId: "", videoId: "", unkParam1: 0, unkParam2: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.commentId = e.string();
          break;
        case 4:
          s.unkopts = C1.internalBinaryRead(e, e.uint32(), i, s.unkopts);
          break;
        case 5:
          s.channelId = e.string();
          break;
        case 6:
          s.videoId = e.string();
          break;
        case 8:
          s.unkParam1 = e.int32();
          break;
        case 9:
          s.unkParam2 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.commentId !== "" && t.tag(2, L.LengthDelimited).string(e.commentId), e.unkopts && C1.internalBinaryWrite(e.unkopts, t.tag(4, L.LengthDelimited).fork(), i).join(), e.channelId !== void 0 && t.tag(5, L.LengthDelimited).string(e.channelId), e.videoId !== "" && t.tag(6, L.LengthDelimited).string(e.videoId), e.unkParam1 !== 0 && t.tag(8, L.Varint).int32(e.unkParam1), e.unkParam2 !== 0 && t.tag(9, L.Varint).int32(e.unkParam2);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(pg, "GetCommentsSectionParams_Params_RepliesOptions$Type");
var S1 = new pg(), fg = class extends we {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.RepliesOptions.UnkOpts", [
      { no: 1, name: "unk_param", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { unkParam: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkParam = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkParam !== 0 && t.tag(1, L.Varint).int32(e.unkParam);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(fg, "GetCommentsSectionParams_Params_RepliesOptions_UnkOpts$Type");
var C1 = new fg(), mg = class extends we {
  constructor() {
    super("youtube.CreateCommentParams", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 },
      { no: 5, name: "params", kind: "message", T: () => T1 },
      { no: 10, name: "number", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", number: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        case 5:
          s.params = T1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 10:
          s.number = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, L.LengthDelimited).string(e.videoId), e.params && T1.internalBinaryWrite(e.params, t.tag(5, L.LengthDelimited).fork(), i).join(), e.number !== 0 && t.tag(10, L.Varint).int32(e.number);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(mg, "CreateCommentParams$Type");
var b7 = new mg(), vg = class extends we {
  constructor() {
    super("youtube.CreateCommentParams.Params", [
      { no: 1, name: "index", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { index: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.index = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.index !== 0 && t.tag(1, L.Varint).int32(e.index);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(vg, "CreateCommentParams_Params$Type");
var T1 = new vg(), gg = class extends we {
  constructor() {
    super("youtube.CreateCommentReplyParams", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 },
      { no: 4, name: "comment_id", kind: "scalar", T: 9 },
      { no: 5, name: "params", kind: "message", T: () => x1 },
      { no: 10, name: "unk_num", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", commentId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        case 4:
          s.commentId = e.string();
          break;
        case 5:
          s.params = x1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 10:
          s.unkNum = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, L.LengthDelimited).string(e.videoId), e.commentId !== "" && t.tag(4, L.LengthDelimited).string(e.commentId), e.params && x1.internalBinaryWrite(e.params, t.tag(5, L.LengthDelimited).fork(), i).join(), e.unkNum !== void 0 && t.tag(10, L.Varint).int32(e.unkNum);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(gg, "CreateCommentReplyParams$Type");
var w7 = new gg(), yg = class extends we {
  constructor() {
    super("youtube.CreateCommentReplyParams.UnknownParams", [
      { no: 1, name: "unk_num", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { unkNum: 0 };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkNum = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkNum !== 0 && t.tag(1, L.Varint).int32(e.unkNum);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(yg, "CreateCommentReplyParams_UnknownParams$Type");
var x1 = new yg(), _g = class extends we {
  constructor() {
    super("youtube.PeformCommentActionParams", [
      { no: 1, name: "type", kind: "scalar", T: 5 },
      { no: 3, name: "comment_id", kind: "scalar", T: 9 },
      { no: 5, name: "video_id", kind: "scalar", T: 9 },
      { no: 2, name: "unk_num", kind: "scalar", opt: !0, T: 5 },
      { no: 23, name: "channel_id", kind: "scalar", opt: !0, T: 9 },
      { no: 31, name: "translate_comment_params", kind: "message", T: () => E1 }
    ]);
  }
  create(e) {
    const t = { type: 0, commentId: "", videoId: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.type = e.int32();
          break;
        case 3:
          s.commentId = e.string();
          break;
        case 5:
          s.videoId = e.string();
          break;
        case 2:
          s.unkNum = e.int32();
          break;
        case 23:
          s.channelId = e.string();
          break;
        case 31:
          s.translateCommentParams = E1.internalBinaryRead(e, e.uint32(), i, s.translateCommentParams);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type !== 0 && t.tag(1, L.Varint).int32(e.type), e.commentId !== "" && t.tag(3, L.LengthDelimited).string(e.commentId), e.videoId !== "" && t.tag(5, L.LengthDelimited).string(e.videoId), e.unkNum !== void 0 && t.tag(2, L.Varint).int32(e.unkNum), e.channelId !== void 0 && t.tag(23, L.LengthDelimited).string(e.channelId), e.translateCommentParams && E1.internalBinaryWrite(e.translateCommentParams, t.tag(31, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(_g, "PeformCommentActionParams$Type");
var S7 = new _g(), bg = class extends we {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams", [
      { no: 3, name: "params", kind: "message", T: () => k1 },
      { no: 2, name: "comment_id", kind: "scalar", T: 9 },
      { no: 4, name: "target_language", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { commentId: "", targetLanguage: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 3:
          s.params = k1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 2:
          s.commentId = e.string();
          break;
        case 4:
          s.targetLanguage = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && k1.internalBinaryWrite(e.params, t.tag(3, L.LengthDelimited).fork(), i).join(), e.commentId !== "" && t.tag(2, L.LengthDelimited).string(e.commentId), e.targetLanguage !== "" && t.tag(4, L.LengthDelimited).string(e.targetLanguage);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(bg, "PeformCommentActionParams_TranslateCommentParams$Type");
var E1 = new bg(), wg = class extends we {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams.Params", [
      { no: 1, name: "comment", kind: "message", T: () => A1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.comment = A1.internalBinaryRead(e, e.uint32(), i, s.comment);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.comment && A1.internalBinaryWrite(e.comment, t.tag(1, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(wg, "PeformCommentActionParams_TranslateCommentParams_Params$Type");
var k1 = new wg(), Sg = class extends we {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams.Params.Comment", [
      { no: 1, name: "text", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { text: "" };
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.text = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.text !== "" && t.tag(1, L.LengthDelimited).string(e.text);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Sg, "PeformCommentActionParams_TranslateCommentParams_Params_Comment$Type");
var A1 = new Sg(), Cg = class extends we {
  constructor() {
    super("youtube.MusicSearchFilter", [
      { no: 2, name: "filters", kind: "message", T: () => I1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.filters = I1.internalBinaryRead(e, e.uint32(), i, s.filters);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.filters && I1.internalBinaryWrite(e.filters, t.tag(2, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Cg, "MusicSearchFilter$Type");
var C7 = new Cg(), Tg = class extends we {
  constructor() {
    super("youtube.MusicSearchFilter.Filters", [
      { no: 17, name: "type", kind: "message", T: () => P1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 17:
          s.type = P1.internalBinaryRead(e, e.uint32(), i, s.type);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type && P1.internalBinaryWrite(e.type, t.tag(17, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Tg, "MusicSearchFilter_Filters$Type");
var I1 = new Tg(), xg = class extends we {
  constructor() {
    super("youtube.MusicSearchFilter.Filters.Type", [
      { no: 1, name: "song", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "video", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "album", kind: "scalar", opt: !0, T: 5 },
      { no: 4, name: "artist", kind: "scalar", opt: !0, T: 5 },
      { no: 5, name: "playlist", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.song = e.int32();
          break;
        case 2:
          s.video = e.int32();
          break;
        case 3:
          s.album = e.int32();
          break;
        case 4:
          s.artist = e.int32();
          break;
        case 5:
          s.playlist = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.song !== void 0 && t.tag(1, L.Varint).int32(e.song), e.video !== void 0 && t.tag(2, L.Varint).int32(e.video), e.album !== void 0 && t.tag(3, L.Varint).int32(e.album), e.artist !== void 0 && t.tag(4, L.Varint).int32(e.artist), e.playlist !== void 0 && t.tag(5, L.Varint).int32(e.playlist);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(xg, "MusicSearchFilter_Filters_Type$Type");
var P1 = new xg(), Eg = class extends we {
  constructor() {
    super("youtube.SearchFilter", [
      { no: 1, name: "sort_by", kind: "scalar", opt: !0, T: 5 },
      { no: 19, name: "no_filter", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "filters", kind: "message", T: () => M1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.sortBy = e.int32();
          break;
        case 19:
          s.noFilter = e.int32();
          break;
        case 2:
          s.filters = M1.internalBinaryRead(e, e.uint32(), i, s.filters);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.sortBy !== void 0 && t.tag(1, L.Varint).int32(e.sortBy), e.noFilter !== void 0 && t.tag(19, L.Varint).int32(e.noFilter), e.filters && M1.internalBinaryWrite(e.filters, t.tag(2, L.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Eg, "SearchFilter$Type");
var T7 = new Eg(), kg = class extends we {
  constructor() {
    super("youtube.SearchFilter.Filters", [
      { no: 1, name: "upload_date", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "type", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "duration", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, be, { enumerable: !1, value: this }), e !== void 0 && ge(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n ?? this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.uploadDate = e.int32();
          break;
        case 2:
          s.type = e.int32();
          break;
        case 3:
          s.duration = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? W.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.uploadDate !== void 0 && t.tag(1, L.Varint).int32(e.uploadDate), e.type !== void 0 && t.tag(2, L.Varint).int32(e.type), e.duration !== void 0 && t.tag(3, L.Varint).int32(e.duration);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? W.onWrite : n)(this.typeName, e, t), t;
  }
};
l(kg, "SearchFilter_Filters$Type");
var M1 = new kg(), Ag = class {
  static encodeVisitorData(e, t) {
    const i = f7.toBinary({
      id: e,
      timestamp: t
    });
    return encodeURIComponent(Ft(i).replace(/\/|\+/g, "_"));
  }
  static encodeChannelAnalyticsParams(e) {
    const t = m7.toBinary({
      params: {
        channelId: e
      }
    });
    return encodeURIComponent(Ft(t));
  }
  static encodeSearchFilters(e) {
    const t = {
      all: void 0,
      hour: 1,
      today: 2,
      week: 3,
      month: 4,
      year: 5
    }, i = {
      all: void 0,
      video: 1,
      channel: 2,
      playlist: 3,
      movie: 4
    }, n = {
      all: void 0,
      short: 1,
      long: 2,
      medium: 3
    }, s = {
      relevance: void 0,
      rating: 1,
      upload_date: 2,
      view_count: 3
    }, r = {};
    if (e ? r.filters = {} : r.noFilter = 0, r.filters) {
      if (e.upload_date && e.type !== "video")
        throw new Error(`Upload date filter cannot be used with type ${e.type}`);
      e.upload_date && (r.filters.uploadDate = t[e.upload_date]), e.type && (r.filters.type = i[e.type]), e.duration && (r.filters.duration = n[e.duration]), e.sort_by && e.sort_by !== "relevance" && (r.sortBy = s[e.sort_by]);
    }
    const a = T7.toBinary(r);
    return encodeURIComponent(Ft(a));
  }
  static encodeMusicSearchFilters(e) {
    var t;
    const i = {
      filters: {
        type: {}
      }
    };
    e.type && e.type !== "all" && ((t = i.filters) === null || t === void 0 ? void 0 : t.type) && (i.filters.type[e.type] = 1);
    const n = C7.toBinary(i);
    return encodeURIComponent(Ft(n));
  }
  static encodeMessageParams(e, t) {
    const i = _7.toBinary({
      params: {
        ids: {
          channelId: e,
          videoId: t
        }
      },
      number0: 1,
      number1: 4
    });
    return btoa(encodeURIComponent(Ft(i)));
  }
  static encodeCommentsSectionParams(e, t = {}) {
    const i = {
      TOP_COMMENTS: 0,
      NEWEST_FIRST: 1
    }, n = P5.toBinary({
      ctx: {
        videoId: e
      },
      unkParam: 6,
      params: {
        opts: {
          videoId: e,
          sortBy: i[t.sort_by || "TOP_COMMENTS"],
          type: t.type || 2
        },
        target: "comments-section"
      }
    });
    return encodeURIComponent(Ft(n));
  }
  static encodeCommentRepliesParams(e, t) {
    const i = P5.toBinary({
      ctx: {
        videoId: e
      },
      unkParam: 6,
      params: {
        repliesOpts: {
          videoId: e,
          commentId: t,
          unkopts: {
            unkParam: 0
          },
          unkParam1: 1,
          unkParam2: 10,
          channelId: " "
        },
        target: `comment-replies-item-${t}`
      }
    });
    return encodeURIComponent(Ft(i));
  }
  static encodeCommentParams(e) {
    const t = b7.toBinary({
      videoId: e,
      params: {
        index: 0
      },
      number: 7
    });
    return encodeURIComponent(Ft(t));
  }
  static encodeCommentReplyParams(e, t) {
    const i = w7.toBinary({
      videoId: t,
      commentId: e,
      params: {
        unkNum: 0
      },
      unkNum: 7
    });
    return encodeURIComponent(Ft(i));
  }
  static encodeCommentActionParams(e, t = {}) {
    const i = {
      type: e,
      commentId: t.comment_id || " ",
      videoId: t.video_id || " ",
      unkNum: 2
    };
    if (t.hasOwnProperty("text")) {
      if (typeof t.target_language != "string")
        throw new Error("target_language must be a string");
      t.comment_id && delete i.unkNum, i.translateCommentParams = {
        params: {
          comment: {
            text: t.text
          }
        },
        commentId: t.comment_id || " ",
        targetLanguage: t.target_language
      };
    }
    const n = S7.toBinary(i);
    return encodeURIComponent(Ft(n));
  }
  static encodeNotificationPref(e, t) {
    const i = y7.toBinary({
      channelId: e,
      prefId: {
        index: t
      },
      number0: 0,
      number1: 4
    });
    return encodeURIComponent(Ft(i));
  }
  static encodeCustomThumbnailPayload(e, t) {
    const i = {
      context: {
        client: {
          unkparam: 14,
          clientName: Il.ANDROID.NAME,
          clientVersion: Il.ANDROID.VERSION
        }
      },
      target: e,
      videoSettings: {
        type: 3,
        thumbnail: {
          imageData: t
        }
      }
    };
    return v7.toBinary(i);
  }
  static encodeSoundInfoParams(e) {
    const t = {
      sound: {
        params: {
          ids: {
            id1: e,
            id2: e,
            id3: e
          }
        }
      }
    }, i = g7.toBinary(t);
    return encodeURIComponent(Ft(i));
  }
};
l(Ag, "Proto");
var Vt = Ag, Ig = class {
  constructor(e) {
    this.itag = e.itag, this.mime_type = e.mimeType, this.bitrate = e.bitrate, this.average_bitrate = e.averageBitrate, this.width = e.width || void 0, this.height = e.height || void 0, this.init_range = e.initRange ? {
      start: parseInt(e.initRange.start),
      end: parseInt(e.initRange.end)
    } : void 0, this.index_range = e.indexRange ? {
      start: parseInt(e.indexRange.start),
      end: parseInt(e.indexRange.end)
    } : void 0, this.last_modified = new Date(Math.floor(parseInt(e.lastModified) / 1e3)), this.content_length = parseInt(e.contentLength), this.quality = e.quality, this.quality_label = e.qualityLabel || void 0, this.fps = e.fps || void 0, this.url = e.url || void 0, this.cipher = e.cipher || void 0, this.signature_cipher = e.signatureCipher || void 0, this.audio_quality = e.audioQuality || void 0, this.approx_duration_ms = parseInt(e.approxDurationMs), this.audio_sample_rate = parseInt(e.audioSampleRate), this.audio_channels = e.audioChannels, this.loudness_db = e.loudnessDb, this.has_audio = !!e.audioBitrate || !!e.audioQuality, this.has_video = !!e.qualityLabel;
  }
  decipher(e) {
    return e.decipher(this.url, this.signature_cipher, this.cipher);
  }
};
l(Ig, "Format");
var x7 = Ig, Xc = class {
  constructor(e) {
    this.url = e.url, this.width = e.width, this.height = e.height;
  }
  static fromResponse(e) {
    return !e || !e.thumbnails ? [] : e.thumbnails.map((t) => new Xc(t)).sort((t, i) => i.width - t.width);
  }
};
l(Xc, "Thumbnail");
var $ = Xc, Pg = class {
  constructor(e) {
    this.id = e.videoId, this.channel_id = e.channelId, this.title = e.title, this.duration = parseInt(e.lengthSeconds), this.keywords = e.keywords, this.is_owner_viewing = !!e.isOwnerViewing, this.short_description = e.shortDescription, this.thumbnail = $.fromResponse(e.thumbnail), this.allow_ratings = !!e.allowRatings, this.view_count = parseInt(e.viewCount), this.author = e.author, this.is_private = !!e.isPrivate, this.is_live_content = !!e.isLiveContent, this.is_crawlable = !!e.isCrawlable;
  }
};
l(Pg, "VideoDetails");
var E7 = Pg, oe = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Mg = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, tc, Ng, ot, Be, Mi, Ki, ts, Rg = Symbol("ObservedArray.isObserved"), w = class {
  constructor() {
    tc.add(this), this.type = this.constructor.type;
  }
  is(...e) {
    return e.some((t) => oe(this, tc, "m", Ng).call(this, t));
  }
  as(...e) {
    if (!this.is(...e))
      throw new nn(`Cannot cast ${this.type} to one of ${e.map((t) => t.type).join(", ")}`);
    return this;
  }
  hasKey(e) {
    return Reflect.has(this, e);
  }
  key(e) {
    if (!this.hasKey(e))
      throw new nn(`Missing key ${e}`);
    return new Jc(this[e]);
  }
};
l(w, "YTNode");
tc = /* @__PURE__ */ new WeakSet(), Ng = /* @__PURE__ */ l(function(t) {
  return this.type === t.type;
}, "_YTNode_is");
w.type = "YTNode";
var Jc = class {
  constructor(e) {
    ot.add(this), Be.set(this, void 0), Mg(this, Be, e, "f");
  }
  get typeof() {
    return typeof oe(this, Be, "f");
  }
  string() {
    return oe(this, ot, "m", Ki).call(this, "string");
  }
  isString() {
    return oe(this, ot, "m", Mi).call(this, "string");
  }
  number() {
    return oe(this, ot, "m", Ki).call(this, "number");
  }
  isNumber() {
    return oe(this, ot, "m", Mi).call(this, "number");
  }
  bigint() {
    return oe(this, ot, "m", Ki).call(this, "bigint");
  }
  isBigint() {
    return oe(this, ot, "m", Mi).call(this, "bigint");
  }
  boolean() {
    return oe(this, ot, "m", Ki).call(this, "boolean");
  }
  isBoolean() {
    return oe(this, ot, "m", Mi).call(this, "boolean");
  }
  symbol() {
    return oe(this, ot, "m", Ki).call(this, "symbol");
  }
  isSymbol() {
    return oe(this, ot, "m", Mi).call(this, "symbol");
  }
  undefined() {
    return oe(this, ot, "m", Ki).call(this, "undefined");
  }
  isUndefined() {
    return oe(this, ot, "m", Mi).call(this, "undefined");
  }
  null() {
    if (oe(this, Be, "f") !== null)
      throw new TypeError(`Expected null, got ${typeof oe(this, Be, "f")}`);
    return oe(this, Be, "f");
  }
  isNull() {
    return oe(this, Be, "f") === null;
  }
  object() {
    return oe(this, ot, "m", Ki).call(this, "object");
  }
  isObject() {
    return oe(this, ot, "m", Mi).call(this, "object");
  }
  function() {
    return oe(this, ot, "m", Ki).call(this, "function");
  }
  isFunction() {
    return oe(this, ot, "m", Mi).call(this, "function");
  }
  array() {
    if (!Array.isArray(oe(this, Be, "f")))
      throw new TypeError(`Expected array, got ${typeof oe(this, Be, "f")}`);
    return oe(this, Be, "f");
  }
  arrayOfMaybe() {
    const e = [];
    return new Proxy(this.array(), {
      get(t, i) {
        return Reflect.has(e, i) ? Reflect.get(t, i) : new Jc(Reflect.get(t, i));
      }
    });
  }
  isArray() {
    return Array.isArray(oe(this, Be, "f"));
  }
  node() {
    if (!(oe(this, Be, "f") instanceof w))
      throw new TypeError(`Expected YTNode, got ${oe(this, Be, "f").constructor.name}`);
    return oe(this, Be, "f");
  }
  isNode() {
    return oe(this, Be, "f") instanceof w;
  }
  nodeOfType(...e) {
    return this.node().as(...e);
  }
  isNodeOfType(...e) {
    return this.isNode() && this.node().is(...e);
  }
  observed() {
    if (!this.isObserved())
      throw new TypeError(`Expected ObservedArray, got ${typeof oe(this, Be, "f")}`);
    return oe(this, Be, "f");
  }
  isObserved() {
    var e;
    return (e = oe(this, Be, "f")) === null || e === void 0 ? void 0 : e[Rg];
  }
  parsed() {
    if (!(oe(this, Be, "f") instanceof lr))
      throw new TypeError(`Expected SuperParsedResult, got ${typeof oe(this, Be, "f")}`);
    return oe(this, Be, "f");
  }
  isParsed() {
    return oe(this, Be, "f") instanceof lr;
  }
  any() {
    return console.warn("This call is not meant to be used outside of debugging. Please use the specific type getter instead."), oe(this, Be, "f");
  }
  instanceof(e) {
    if (!this.isInstanceof(e))
      throw new TypeError(`Expected instance of ${e.name}, got ${oe(this, Be, "f").constructor.name}`);
    return oe(this, Be, "f");
  }
  isInstanceof(e) {
    return oe(this, Be, "f") instanceof e;
  }
};
l(Jc, "Maybe");
Be = /* @__PURE__ */ new WeakMap(), ot = /* @__PURE__ */ new WeakSet(), Mi = /* @__PURE__ */ l(function(t) {
  return typeof oe(this, Be, "f") === t;
}, "_Maybe_checkPrimative"), Ki = /* @__PURE__ */ l(function(t) {
  if (!oe(this, ot, "m", Mi).call(this, t))
    throw new TypeError(`Expected ${t}, got ${this.typeof}`);
  return oe(this, Be, "f");
}, "_Maybe_assertPrimative");
var lr = class {
  constructor(e) {
    ts.set(this, void 0), Mg(this, ts, e, "f");
  }
  get is_null() {
    return oe(this, ts, "f") === null;
  }
  get is_array() {
    return !this.is_null && Array.isArray(oe(this, ts, "f"));
  }
  get is_node() {
    return !this.is_array;
  }
  array() {
    if (!this.is_array)
      throw new TypeError("Expected an array, got a node");
    return oe(this, ts, "f");
  }
  item() {
    if (!this.is_node)
      throw new TypeError("Expected a node, got an array");
    return oe(this, ts, "f");
  }
};
l(lr, "SuperParsedResult");
ts = /* @__PURE__ */ new WeakMap();
function Qt(e) {
  return new Proxy(e, {
    get(t, i) {
      return i == "get" ? (n, s) => t.find((r, a) => {
        const u = kl(n, r);
        return u && s && t.splice(a, 1), u;
      }) : i == Rg ? !0 : i == "getAll" ? (n, s) => t.filter((r, a) => {
        const u = kl(n, r);
        return u && s && t.splice(a, 1), u;
      }) : i == "filterType" ? (...n) => Qt(t.filter((s) => !!s.is(...n))) : i == "firstOfType" ? (...n) => t.find((s) => !!s.is(...n)) : i == "as" ? (...n) => Qt(t.map((s) => {
        if (s.is(...n))
          return s;
        throw new nn(`Expected node of any type ${n.map((r) => r.type).join(", ")}, got ${s.type}`);
      })) : i == "remove" ? (n) => t.splice(n, 1) : Reflect.get(t, i);
    }
  });
}
l(Qt, "observe");
var Lg = class extends Map {
  getType(e) {
    return Array.isArray(e) ? Qt(e.flatMap((t) => this.get(t.type) || [])) : Qt(this.get(e.type) || []);
  }
};
l(Lg, "Memo");
var Zc = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.label = new b(e.label).toString(), this.selected = !!e.isSelected, e.int32Value ? this.value = e.int32Value : e.stringValue && (this.value = e.stringValue), !((t = e.onSelectCommand) === null || t === void 0) && t.browseEndpoint && (this.endpoint = new B(e.onSelectCommand)), !((i = e.icon) === null || i === void 0) && i.iconType && (this.icon_type = (n = e.icon) === null || n === void 0 ? void 0 : n.iconType), e.descriptionText && (this.description = new b(e.descriptionText).toString());
  }
};
l(Zc, "DropdownItem");
Zc.type = "DropdownItem";
var Ho = Zc, Qc = class extends w {
  constructor(e) {
    super(), this.label = e.label || "", this.entries = y.parseArray(e.entries, Ho);
  }
};
l(Qc, "Dropdown");
Qc.type = "Dropdown";
var eh = Qc, th = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new b(e.dialogTitle).toString(), this.title_placeholder = e.titlePlaceholder || "", this.privacy_option = ((t = y.parseItem(e.privacyOption, eh)) === null || t === void 0 ? void 0 : t.entries) || null, this.create_button = y.parseItem(e.cancelButton), this.cancel_button = y.parseItem(e.cancelButton);
  }
};
l(th, "CreatePlaylistDialog");
th.type = "CreatePlaylistDialog";
var Dg = th, Bg = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, M5 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, qa, ic, ih = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p, f, _, C, E, P, A, F, M, j, z, D, v, U, Z;
    super(), qa.add(this), Reflect.has(e || {}, "innertubeCommand") && (e = e.innertubeCommand);
    const he = Object.keys(e || {}).find((te) => te.endsWith("Endpoint") || te.endsWith("Command"));
    if (this.payload = he ? Reflect.get(e, he) : {}, Reflect.has(this.payload, "dialog") && (this.dialog = y.parse(this.payload.dialog)), e?.serviceEndpoint && (e = e.serviceEndpoint), this.metadata = {}, !((i = (t = e?.commandMetadata) === null || t === void 0 ? void 0 : t.webCommandMetadata) === null || i === void 0) && i.url && (this.metadata.url = e.commandMetadata.webCommandMetadata.url), !((s = (n = e?.commandMetadata) === null || n === void 0 ? void 0 : n.webCommandMetadata) === null || s === void 0) && s.webPageType && (this.metadata.page_type = e.commandMetadata.webCommandMetadata.webPageType), !((a = (r = e?.commandMetadata) === null || r === void 0 ? void 0 : r.webCommandMetadata) === null || a === void 0) && a.apiUrl ? this.metadata.api_url = e.commandMetadata.webCommandMetadata.apiUrl.replace("/youtubei/v1/", "") : he && (this.metadata.api_url = this.getEndpoint(he)), !((c = (u = e?.commandMetadata) === null || u === void 0 ? void 0 : u.webCommandMetadata) === null || c === void 0) && c.sendPost && (this.metadata.send_post = e.commandMetadata.webCommandMetadata.sendPost), e?.browseEndpoint) {
      const te = (p = (h = e?.browseEndpoint) === null || h === void 0 ? void 0 : h.browseEndpointContextSupportedConfigs) === null || p === void 0 ? void 0 : p.browseEndpointContextMusicConfig;
      this.browse = {
        id: ((f = e?.browseEndpoint) === null || f === void 0 ? void 0 : f.browseId) || null,
        params: e?.browseEndpoint.params || null,
        base_url: ((_ = e?.browseEndpoint) === null || _ === void 0 ? void 0 : _.canonicalBaseUrl) || null,
        page_type: te?.pageType || null
      };
    }
    if (e?.watchEndpoint) {
      const te = (E = (C = e?.watchEndpoint) === null || C === void 0 ? void 0 : C.watchEndpointMusicSupportedConfigs) === null || E === void 0 ? void 0 : E.watchEndpointMusicConfig;
      this.watch = {
        video_id: (P = e?.watchEndpoint) === null || P === void 0 ? void 0 : P.videoId,
        playlist_id: e?.watchEndpoint.playlistId || null,
        params: e?.watchEndpoint.params || null,
        index: e?.watchEndpoint.index || null,
        supported_onesie_config: (A = e?.watchEndpoint) === null || A === void 0 ? void 0 : A.watchEndpointSupportedOnesieConfig,
        music_video_type: te?.musicVideoType || null
      };
    }
    e?.searchEndpoint && (this.search = {
      query: e.searchEndpoint.query,
      params: e.searchEndpoint.params
    }), e?.subscribeEndpoint && (this.subscribe = {
      channel_ids: e.subscribeEndpoint.channelIds,
      params: e.subscribeEndpoint.params
    }), e?.unsubscribeEndpoint && (this.unsubscribe = {
      channel_ids: e.unsubscribeEndpoint.channelIds,
      params: e.unsubscribeEndpoint.params
    }), e?.likeEndpoint && (this.like = {
      status: e.likeEndpoint.status,
      target: {
        video_id: e.likeEndpoint.target.videoId,
        playlist_id: e.likeEndpoint.target.playlistId
      },
      params: ((F = e.likeEndpoint) === null || F === void 0 ? void 0 : F.removeLikeParams) || ((M = e.likeEndpoint) === null || M === void 0 ? void 0 : M.likeParams) || ((j = e.likeEndpoint) === null || j === void 0 ? void 0 : j.dislikeParams)
    }), e?.performCommentActionEndpoint && (this.perform_comment_action = {
      action: e?.performCommentActionEndpoint.action
    }), e?.offlineVideoEndpoint && (this.offline_video = {
      video_id: e.offlineVideoEndpoint.videoId,
      on_add_command: {
        get_download_action: {
          video_id: e.offlineVideoEndpoint.videoId,
          params: e.offlineVideoEndpoint.onAddCommand.getDownloadActionCommand.params
        }
      }
    }), e?.continuationCommand && (this.continuation = {
      request: ((z = e?.continuationCommand) === null || z === void 0 ? void 0 : z.request) || null,
      token: ((D = e?.continuationCommand) === null || D === void 0 ? void 0 : D.token) || null
    }), e?.feedbackEndpoint && (this.feedback = {
      token: e.feedbackEndpoint.feedbackToken
    }), e?.watchPlaylistEndpoint && (this.watch_playlist = {
      playlist_id: (v = e.watchPlaylistEndpoint) === null || v === void 0 ? void 0 : v.playlistId,
      params: ((U = e.watchPlaylistEndpoint) === null || U === void 0 ? void 0 : U.params) || null
    }), e?.playlistEditEndpoint && (this.playlist_edit = {
      playlist_id: e.playlistEditEndpoint.playlistId,
      actions: e.playlistEditEndpoint.actions.map((te) => ({
        action: te.action,
        removed_video_id: te.removedVideoId
      }))
    }), e?.addToPlaylistEndpoint && (this.add_to_playlist = {
      video_id: e.addToPlaylistEndpoint.videoId
    }), e?.addToPlaylistServiceEndpoint && (this.add_to_playlist = {
      video_id: e.addToPlaylistServiceEndpoint.videoId
    }), e?.createPlaylistEndpoint && (e?.createPlaylistEndpoint.createPlaylistDialog && (this.dialog = y.parseItem(e?.createPlaylistEndpoint.createPlaylistDialog, Dg)), this.create_playlist = {}), e?.getReportFormEndpoint && (this.get_report_form = {
      params: e.getReportFormEndpoint.params
    }), e?.liveChatItemContextMenuEndpoint && (this.live_chat_item_context_menu = {
      params: (Z = e?.liveChatItemContextMenuEndpoint) === null || Z === void 0 ? void 0 : Z.params
    }), e?.sendLiveChatVoteEndpoint && (this.send_live_chat_vote = {
      params: e.sendLiveChatVoteEndpoint.params
    }), e?.liveChatItemContextMenuEndpoint && (this.live_chat_item_context_menu = {
      params: e.liveChatItemContextMenuEndpoint.params
    });
  }
  getEndpoint(e) {
    switch (e) {
      case "browseEndpoint":
        return "/browse";
      case "watchEndpoint":
        return "/player";
      case "watchPlaylistEndpoint":
        return "/next";
    }
  }
  callTest(e, t) {
    if (!e)
      throw new Error("An active caller must be provided");
    if (!this.metadata.api_url)
      throw new Error("Expected an api_url, but none was found, this is a bug.");
    return e.execute(this.metadata.api_url, Object.assign(Object.assign({}, this.payload), t));
  }
  call(e, t, i) {
    return Bg(this, void 0, void 0, function* () {
      const n = yield M5(this, qa, "m", ic).call(this, e, t);
      return i && n ? y.parseResponse(n.data) : M5(this, qa, "m", ic).call(this, e, t);
    });
  }
};
l(ih, "NavigationEndpoint");
qa = /* @__PURE__ */ new WeakSet(), ic = /* @__PURE__ */ l(function(t, i) {
  return Bg(this, void 0, void 0, function* () {
    if (!t)
      throw new Error("An active caller must be provided");
    if (this.continuation)
      switch (this.continuation.request) {
        case "CONTINUATION_REQUEST_TYPE_BROWSE":
          return yield t.browse(this.continuation.token, { is_ctoken: !0 });
        case "CONTINUATION_REQUEST_TYPE_SEARCH":
          return yield t.search({ ctoken: this.continuation.token });
        case "CONTINUATION_REQUEST_TYPE_WATCH_NEXT":
          return yield t.next({ ctoken: this.continuation.token });
        default:
          throw new Error(`${this.continuation.request} not implemented`);
      }
    if (this.search)
      return yield t.search({ query: this.search.query, params: this.search.params, client: i });
    if (this.browse)
      return yield t.browse(this.browse.id, Object.assign(Object.assign({}, this.browse), { client: i }));
    if (this.like) {
      if (!this.metadata.api_url)
        throw new Error("Like endpoint requires an api_url, but was not parsed from the response.");
      return yield t.engage(this.metadata.api_url, { video_id: this.like.target.video_id, params: this.like.params });
    }
  });
}, "_NavigationEndpoint_call");
ih.type = "NavigationEndpoint";
var B = ih, Og = class {
  constructor(e) {
    this.text = e.text, this.endpoint = e.navigationEndpoint ? new B(e.navigationEndpoint) : void 0;
  }
};
l(Og, "TextRun");
var k7 = Og, Fg = class {
  constructor(e) {
    var t, i, n;
    this.text = ((t = e.emoji) === null || t === void 0 ? void 0 : t.emojiId) || ((n = (i = e.emoji) === null || i === void 0 ? void 0 : i.shortcuts) === null || n === void 0 ? void 0 : n[0]) || "", this.emoji = {
      emoji_id: e.emoji.emojiId,
      shortcuts: e.emoji.shortcuts,
      search_terms: e.emoji.searchTerms,
      image: $.fromResponse(e.emoji.image)
    };
  }
};
l(Fg, "EmojiRun");
var A7 = Fg, Vg = class {
  constructor(e) {
    e?.hasOwnProperty("runs") && Array.isArray(e.runs) ? (this.runs = e.runs.map((t) => t.emoji ? new A7(t) : new k7(t)), this.text = this.runs.map((t) => t.text).join("")) : this.text = e?.simpleText || "N/A";
  }
  toString() {
    return this.text;
  }
};
l(Vg, "Text");
var b = Vg, nh = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.endpoint = new B(e.navigationEndpoint);
  }
};
l(nh, "AccountChannel");
nh.type = "AccountChannel";
var Ug = nh, sh = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(sh, "AccountItemSectionHeader");
sh.type = "AccountItemSectionHeader";
var jg = sh, rh = class {
  constructor(e) {
    this.account_name = new b(e.accountName), this.account_photo = $.fromResponse(e.accountPhoto), this.is_selected = e.isSelected, this.is_disabled = e.isDisabled, this.has_channel = e.hasChannel, this.endpoint = new B(e.serviceEndpoint), this.account_byline = new b(e.accountByline);
  }
};
l(rh, "AccountItem");
rh.type = "AccountItem";
var oh = class extends w {
  constructor(e) {
    super(), this.contents = e.contents.map((t) => new rh(t.accountItem)), this.header = y.parseItem(e.header, jg);
  }
};
l(oh, "AccountItemSection");
oh.type = "AccountItemSection";
var Hg = oh, ah = class extends w {
  constructor(e) {
    super(), this.contents = y.parseItem(e.contents[0], Hg), this.footers = y.parseItem(e.footers[0], Ug);
  }
};
l(ah, "AccountSectionList");
ah.type = "AccountSectionList";
var Wg = ah, lh = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.continuationItems), this.target = e.target;
  }
};
l(lh, "AppendContinuationItemsAction");
lh.type = "AppendContinuationItemsAction";
var $g = lh, uh = class extends w {
  constructor(e) {
    super(), this.popup = y.parse(e.popup), this.popup_type = e.popupType;
  }
};
l(uh, "OpenPopupAction");
uh.type = "OpenPopupAction";
var I7 = uh, ch = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.subtitle = e.subtitle, this.metric_value = e.metricValue, this.comparison_indicator = e.comparisonIndicator;
    const t = e.seriesConfiguration.lineSeries;
    this.series_configuration = {
      line_series: {
        lines_data: {
          x: t.linesData[0].x,
          y: t.linesData[0].y,
          style: {
            line_width: t.linesData[0].style.lineWidth,
            line_color: t.linesData[0].style.lineColor
          }
        },
        domain_axis: {
          tick_values: t.domainAxis.tickValues,
          custom_formatter: t.domainAxis.customFormatter
        },
        measure_axis: {
          tick_values: t.measureAxis.tickValues,
          custom_formatter: t.measureAxis.customFormatter
        }
      }
    };
  }
};
l(ch, "DataModelSection");
ch.type = "DataModelSection";
var Gg = ch, hh = class extends w {
  constructor(e) {
    super(), this.period = e.cardData.periodLabel;
    const t = e.cardData.sections[0].analyticsKeyMetricsData;
    this.sections = t.dataModel.sections.map((i) => new Gg(i));
  }
};
l(hh, "AnalyticsMainAppKeyMetrics");
hh.type = "AnalyticsMainAppKeyMetrics";
var P7 = hh, dh = class extends w {
  constructor(e) {
    super();
    const t = e.analyticsTableCarouselData.data.tableCards;
    this.title = e.analyticsTableCarouselData.carouselTitle, this.selected_card_index_key = e.analyticsTableCarouselData.selectedCardIndexKey, this.table_cards = t.map((i) => ({
      title: i.cardData.title,
      rows: i.cardData.rows.map((n) => ({
        label: n.label,
        display_value: n.displayValue,
        display_value_a11y: n.displayValueA11y,
        bar_ratio: n.barRatio,
        bar_color: n.barColor,
        bar_opacity: n.barOpacity
      }))
    })), this.use_main_app_specs = e.analyticsTableCarouselData.useMainAppSpecs;
  }
};
l(dh, "AnalyticsRoot");
dh.type = "AnalyticsRoot";
var M7 = dh, ph = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.shorts = e.shortsCarouselData.shorts.map((t) => ({
      description: t.shortsDescription,
      thumbnail_url: t.thumbnailUrl,
      endpoint: new B(t.videoEndpoint)
    }));
  }
};
l(ph, "AnalyticsShortsCarouselCard");
ph.type = "AnalyticsShortsCarouselCard";
var N7 = ph, fh = class extends w {
  constructor(e) {
    super(), this.title = e.videoTitle, this.metadata = {
      views: e.videoDescription.split("\xB7")[0].trim(),
      published: e.videoDescription.split("\xB7")[1].trim(),
      thumbnails: $.fromResponse(e.thumbnailDetails),
      duration: e.formattedLength,
      is_short: e.isShort
    };
  }
};
l(fh, "AnalyticsVideo");
fh.type = "AnalyticsVideo";
var qg = fh, mh = class extends w {
  constructor(e) {
    var t;
    super(), this.title = e.title, e.noDataMessage && (this.no_data_message = e.noDataMessage), this.videos = ((t = e.videoCarouselData) === null || t === void 0 ? void 0 : t.videos.map((i) => new qg(i))) || null;
  }
};
l(mh, "AnalyticsVodCarouselCard");
mh.type = "AnalyticsVodCarouselCard";
var R7 = mh, vh = class extends w {
  constructor(e) {
    super(), this.title = e.buttonLabel, this.use_new_specs = e.useNewSpecs;
  }
};
l(vh, "CtaGoToCreatorStudio");
vh.type = "CtaGoToCreatorStudio";
var L7 = vh, gh = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.contents = new b(e.contents);
  }
};
l(gh, "StatRow");
gh.type = "StatRow";
var D7 = gh, yh = class extends w {
  constructor(e) {
    super(), this.audio_only_availability = e.audioOnlyAvailability;
  }
};
l(yh, "AudioOnlyPlayability");
yh.type = "AudioOnlyPlayability";
var Kg = yh, _h = class extends w {
  constructor(e) {
    var t, i;
    super(), !((i = (t = e?.content) === null || t === void 0 ? void 0 : t.automixPlaylistVideoRenderer) === null || i === void 0) && i.navigationEndpoint && (this.playlist_video = {
      endpoint: new B(e.content.automixPlaylistVideoRenderer.navigationEndpoint)
    });
  }
};
l(_h, "AutomixPreviewVideo");
_h.type = "AutomixPreviewVideo";
var bh = _h, wh = class extends w {
  constructor(e) {
    super(), this.image = $.fromResponse(e.image);
  }
};
l(wh, "BackstageImage");
wh.type = "BackstageImage";
var B7 = wh, Sh = class extends b {
  constructor(e) {
    var t, i;
    super(e), this.endpoint = !((i = (t = e.runs) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0) && i.navigationEndpoint ? new B(e.runs[0].navigationEndpoint) : e.navigationEndpoint ? new B(e.navigationEndpoint) : e.titleNavigationEndpoint ? new B(e.titleNavigationEndpoint) : null;
  }
  toJSON() {
    return this;
  }
};
l(Sh, "NavigatableText");
Sh.type = "NavigatableText";
var zg = Sh, O7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ti = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Kt, Yg = class {
  constructor(e, t, i) {
    var n, s, r, a, u, c, h, p, f, _, C, E, P, A, F, M, j, z, D, v, U, Z, he, te, Je, Q, ie, ye, Ze, Te, st;
    Kt.set(this, void 0), O7(this, Kt, new zg(e), "f"), this.id = ((a = (r = (s = (n = Ti(this, Kt, "f").runs) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.id) || ((h = (c = (u = Ti(this, Kt, "f")) === null || u === void 0 ? void 0 : u.endpoint) === null || c === void 0 ? void 0 : c.browse) === null || h === void 0 ? void 0 : h.id) || "N/A", this.name = Ti(this, Kt, "f").text || "N/A", this.thumbnails = i ? $.fromResponse(i) : [], this.endpoint = ((f = (p = Ti(this, Kt, "f").runs) === null || p === void 0 ? void 0 : p[0]) === null || f === void 0 ? void 0 : f.endpoint) || Ti(this, Kt, "f").endpoint, this.badges = Array.isArray(t) ? y.parseArray(t) : [], this.is_verified = ((_ = this.badges) === null || _ === void 0 ? void 0 : _.some((Ve) => Ve.style == "BADGE_STYLE_TYPE_VERIFIED")) || null, this.is_verified_artist = ((C = this.badges) === null || C === void 0 ? void 0 : C.some((Ve) => Ve.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST")) || null, this.url = ((F = (A = (P = (E = Ti(this, Kt, "f")) === null || E === void 0 ? void 0 : E.runs) === null || P === void 0 ? void 0 : P[0]) === null || A === void 0 ? void 0 : A.endpoint) === null || F === void 0 ? void 0 : F.browse) && `${ve.URLS.YT_BASE}${((v = (D = (z = (j = (M = Ti(this, Kt, "f")) === null || M === void 0 ? void 0 : M.runs) === null || j === void 0 ? void 0 : j[0]) === null || z === void 0 ? void 0 : z.endpoint) === null || D === void 0 ? void 0 : D.browse) === null || v === void 0 ? void 0 : v.base_url) || `/u/${(Je = (te = (he = (Z = (U = Ti(this, Kt, "f")) === null || U === void 0 ? void 0 : U.runs) === null || Z === void 0 ? void 0 : Z[0]) === null || he === void 0 ? void 0 : he.endpoint) === null || te === void 0 ? void 0 : te.browse) === null || Je === void 0 ? void 0 : Je.id}`}` || `${ve.URLS.YT_BASE}${((ye = (ie = (Q = Ti(this, Kt, "f")) === null || Q === void 0 ? void 0 : Q.endpoint) === null || ie === void 0 ? void 0 : ie.browse) === null || ye === void 0 ? void 0 : ye.base_url) || `/u/${(st = (Te = (Ze = Ti(this, Kt, "f")) === null || Ze === void 0 ? void 0 : Ze.endpoint) === null || Te === void 0 ? void 0 : Te.browse) === null || st === void 0 ? void 0 : st.id}`}` || null;
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(Yg, "Author");
Kt = /* @__PURE__ */ new WeakMap();
var $t = Yg, Ch = class extends w {
  constructor(e) {
    super(), this.id = e.postId, this.author = new $t(Object.assign(Object.assign({}, e.authorText), { navigationEndpoint: e.authorEndpoint }), null, e.authorThumbnail), this.content = new b(e.contentText), this.published = new b(e.publishedTimeText), this.poll_status = e.pollStatus, this.vote_status = e.voteStatus, this.likes = new b(e.voteCount), this.menu = y.parse(e.actionMenu) || null, this.actions = y.parse(e.actionButtons), this.vote_button = y.parse(e.voteButton), this.surface = e.surface, this.endpoint = new B(e.navigationEndpoint), this.attachment = y.parse(e.backstageAttachment) || null;
  }
};
l(Ch, "BackstagePost");
Ch.type = "BackstagePost";
var Th = Ch, xh = class extends w {
  constructor(e) {
    super(), this.post = y.parse(e.post);
  }
};
l(xh, "BackstagePostThread");
xh.type = "BackstagePostThread";
var F7 = xh, Eh = class extends w {
  constructor(e) {
    super(), this.contents = y.parseArray(e.contents);
  }
};
l(Eh, "BrowseFeedActions");
Eh.type = "BrowseFeedActions";
var Xg = Eh, kh = class extends w {
  constructor(e) {
    super(), this.album = new b(e.album), this.thumbnails = $.fromResponse(e.thumbnailDetails);
  }
};
l(kh, "BrowserMediaSession");
kh.type = "BrowserMediaSession";
var V7 = kh, Ah = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.text = new b(e.text).toString(), !((t = e.accessibility) === null || t === void 0) && t.label && (this.label = (i = e.accessibility) === null || i === void 0 ? void 0 : i.label), e.tooltip && (this.tooltip = e.tooltip), !((n = e.icon) === null || n === void 0) && n.iconType && (this.icon_type = (s = e.icon) === null || s === void 0 ? void 0 : s.iconType), this.endpoint = new B(e.navigationEndpoint || e.serviceEndpoint || e.command);
  }
};
l(Ah, "Button");
Ah.type = "Button";
var ut = Ah, Ih = class extends w {
  constructor(e) {
    super(), this.author = new $t({
      simpleText: e.title,
      navigationEndpoint: e.navigationEndpoint
    }, e.badges, e.avatar), this.banner = e.banner ? $.fromResponse(e.banner) : [], this.tv_banner = e.tvBanner ? $.fromResponse(e.tvBanner) : [], this.mobile_banner = e.mobileBanner ? $.fromResponse(e.mobileBanner) : [], this.subscribers = new b(e.subscriberCountText), this.sponsor_button = e.sponsorButton ? y.parseItem(e.sponsorButton) : void 0, this.subscribe_button = e.subscribeButton ? y.parseItem(e.subscribeButton) : void 0, this.header_links = e.headerLinks ? y.parse(e.headerLinks) : void 0;
  }
};
l(Ih, "C4TabbedHeader");
Ih.type = "C4TabbedHeader";
var Jg = Ih, Ph = class extends w {
  constructor(e) {
    super(), this.label = new b(e.label), this.icon_type = e.icon.iconType, this.style = e.style;
  }
};
l(Ph, "CallToActionButton");
Ph.type = "CallToActionButton";
var U7 = Ph, Mh = class extends w {
  constructor(e) {
    super(), this.teaser = y.parseItem(e.teaser), this.content = y.parseItem(e.content), this.card_id = e.cardId || null, this.feature = e.feature || null, this.cue_ranges = e.cueRanges.map((t) => ({
      start_card_active_ms: t.startCardActiveMs,
      end_card_active_ms: t.endCardActiveMs,
      teaser_duration_ms: t.teaserDurationMs,
      icon_after_teaser_ms: t.iconAfterTeaserMs
    }));
  }
};
l(Mh, "Card");
Mh.type = "Card";
var j7 = Mh, Nh = class extends w {
  constructor(e) {
    super(), this.cards = y.parseArray(e.cards), this.header = new b(e.headerText), this.allow_teaser_dismiss = e.allowTeaserDismiss;
  }
};
l(Nh, "CardCollection");
Nh.type = "CardCollection";
var Zg = Nh, Rh = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.author = new $t(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.ownerBadges, e.thumbnail), this.subscribers = new b(e.subscriberCountText), this.videos = new b(e.videoCountText), this.endpoint = new B(e.navigationEndpoint), this.description_snippet = new b(e.descriptionSnippet);
  }
};
l(Rh, "Channel");
Rh.type = "Channel";
var Qg = Rh, Lh = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.name = new b(e.title), this.avatar = $.fromResponse(e.avatar), this.canonical_channel_url = e.canonicalChannelUrl, this.views = new b(e.viewCountText), this.joined = new b(e.joinedDateText), this.description = new b(e.description), this.email_reveal = new B(e.onBusinessEmailRevealClickCommand), this.can_reveal_email = !e.signInForBusinessEmail, this.country = new b(e.country), this.buttons = y.parse(e.actionButtons);
  }
};
l(Lh, "ChannelAboutFullMetadata");
Lh.type = "ChannelAboutFullMetadata";
var ey = Lh, Dh = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.items = y.parse(e.items);
  }
};
l(Dh, "ChannelFeaturedContent");
Dh.type = "ChannelFeaturedContent";
var H7 = Dh, nc = class {
  constructor(e) {
    this.endpoint = new B(e.navigationEndpoint), this.icon = $.fromResponse(e.icon), this.title = new b(e.title);
  }
};
l(nc, "HeaderLink");
var Bh = class extends w {
  constructor(e) {
    var t, i;
    super(), this.primary = ((t = e.primaryLinks) === null || t === void 0 ? void 0 : t.map((n) => new nc(n))) || [], this.secondary = ((i = e.secondaryLinks) === null || i === void 0 ? void 0 : i.map((n) => new nc(n))) || [];
  }
};
l(Bh, "ChannelHeaderLinks");
Bh.type = "ChannelHeaderLinks";
var W7 = Bh, Oh = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description, this.url = e.channelUrl, this.rss_urls = e.rssUrl, this.vanity_channel_url = e.vanityChannelUrl, this.external_id = e.externalId, this.is_family_safe = e.isFamilySafe, this.keywords = e.keywords, this.avatar = $.fromResponse(e.avatar), this.available_countries = e.availableCountryCodes, this.android_deep_link = e.androidDeepLink, this.android_appindexing_link = e.androidAppindexingLink, this.ios_appindexing_link = e.iosAppindexingLink;
  }
};
l(Oh, "ChannelMetadata");
Oh.type = "ChannelMetadata";
var ty = Oh, Fh = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(Fh, "ChannelMobileHeader");
Fh.type = "ChannelMobileHeader";
var $7 = Fh, Vh = class extends w {
  constructor(e) {
    super(), this.avatar = $.fromResponse(e.avatar), this.endpoint = new B(e.avatarEndpoint), this.name = e.name, this.links = e.links.map((t) => new b(t));
  }
};
l(Vh, "ChannelOptions");
Vh.type = "ChannelOptions";
var iy = Vh, Uh = class extends w {
  constructor(e) {
    super(), this.thumbnails = $.fromResponse(e.thumbnail), this.endpoint = new B(e.navigationEndpoint), this.label = e.accessibility.accessibilityData.label;
  }
};
l(Uh, "ChannelThumbnailWithLink");
Uh.type = "ChannelThumbnailWithLink";
var G7 = Uh, jh = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new b(e.title), this.description = new b(e.description), this.views = new b(e.viewCountText), this.published = new b(e.publishedTimeText);
  }
};
l(jh, "ChannelVideoPlayer");
jh.type = "ChannelVideoPlayer";
var q7 = jh, Hh = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new b(e.title), this.duration = {
      text: e.lengthText.simpleText,
      seconds: ji(e.lengthText.simpleText)
    }, this.endpoint = new B(e.navigationEndpoint);
  }
};
l(Hh, "ChildVideo");
Hh.type = "ChildVideo";
var K7 = Hh, Wh = class extends w {
  constructor(e) {
    super(), this.is_selected = e.isSelected, this.endpoint = e.navigationEndpoint ? new B(e.navigationEndpoint) : void 0, this.text = new b(e.text).toString();
  }
};
l(Wh, "ChipCloudChip");
Wh.type = "ChipCloudChip";
var Wo = Wh, $h = class extends w {
  constructor(e) {
    super(), this.chips = y.parseArray(e.chips, Wo), this.next_button = y.parseItem(e.nextButton, ut), this.previous_button = y.parseItem(e.previousButton, ut), this.horizontal_scrollable = e.horizontalScrollable;
  }
};
l($h, "ChipCloud");
$h.type = "ChipCloud";
var Gh = $h, qh = class extends w {
  constructor(e) {
    super(), this.channel_avatar = $.fromResponse(e.channelAvatar), this.custom_text = new b(e.customText), this.channel_name = new b(e.channelName), this.subscriber_count = new b(e.subscriberCountText), this.endpoint = new B(e.endpoint);
  }
};
l(qh, "CollaboratorInfoCardContent");
qh.type = "CollaboratorInfoCardContent";
var z7 = qh, Kh = class extends w {
  constructor(e) {
    super(), this.left = $.fromResponse(e.leftThumbnail), this.top_right = $.fromResponse(e.topRightThumbnail), this.bottom_right = $.fromResponse(e.bottomRightThumbnail), this.endpoint = new B(e.navigationEndpoint);
  }
};
l(Kh, "CollageHeroImage");
Kh.type = "CollageHeroImage";
var Y7 = Kh, X7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, J7 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ka, zh = class extends w {
  constructor(e) {
    var t;
    super(), Ka.set(this, void 0), this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.iconType) || null, this.tooltip = e.iconTooltip, this.tooltip === "Verified" && (this.style = "BADGE_STYLE_TYPE_VERIFIED") && (e.style = "BADGE_STYLE_TYPE_VERIFIED"), X7(this, Ka, e, "f");
  }
  get orig_badge() {
    return J7(this, Ka, "f");
  }
};
l(zh, "AuthorCommentBadge");
Ka = /* @__PURE__ */ new WeakMap();
zh.type = "AuthorCommentBadge";
var ny = zh, Yh = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p;
    super(), this.text = new b(e.defaultText), this.toggled_text = new b(e.toggledText), this.tooltip = e.defaultTooltip, this.toggled_tooltip = e.toggledTooltip, this.is_toggled = e.isToggled, this.is_disabled = e.isDisabled, this.icon_type = e.defaultIcon.iconType;
    const f = ((n = (i = (t = e?.defaultText) === null || t === void 0 ? void 0 : t.accessibility) === null || i === void 0 ? void 0 : i.accessibilityData) === null || n === void 0 ? void 0 : n.label) || ((r = (s = e?.accessibilityData) === null || s === void 0 ? void 0 : s.accessibilityData) === null || r === void 0 ? void 0 : r.label) || ((a = e?.accessibility) === null || a === void 0 ? void 0 : a.label);
    this.icon_type == "LIKE" && (this.like_count = parseInt(f.replace(/\D/g, "")), this.short_like_count = new b(e.defaultText).toString()), this.endpoint = !((c = (u = e.defaultServiceEndpoint) === null || u === void 0 ? void 0 : u.commandExecutorCommand) === null || c === void 0) && c.commands ? new B(e.defaultServiceEndpoint.commandExecutorCommand.commands.pop()) : new B(e.defaultServiceEndpoint), this.toggled_endpoint = new B(e.toggledServiceEndpoint), this.button_id = ((p = (h = e.toggleButtonSupportedData) === null || h === void 0 ? void 0 : h.toggleButtonIdData) === null || p === void 0 ? void 0 : p.id) || null, this.target_id = e.targetId || null;
  }
};
l(Yh, "ToggleButton");
Yh.type = "ToggleButton";
var _t = Yh, Xh = class extends w {
  constructor(e) {
    super(), this.reply_button = y.parse(e.replyButton), this.cancel_button = y.parse(e.cancelButton), this.author_thumbnail = $.fromResponse(e.authorThumbnail), this.placeholder = new b(e.placeholderText), this.error_message = new b(e.errorMessage);
  }
};
l(Xh, "CommentReplyDialog");
Xh.type = "CommentReplyDialog";
var sy = Xh, Jh = class extends w {
  constructor(e) {
    super(), this.like_button = y.parse(e.likeButton), this.dislike_button = y.parse(e.dislikeButton), this.reply_button = y.parse(e.replyButton);
  }
};
l(Jh, "CommentActionButtons");
Jh.type = "CommentActionButtons";
var is = Jh, Ea = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, hn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Z7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, di, Zh = class extends w {
  constructor(e) {
    var t, i;
    super(), di.set(this, void 0), this.content = new b(e.contentText), this.published = new b(e.publishedTimeText), this.author_is_channel_owner = e.authorIsChannelOwner, this.current_user_reply_thumbnail = $.fromResponse(e.currentUserReplyThumbnail), this.author_badge = y.parseItem(e.authorCommentBadge, ny), this.author = new $t(Object.assign(Object.assign({}, e.authorText), { navigationEndpoint: e.authorEndpoint }), this.author_badge ? [{
      metadataBadgeRenderer: (t = this.author_badge) === null || t === void 0 ? void 0 : t.orig_badge
    }] : null, e.authorThumbnail), this.action_menu = y.parse(e.actionMenu), this.action_buttons = y.parse(e.actionButtons), this.comment_id = e.commentId, this.vote_status = e.voteStatus, this.vote_count = {
      text: e.voteCount ? (i = e.voteCount.accessibility.accessibilityData) === null || i === void 0 ? void 0 : i.label.replace(/\D/g, "") : "0",
      short_text: e.voteCount ? new b(e.voteCount).toString() : "0"
    }, this.reply_count = e.replyCount || 0, this.is_liked = this.action_buttons.item().as(is).like_button.item().as(_t).is_toggled, this.is_disliked = this.action_buttons.item().as(is).dislike_button.item().as(_t).is_toggled, this.is_pinned = !!e.pinnedCommentBadge;
  }
  like() {
    return Ea(this, void 0, void 0, function* () {
      if (!hn(this, di, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const e = this.action_buttons.item().as(is).like_button.item().as(_t);
      if (e.is_toggled)
        throw new x("This comment is already liked", { comment_id: this.comment_id });
      return yield e.endpoint.callTest(hn(this, di, "f"), { parse: !1 });
    });
  }
  dislike() {
    return Ea(this, void 0, void 0, function* () {
      if (!hn(this, di, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const e = this.action_buttons.item().as(is).dislike_button.item().as(_t);
      if (e.is_toggled)
        throw new x("This comment is already disliked", { comment_id: this.comment_id });
      return yield e.endpoint.callTest(hn(this, di, "f"), { parse: !1 });
    });
  }
  reply(e) {
    return Ea(this, void 0, void 0, function* () {
      if (!hn(this, di, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      if (!this.action_buttons.item().as(is).reply_button)
        throw new x("Cannot reply to another reply. Try mentioning the user instead.", { comment_id: this.comment_id });
      const t = this.action_buttons.item().as(is).reply_button.item().as(_t);
      if (!t.endpoint.dialog)
        throw new x("Reply button endpoint did not have a dialog.");
      const n = t.endpoint.dialog.item().as(sy).reply_button.item().as(_t), s = {
        commentText: e
      };
      return yield n.endpoint.callTest(hn(this, di, "f"), s);
    });
  }
  translate(e) {
    return Ea(this, void 0, void 0, function* () {
      if (!hn(this, di, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const i = {
        text: this.content.toString().replace(/[^\p{L}\p{N}\p{P}\p{Z}]/gu, ""),
        target_language: e,
        comment_id: this.comment_id
      }, n = Vt.encodeCommentActionParams(22, i), s = yield hn(this, di, "f").execute("comment/perform_comment_action", { action: n, client: "ANDROID" }), a = s.data.frameworkUpdates.entityBatchUpdate.mutations[0].payload.commentEntityPayload.translatedContent.content;
      return Object.assign(Object.assign({}, s), { content: a });
    });
  }
  setActions(e) {
    Z7(this, di, e, "f");
  }
};
l(Zh, "Comment");
di = /* @__PURE__ */ new WeakMap();
Zh.type = "Comment";
var za = Zh, Qh = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents), this.view_replies = y.parse(e.viewReplies), this.hide_replies = y.parse(e.hideReplies);
  }
};
l(Qh, "CommentReplies");
Qh.type = "CommentReplies";
var Q7 = Qh, ed = class extends w {
  constructor(e) {
    super(), this.header = new b(e.headerText), this.comment_count = new b(e.commentCount), this.teaser_avatar = $.fromResponse(e.teaserAvatar || e.simpleboxAvatar), this.teaser_content = new b(e.teaserContent), this.simplebox_placeholder = new b(e.simpleboxPlaceholder);
  }
};
l(ed, "CommentsEntryPointHeader");
ed.type = "CommentsEntryPointHeader";
var ry = ed, td = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new b(e.titleText), this.count = new b(e.countText), this.comments_count = new b(e.commentsCount), this.create_renderer = y.parseItem(e.createRenderer), this.sort_menu = y.parse(e.sortMenu), this.custom_emojis = ((t = e.customEmojis) === null || t === void 0 ? void 0 : t.map((i) => ({
      emoji_id: i.emojiId,
      shortcuts: i.shortcuts,
      search_terms: i.searchTerms,
      image: $.fromResponse(i.image),
      is_custom_emoji: i.isCustomEmoji
    }))) || null;
  }
};
l(td, "CommentsHeader");
td.type = "CommentsHeader";
var oy = td, id = class extends w {
  constructor(e) {
    super(), this.submit_button = y.parse(e.submitButton), this.cancel_button = y.parse(e.cancelButton), this.author_thumbnails = $.fromResponse(e.authorThumbnail), this.placeholder = new b(e.placeholderText), this.avatar_size = e.avatarSize;
  }
};
l(id, "CommentSimplebox");
id.type = "CommentSimplebox";
var ay = id, nd = class extends w {
  constructor(e) {
    super(), this.trigger = e.trigger, e.button && (this.button = y.parse(e.button)), this.endpoint = new B(e.continuationEndpoint);
  }
};
l(nd, "ContinuationItem");
nd.type = "ContinuationItem";
var sn = nd, N5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, ka = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, xi = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, $r, zi, $s, sd = class extends w {
  constructor(e) {
    super(), $r.set(this, void 0), zi.set(this, void 0), $s.set(this, void 0), this.comment = y.parseItem(e.comment, za), ka(this, $r, y.parseItem(e.replies), "f"), this.is_moderated_elq_comment = e.isModeratedElqComment;
  }
  getReplies() {
    var e, t, i, n;
    return N5(this, void 0, void 0, function* () {
      if (!xi(this, zi, "f"))
        throw new x("Actions not set for this CommentThread.");
      if (!xi(this, $r, "f"))
        throw new x("This comment has no replies.", { comment_id: (e = this.comment) === null || e === void 0 ? void 0 : e.comment_id });
      const s = (t = xi(this, $r, "f").key("contents").parsed().array().get({ type: "ContinuationItem" })) === null || t === void 0 ? void 0 : t.as(sn), r = yield s?.endpoint.callTest(xi(this, zi, "f"), { parse: !0 });
      return this.replies = (i = r?.on_response_received_endpoints_memo) === null || i === void 0 ? void 0 : i.getType(za).map((a) => (a.setActions(xi(this, zi, "f")), a)), ka(this, $s, (n = r?.on_response_received_endpoints_memo.getType(sn)) === null || n === void 0 ? void 0 : n[0], "f"), this;
    });
  }
  getContinuation() {
    var e, t;
    return N5(this, void 0, void 0, function* () {
      if (!this.replies)
        throw new x("Continuation not available.");
      if (!xi(this, $s, "f"))
        throw new x("Continuation not found.");
      if (!xi(this, zi, "f"))
        throw new x("Actions not set for this CommentThread.");
      const i = yield (e = xi(this, $s, "f").button) === null || e === void 0 ? void 0 : e.item().key("endpoint").nodeOfType(B).callTest(xi(this, zi, "f"), { parse: !0 });
      return this.replies = i?.on_response_received_endpoints_memo.getType(za).map((n) => (n.setActions(xi(this, zi, "f")), n)), ka(this, $s, (t = i?.on_response_received_endpoints_memo.getType(sn)) === null || t === void 0 ? void 0 : t[0], "f"), this;
    });
  }
  setActions(e) {
    ka(this, zi, e, "f");
  }
};
l(sd, "CommentThread");
$r = /* @__PURE__ */ new WeakMap(), zi = /* @__PURE__ */ new WeakMap(), $s = /* @__PURE__ */ new WeakMap();
sd.type = "CommentThread";
var ly = sd, rd = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title).toString(), this.endpoint = new B(e.navigationEndpoint), this.style = e.style;
  }
};
l(rd, "CompactLink");
rd.type = "CompactLink";
var uy = rd, cy = class extends $t {
  constructor(e, t, i) {
    super(e, t, i), delete this.badges, delete this.is_verified, delete this.is_verified_artist;
  }
};
l(cy, "PlaylistAuthor");
var su = cy, od = class extends w {
  constructor(e) {
    var t;
    super(), this.id = e.playlistId, this.title = new b(e.title), this.author = !((t = e.shortBylineText) === null || t === void 0) && t.simpleText ? new b(e.shortBylineText) : new su(e.longBylineText, e.ownerBadges, null), this.thumbnails = $.fromResponse(e.thumbnail || { thumbnails: e.thumbnails.map((i) => i.thumbnails).flat(1) }), this.video_count = new b(e.thumbnailText), this.video_count_short = new b(e.videoCountShortText), this.first_videos = y.parse(e.videos) || [], this.share_url = e.shareUrl || null, this.menu = y.parse(e.menu), this.badges = y.parse(e.ownerBadges), this.endpoint = new B(e.navigationEndpoint), this.thumbnail_overlays = y.parse(e.thumbnailOverlays) || [];
  }
};
l(od, "Playlist");
od.type = "Playlist";
var ea = od, ad = class extends ea {
  constructor(e) {
    super(e);
  }
};
l(ad, "CompactMix");
ad.type = "CompactMix";
var eS = ad, ld = class extends ea {
  constructor(e) {
    super(e);
  }
};
l(ld, "CompactPlaylist");
ld.type = "CompactPlaylist";
var tS = ld, ud = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.thumbnails = $.fromResponse(e.thumbnail) || null, this.rich_thumbnail = e.richThumbnail && y.parse(e.richThumbnail), this.title = new b(e.title), this.author = new $t(e.longBylineText, e.ownerBadges, e.channelThumbnail), this.view_count = new b(e.viewCountText), this.short_view_count = new b(e.shortViewCountText), this.published = new b(e.publishedTimeText), this.duration = {
      text: new b(e.lengthText).toString(),
      seconds: ji(new b(e.lengthText).toString())
    }, this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.endpoint = new B(e.navigationEndpoint), this.menu = y.parse(e.menu);
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(ud, "CompactVideo");
ud.type = "CompactVideo";
var hy = ud, cd = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.confirm_button = y.parseItem(e.confirmButton, ut), this.cancel_button = y.parseItem(e.cancelButton, ut), this.dialog_messages = e.dialogMessages.map((t) => new b(t));
  }
};
l(cd, "ConfirmDialog");
cd.type = "ConfirmDialog";
var iS = cd, hd = class extends w {
  constructor(e) {
    super(), this.copy_button = y.parseItem(e.copyButton, ut), this.short_url = e.shortUrl, this.style = e.style;
  }
};
l(hd, "CopyLink");
hd.type = "CopyLink";
var dy = hd, dd = class extends w {
  constructor(e) {
    super(), this.text = new b(e.didYouMean).toString(), this.corrected_query = new b(e.correctedQuery), this.endpoint = new B(e.navigationEndpoint || e.correctedQueryEndpoint);
  }
};
l(dd, "DidYouMean");
dd.type = "DidYouMean";
var py = dd, pd = class extends w {
  constructor(e) {
    super(), this.style = e.style, this.size = e.size, this.endpoint = new B(e.command), this.target_id = e.targetId;
  }
};
l(pd, "DownloadButton");
pd.type = "DownloadButton";
var nS = pd, ru = class {
  constructor(e) {
    var t, i;
    this.text = ((i = (t = e.type.textType) === null || t === void 0 ? void 0 : t.text) === null || i === void 0 ? void 0 : i.content) || null, this.properties = e.properties, e.childElements && (this.child_elements = e.childElements.map((n) => new ru(n)));
  }
};
l(ru, "ChildElement");
ru.type = "ChildElement";
var sS = ru, ou = class extends w {
  constructor(e) {
    var t, i, n;
    if (super(), Reflect.has(e, "elementRenderer"))
      return y.parseItem(e, ou);
    const s = e.newElement.type.componentType;
    this.model = y.parse(s?.model), !((t = e.newElement) === null || t === void 0) && t.childElements && (this.child_elements = ((n = (i = e.newElement) === null || i === void 0 ? void 0 : i.childElements) === null || n === void 0 ? void 0 : n.map((r) => new sS(r))) || null);
  }
};
l(ou, "Element");
ou.type = "Element";
var fd = ou, md = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.first_option = y.parse(e.firstOption), this.menu = y.parse(e.menu);
  }
};
l(md, "EmergencyOnebox");
md.type = "EmergencyOnebox";
var rS = md, vd = class extends w {
  constructor(e) {
    super(), this.elements = y.parseArray(e.elements), this.start_ms = e.startMs;
  }
};
l(vd, "Endscreen");
vd.type = "Endscreen";
var fy = vd, gd = class extends w {
  constructor(e) {
    super(), this.style = `${e.style}`, this.title = new b(e.title), this.endpoint = new B(e.endpoint), e.image && (this.image = $.fromResponse(e.image)), e.icon && (this.icon = $.fromResponse(e.icon)), e.metadata && (this.metadata = new b(e.metadata)), e.callToAction && (this.call_to_action = new b(e.callToAction)), e.hovercardButton && (this.hovercard_button = y.parseItem(e.hovercardButton)), e.isSubscribe && (this.is_subscribe = !!e.isSubscribe), e.playlistLength && (this.playlist_length = new b(e.playlistLength)), this.thumbnail_overlays = e.thumbnailOverlays ? y.parseArray(e.thumbnailOverlays) : void 0, this.left = parseFloat(e.left), this.width = parseFloat(e.width), this.top = parseFloat(e.top), this.aspect_ratio = parseFloat(e.aspectRatio), this.start_ms = parseFloat(e.startMs), this.end_ms = parseFloat(e.endMs), this.id = e.id;
  }
};
l(gd, "EndscreenElement");
gd.type = "EndscreenElement";
var oS = gd, yd = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.title = new b(e.title), this.author = new b(e.longBylineText), this.endpoint = new B(e.navigationEndpoint), this.thumbnails = $.fromResponse(e.thumbnail), this.video_count = new b(e.videoCountText);
  }
};
l(yd, "EndScreenPlaylist");
yd.type = "EndScreenPlaylist";
var my = yd, _d = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new b(e.title), this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new $t(e.shortBylineText, e.ownerBadges), this.endpoint = new B(e.navigationEndpoint), this.short_view_count = new b(e.shortViewCountText), this.badges = y.parse(e.badges), this.duration = {
      text: new b(e.lengthText).toString(),
      seconds: e.lengthInSeconds
    };
  }
};
l(_d, "EndScreenVideo");
_d.type = "EndScreenVideo";
var vy = _d, bd = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.endpoint = new B(e.endpoint), this.selected = e.selected, this.content = e.content ? y.parse(e.content) : null;
  }
};
l(bd, "ExpandableTab");
bd.type = "ExpandableTab";
var aS = bd, wd = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(wd, "ExpandedShelfContents");
wd.type = "ExpandedShelfContents";
var lS = wd, Sd = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(Sd, "FeedFilterChipBar");
Sd.type = "FeedFilterChipBar";
var sc = Sd, Cd = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(Cd, "FeedTabbedHeader");
Cd.type = "FeedTabbedHeader";
var uS = Cd, Td = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.items = y.parse(e.items), this.is_collapsible = e.isCollapsible, this.visible_row_count = e.visibleRowCount, this.target_id = e.targetId, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || null, e.header && (this.header = y.parse(e.header));
  }
  get contents() {
    return this.items;
  }
};
l(Td, "Grid");
Td.type = "Grid";
var gy = Td, xd = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.author = new $t(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.ownerBadges, e.thumbnail), this.subscribers = new b(e.subscriberCountText), this.video_count = new b(e.videoCountText), this.endpoint = new B(e.navigationEndpoint), this.subscribe_button = y.parse(e.subscribeButton);
  }
};
l(xd, "GridChannel");
xd.type = "GridChannel";
var yy = xd, Ed = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(Ed, "GridHeader");
Ed.type = "GridHeader";
var cS = Ed, kd = class extends w {
  constructor(e) {
    var t;
    super(), this.id = e.playlistId, this.title = new b(e.title), e.shortBylineText && (this.author = new su(e.shortBylineText, e.ownerBadges)), this.badges = y.parse(e.ownerBadges), this.endpoint = new B(e.navigationEndpoint), this.view_playlist = new zg(e.viewPlaylistText), this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_renderer = y.parse(e.thumbnailRenderer), this.sidebar_thumbnails = [].concat(...((t = e.sidebarThumbnails) === null || t === void 0 ? void 0 : t.map((i) => $.fromResponse(i))) || []) || null, this.video_count = new b(e.thumbnailText), this.video_count_short = new b(e.videoCountShortText);
  }
};
l(kd, "GridPlaylist");
kd.type = "GridPlaylist";
var _y = kd, Ad = class extends w {
  constructor(e) {
    var t;
    super();
    const i = (t = e.thumbnailOverlays.find((n) => n.hasOwnProperty("thumbnailOverlayTimeStatusRenderer"))) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer;
    this.id = e.videoId, this.title = new b(e.title), this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.rich_thumbnail = e.richThumbnail && y.parse(e.richThumbnail), this.published = new b(e.publishedTimeText), this.duration = e.lengthText ? new b(e.lengthText) : i?.text ? new b(i.text) : "", this.author = e.shortBylineText && new $t(e.shortBylineText, e.ownerBadges), this.views = new b(e.viewCountText), this.short_view_count = new b(e.shortViewCountText), this.endpoint = new B(e.navigationEndpoint), this.menu = y.parse(e.menu);
  }
};
l(Ad, "GridVideo");
Ad.type = "GridVideo";
var by = Ad, Id = class {
  constructor(e) {
    this.thumbnail = {
      image: e.thumbnail.image.sources,
      endpoint: new B(e.thumbnail.onTap),
      on_long_press_endpoint: new B(e.thumbnail.onLongPress),
      content_mode: e.thumbnail.contentMode,
      crop_options: e.thumbnail.cropOptions
    }, this.background_image = {
      image: e.backgroundImage.image.sources,
      gradient_image: e.backgroundImage.gradientImage.sources
    }, this.strapline = e.strapline, this.title = e.title, this.description = e.description, this.cta = {
      icon_name: e.cta.iconName,
      title: e.cta.title,
      endpoint: new B(e.cta.onTap),
      accessibility_text: e.cta.accessibilityText,
      state: e.cta.state
    }, this.text_on_tap_endpoint = new B(e.textOnTap);
  }
};
l(Id, "Panel");
Id.type = "Panel";
var Pd = class extends w {
  constructor(e) {
    super(), this.panels = e.highlightsCarousel.panels.map((t) => new Id(t));
  }
};
l(Pd, "HighlightsCarousel");
Pd.type = "HighlightsCarousel";
var rc = Pd, Md = class extends w {
  constructor(e) {
    super(), this.suggestion = new b(e.suggestion), this.endpoint = new B(e.navigationEndpoint), this.icon_type = e.icon.iconType, e.serviceEndpoint && (this.service_endpoint = new B(e.serviceEndpoint));
  }
};
l(Md, "SearchSuggestion");
Md.type = "SearchSuggestion";
var wy = Md, Nd = class extends wy {
  constructor(e) {
    super(e);
  }
};
l(Nd, "HistorySuggestion");
Nd.type = "HistorySuggestion";
var hS = Nd, Rd = class extends w {
  constructor(e) {
    super(), this.cards = y.parse(e.cards), this.header = y.parse(e.header), this.previous_button = y.parse(e.previousButton), this.next_button = y.parse(e.nextButton);
  }
};
l(Rd, "HorizontalCardList");
Rd.type = "HorizontalCardList";
var Sy = Rd, Ld = class extends w {
  constructor(e) {
    super(), this.visible_item_count = e.visibleItemCount, this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Ld, "HorizontalList");
Ld.type = "HorizontalList";
var dS = Ld, Dd = class extends w {
  constructor(e) {
    var t;
    super(), this.icon_type = (t = e.icon) === null || t === void 0 ? void 0 : t.iconType, e.tooltip && (this.tooltip = new b(e.tooltip).toString()), this.endpoint = new B(e.navigationEndpoint);
  }
};
l(Dd, "IconLink");
Dd.type = "IconLink";
var Cy = Dd, Bd = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(Bd, "ItemSectionHeader");
Bd.type = "ItemSectionHeader";
var Ty = Bd, Od = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.selected = e.selected || !1, this.endpoint = new B(e.endpoint);
  }
};
l(Od, "ItemSectionTab");
Od.type = "Tab";
var xy = Od, Fd = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.tabs = y.parseArray(e.tabs, xy), e.endItems && (this.end_items = y.parseArray(e.endItems));
  }
};
l(Fd, "ItemSectionTabbedHeader");
Fd.type = "ItemSectionTabbedHeader";
var Ey = Fd, Vd = class extends w {
  constructor(e) {
    super(), this.header = y.parseItem(e.header, [Ty, Ey]), this.contents = y.parse(e.contents, !0), (e.targetId || e.sectionIdentifier) && (this.target_id = e?.target_id || e?.sectionIdentifier);
  }
};
l(Vd, "ItemSection");
Vd.type = "ItemSection";
var Hi = Vd, Ud = class extends w {
  constructor(e) {
    var t;
    super(), this.target = {
      video_id: e.target.videoId
    }, this.like_status = e.likeStatus, this.likes_allowed = e.likesAllowed, e.serviceEndpoints && (this.endpoints = (t = e.serviceEndpoints) === null || t === void 0 ? void 0 : t.map((i) => new B(i)));
  }
};
l(Ud, "LikeButton");
Ud.type = "LikeButton";
var pS = Ud, jd = class extends w {
  constructor(e) {
    var t, i;
    super(), this.header = y.parse(e.header), this.initial_display_state = e.initialDisplayState, this.continuation = (i = (t = e.continuations[0]) === null || t === void 0 ? void 0 : t.reloadContinuationData) === null || i === void 0 ? void 0 : i.continuation, this.client_messages = {
      reconnect_message: new b(e.clientMessages.reconnectMessage),
      unable_to_reconnect_message: new b(e.clientMessages.unableToReconnectMessage),
      fatal_error: new b(e.clientMessages.fatalError),
      reconnected_message: new b(e.clientMessages.reconnectedMessage),
      generic_error: new b(e.clientMessages.genericError)
    }, this.is_replay = e.isReplay || !1;
  }
};
l(jd, "LiveChat");
jd.type = "LiveChat";
var ky = jd, Hd = class extends w {
  constructor(e) {
    super(), this.banner = y.parse(e.bannerRenderer);
  }
};
l(Hd, "AddBannerToLiveChatCommand");
Hd.type = "AddBannerToLiveChatCommand";
var fS = Hd, Wd = class extends w {
  constructor(e) {
    super(), this.item = y.parseItem(e.item), this.client_id = e.clientId || null;
  }
};
l(Wd, "AddChatItemAction");
Wd.type = "AddChatItemAction";
var Ay = Wd, $d = class extends w {
  constructor(e) {
    super(), this.item = y.parseItem(e.item), this.duration_sec = e.durationSec;
  }
};
l($d, "AddLiveChatTickerItemAction");
$d.type = "AddLiveChatTickerItemAction";
var mS = $d, Gd = class extends w {
  constructor(e) {
    super(), this.auto_moderated_item = y.parse(e.autoModeratedItem), this.header_text = new b(e.headerText), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.id = e.id;
  }
};
l(Gd, "LiveChatAutoModMessage");
Gd.type = "LiveChatAutoModMessage";
var vS = Gd, qd = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.contents = y.parse(e.contents), this.action_id = e.actionId, this.viewer_is_creator = e.viewerIsCreator, this.target_id = e.targetId, this.is_stackable = e.isStackable, this.background_type = e.backgroundType;
  }
};
l(qd, "LiveChatBanner");
qd.type = "LiveChatBanner";
var gS = qd, Kd = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString(), this.icon_type = e.icon.iconType, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(Kd, "LiveChatBannerHeader");
Kd.type = "LiveChatBannerHeader";
var yS = Kd, zd = class extends w {
  constructor(e) {
    super(), this.poll_question = new b(e.pollQuestion), this.author_photo = $.fromResponse(e.authorPhoto), this.choices = e.pollChoices.map((t) => ({
      option_id: t.pollOptionId,
      text: new b(t.text).toString()
    })), this.collapsed_state_entity_key = e.collapsedStateEntityKey, this.live_chat_poll_state_entity_key = e.liveChatPollStateEntityKey, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(zd, "LiveChatBannerPoll");
zd.type = "LiveChatBannerPoll";
var _S = zd, Yd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.header_subtext = new b(e.headerSubtext), this.author = {
      id: e.authorExternalChannelId,
      name: new b(e?.authorName),
      thumbnails: $.fromResponse(e.authorPhoto),
      badges: y.parse(e.authorBadges)
    }, this.menu_endpoint = new B(e.contextMenuEndpoint);
  }
};
l(Yd, "LiveChatMembershipItem");
Yd.type = "LiveChatMembershipItem";
var bS = Yd, Xd = class extends w {
  constructor(e) {
    super(), e?.icon && (this.icon_type = e.icon.iconType), e?.style && (this.style = e.style), this.tooltip = e?.tooltip || e?.iconTooltip || null;
  }
};
l(Xd, "MetadataBadge");
Xd.type = "MetadataBadge";
var Ts = Xd, Jd = class extends Ts {
  constructor(e) {
    super(e), this.custom_thumbnail = e.customThumbnail ? $.fromResponse(e.customThumbnail) : null;
  }
};
l(Jd, "LiveChatAuthorBadge");
Jd.type = "LiveChatAuthorBadge";
var dr = Jd, Zd = class extends w {
  constructor(e) {
    super(), this.message = new b(e.message), this.author = {
      id: e.authorExternalChannelId,
      name: new b(e.authorName),
      thumbnails: $.fromResponse(e.authorPhoto),
      badges: y.parseArray(e.authorBadges, [Ts, dr]),
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [Ts, dr]);
    this.author.badges = t, this.author.is_moderator = t?.some((i) => i.icon_type == "MODERATOR") || null, this.author.is_verified = t?.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED") || null, this.author.is_verified_artist = t?.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST") || null, this.header_background_color = e.headerBackgroundColor, this.header_text_color = e.headerTextColor, this.body_background_color = e.bodyBackgroundColor, this.body_text_color = e.bodyTextColor, this.purchase_amount = new b(e.purchaseAmountText).toString(), this.menu_endpoint = new B(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.timestamp_text = new b(e.timestampText).toString(), this.id = e.id;
  }
};
l(Zd, "LiveChatPaidMessage");
Zd.type = "LiveChatPaidMessage";
var wS = Zd, Qd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.author = {
      id: e.authorExternalChannelId,
      name: new b(e.authorName),
      thumbnails: $.fromResponse(e.authorPhoto),
      badges: y.parse(e.authorBadges)
    }, this.money_chip_background_color = e.moneyChipBackgroundColor, this.money_chip_text_color = e.moneyChipTextColor, this.background_color = e.backgroundColor, this.author_name_text_color = e.authorNameTextColor, this.sticker = $.fromResponse(e.sticker), this.purchase_amount = new b(e.purchaseAmountText).toString(), this.context_menu = new B(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3);
  }
};
l(Qd, "LiveChatPaidSticker");
Qd.type = "LiveChatPaidSticker";
var SS = Qd, ep = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3);
  }
};
l(ep, "LiveChatPlaceholderItem");
ep.type = "LiveChatPlaceholderItem";
var CS = ep, tp = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.accessibility_title = e.accessibilityTitle, this.thumbnail = $.fromResponse(e.thumbnail), this.price = e.price, this.vendor_name = e.vendorName, this.from_vendor_text = e.fromVendorText, this.information_button = y.parse(e.informationButton), this.endpoint = new B(e.onClickCommand), this.creator_message = e.creatorMessage, this.creator_name = e.creatorName, this.author_photo = $.fromResponse(e.authorPhoto), this.information_dialog = y.parse(e.informationDialog), this.is_verified = e.isVerified, this.creator_custom_message = new b(e.creatorCustomMessage);
  }
};
l(tp, "LiveChatProductItem");
tp.type = "LiveChatProductItem";
var TS = tp, ip = class extends w {
  constructor(e) {
    super(), this.message = new b(e.message), this.author = {
      id: e.authorExternalChannelId,
      name: new b(e.authorName),
      thumbnails: $.fromResponse(e.authorPhoto),
      badges: [],
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [Ts, dr]);
    this.author.badges = t, this.author.is_moderator = t ? t.some((i) => i.icon_type == "MODERATOR") : null, this.author.is_verified = t ? t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED") : null, this.author.is_verified_artist = t ? t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST") : null, this.menu_endpoint = new B(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.id = e.id;
  }
};
l(ip, "LiveChatTextMessage");
ip.type = "LiveChatTextMessage";
var Iy = ip, np = class extends w {
  constructor(e) {
    super(), this.author = {
      id: e.authorExternalChannelId,
      thumbnails: $.fromResponse(e.authorPhoto),
      badges: y.parseArray(e.authorBadges, [Ts, dr]),
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [Ts, dr]);
    this.author.badges = t, this.author.is_moderator = t?.some((i) => i.icon_type == "MODERATOR") || null, this.author.is_verified = t?.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED") || null, this.author.is_verified_artist = t?.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST") || null, this.amount = new b(e.amount), this.duration_sec = e.durationSec, this.full_duration_sec = e.fullDurationSec, this.show_item = y.parse(e.showItemEndpoint.showLiveChatItemEndpoint.renderer), this.show_item_endpoint = new B(e.showItemEndpoint), this.id = e.id;
  }
};
l(np, "LiveChatTickerPaidMessageItem");
np.type = "LiveChatTickerPaidMessageItem";
var xS = np, sp = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.detail_text = new b(e.detailText).toString(), this.author = {
      id: e.authorExternalChannelId,
      name: new b(e?.authorName),
      thumbnails: $.fromResponse(e.sponsorPhoto)
    }, this.duration_sec = e.durationSec;
  }
};
l(sp, "LiveChatTickerSponsorItem");
sp.type = "LiveChatTickerSponsorItem";
var ES = sp, rp = class extends Iy {
  constructor(e) {
    super(e), delete this.author, delete this.menu_endpoint, this.icon_type = e.icon.iconType, this.action_button = y.parse(e.actionButton);
  }
};
l(rp, "LiveChatViewerEngagementMessage");
rp.type = "LiveChatViewerEngagementMessage";
var kS = rp, op = class extends w {
  constructor(e) {
    super(), this.poll_question = new b(e.pollQuestion), this.thumbnails = $.fromResponse(e.thumbnail), this.metadata = new b(e.metadataText), this.live_chat_poll_type = e.liveChatPollType, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(op, "PollHeader");
op.type = "PollHeader";
var AS = op, ap = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.contents = y.parse(e.contents), this.target_id = e.targetId;
  }
};
l(ap, "LiveChatActionPanel");
ap.type = "LiveChatActionPanel";
var IS = ap, lp = class extends w {
  constructor(e) {
    super(), this.deleted_state_message = new b(e.deletedStateMessage), this.target_item_id = e.targetItemId;
  }
};
l(lp, "MarkChatItemAsDeletedAction");
lp.type = "MarkChatItemAsDeletedAction";
var PS = lp, up = class extends w {
  constructor(e) {
    super(), this.deleted_state_message = new b(e.deletedStateMessage), this.channel_id = e.externalChannelId;
  }
};
l(up, "MarkChatItemsByAuthorAsDeletedAction");
up.type = "MarkChatItemsByAuthorAsDeletedAction";
var MS = up, cp = class extends w {
  constructor(e) {
    super(), this.target_action_id = e.targetActionId;
  }
};
l(cp, "RemoveBannerForLiveChatCommand");
cp.type = "RemoveBannerForLiveChatCommand";
var NS = cp, hp = class extends w {
  constructor(e) {
    super(), this.target_item_id = e.targetItemId, this.replacement_item = y.parse(e.replacementItem);
  }
};
l(hp, "ReplaceChatItemAction");
hp.type = "ReplaceChatItemAction";
var RS = hp, dp = class extends w {
  constructor(e) {
    var t;
    super(), this.actions = y.parse((t = e.actions) === null || t === void 0 ? void 0 : t.map((i) => (delete i.clickTrackingParams, i))) || [], this.video_offset_time_msec = e.videoOffsetTimeMsec;
  }
};
l(dp, "ReplayChatItemAction");
dp.type = "ReplayChatItemAction";
var LS = dp, pp = class extends w {
  constructor(e) {
    super(), this.panel_to_show = y.parse(e.panelToShow);
  }
};
l(pp, "ShowLiveChatActionPanelAction");
pp.type = "ShowLiveChatActionPanelAction";
var DS = pp, fp = class extends w {
  constructor(e) {
    super(), this.tooltip = y.parse(e.tooltip);
  }
};
l(fp, "ShowLiveChatTooltipCommand");
fp.type = "ShowLiveChatTooltipCommand";
var BS = fp, mp = class extends w {
  constructor(e) {
    super(), this.date_text = new b(e.dateText).toString();
  }
};
l(mp, "UpdateDateTextAction");
mp.type = "UpdateDateTextAction";
var Py = mp, vp = class extends w {
  constructor(e) {
    super(), this.description = new b(e.description);
  }
};
l(vp, "UpdateDescriptionAction");
vp.type = "UpdateDescriptionAction";
var My = vp, gp = class extends w {
  constructor(e) {
    super(), this.poll_to_update = y.parse(e.pollToUpdate);
  }
};
l(gp, "UpdateLiveChatPollAction");
gp.type = "UpdateLiveChatPollAction";
var OS = gp, yp = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(yp, "UpdateTitleAction");
yp.type = "UpdateTitleAction";
var Ny = yp, _p = class extends w {
  constructor(e) {
    super(), this.default_text = new b(e.defaultText).toString(), this.toggled_text = new b(e.toggledText).toString(), this.button_id = e.buttonId;
  }
};
l(_p, "UpdateToggleButtonTextAction");
_p.type = "UpdateToggleButtonTextAction";
var Ry = _p, bp = class extends w {
  constructor(e) {
    super();
    const t = e.viewCount.videoViewCountRenderer;
    this.view_count = new b(t.viewCount), this.extra_short_view_count = new b(t.extraShortViewCount), this.is_live = t.isLive;
  }
};
l(bp, "UpdateViewershipAction");
bp.type = "UpdateViewershipAction";
var Ly = bp, wp = class extends w {
  constructor(e) {
    super(), this.confirm_button = y.parseItem(e.confirmButton, ut), this.dialog_messages = e.dialogMessages.map((t) => new b(t));
  }
};
l(wp, "LiveChatDialog");
wp.type = "LiveChatDialog";
var FS = wp, Sp = class extends w {
  constructor(e) {
    super(), this.overflow_menu = y.parse(e.overflowMenu), this.collapse_button = y.parse(e.collapseButton), this.view_selector = y.parse(e.viewSelector);
  }
};
l(Sp, "LiveChatHeader");
Sp.type = "LiveChatHeader";
var VS = Sp, Cp = class extends w {
  constructor(e) {
    super(), this.max_items_to_display = e.maxItemsToDisplay, this.more_comments_below_button = y.parse(e.moreCommentsBelowButton);
  }
};
l(Cp, "LiveChatItemList");
Cp.type = "LiveChatItemList";
var US = Cp, Tp = class extends w {
  constructor(e) {
    super(), this.author_name = new b(e.authorName), this.author_photo = $.fromResponse(e.authorPhoto), this.send_button = y.parse(e.sendButton), this.target_id = e.targetId;
  }
};
l(Tp, "LiveChatMessageInput");
Tp.type = "LiveChatMessageInput";
var jS = Tp, xp = class extends w {
  constructor(e) {
    super(), this.name = new b(e.authorName), this.photo = $.fromResponse(e.authorPhoto), this.badges = y.parse(e.authorBadges);
  }
};
l(xp, "LiveChatParticipant");
xp.type = "LiveChatParticipant";
var HS = xp, Ep = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.participants = y.parse(e.participants);
  }
};
l(Ep, "LiveChatParticipantsList");
Ep.type = "LiveChatParticipantsList";
var WS = Ep, kp = class extends w {
  constructor(e) {
    var t, i;
    super(), this.items = y.parseArray(e.items), this.top_level_buttons = y.parseArray(e.topLevelButtons), this.label = ((i = (t = e.accessibility) === null || t === void 0 ? void 0 : t.accessibilityData) === null || i === void 0 ? void 0 : i.label) || null;
  }
  get contents() {
    return this.items;
  }
};
l(kp, "Menu");
kp.type = "Menu";
var rn = kp, Ap = class extends ut {
  constructor(e) {
    super(e);
  }
};
l(Ap, "MenuNavigationItem");
Ap.type = "MenuNavigationItem";
var $S = Ap, Ip = class extends ut {
  constructor(e) {
    super(e);
  }
};
l(Ip, "MenuServiceItem");
Ip.type = "MenuServiceItem";
var GS = Ip, Pp = class extends w {
  constructor(e) {
    super(), this.has_separator = e.hasSeparator, this.endpoint = new B(e.navigationEndpoint || e.serviceEndpoint);
  }
};
l(Pp, "MenuServiceItemDownload");
Pp.type = "MenuServiceItemDownload";
var qS = Pp, Mp = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.sections = y.parse(e.sections), this.style = e.style;
  }
};
l(Mp, "MultiPageMenu");
Mp.type = "MultiPageMenu";
var KS = Mp, Np = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Np, "MultiPageMenuNotificationSection");
Np.type = "MultiPageMenuNotificationSection";
var zS = Np, Rp = class extends w {
  constructor(e) {
    super();
  }
};
l(Rp, "MusicMenuItemDivider");
Rp.type = "MusicMenuItemDivider";
var Dy = Rp, Lp = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.title = new b(e.title).text, this.form_item_entity_key = e.formItemEntityKey, this.selected_icon_type = ((t = e.selectedIcon) === null || t === void 0 ? void 0 : t.iconType) || null;
    const r = (s = (n = (i = e.selectedCommand) === null || i === void 0 ? void 0 : i.commandExecutorCommand) === null || n === void 0 ? void 0 : n.commands) === null || s === void 0 ? void 0 : s.find((a) => {
      var u;
      return (u = a.musicBrowseFormBinderCommand) === null || u === void 0 ? void 0 : u.browseEndpoint;
    });
    r && (this.endpoint = new B(r.musicBrowseFormBinderCommand)), this.selected = !!this.endpoint;
  }
};
l(Lp, "MusicMultiSelectMenuItem");
Lp.type = "MusicMultiSelectMenuItem";
var Dp = Lp, Bp = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new b((t = e.title.musicMenuTitleRenderer) === null || t === void 0 ? void 0 : t.primaryText).text, this.options = y.parseArray(e.options, [Dp, Dy]);
  }
};
l(Bp, "MusicMultiSelectMenu");
Bp.type = "MusicMultiSelectMenu";
var By = Bp, Op = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.buttons = y.parse(e.buttons);
  }
};
l(Op, "SimpleMenuHeader");
Op.type = "SimpleMenuHeader";
var Oy = Op, Fp = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description, this.thumbnails = $.fromResponse(e.thumbnail), this.price = e.price, this.vendor_name = e.vendorName, this.button_text = e.buttonText, this.button_accessibility_text = e.buttonAccessibilityText, this.from_vendor_text = e.fromVendorText, this.additional_fees_text = e.additionalFeesText, this.region_format = e.regionFormat, this.endpoint = new B(e.buttonCommand);
  }
};
l(Fp, "MerchandiseItem");
Fp.type = "MerchandiseItem";
var YS = Fp, Vp = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.menu = y.parse(e.actionButton), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Vp, "MerchandiseShelf");
Vp.type = "MerchandiseShelf";
var Fy = Vp, Up = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString();
  }
};
l(Up, "Message");
Up.type = "Message";
var ta = Up, jp = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.contents = e.contents.map((t) => new b(t));
  }
};
l(jp, "MetadataRow");
jp.type = "MetadataRow";
var XS = jp, Hp = class extends w {
  constructor(e) {
    super(), this.rows = y.parseArray(e.rows), this.collapsed_item_count = e.collapsedItemCount;
  }
};
l(Hp, "MetadataRowContainer");
Hp.type = "MetadataRowContainer";
var Vy = Hp, Wp = class extends w {
  constructor(e) {
    super(), this.content = new b(e.content), this.has_divider_line = e.hasDividerLine;
  }
};
l(Wp, "MetadataRowHeader");
Wp.type = "MetadataRowHeader";
var JS = Wp, $p = class extends w {
  constructor(e) {
    super(), this.section_list = y.parseItem(e);
  }
};
l($p, "MetadataScreen");
$p.type = "MetadataScreen";
var ZS = $p, Gp = class extends w {
  constructor(e) {
    super(), this.url_canonical = e.urlCanonical, this.title = e.title, this.description = e.description, this.thumbnail = e.thumbnail ? $.fromResponse(e.thumbnail) : null, this.site_name = e.siteName, this.app_name = e.appName, this.android_package = e.androidPackage, this.ios_app_store_id = e.iosAppStoreId, this.ios_app_arguments = e.iosAppArguments, this.og_type = e.ogType, this.url_applinks_web = e.urlApplinksWeb, this.url_applinks_ios = e.urlApplinksIos, this.url_applinks_android = e.urlApplinksAndroid, this.url_twitter_ios = e.urlTwitterIos, this.url_twitter_android = e.urlTwitterAndroid, this.twitter_card_type = e.twitterCardType, this.twitter_site_handle = e.twitterSiteHandle, this.schema_dot_org_type = e.schemaDotOrgType, this.noindex = e.noindex, this.is_unlisted = e.unlisted, this.is_family_safe = e.familySafe, this.tags = e.tags, this.available_countries = e.availableCountries;
  }
};
l(Gp, "MicroformatData");
Gp.type = "MicroformatData";
var ia = Gp, qp = class extends ea {
  constructor(e) {
    super(e);
  }
};
l(qp, "Mix");
qp.type = "Mix";
var QS = qp, Kp = class extends w {
  constructor(e) {
    var t, i, n;
    super();
    const s = ((t = e.thumbnailOverlays.find((r) => r.thumbnailOverlayTimeStatusRenderer)) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer.text) || "N/A";
    this.id = e.videoId, this.title = new b(e.title), this.description_snippet = e.descriptionSnippet ? new b(e.descriptionSnippet) : null, this.top_metadata_items = new b(e.topMetadataItems), this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new $t(e.longBylineText, e.ownerBadges, (n = (i = e.channelThumbnailSupportedRenderers) === null || i === void 0 ? void 0 : i.channelThumbnailWithLinkRenderer) === null || n === void 0 ? void 0 : n.thumbnail), this.duration = {
      text: e.lengthText ? new b(e.lengthText).text : new b(s).text,
      seconds: ji(e.lengthText ? new b(e.lengthText).text : new b(s).text)
    }, this.endpoint = new B(e.navigationEndpoint), this.badges = y.parse(e.badges), this.use_vertical_poster = e.useVerticalPoster, this.show_action_menu = e.showActionMenu, this.menu = y.parse(e.menu);
  }
};
l(Kp, "Movie");
Kp.type = "Movie";
var e8 = Kp, zp = class extends w {
  constructor(e) {
    var t;
    return super(), (t = e.movingThumbnailDetails) === null || t === void 0 ? void 0 : t.thumbnails.map((i) => new $(i)).sort((i, n) => n.width - i.width);
  }
};
l(zp, "MovingThumbnail");
zp.type = "MovingThumbnail";
var t8 = zp, Yp = class extends w {
  constructor(e) {
    var t;
    super(), this.endpoint = new B(e.playNavigationEndpoint), this.play_icon_type = e.playIcon.iconType, this.pause_icon_type = e.pauseIcon.iconType, e.accessibilityPlayData && (this.play_label = e.accessibilityPlayData.accessibilityData.label), e.accessibilityPlayData && (this.pause_label = (t = e.accessibilityPauseData) === null || t === void 0 ? void 0 : t.accessibilityData.label), this.icon_color = e.iconColor;
  }
};
l(Yp, "MusicPlayButton");
Yp.type = "MusicPlayButton";
var Uy = Yp, Xp = class extends w {
  constructor(e) {
    super(), this.content = y.parseItem(e.content, Uy), this.content_position = e.contentPosition, this.display_style = e.displayStyle;
  }
};
l(Xp, "MusicItemThumbnailOverlay");
Xp.type = "MusicItemThumbnailOverlay";
var Jp = Xp, Zp = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p, f, _, C, E, P, A, F, M, j;
    switch (super(), this.title = new b(e.title), this.endpoint = new B(e.navigationEndpoint), this.id = ((i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id) || ((s = (n = this.endpoint) === null || n === void 0 ? void 0 : n.watch) === null || s === void 0 ? void 0 : s.video_id), this.subtitle = new b(e.subtitle), this.badges = y.parse(e.subtitleBadges), (a = (r = this.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.page_type) {
      case "MUSIC_PAGE_TYPE_ARTIST":
        this.item_type = "artist";
        break;
      case "MUSIC_PAGE_TYPE_PLAYLIST":
        this.item_type = "playlist";
        break;
      case "MUSIC_PAGE_TYPE_ALBUM":
        this.item_type = "album";
        break;
      default:
        !((u = this.endpoint) === null || u === void 0) && u.watch_playlist ? this.item_type = "endpoint" : !((c = this.subtitle.runs) === null || c === void 0) && c[0] ? this.subtitle.runs[0].text !== "Song" ? this.item_type = "video" : this.item_type = "song" : this.endpoint ? this.item_type = "endpoint" : this.item_type = "unknown";
        break;
    }
    if (this.item_type == "artist")
      this.subscribers = ((p = (h = this.subtitle.runs) === null || h === void 0 ? void 0 : h.find((z) => /^(\d*\.)?\d+[M|K]? subscribers?$/i.test(z.text))) === null || p === void 0 ? void 0 : p.text) || "";
    else if (this.item_type == "playlist") {
      const z = (f = this.subtitle.runs) === null || f === void 0 ? void 0 : f.find((D) => D.text.match(/\d+ songs|song/));
      this.item_count = z ? z.text : null;
    } else if (this.item_type == "album") {
      const z = (_ = this.subtitle.runs) === null || _ === void 0 ? void 0 : _.filter((D) => {
        var v, U;
        return (U = (v = D.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || U === void 0 ? void 0 : U.id.startsWith("UC");
      });
      z && (this.artists = z.map((D) => ({
        name: D.text,
        channel_id: D.endpoint.browse.id,
        endpoint: D.endpoint
      }))), this.year = (C = this.subtitle.runs) === null || C === void 0 ? void 0 : C.slice(-1)[0].text, isNaN(Number(this.year)) && delete this.year;
    } else if (this.item_type == "video") {
      this.views = ((P = (E = this === null || this === void 0 ? void 0 : this.subtitle.runs) === null || E === void 0 ? void 0 : E.find((D) => D?.text.match(/(.*?) views/))) === null || P === void 0 ? void 0 : P.text) || "N/A";
      const z = (A = this.subtitle.runs) === null || A === void 0 ? void 0 : A.find((D) => {
        var v, U, Z;
        return (Z = (U = (v = D.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || U === void 0 ? void 0 : U.id) === null || Z === void 0 ? void 0 : Z.startsWith("UC");
      });
      z && (this.author = {
        name: z?.text,
        channel_id: (M = (F = z?.endpoint) === null || F === void 0 ? void 0 : F.browse) === null || M === void 0 ? void 0 : M.id,
        endpoint: z?.endpoint
      });
    } else if (this.item_type == "song") {
      const z = (j = this.subtitle.runs) === null || j === void 0 ? void 0 : j.filter((D) => {
        var v, U;
        return (U = (v = D.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || U === void 0 ? void 0 : U.id.startsWith("UC");
      });
      z && (this.artists = z.map((D) => {
        var v, U;
        return {
          name: D?.text,
          channel_id: (U = (v = D?.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || U === void 0 ? void 0 : U.id,
          endpoint: D?.endpoint
        };
      }));
    }
    this.thumbnail = $.fromResponse(e.thumbnailRenderer.musicThumbnailRenderer.thumbnail), this.thumbnail_overlay = y.parseItem(e.thumbnailOverlay, Jp), this.menu = y.parseItem(e.menu, rn);
  }
};
l(Zp, "MusicTwoRowItem");
Zp.type = "MusicTwoRowItem";
var Qp = Zp, ef = class extends w {
  constructor(e) {
    super(), this.title = new b(e.text), this.display_priority = e.displayPriority;
  }
};
l(ef, "MusicResponsiveListItemFlexColumn");
ef.type = "musicResponsiveListItemFlexColumnRenderer";
var jy = ef, tf = class extends w {
  constructor(e) {
    super(), this.title = new b(e.text), this.display_priority = e.displayPriority;
  }
};
l(tf, "MusicResponsiveListItemFixedColumn");
tf.type = "musicResponsiveListItemFlexColumnRenderer";
var Hy = tf, N1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, xe = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ri, $e, Eo, ko, Wy, $y, R5, L5, Gy, qy, Ky, zy, nf = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    switch (super(), Ri.add(this), $e.set(this, void 0), Eo.set(this, void 0), ko.set(this, void 0), N1(this, $e, y.parseArray(e.flexColumns, jy), "f"), N1(this, Eo, y.parseArray(e.fixedColumns, Hy), "f"), N1(this, ko, {
      video_id: ((t = e?.playlistItemData) === null || t === void 0 ? void 0 : t.videoId) || null,
      playlist_set_video_id: ((i = e?.playlistItemData) === null || i === void 0 ? void 0 : i.playlistSetVideoId) || null
    }, "f"), this.endpoint = e.navigationEndpoint ? new B(e.navigationEndpoint) : null, (s = (n = this.endpoint) === null || n === void 0 ? void 0 : n.browse) === null || s === void 0 ? void 0 : s.page_type) {
      case "MUSIC_PAGE_TYPE_ALBUM":
        this.item_type = "album", xe(this, Ri, "m", Ky).call(this);
        break;
      case "MUSIC_PAGE_TYPE_PLAYLIST":
        this.item_type = "playlist", xe(this, Ri, "m", zy).call(this);
        break;
      case "MUSIC_PAGE_TYPE_ARTIST":
      case "MUSIC_PAGE_TYPE_USER_CHANNEL":
        this.item_type = "artist", xe(this, Ri, "m", Gy).call(this);
        break;
      case "MUSIC_PAGE_TYPE_LIBRARY_ARTIST":
        this.item_type = "library_artist", xe(this, Ri, "m", qy).call(this);
        break;
      default:
        xe(this, $e, "f")[1] ? xe(this, Ri, "m", $y).call(this) : xe(this, Ri, "m", Wy).call(this);
        break;
    }
    e.index && (this.index = new b(e.index)), this.thumbnails = e.thumbnail ? $.fromResponse((r = e.thumbnail.musicThumbnailRenderer) === null || r === void 0 ? void 0 : r.thumbnail) : [], this.badges = y.parseArray(e.badges), this.menu = y.parseItem(e.menu, rn), this.overlay = y.parseItem(e.overlay, Jp);
  }
};
l(nf, "MusicResponsiveListItem");
$e = /* @__PURE__ */ new WeakMap(), Eo = /* @__PURE__ */ new WeakMap(), ko = /* @__PURE__ */ new WeakMap(), Ri = /* @__PURE__ */ new WeakSet(), Wy = /* @__PURE__ */ l(function() {
  this.title = xe(this, $e, "f")[0].key("title").instanceof(b).toString(), this.endpoint ? this.item_type = "endpoint" : this.item_type = "unknown";
}, "_MusicResponsiveListItem_parseOther"), $y = /* @__PURE__ */ l(function() {
  var t;
  ((t = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || t === void 0 ? void 0 : t.some((n) => n.text.match(/(.*?) views/))) ? (this.item_type = "video", xe(this, Ri, "m", L5).call(this)) : (this.item_type = "song", xe(this, Ri, "m", R5).call(this));
}, "_MusicResponsiveListItem_parseVideoOrSong"), R5 = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u, c, h, p, f, _, C;
  this.id = xe(this, ko, "f").video_id || ((i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.watch) === null || i === void 0 ? void 0 : i.video_id), this.title = xe(this, $e, "f")[0].key("title").instanceof(b).toString();
  const E = ((s = (n = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || n === void 0 ? void 0 : n.find((F) => /^\d+$/.test(F.text.replace(/:/g, "")))) === null || s === void 0 ? void 0 : s.text) || ((u = (a = (r = xe(this, Eo, "f")) === null || r === void 0 ? void 0 : r[0]) === null || a === void 0 ? void 0 : a.key("title").instanceof(b)) === null || u === void 0 ? void 0 : u.toString());
  E && (this.duration = {
    text: E,
    seconds: ji(E)
  });
  const P = ((c = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || c === void 0 ? void 0 : c.find((F) => {
    var M, j;
    return (j = (M = Reflect.get(F, "endpoint")) === null || M === void 0 ? void 0 : M.browse) === null || j === void 0 ? void 0 : j.id.startsWith("MPR");
  })) || ((p = (h = xe(this, $e, "f")[2]) === null || h === void 0 ? void 0 : h.key("title").instanceof(b).runs) === null || p === void 0 ? void 0 : p.find((F) => {
    var M, j;
    return (j = (M = Reflect.get(F, "endpoint")) === null || M === void 0 ? void 0 : M.browse) === null || j === void 0 ? void 0 : j.id.startsWith("MPR");
  }));
  P && (this.album = {
    id: (_ = (f = P.endpoint) === null || f === void 0 ? void 0 : f.browse) === null || _ === void 0 ? void 0 : _.id,
    name: P.text,
    endpoint: P.endpoint
  });
  const A = (C = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || C === void 0 ? void 0 : C.filter((F) => {
    var M, j;
    return (j = (M = Reflect.get(F, "endpoint")) === null || M === void 0 ? void 0 : M.browse) === null || j === void 0 ? void 0 : j.id.startsWith("UC");
  });
  A && (this.artists = A.map((F) => {
    var M, j;
    return {
      name: F.text,
      channel_id: (j = (M = F.endpoint) === null || M === void 0 ? void 0 : M.browse) === null || j === void 0 ? void 0 : j.id,
      endpoint: F.endpoint
    };
  }));
}, "_MusicResponsiveListItem_parseSong"), L5 = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u, c;
  this.id = xe(this, ko, "f").video_id, this.title = xe(this, $e, "f")[0].key("title").instanceof(b).toString(), this.views = (i = (t = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || t === void 0 ? void 0 : t.find((f) => f.text.match(/(.*?) views/))) === null || i === void 0 ? void 0 : i.text;
  const h = (n = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || n === void 0 ? void 0 : n.filter((f) => {
    var _, C;
    return (C = (_ = Reflect.get(f, "endpoint")) === null || _ === void 0 ? void 0 : _.browse) === null || C === void 0 ? void 0 : C.id.startsWith("UC");
  });
  h && (this.authors = h.map((f) => {
    var _, C;
    return {
      name: f.text,
      channel_id: (C = (_ = f.endpoint) === null || _ === void 0 ? void 0 : _.browse) === null || C === void 0 ? void 0 : C.id,
      endpoint: f.endpoint
    };
  }));
  const p = ((r = (s = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || s === void 0 ? void 0 : s.find((f) => /^\d+$/.test(f.text.replace(/:/g, "")))) === null || r === void 0 ? void 0 : r.text) || ((c = (u = (a = xe(this, Eo, "f")[0]) === null || a === void 0 ? void 0 : a.key("title").instanceof(b).runs) === null || u === void 0 ? void 0 : u.find((f) => /^\d+$/.test(f.text.replace(/:/g, "")))) === null || c === void 0 ? void 0 : c.text);
  p && (this.duration = {
    text: p,
    seconds: ji(p)
  });
}, "_MusicResponsiveListItem_parseVideo"), Gy = /* @__PURE__ */ l(function() {
  var t, i, n, s;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.name = xe(this, $e, "f")[0].key("title").instanceof(b).toString(), this.subtitle = xe(this, $e, "f")[1].key("title").instanceof(b), this.subscribers = ((s = (n = this.subtitle.runs) === null || n === void 0 ? void 0 : n.find((r) => /^(\d*\.)?\d+[M|K]? subscribers?$/i.test(r.text))) === null || s === void 0 ? void 0 : s.text) || "";
}, "_MusicResponsiveListItem_parseArtist"), qy = /* @__PURE__ */ l(function() {
  var t, i, n;
  this.name = xe(this, $e, "f")[0].key("title").instanceof(b).toString(), this.subtitle = xe(this, $e, "f")[1].key("title").instanceof(b), this.song_count = ((n = (i = (t = this.subtitle) === null || t === void 0 ? void 0 : t.runs) === null || i === void 0 ? void 0 : i.find((s) => /^\d+(,\d+)? songs?$/i.test(s.text))) === null || n === void 0 ? void 0 : n.text) || "";
}, "_MusicResponsiveListItem_parseLibraryArtist"), Ky = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.title = xe(this, $e, "f")[0].key("title").instanceof(b).toString();
  const c = (n = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || n === void 0 ? void 0 : n.find((h) => {
    var p, f;
    return (f = (p = Reflect.get(h, "endpoint")) === null || p === void 0 ? void 0 : p.browse) === null || f === void 0 ? void 0 : f.id.startsWith("UC");
  });
  c && (this.author = {
    name: c.text,
    channel_id: (r = (s = c.endpoint) === null || s === void 0 ? void 0 : s.browse) === null || r === void 0 ? void 0 : r.id,
    endpoint: c.endpoint
  }), this.year = (u = (a = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || a === void 0 ? void 0 : a.find((h) => /^[12][0-9]{3}$/.test(h.text))) === null || u === void 0 ? void 0 : u.text;
}, "_MusicResponsiveListItem_parseAlbum"), zy = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.title = xe(this, $e, "f")[0].key("title").instanceof(b).toString();
  const u = (n = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || n === void 0 ? void 0 : n.find((h) => h.text.match(/\d+ (song|songs)/));
  this.item_count = u ? u.text : void 0;
  const c = (s = xe(this, $e, "f")[1].key("title").instanceof(b).runs) === null || s === void 0 ? void 0 : s.find((h) => {
    var p, f;
    return (f = (p = Reflect.get(h, "endpoint")) === null || p === void 0 ? void 0 : p.browse) === null || f === void 0 ? void 0 : f.id.startsWith("UC");
  });
  c && (this.author = {
    name: c.text,
    channel_id: (a = (r = c.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.id,
    endpoint: c.endpoint
  });
}, "_MusicResponsiveListItem_parsePlaylist");
nf.type = "MusicResponsiveListItem";
var na = nf, sf = class extends w {
  constructor(e) {
    super(), this.contents = $.fromResponse(e.thumbnail);
  }
};
l(sf, "MusicThumbnail");
sf.type = "MusicThumbnail";
var rf = sf, of = class extends w {
  constructor(e) {
    super(), e.strapline && (this.strapline = new b(e.strapline)), this.title = new b(e.title), e.thumbnail && (this.thumbnail = y.parseItem(e.thumbnail, rf)), e.moreContentButton && (this.more_content = y.parseItem(e.moreContentButton, ut)), e.endIcons && (this.end_icons = y.parseArray(e.endIcons, Cy));
  }
};
l(of, "MusicCarouselShelfBasicHeader");
of.type = "MusicCarouselShelfBasicHeader";
var Yy = of, af = class extends w {
  constructor(e) {
    super(), this.button_text = new b(e.buttonText).toString(), this.endpoint = new B(e.clickCommand);
  }
};
l(af, "MusicNavigationButton");
af.type = "MusicNavigationButton";
var lf = af, uf = class extends w {
  constructor(e) {
    super(), this.header = y.parseItem(e.header, Yy), this.contents = y.parseArray(e.contents, [Qp, na, lf]), this.num_items_per_column = Reflect.has(e, "numItemsPerColumn") ? parseInt(e.numItemsPerColumn) : null;
  }
};
l(uf, "MusicCarouselShelf");
uf.type = "MusicCarouselShelf";
var pr = uf, cf = class extends w {
  constructor(e) {
    super(), this.description = new b(e.description), this.max_collapsed_lines && (this.max_collapsed_lines = e.maxCollapsedLines), this.max_expanded_lines && (this.max_expanded_lines = e.maxExpandedLines), this.footer = new b(e.footer);
  }
};
l(cf, "MusicDescriptionShelf");
cf.type = "MusicDescriptionShelf";
var Ll = cf, hf = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h;
    super(), this.title = new b(e.title), this.description = new b(e.description), this.subtitle = new b(e.subtitle), this.second_subtitle = new b(e.secondSubtitle), this.year = ((i = (t = this.subtitle.runs) === null || t === void 0 ? void 0 : t.find((f) => /^[12][0-9]{3}$/.test(f.text))) === null || i === void 0 ? void 0 : i.text) || "", this.song_count = ((s = (n = this.second_subtitle.runs) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.text) || "", this.total_duration = ((a = (r = this.second_subtitle.runs) === null || r === void 0 ? void 0 : r[2]) === null || a === void 0 ? void 0 : a.text) || "", this.thumbnails = $.fromResponse(e.thumbnail.croppedSquareThumbnailRenderer.thumbnail), this.badges = y.parse(e.subtitleBadges);
    const p = (u = this.subtitle.runs) === null || u === void 0 ? void 0 : u.find((f) => {
      var _, C;
      return (C = (_ = f?.endpoint) === null || _ === void 0 ? void 0 : _.browse) === null || C === void 0 ? void 0 : C.id.startsWith("UC");
    });
    p && (this.author = {
      name: p.text,
      channel_id: (h = (c = p.endpoint) === null || c === void 0 ? void 0 : c.browse) === null || h === void 0 ? void 0 : h.id,
      endpoint: p.endpoint
    }), this.menu = y.parse(e.menu);
  }
};
l(hf, "MusicDetailHeader");
hf.type = "MusicDetailHeader";
var Dl = hf, df = class extends w {
  constructor(e) {
    super(), this.playlist_id = e.playlistId, this.supported_download_states = e.supportedDownloadStates;
  }
};
l(df, "MusicDownloadStateBadge");
df.type = "MusicDownloadStateBadge";
var i8 = df, pf = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header);
  }
};
l(pf, "MusicEditablePlaylistDetailHeader");
pf.type = "MusicEditablePlaylistDetailHeader";
var Xy = pf, ff = class extends w {
  constructor(e) {
    super(), this.element = Reflect.has(e, "elementRenderer") ? y.parseItem(e, fd) : null;
  }
};
l(ff, "MusicElementHeader");
ff.type = "MusicElementHeader";
var oc = ff, mf = class extends w {
  constructor(e) {
    super(), e.header && (this.header = y.parse(e.header)), e.title && (this.title = new b(e.title));
  }
};
l(mf, "MusicHeader");
mf.type = "MusicHeader";
var vf = mf, gf = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.description = new b(e.description), this.thumbnail = y.parseItem(e.thumbnail, rf);
  }
};
l(gf, "MusicImmersiveHeader");
gf.type = "MusicImmersiveHeader";
var Jy = gf, yf = class extends w {
  constructor(e) {
    super(), this.icon_type = e.icon.iconType, this.label = e.accessibilityData.accessibilityData.label;
  }
};
l(yf, "MusicInlineBadge");
yf.type = "MusicInlineBadge";
var n8 = yf, _f = class {
  constructor(e) {
    this.icon_name = e.iconName, this.endpoint = new B(e.onTap), this.a11y_text = e.a11yText, this.style = e.style;
  }
};
l(_f, "ActionButton");
_f.type = "ActionButton";
var bf = class {
  constructor(e) {
    this.image = e.image.image.sources, this.content_mode = e.image.contentMode, this.crop_options = e.image.cropOptions, this.image_aspect_ratio = e.imageAspectRatio, this.caption = e.caption, this.action_buttons = e.actionButtons.map((t) => new _f(t));
  }
};
l(bf, "Panel");
bf.type = "Panel";
var wf = class extends w {
  constructor(e) {
    super(), this.header = e.shelf.header, this.panels = e.shelf.panels.map((t) => new bf(t));
  }
};
l(wf, "MusicLargeCardItemCarousel");
wf.type = "MusicLargeCardItemCarousel";
var s8 = wf, Sf = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.playlist_id = e.playlistId, this.contents = y.parseArray(e.contents, na), this.collapsed_item_count = e.collapsedItemCount, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || null;
  }
};
l(Sf, "MusicPlaylistShelf");
Sf.type = "MusicPlaylistShelf";
var Bl = Sf, Cf = class extends w {
  constructor(e) {
    var t, i, n, s, r, a;
    super(), this.title = e.title, this.title_text = new b(e.titleText), this.contents = y.parseArray(e.contents), this.playlist_id = e.playlistId, this.is_infinite = e.isInfinite, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextRadioContinuationData) === null || n === void 0 ? void 0 : n.continuation) || ((a = (r = (s = e.continuations) === null || s === void 0 ? void 0 : s[0]) === null || r === void 0 ? void 0 : r.nextContinuationData) === null || a === void 0 ? void 0 : a.continuation), this.is_editable = e.isEditable, this.preview_description = e.previewDescription, this.num_items_to_show = e.numItemsToShow;
  }
};
l(Cf, "PlaylistPanel");
Cf.type = "PlaylistPanel";
var xs = Cf, Tf = class extends w {
  constructor(e) {
    super(), this.content = y.parseItem(e.content, xs);
  }
};
l(Tf, "MusicQueue");
Tf.type = "MusicQueue";
var xf = Tf, Ef = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.title = new b(e.title), this.contents = y.parseArray(e.contents, na), this.endpoint = Reflect.has(e, "bottomEndpoint") ? new B(e.bottomEndpoint) : null, this.continuation = ((i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData) === null || i === void 0 ? void 0 : i.continuation) || ((s = (n = e.continuations) === null || n === void 0 ? void 0 : n[0].reloadContinuationData) === null || s === void 0 ? void 0 : s.continuation) || null, this.bottom_text = Reflect.has(e, "bottomText") ? new b(e.bottomText) : null, this.bottom_button = y.parseItem(e.bottomButton, ut), e.subheaders && (this.subheaders = y.parseArray(e.subheaders));
  }
};
l(Ef, "MusicShelf");
Ef.type = "MusicShelf";
var fs = Ef, kf = class extends w {
  constructor(e) {
    super(), e.startItems && (this.start_items = y.parseArray(e.startItems));
  }
};
l(kf, "MusicSideAlignedItem");
kf.type = "MusicSideAlignedItem";
var r8 = kf, Af = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new b(e.title).text, this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.icon_type) || null, this.menu = y.parseItem(e.menu, By);
  }
};
l(Af, "MusicSortFilterButton");
Af.type = "MusicSortFilterButton";
var o8 = Af, If = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new b(e.title), this.thumbnails = e.thumbnail ? $.fromResponse((t = e.thumbnail.musicThumbnailRenderer) === null || t === void 0 ? void 0 : t.thumbnail) : [], this.menu = y.parseItem(e.menu, rn), this.foreground_thumbnails = e.foregroundThumbnail ? $.fromResponse((i = e.foregroundThumbnail.musicThumbnailRenderer) === null || i === void 0 ? void 0 : i.thumbnail) : [];
  }
};
l(If, "MusicVisualHeader");
If.type = "MusicVisualHeader";
var Zy = If, Pf = class extends w {
  constructor(e) {
    super(), this.thumbnails = $.fromResponse(e.thumbnail), this.video_thumbnails = $.fromResponse(e.videoThumbnail), this.short_message = new b(e.shortMessage), this.sent_time = new b(e.sentTimeText), this.notification_id = e.notificationId, this.endpoint = new B(e.navigationEndpoint), this.record_click_endpoint = new B(e.recordClickEndpoint), this.menu = y.parse(e.contextualMenu), this.read = e.read;
  }
};
l(Pf, "Notification");
Pf.type = "Notification";
var a8 = Pf, Mf = class extends w {
  constructor(e) {
    super(), this.header_text = new b(e.headerText).toString(), this.body_text = new b(e.bodyText).toString(), this.page_title = new b(e.pageTitle).toString(), this.header_icon_type = e.headerIcon.iconType;
  }
};
l(Mf, "PageIntroduction");
Mf.type = "PageIntroduction";
var Qy = Mf, Nf = class extends w {
  constructor(e) {
    super(), this.featured_channel = {
      start_time_ms: e.featuredChannel.startTimeMs,
      end_time_ms: e.featuredChannel.endTimeMs,
      watermark: $.fromResponse(e.featuredChannel.watermark),
      channel_name: e.featuredChannel.channelName,
      endpoint: new B(e.featuredChannel.navigationEndpoint),
      subscribe_button: y.parse(e.featuredChannel.subscribeButton)
    }, this.allow_swipe_dismiss = e.allowSwipeDismiss, this.annotation_id = e.annotationId;
  }
};
l(Nf, "PlayerAnnotationsExpanded");
Nf.type = "PlayerAnnotationsExpanded";
var e_ = Nf, Rf = class extends w {
  constructor(e) {
    super(), this.caption_tracks = e.captionTracks.map((t) => ({
      base_url: t.baseUrl,
      name: new b(t.name),
      vss_id: t.vssId,
      language_code: t.languageCode,
      kind: t.kind,
      is_translatable: t.isTranslatable
    })), this.audio_tracks = e.audioTracks.map((t) => ({
      caption_track_indices: t.captionTrackIndices
    })), this.translation_languages = e.translationLanguages.map((t) => ({
      language_code: t.languageCode,
      language_name: new b(t.languageName)
    }));
  }
};
l(Rf, "PlayerCaptionsTracklist");
Rf.type = "PlayerCaptionsTracklist";
var t_ = Rf, Lf = class extends w {
  constructor(e) {
    var t;
    super(), this.subreason = new b(e.subreason), this.reason = new b(e.reason), this.proceed_button = y.parseItem(e.proceedButton, ut), this.thumbnails = $.fromResponse(e.thumbnail), this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.iconType) || null;
  }
};
l(Lf, "PlayerErrorMessage");
Lf.type = "PlayerErrorMessage";
var l8 = Lf, Df = class extends w {
  constructor() {
    super();
  }
};
l(Df, "PlayerLiveStoryboardSpec");
Df.type = "PlayerLiveStoryboardSpec";
var i_ = Df, Bf = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.description = new b(e.description), this.thumbnails = $.fromResponse(e.thumbnail), this.embed = {
      iframe_url: e.embed.iframeUrl,
      flash_url: e.embed.flashUrl,
      flash_secure_url: e.embed.flashSecureUrl,
      width: e.embed.width,
      height: e.embed.height
    }, this.length_seconds = parseInt(e.lengthSeconds), this.channel = {
      id: e.externalChannelId,
      name: e.ownerChannelName,
      url: e.ownerProfileUrl
    }, this.is_family_safe = !!e.isFamilySafe, this.is_unlisted = !!e.isUnlisted, this.has_ypc_metadata = !!e.hasYpcMetadata, this.view_count = parseInt(e.viewCount), this.category = e.category, this.publish_date = e.publishDate, this.upload_date = e.uploadDate, this.available_countries = e.availableCountries;
  }
};
l(Bf, "PlayerMicroformat");
Bf.type = "PlayerMicroformat";
var Gr = Bf, Of = class extends w {
  constructor(e) {
    super(), this.results = y.parseArray(e.results, [vy, my]), this.title = new b(e.title).toString();
  }
};
l(Of, "WatchNextEndScreen");
Of.type = "WatchNextEndScreen";
var n_ = Of, Ff = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.video_id = e.videoId, this.video_title = new b(e.videoTitle), this.short_view_count = new b(e.shortViewCountText), this.prefer_immediate_redirect = e.preferImmediateRedirect, this.count_down_secs_for_fullscreen = e.countDownSecsForFullscreen, this.published = new b(e.publishedTimeText), this.background = $.fromResponse(e.background), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new $t(e.byline), this.cancel_button = y.parseItem(e.cancelButton, ut), this.next_button = y.parseItem(e.nextButton, ut), this.close_button = y.parseItem(e.closeButton, ut);
  }
};
l(Ff, "PlayerOverlayAutoplay");
Ff.type = "PlayerOverlayAutoplay";
var s_ = Ff, Vf = class extends w {
  constructor(e) {
    super(), this.end_screen = y.parseItem(e.endScreen, n_), this.autoplay = y.parseItem(e.autoplay, s_), this.share_button = y.parseItem(e.shareButton, ut), this.add_to_menu = y.parseItem(e.addToMenu, rn), this.fullscreen_engagement = y.parse(e.fullscreenEngagement), this.actions = y.parseArray(e.actions), this.browser_media_session = y.parseItem(e.browserMediaSession);
  }
};
l(Vf, "PlayerOverlay");
Vf.type = "PlayerOverlay";
var Uf = Vf, jf = class extends w {
  constructor(e) {
    super();
    const t = e.spec.split("|"), i = new URL(t.shift());
    this.boards = t.map((n, s) => {
      const [r, a, u, c, h, p, f, _] = n.split("#");
      i.searchParams.set("sigh", _);
      const C = Math.ceil(parseInt(u, 10) / (parseInt(c, 10) * parseInt(h, 10)));
      return {
        template_url: i.toString().replace("$L", s).replace("$N", f),
        thumbnail_width: parseInt(r, 10),
        thumbnail_height: parseInt(a, 10),
        thumbnail_count: parseInt(u, 10),
        interval: parseInt(p, 10),
        columns: parseInt(c, 10),
        rows: parseInt(h, 10),
        storyboard_count: C
      };
    });
  }
};
l(jf, "PlayerStoryboardSpec");
jf.type = "PlayerStoryboardSpec";
var r_ = jf, Hf = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.title = new b(e.title), this.stats = e.stats.map((t) => new b(t)), this.brief_stats = e.briefStats.map((t) => new b(t)), this.author = new su(Object.assign(Object.assign({}, e.ownerText), { navigationEndpoint: e.ownerEndpoint }), e.ownerBadges, null), this.description = new b(e.descriptionText), this.num_videos = new b(e.numVideosText), this.view_count = new b(e.viewCountText), this.can_share = e.shareData.canShare, this.can_delete = e.editableDetails.canDelete, this.is_editable = e.isEditable, this.privacy = e.privacy, this.save_button = y.parse(e.saveButton), this.shuffle_play_button = y.parse(e.shufflePlayButton), this.menu = y.parse(e.moreActionsMenu);
  }
};
l(Hf, "PlaylistHeader");
Hf.type = "PlaylistHeader";
var o_ = Hf, Wf = class extends w {
  constructor(e) {
    super(), this.title = new b(e.playlistTitle), this.thumbnails = $.fromResponse(e.thumbnail), this.video_count = new b(e.playlistVideoCount), this.channel_name = new b(e.channelName), this.endpoint = new B(e.action);
  }
};
l(Wf, "PlaylistInfoCardContent");
Wf.type = "PlaylistInfoCardContent";
var u8 = Wf, $f = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description || null;
  }
};
l($f, "PlaylistMetadata");
$f.type = "PlaylistMetadata";
var a_ = $f, Gf = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    super(), this.title = new b(e.title), this.thumbnail = $.fromResponse(e.thumbnail), this.endpoint = new B(e.navigationEndpoint), this.selected = e.selected, this.video_id = e.videoId, this.duration = {
      text: new b(e.lengthText).toString(),
      seconds: ji(new b(e.lengthText).toString())
    };
    const a = (t = new b(e.longBylineText).runs) === null || t === void 0 ? void 0 : t.find((c) => {
      var h, p;
      return (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id.startsWith("MPR");
    }), u = (i = new b(e.longBylineText).runs) === null || i === void 0 ? void 0 : i.filter((c) => {
      var h, p;
      return (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id.startsWith("UC");
    });
    this.author = new b(e.shortBylineText).toString(), a && (this.album = {
      id: (s = (n = a.endpoint) === null || n === void 0 ? void 0 : n.browse) === null || s === void 0 ? void 0 : s.id,
      name: a.text,
      year: (r = new b(e.longBylineText).runs) === null || r === void 0 ? void 0 : r.slice(-1)[0].text,
      endpoint: a.endpoint
    }), u && (this.artists = u.map((c) => {
      var h, p;
      return {
        name: c.text,
        channel_id: (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id,
        endpoint: c.endpoint
      };
    })), this.badges = y.parse(e.badges), this.menu = y.parse(e.menu), this.set_video_id = e.playlistSetVideoId;
  }
};
l(Gf, "PlaylistPanelVideo");
Gf.type = "PlaylistPanelVideo";
var l_ = Gf, qf = class extends w {
  constructor(e) {
    var t;
    super(), this.primary = y.parseItem(e.primaryRenderer), this.counterpart = ((t = e.counterpart) === null || t === void 0 ? void 0 : t.map((i) => y.parseItem(i.counterpartRenderer))) || [];
  }
};
l(qf, "PlaylistPanelVideoWrapper");
qf.type = "PlaylistPanelVideoWrapper";
var c8 = qf, Kf = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Kf, "PlaylistSidebar");
Kf.type = "PlaylistSidebar";
var ac = Kf, zf = class extends w {
  constructor(e) {
    super(), this.stats = e.stats.map((t) => new b(t)), this.thumbnail_renderer = y.parse(e.thumbnailRenderer), this.title = new b(e.title), this.menu = e.menu && y.parse(e.menu), this.endpoint = new B(e.navigationEndpoint), this.description = new b(e.description);
  }
};
l(zf, "PlaylistSidebarPrimaryInfo");
zf.type = "PlaylistSidebarPrimaryInfo";
var u_ = zf, Yf = class extends w {
  constructor(e) {
    super(), this.owner = y.parse(e.videoOwner) || null, this.button = y.parse(e.button) || null;
  }
};
l(Yf, "PlaylistSidebarSecondaryInfo");
Yf.type = "PlaylistSidebarSecondaryInfo";
var c_ = Yf, Xf = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.index = new b(e.index), this.title = new b(e.title), this.author = new su(e.shortBylineText), this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.set_video_id = e?.setVideoId, this.endpoint = new B(e.navigationEndpoint), this.is_playable = e.isPlayable, this.menu = y.parse(e.menu), this.duration = {
      text: new b(e.lengthText).text,
      seconds: parseInt(e.lengthSeconds)
    };
  }
};
l(Xf, "PlaylistVideo");
Xf.type = "PlaylistVideo";
var h_ = Xf, Jf = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.is_editable = e.isEditable, this.can_reorder = e.canReorder, this.videos = y.parse(e.contents);
  }
};
l(Jf, "PlaylistVideoList");
Jf.type = "PlaylistVideoList";
var h8 = Jf, Zf = class extends w {
  constructor(e) {
    super(), this.thumbnail = $.fromResponse(e.thumbnail);
  }
};
l(Zf, "PlaylistVideoThumbnail");
Zf.type = "PlaylistVideoThumbnail";
var d_ = Zf, Qf = class extends w {
  constructor(e) {
    super(), this.choices = e.choices.map((t) => ({
      text: new b(t.text).toString(),
      select_endpoint: t.selectServiceEndpoint ? new B(t.selectServiceEndpoint) : null,
      deselect_endpoint: t.deselectServiceEndpoint ? new B(t.deselectServiceEndpoint) : null,
      vote_ratio_if_selected: t?.voteRatioIfSelected || null,
      vote_percentage_if_selected: new b(t.votePercentageIfSelected),
      vote_ratio_if_not_selected: t?.voteRatioIfSelected || null,
      vote_percentage_if_not_selected: new b(t.votePercentageIfSelected),
      image: t.image ? $.fromResponse(t.image) : null
    })), e.type && (this.poll_type = e.type), e.totalVotes && (this.total_votes = new b(e.totalVotes)), e.liveChatPollId && (this.live_chat_poll_id = e.liveChatPollId);
  }
};
l(Qf, "Poll");
Qf.type = "Poll";
var d8 = Qf, e0 = class extends Th {
  constructor(e) {
    super(e);
  }
};
l(e0, "Post");
e0.type = "Post";
var p_ = e0, t0 = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(t0, "ProfileColumn");
t0.type = "ProfileColumn";
var lc = t0, i0 = class extends w {
  constructor(e) {
    super(), this.items = y.parseArray(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(i0, "ProfileColumnStats");
i0.type = "ProfileColumnStats";
var f_ = i0, n0 = class extends w {
  constructor(e) {
    super(), this.label = new b(e.label), this.value = new b(e.value);
  }
};
l(n0, "ProfileColumnStatsEntry");
n0.type = "ProfileColumnStatsEntry";
var p8 = n0, s0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.thumbnails = $.fromResponse(e.thumbnail);
  }
};
l(s0, "ProfileColumnUserInfo");
s0.type = "ProfileColumnUserInfo";
var m_ = s0, r0 = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new b(e.headline), this.thumbnails = $.fromResponse(e.thumbnail), this.views = new b(e.viewCountText), this.endpoint = new B(e.navigationEndpoint);
  }
};
l(r0, "ReelItem");
r0.type = "ReelItem";
var f8 = r0, o0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.items = y.parse(e.items), this.endpoint = e.endpoint ? new B(e.endpoint) : null;
  }
  get contents() {
    return this.items;
  }
};
l(o0, "ReelShelf");
o0.type = "ReelShelf";
var v_ = o0, a0 = class extends w {
  constructor(e) {
    super(), this.content = y.parse(e.content);
  }
};
l(a0, "RelatedChipCloud");
a0.type = "RelatedChipCloud";
var g_ = a0, l0 = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.contents = y.parse(e.contents);
  }
};
l(l0, "RichGrid");
l0.type = "RichGrid";
var y_ = l0, u0 = class extends w {
  constructor(e) {
    super(), this.content = y.parse(e.content);
  }
};
l(u0, "RichItem");
u0.type = "RichItem";
var m8 = u0, c0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.icon_type = e.icon.iconType;
  }
};
l(c0, "RichListHeader");
c0.type = "RichListHeader";
var __ = c0, h0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.content);
  }
};
l(h0, "RichSection");
h0.type = "RichSection";
var v8 = h0, d0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.contents = y.parse(e.contents), this.endpoint = e.endpoint ? new B(e.endpoint) : null;
  }
};
l(d0, "RichShelf");
d0.type = "RichShelf";
var b_ = d0, p0 = class extends w {
  constructor(e) {
    super(), this.endpoint = new B(e.endpoint), this.search_button = y.parse(e.searchButton), this.clear_button = y.parse(e.clearButton), this.placeholder_text = new b(e.placeholderText);
  }
};
l(p0, "SearchBox");
p0.type = "SearchBox";
var g8 = p0, f0 = class extends w {
  constructor(e) {
    super(), this.thumbnails = $.fromResponse(e.thumbnail), this.endpoint = new B(e.searchEndpoint), this.query = new b(e.query).toString();
  }
};
l(f0, "SearchRefinementCard");
f0.type = "SearchRefinementCard";
var w_ = f0, m0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(m0, "SearchSuggestionsSection");
m0.type = "SearchSuggestionsSection";
var S_ = m0, v0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(v0, "SecondarySearchContainer");
v0.type = "SecondarySearchContainer";
var y8 = v0, g0 = class extends w {
  constructor(e) {
    super(), e.targetId && (this.target_id = e.targetId), this.contents = y.parse(e.contents), e.continuations && (e.continuations[0].nextContinuationData ? this.continuation = e.continuations[0].nextContinuationData.continuation : e.continuations[0].reloadContinuationData && (this.continuation = e.continuations[0].reloadContinuationData.continuation)), e.header && (this.header = y.parse(e.header));
  }
};
l(g0, "SectionList");
g0.type = "SectionList";
var ft = g0, y0 = class extends w {
  constructor(e) {
    super(), this.like_button = y.parseItem(e.likeButton, _t), this.dislike_button = y.parseItem(e.dislikeButton, _t);
  }
};
l(y0, "SegmentedLikeDislikeButton");
y0.type = "SegmentedLikeDislikeButton";
var qr = y0, _0 = class extends w {
  constructor(e) {
    super(), e.title && (this.title = new b(e.title)), e.summary && (this.summary = new b(e.summary)), e.enableServiceEndpoint && (this.enable_endpoint = new B(e.enableServiceEndpoint)), e.disableServiceEndpoint && (this.disable_endpoint = new B(e.disableServiceEndpoint)), this.item_id = e.itemId;
  }
};
l(_0, "SettingBoolean");
_0.type = "SettingBoolean";
var _8 = _0, b0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.help_text = new b(e.helpText), this.enabled = e.enabled, this.disabled = e.disabled, this.id = e.id;
  }
};
l(b0, "SettingsCheckbox");
b0.type = "SettingsCheckbox";
var C_ = b0, w0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.subtitle = new b(e.subtitle), this.enabled = e.enabled, this.enable_endpoint = new B(e.enableServiceEndpoint), this.disable_endpoint = new B(e.disableServiceEndpoint);
  }
};
l(w0, "SettingsSwitch");
w0.type = "SettingsSwitch";
var S0 = w0, C0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), Reflect.has(e, "text") && (this.text = new b(e.text).toString()), Reflect.has(e, "options") && (this.options = y.parseArray(e.options, [
      S0,
      eh,
      dy,
      C_,
      iy
    ]));
  }
};
l(C0, "SettingsOptions");
C0.type = "SettingsOptions";
var Ya = C0, T0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.items = y.parseArray(e.items, uy);
  }
  get contents() {
    return this.items;
  }
};
l(T0, "SettingsSidebar");
T0.type = "SettingsSidebar";
var T_ = T0, x0 = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new b(e.title), e.endpoint && (this.endpoint = new B(e.endpoint)), this.content = y.parse(e.content) || null, !((t = e.icon) === null || t === void 0) && t.iconType && (this.icon_type = (i = e.icon) === null || i === void 0 ? void 0 : i.iconType), e.menu && (this.menu = y.parse(e.menu));
  }
};
l(x0, "Shelf");
x0.type = "Shelf";
var E0 = x0, k0 = class extends w {
  constructor(e) {
    super(), this.corrected_query = new b(e.correctedQuery), this.endpoint = new B(e.correctedQueryEndpoint), this.original_query_endpoint = new B(e.originalQueryEndpoint);
  }
};
l(k0, "ShowingResultsFor");
k0.type = "ShowingResultsFor";
var x_ = k0, A0 = class extends w {
  constructor(e) {
    super(), this.image = $.fromResponse(e.image), this.title = new b(e.title), this.display_domain = new b(e.displayDomain), this.show_link_icon = e.showLinkIcon, this.call_to_action = e.callToAction, this.endpoint = new B(e.command);
  }
};
l(A0, "SimpleCardContent");
A0.type = "SimpleCardContent";
var b8 = A0, I0 = class extends w {
  constructor(e) {
    super(), this.message = new b(e.message), this.prominent = e.prominent;
  }
};
l(I0, "SimpleCardTeaser");
I0.type = "SimpleCardTeaser";
var w8 = I0, P0 = class extends w {
  constructor(e) {
    super(), this.lines = e.lines.map((t) => new b(t)), this.style = e.layoutStyle;
  }
};
l(P0, "SimpleTextSection");
P0.type = "SimpleTextSection";
var S8 = P0, M0 = class extends w {
  constructor(e) {
    super(), this.action_text = new b(e.actionText), this.nav_text = new b(e.navigationText), this.details = new b(e.detailsText), this.icon_type = e.icon.iconType, this.endpoint = new B(e.navigationEndpoint);
  }
};
l(M0, "SingleActionEmergencySupport");
M0.type = "SingleActionEmergencySupport";
var C8 = M0, N0 = class extends w {
  constructor(e) {
    super(), this.title = e.title || "N/A", this.selected = e.selected || !1, this.endpoint = new B(e.endpoint), this.content = y.parseItem(e.content, [ft, xf, y_]);
  }
};
l(N0, "Tab");
N0.type = "Tab";
var jt = N0, R0 = class extends w {
  constructor(e) {
    super(), this.tabs = y.parseArray(e.tabs, jt);
  }
};
l(R0, "SingleColumnBrowseResults");
R0.type = "SingleColumnBrowseResults";
var sa = R0, L0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e);
  }
};
l(L0, "SingleColumnMusicWatchNextResults");
L0.type = "SingleColumnMusicWatchNextResults";
var Ao = L0, D0 = class extends w {
  constructor(e) {
    super(), this.thumbnails = $.fromResponse(e.thumbnail), this.style = e.style;
  }
};
l(D0, "SingleHeroImage");
D0.type = "SingleHeroImage";
var T8 = D0, B0 = class extends w {
  constructor(e) {
    super(), this.sub_menu_items = e.subMenuItems.map((t) => {
      var i;
      return {
        title: t.title,
        selected: t.selected,
        continuation: (i = t.continuation) === null || i === void 0 ? void 0 : i.reloadContinuationData.continuation,
        subtitle: t.subtitle
      };
    }), this.label = e.accessibility.accessibilityData.label;
  }
};
l(B0, "SortFilterSubMenu");
B0.type = "SortFilterSubMenu";
var x8 = B0, O0 = class extends w {
  constructor(e) {
    super(), this.name = new b(e.name), this.is_selected = e.isSelected, this.endpoint = new B(e.navigationEndpoint);
  }
};
l(O0, "SubFeedOption");
O0.type = "SubFeedOption";
var E8 = O0, F0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.options = y.parse(e.options);
  }
};
l(F0, "SubFeedSelector");
F0.type = "SubFeedSelector";
var k8 = F0, V0 = class extends w {
  constructor(e) {
    super(), this.states = e.states.map((t) => ({
      id: t.stateId,
      next_id: t.nextStateId,
      state: y.parse(t.state)
    })), this.current_state_id = e.currentStateId, this.target_id = e.targetId;
  }
};
l(V0, "SubscriptionNotificationToggleButton");
V0.type = "SubscriptionNotificationToggleButton";
var E_ = V0, U0 = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new b(e.buttonText), this.subscribed = e.subscribed, this.enabled = e.enabled, this.item_type = e.type, this.channel_id = e.channelId, this.show_preferences = e.showPreferences, this.subscribed_text = new b(e.subscribedButtonText), this.unsubscribed_text = new b(e.unsubscribedButtonText), this.notification_preference_button = y.parseItem(e.notificationPreferenceButton, E_), this.endpoint = new B(((t = e.serviceEndpoints) === null || t === void 0 ? void 0 : t[0]) || ((i = e.onSubscribeEndpoints) === null || i === void 0 ? void 0 : i[0]));
  }
};
l(U0, "SubscribeButton");
U0.type = "SubscribeButton";
var k_ = U0, j0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e);
  }
};
l(j0, "Tabbed");
j0.type = "Tabbed";
var Io = j0, H0 = class extends w {
  constructor(e) {
    super(), this.tabs = y.parseArray(e.tabs, jt);
  }
};
l(H0, "TabbedSearchResults");
H0.type = "TabbedSearchResults";
var A_ = H0, W0 = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.style = e.style;
  }
};
l(W0, "TextHeader");
W0.type = "TextHeader";
var A8 = W0, $0 = class extends w {
  constructor(e) {
    super(), this.icon_type = e.icon.iconType;
  }
};
l($0, "ThumbnailOverlayBottomPanel");
$0.type = "ThumbnailOverlayBottomPanel";
var I8 = $0, G0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString();
  }
};
l(G0, "ThumbnailOverlayEndorsement");
G0.type = "ThumbnailOverlayEndorsement";
var P8 = G0, q0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text), this.icon_type = e.icon.iconType;
  }
};
l(q0, "ThumbnailOverlayHoverText");
q0.type = "ThumbnailOverlayHoverText";
var M8 = q0, K0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString(), this.icon_type = e.icon.iconType;
  }
};
l(K0, "ThumbnailOverlayInlineUnplayable");
K0.type = "ThumbnailOverlayInlineUnplayable";
var N8 = K0, z0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text);
  }
};
l(z0, "ThumbnailOverlayLoadingPreview");
z0.type = "ThumbnailOverlayLoadingPreview";
var R8 = z0, Y0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString();
  }
};
l(Y0, "ThumbnailOverlayNowPlaying");
Y0.type = "ThumbnailOverlayNowPlaying";
var L8 = Y0, X0 = class extends w {
  constructor(e) {
    super(), this.hack = e.hack;
  }
};
l(X0, "ThumbnailOverlayPinking");
X0.type = "ThumbnailOverlayPinking";
var D8 = X0, J0 = class extends w {
  constructor(e) {
    super(), this.text = e.texts.map((t) => new b(t))[0].toString();
  }
};
l(J0, "ThumbnailOverlayPlaybackStatus");
J0.type = "ThumbnailOverlayPlaybackStatus";
var B8 = J0, Z0 = class extends w {
  constructor(e) {
    super(), this.percent_duration_watched = e.percentDurationWatched;
  }
};
l(Z0, "ThumbnailOverlayResumePlayback");
Z0.type = "ThumbnailOverlayResumePlayback";
var O8 = Z0, Q0 = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text), this.icon_type = e.icon.iconType;
  }
};
l(Q0, "ThumbnailOverlaySidePanel");
Q0.type = "ThumbnailOverlaySidePanel";
var F8 = Q0, em = class extends w {
  constructor(e) {
    super(), this.text = new b(e.text).toString();
  }
};
l(em, "ThumbnailOverlayTimeStatus");
em.type = "ThumbnailOverlayTimeStatus";
var V8 = em, tm = class extends w {
  constructor(e) {
    super(), this.is_toggled = e.isToggled || null, this.icon_type = {
      toggled: e.toggledIcon.iconType,
      untoggled: e.untoggledIcon.iconType
    }, this.tooltip = {
      toggled: e.toggledTooltip,
      untoggled: e.untoggledTooltip
    }, this.toggled_endpoint = new B(e.toggledServiceEndpoint), this.untoggled_endpoint = new B(e.untoggledServiceEndpoint);
  }
};
l(tm, "ThumbnailOverlayToggleButton");
tm.type = "ThumbnailOverlayToggleButton";
var U8 = tm, im = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title);
  }
};
l(im, "TitleAndButtonListHeader");
im.type = "TitleAndButtonListHeader";
var j8 = im, nm = class extends w {
  constructor(e) {
    super(), this.text = new b(e.defaultText), this.toggled_text = new b(e.toggledText), this.icon_type = e.defaultIcon.iconType, this.toggled_icon_type = e.toggledIcon.iconType, this.endpoint = new B(e.toggledServiceEndpoint);
  }
};
l(nm, "ToggleMenuServiceItem");
nm.type = "ToggleMenuServiceItem";
var H8 = nm, sm = class extends w {
  constructor(e) {
    super(), this.promo_config = {
      promo_id: e.promoConfig.promoId,
      impression_endpoints: e.promoConfig.impressionEndpoints.map((t) => new B(t)),
      accept: new B(e.promoConfig.acceptCommand),
      dismiss: new B(e.promoConfig.dismissCommand)
    }, this.target_id = e.targetId, this.details = new b(e.detailsText), this.suggested_position = e.suggestedPosition.type, this.dismiss_stratedy = e.dismissStrategy.type, this.dwell_time_ms = parseInt(e.dwellTimeMs);
  }
};
l(sm, "Tooltip");
sm.type = "Tooltip";
var W8 = sm, rm = class extends w {
  constructor(e) {
    super(), this.tabs = y.parse(e.tabs), this.secondary_contents = y.parse(e.secondaryContents);
  }
};
l(rm, "TwoColumnBrowseResults");
rm.type = "TwoColumnBrowseResults";
var ra = rm, om = class extends w {
  constructor(e) {
    super(), this.primary_contents = y.parse(e.primaryContents), this.secondary_contents = y.parse(e.secondaryContents);
  }
};
l(om, "TwoColumnSearchResults");
om.type = "TwoColumnSearchResults";
var am = om, lm = class extends w {
  constructor(e) {
    var t, i;
    super(), this.results = y.parse((t = e.results) === null || t === void 0 ? void 0 : t.results.contents, !0), this.secondary_results = y.parse((i = e.secondaryResults) === null || i === void 0 ? void 0 : i.secondaryResults.results, !0), this.conversation_bar = y.parse(e?.conversationBar);
  }
};
l(lm, "TwoColumnWatchNextResults");
lm.type = "TwoColumnWatchNextResults";
var I_ = lm, um = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.call_to_action = y.parse(e.callToAction), this.sections = y.parse(e.sections);
  }
};
l(um, "UniversalWatchCard");
um.type = "UniversalWatchCard";
var P_ = um, cm = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items), this.collapsed_item_count = e.collapsedItemCount, this.collapsed_state_button_text = new b(e.collapsedStateButtonText);
  }
  get contents() {
    return this.items;
  }
};
l(cm, "VerticalList");
cm.type = "VerticalList";
var $8 = cm, hm = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items), this.contents = this.items, this.view_all_text = new b(e.viewAllText), this.view_all_endpoint = new B(e.viewAllEndpoint);
  }
};
l(hm, "VerticalWatchCardList");
hm.type = "VerticalWatchCardList";
var G8 = hm, dm = class extends w {
  constructor(e) {
    var t, i, n, s;
    super();
    const r = ((t = e.thumbnailOverlays.find((u) => u.thumbnailOverlayTimeStatusRenderer)) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer.text) || "N/A";
    this.id = e.videoId, this.title = new b(e.title), this.description_snippet = e.descriptionSnippet ? new b(e.descriptionSnippet) : null, this.snippets = ((i = e.detailedMetadataSnippets) === null || i === void 0 ? void 0 : i.map((u) => ({
      text: new b(u.snippetText),
      hover_text: new b(u.snippetHoverText)
    }))) || [], this.thumbnails = $.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parseArray(e.thumbnailOverlays), this.rich_thumbnail = e.richThumbnail ? y.parse(e.richThumbnail) : null, this.author = new $t(e.ownerText, e.ownerBadges, (s = (n = e.channelThumbnailSupportedRenderers) === null || n === void 0 ? void 0 : n.channelThumbnailWithLinkRenderer) === null || s === void 0 ? void 0 : s.thumbnail), this.endpoint = new B(e.navigationEndpoint), this.published = new b(e.publishedTimeText), this.view_count = new b(e.viewCountText), this.short_view_count = new b(e.shortViewCountText);
    const a = e.upcomingEventData && Number(`${e.upcomingEventData.startTime}000`);
    a && (this.upcoming = new Date(a)), this.duration = {
      text: e.lengthText ? new b(e.lengthText).text : new b(r).text,
      seconds: ji(e.lengthText ? new b(e.lengthText).text : new b(r).text)
    }, this.show_action_menu = e.showActionMenu, this.is_watched = e.isWatched || !1, this.menu = y.parseItem(e.menu, rn);
  }
  get description() {
    var e;
    return this.snippets.length > 0 ? this.snippets.map((t) => t.text.toString()).join("") : ((e = this.description_snippet) === null || e === void 0 ? void 0 : e.toString()) || "";
  }
  get is_upcoming() {
    return this.upcoming && this.upcoming > new Date();
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(dm, "Video");
dm.type = "Video";
var M_ = dm, pm = class extends w {
  constructor(e) {
    super(), this.title = new b(e.videoTitle), this.channel_name = new b(e.channelName), this.view_count = new b(e.viewCountText), this.video_thumbnails = $.fromResponse(e.videoThumbnail), this.duration = new b(e.lengthString), this.endpoint = new B(e.action);
  }
};
l(pm, "VideoInfoCardContent");
pm.type = "VideoInfoCardContent";
var q8 = pm, fm = class extends w {
  constructor(e) {
    super(), this.subscription_button = e.subscriptionButton || null, this.subscriber_count = new b(e.subscriberCountText), this.author = new $t(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.badges, e.thumbnail);
  }
};
l(fm, "VideoOwner");
fm.type = "VideoOwner";
var N_ = fm, mm = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.super_title_link = new b(e.superTitleLink), this.view_count = new b(e.viewCount.videoViewCountRenderer.viewCount), this.short_view_count = new b(e.viewCount.videoViewCountRenderer.shortViewCount), this.published = new b(e.dateText), this.menu = y.parseItem(e.videoActions, rn);
  }
};
l(mm, "VideoPrimaryInfo");
mm.type = "VideoPrimaryInfo";
var R_ = mm, vm = class extends w {
  constructor(e) {
    super(), this.owner = y.parseItem(e.owner), this.description = new b(e.description), this.subscribe_button = y.parseItem(e.subscribeButton, [k_, ut]), this.metadata = y.parseItem(e.metadataRowContainer, Vy), this.show_more_text = e.showMoreText, this.show_less_text = e.showLessText, this.default_expanded = e.defaultExpanded, this.description_collapsed_lines = e.descriptionCollapsedLines;
  }
};
l(vm, "VideoSecondaryInfo");
vm.type = "VideoSecondaryInfo";
var L_ = vm, gm = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.subtitle = new b(e.subtitle), this.duration = {
      text: new b(e.lengthText).toString(),
      seconds: ji(e.lengthText.simpleText)
    }, this.style = e.style;
  }
};
l(gm, "WatchCardCompactVideo");
gm.type = "WatchCardCompactVideo";
var D_ = gm, ym = class extends w {
  constructor(e) {
    super(), this.endpoint = new B(e.navigationEndpoint), this.call_to_action_button = y.parse(e.callToActionButton), this.hero_image = y.parse(e.heroImage), this.label = e.accessibility.accessibilityData.label;
  }
};
l(ym, "WatchCardHeroVideo");
ym.type = "WatchCardHeroVideo";
var B_ = ym, _m = class extends w {
  constructor(e) {
    super(), this.title = new b(e.title), this.title_endpoint = new B(e.titleNavigationEndpoint), this.subtitle = new b(e.subtitle), this.author = new $t(e, e.titleBadge ? [e.titleBadge] : null, e.avatar), this.author.name = this.title.toString(), this.style = e.style;
  }
};
l(_m, "WatchCardRichHeader");
_m.type = "WatchCardRichHeader";
var K8 = _m, bm = class extends w {
  constructor(e) {
    super(), this.lists = y.parse(e.lists);
  }
};
l(bm, "WatchCardSectionSequence");
bm.type = "WatchCardSectionSequence";
var O_ = bm, wm = class extends ra {
  constructor(e) {
    super(e);
  }
};
l(wm, "WatchNextTabbedResults");
wm.type = "WatchNextTabbedResults";
var Po = wm, z8 = {
  AccountChannel: Ug,
  AccountItemSection: Hg,
  AccountItemSectionHeader: jg,
  AccountSectionList: Wg,
  AppendContinuationItemsAction: $g,
  OpenPopupAction: I7,
  AnalyticsMainAppKeyMetrics: P7,
  AnalyticsRoot: M7,
  AnalyticsShortsCarouselCard: N7,
  AnalyticsVideo: qg,
  AnalyticsVodCarouselCard: R7,
  CtaGoToCreatorStudio: L7,
  DataModelSection: Gg,
  StatRow: D7,
  AudioOnlyPlayability: Kg,
  AutomixPreviewVideo: bh,
  BackstageImage: B7,
  BackstagePost: Th,
  BackstagePostThread: F7,
  BrowseFeedActions: Xg,
  BrowserMediaSession: V7,
  Button: ut,
  C4TabbedHeader: Jg,
  CallToActionButton: U7,
  Card: j7,
  CardCollection: Zg,
  Channel: Qg,
  ChannelAboutFullMetadata: ey,
  ChannelFeaturedContent: H7,
  ChannelHeaderLinks: W7,
  ChannelMetadata: ty,
  ChannelMobileHeader: $7,
  ChannelOptions: iy,
  ChannelThumbnailWithLink: G7,
  ChannelVideoPlayer: q7,
  ChildVideo: K7,
  ChipCloud: Gh,
  ChipCloudChip: Wo,
  CollaboratorInfoCardContent: z7,
  CollageHeroImage: Y7,
  AuthorCommentBadge: ny,
  Comment: za,
  CommentActionButtons: is,
  CommentReplies: Q7,
  CommentReplyDialog: sy,
  CommentsEntryPointHeader: ry,
  CommentsHeader: oy,
  CommentSimplebox: ay,
  CommentThread: ly,
  CompactLink: uy,
  CompactMix: eS,
  CompactPlaylist: tS,
  CompactVideo: hy,
  ConfirmDialog: iS,
  ContinuationItem: sn,
  CopyLink: dy,
  CreatePlaylistDialog: Dg,
  DidYouMean: py,
  DownloadButton: nS,
  Dropdown: eh,
  DropdownItem: Ho,
  Element: fd,
  EmergencyOnebox: rS,
  Endscreen: fy,
  EndscreenElement: oS,
  EndScreenPlaylist: my,
  EndScreenVideo: vy,
  ExpandableTab: aS,
  ExpandedShelfContents: lS,
  FeedFilterChipBar: sc,
  FeedTabbedHeader: uS,
  Grid: gy,
  GridChannel: yy,
  GridHeader: cS,
  GridPlaylist: _y,
  GridVideo: by,
  HighlightsCarousel: rc,
  HistorySuggestion: hS,
  HorizontalCardList: Sy,
  HorizontalList: dS,
  IconLink: Cy,
  ItemSection: Hi,
  ItemSectionHeader: Ty,
  ItemSectionTab: xy,
  ItemSectionTabbedHeader: Ey,
  LikeButton: pS,
  LiveChat: ky,
  AddBannerToLiveChatCommand: fS,
  AddChatItemAction: Ay,
  AddLiveChatTickerItemAction: mS,
  LiveChatAutoModMessage: vS,
  LiveChatBanner: gS,
  LiveChatBannerHeader: yS,
  LiveChatBannerPoll: _S,
  LiveChatMembershipItem: bS,
  LiveChatPaidMessage: wS,
  LiveChatPaidSticker: SS,
  LiveChatPlaceholderItem: CS,
  LiveChatProductItem: TS,
  LiveChatTextMessage: Iy,
  LiveChatTickerPaidMessageItem: xS,
  LiveChatTickerSponsorItem: ES,
  LiveChatViewerEngagementMessage: kS,
  PollHeader: AS,
  LiveChatActionPanel: IS,
  MarkChatItemAsDeletedAction: PS,
  MarkChatItemsByAuthorAsDeletedAction: MS,
  RemoveBannerForLiveChatCommand: NS,
  ReplaceChatItemAction: RS,
  ReplayChatItemAction: LS,
  ShowLiveChatActionPanelAction: DS,
  ShowLiveChatTooltipCommand: BS,
  UpdateDateTextAction: Py,
  UpdateDescriptionAction: My,
  UpdateLiveChatPollAction: OS,
  UpdateTitleAction: Ny,
  UpdateToggleButtonTextAction: Ry,
  UpdateViewershipAction: Ly,
  LiveChatAuthorBadge: dr,
  LiveChatDialog: FS,
  LiveChatHeader: VS,
  LiveChatItemList: US,
  LiveChatMessageInput: jS,
  LiveChatParticipant: HS,
  LiveChatParticipantsList: WS,
  Menu: rn,
  MenuNavigationItem: $S,
  MenuServiceItem: GS,
  MenuServiceItemDownload: qS,
  MultiPageMenu: KS,
  MultiPageMenuNotificationSection: zS,
  MusicMenuItemDivider: Dy,
  MusicMultiSelectMenu: By,
  MusicMultiSelectMenuItem: Dp,
  SimpleMenuHeader: Oy,
  MerchandiseItem: YS,
  MerchandiseShelf: Fy,
  Message: ta,
  MetadataBadge: Ts,
  MetadataRow: XS,
  MetadataRowContainer: Vy,
  MetadataRowHeader: JS,
  MetadataScreen: ZS,
  MicroformatData: ia,
  Mix: QS,
  Movie: e8,
  MovingThumbnail: t8,
  MusicCarouselShelf: pr,
  MusicCarouselShelfBasicHeader: Yy,
  MusicDescriptionShelf: Ll,
  MusicDetailHeader: Dl,
  MusicDownloadStateBadge: i8,
  MusicEditablePlaylistDetailHeader: Xy,
  MusicElementHeader: oc,
  MusicHeader: vf,
  MusicImmersiveHeader: Jy,
  MusicInlineBadge: n8,
  MusicItemThumbnailOverlay: Jp,
  MusicLargeCardItemCarousel: s8,
  MusicNavigationButton: lf,
  MusicPlayButton: Uy,
  MusicPlaylistShelf: Bl,
  MusicQueue: xf,
  MusicResponsiveListItem: na,
  MusicResponsiveListItemFixedColumn: Hy,
  MusicResponsiveListItemFlexColumn: jy,
  MusicShelf: fs,
  MusicSideAlignedItem: r8,
  MusicSortFilterButton: o8,
  MusicThumbnail: rf,
  MusicTwoRowItem: Qp,
  MusicVisualHeader: Zy,
  NavigationEndpoint: B,
  Notification: a8,
  PageIntroduction: Qy,
  PlayerAnnotationsExpanded: e_,
  PlayerCaptionsTracklist: t_,
  PlayerErrorMessage: l8,
  PlayerLiveStoryboardSpec: i_,
  PlayerMicroformat: Gr,
  PlayerOverlay: Uf,
  PlayerOverlayAutoplay: s_,
  PlayerStoryboardSpec: r_,
  Playlist: ea,
  PlaylistHeader: o_,
  PlaylistInfoCardContent: u8,
  PlaylistMetadata: a_,
  PlaylistPanel: xs,
  PlaylistPanelVideo: l_,
  PlaylistPanelVideoWrapper: c8,
  PlaylistSidebar: ac,
  PlaylistSidebarPrimaryInfo: u_,
  PlaylistSidebarSecondaryInfo: c_,
  PlaylistVideo: h_,
  PlaylistVideoList: h8,
  PlaylistVideoThumbnail: d_,
  Poll: d8,
  Post: p_,
  ProfileColumn: lc,
  ProfileColumnStats: f_,
  ProfileColumnStatsEntry: p8,
  ProfileColumnUserInfo: m_,
  ReelItem: f8,
  ReelShelf: v_,
  RelatedChipCloud: g_,
  RichGrid: y_,
  RichItem: m8,
  RichListHeader: __,
  RichSection: v8,
  RichShelf: b_,
  SearchBox: g8,
  SearchRefinementCard: w_,
  SearchSuggestion: wy,
  SearchSuggestionsSection: S_,
  SecondarySearchContainer: y8,
  SectionList: ft,
  SegmentedLikeDislikeButton: qr,
  SettingBoolean: _8,
  SettingsCheckbox: C_,
  SettingsOptions: Ya,
  SettingsSidebar: T_,
  SettingsSwitch: S0,
  Shelf: E0,
  ShowingResultsFor: x_,
  SimpleCardContent: b8,
  SimpleCardTeaser: w8,
  SimpleTextSection: S8,
  SingleActionEmergencySupport: C8,
  SingleColumnBrowseResults: sa,
  SingleColumnMusicWatchNextResults: Ao,
  SingleHeroImage: T8,
  SortFilterSubMenu: x8,
  SubFeedOption: E8,
  SubFeedSelector: k8,
  SubscribeButton: k_,
  SubscriptionNotificationToggleButton: E_,
  Tab: jt,
  Tabbed: Io,
  TabbedSearchResults: A_,
  TextHeader: A8,
  ThumbnailOverlayBottomPanel: I8,
  ThumbnailOverlayEndorsement: P8,
  ThumbnailOverlayHoverText: M8,
  ThumbnailOverlayInlineUnplayable: N8,
  ThumbnailOverlayLoadingPreview: R8,
  ThumbnailOverlayNowPlaying: L8,
  ThumbnailOverlayPinking: D8,
  ThumbnailOverlayPlaybackStatus: B8,
  ThumbnailOverlayResumePlayback: O8,
  ThumbnailOverlaySidePanel: F8,
  ThumbnailOverlayTimeStatus: V8,
  ThumbnailOverlayToggleButton: U8,
  TitleAndButtonListHeader: j8,
  ToggleButton: _t,
  ToggleMenuServiceItem: H8,
  Tooltip: W8,
  TwoColumnBrowseResults: ra,
  TwoColumnSearchResults: am,
  TwoColumnWatchNextResults: I_,
  UniversalWatchCard: P_,
  VerticalList: $8,
  VerticalWatchCardList: G8,
  Video: M_,
  VideoInfoCardContent: q8,
  VideoOwner: N_,
  VideoPrimaryInfo: R_,
  VideoSecondaryInfo: L_,
  WatchCardCompactVideo: D_,
  WatchCardHeroVideo: B_,
  WatchCardRichHeader: K8,
  WatchCardSectionSequence: O_,
  WatchNextEndScreen: n_,
  WatchNextTabbedResults: Po
};
function F_(e) {
  const t = z8[e];
  if (!t) {
    const i = new Error(`Module not found: ${e}`);
    throw i.code = "MODULE_NOT_FOUND", i;
  }
  return t;
}
l(F_, "GetParserByName");
var D5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, tt = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ke, vn, Gs, qs, V_, Ks, Sm = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.continuationItems, !0);
  }
};
l(Sm, "AppendContinuationItemsAction");
Sm.type = "appendContinuationItemsAction";
var au = class extends w {
  constructor(e) {
    super(), this.target_id = e.targetId, this.contents = y.parse(e.continuationItems, !0);
  }
};
l(au, "ReloadContinuationItemsCommand");
au.type = "reloadContinuationItemsCommand";
var Es = class extends w {
  constructor(e) {
    var t;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
};
l(Es, "SectionListContinuation");
Es.type = "sectionListContinuation";
var lu = class extends w {
  constructor(e) {
    var t;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
};
l(lu, "MusicPlaylistShelfContinuation");
lu.type = "musicPlaylistShelfContinuation";
var oa = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData) === null || i === void 0 ? void 0 : i.continuation) || ((s = (n = e.continuations) === null || n === void 0 ? void 0 : n[0].reloadContinuationData) === null || s === void 0 ? void 0 : s.continuation) || null;
  }
};
l(oa, "MusicShelfContinuation");
oa.type = "musicShelfContinuation";
var uu = class extends w {
  constructor(e) {
    var t;
    super(), this.items = y.parse(e.items, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
  get contents() {
    return this.items;
  }
};
l(uu, "GridContinuation");
uu.type = "gridContinuation";
var cu = class extends w {
  constructor(e) {
    var t, i, n, s, r, a;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || ((a = (r = (s = e.continuations) === null || s === void 0 ? void 0 : s[0]) === null || r === void 0 ? void 0 : r.nextRadioContinuationData) === null || a === void 0 ? void 0 : a.continuation) || null;
  }
};
l(cu, "PlaylistPanelContinuation");
cu.type = "playlistPanelContinuation";
var hu = class extends w {
  constructor(e) {
    super(), this.timeout_ms = e.timeoutMs || e.timeUntilLastMessageMsec, this.token = e.continuation;
  }
};
l(hu, "TimedContinuation");
hu.type = "timedContinuationData";
var du = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    super(), this.actions = y.parse((t = e.actions) === null || t === void 0 ? void 0 : t.map((a) => (delete a.clickTrackingParams, a)), !0) || Qt([]), this.action_panel = y.parseItem(e.actionPanel), this.item_list = y.parseItem(e.itemList), this.header = y.parseItem(e.header), this.participants_list = y.parseItem(e.participantsList), this.popout_message = y.parseItem(e.popoutMessage), this.emojis = ((i = e.emojis) === null || i === void 0 ? void 0 : i.map((a) => ({
      emoji_id: a.emojiId,
      shortcuts: a.shortcuts,
      search_terms: a.searchTerms,
      image: a.image,
      is_custom_emoji: a.isCustomEmoji
    }))) || null, this.continuation = new hu(((n = e.continuations) === null || n === void 0 ? void 0 : n[0].timedContinuationData) || ((s = e.continuations) === null || s === void 0 ? void 0 : s[0].invalidationContinuationData) || ((r = e.continuations) === null || r === void 0 ? void 0 : r[0].liveChatReplayContinuationData)), this.viewer_name = e.viewerName;
  }
};
l(du, "LiveChatContinuation");
du.type = "liveChatContinuation";
var y = class {
  static parseResponse(e) {
    var t, i, n, s, r;
    tt(this, Ke, "m", qs).call(this);
    const a = y.parse(e.contents), u = tt(this, Ke, "m", Ks).call(this);
    tt(this, Ke, "m", Gs).call(this), tt(this, Ke, "m", qs).call(this);
    const c = e.onResponseReceivedActions ? y.parseRR(e.onResponseReceivedActions) : null, h = tt(this, Ke, "m", Ks).call(this);
    tt(this, Ke, "m", Gs).call(this), tt(this, Ke, "m", qs).call(this);
    const p = e.onResponseReceivedEndpoints ? y.parseRR(e.onResponseReceivedEndpoints) : null, f = tt(this, Ke, "m", Ks).call(this);
    tt(this, Ke, "m", Gs).call(this), tt(this, Ke, "m", qs).call(this);
    const _ = e.onResponseReceivedCommands ? y.parseRR(e.onResponseReceivedCommands) : null, C = tt(this, Ke, "m", Ks).call(this);
    tt(this, Ke, "m", Gs).call(this), tt(this, Ke, "m", qs).call(this);
    const E = e.actions ? y.parseActions(e.actions) : null, P = tt(this, Ke, "m", Ks).call(this);
    return tt(this, Ke, "m", Gs).call(this), this.applyMutations(u, (i = (t = e.frameworkUpdates) === null || t === void 0 ? void 0 : t.entityBatchUpdate) === null || i === void 0 ? void 0 : i.mutations), {
      actions: E,
      actions_memo: P,
      contents: a,
      contents_memo: u,
      on_response_received_actions: c,
      on_response_received_actions_memo: h,
      on_response_received_endpoints: p,
      on_response_received_endpoints_memo: f,
      on_response_received_commands: _,
      on_response_received_commands_memo: C,
      continuation: e.continuation ? y.parseC(e.continuation) : null,
      continuation_contents: e.continuationContents ? y.parseLC(e.continuationContents) : null,
      metadata: y.parse(e.metadata),
      header: y.parse(e.header),
      microformat: e.microformat ? y.parseItem(e.microformat) : null,
      sidebar: y.parseItem(e.sidebar),
      overlay: y.parseItem(e.overlay),
      refinements: e.refinements || null,
      estimated_results: e.estimatedResults ? parseInt(e.estimatedResults) : null,
      player_overlays: y.parse(e.playerOverlays),
      playback_tracking: e.playbackTracking ? {
        videostats_watchtime_url: e.playbackTracking.videostatsWatchtimeUrl.baseUrl,
        videostats_playback_url: e.playbackTracking.videostatsPlaybackUrl.baseUrl
      } : null,
      playability_status: e.playabilityStatus ? {
        status: e.playabilityStatus.status,
        error_screen: y.parseItem(e.playabilityStatus.errorScreen),
        audio_only_playablility: y.parseItem(e.playabilityStatus.audioOnlyPlayability, Kg),
        embeddable: !!e.playabilityStatus.playableInEmbed || !1,
        reason: ((n = e.playabilityStatus) === null || n === void 0 ? void 0 : n.reason) || ""
      } : void 0,
      streaming_data: e.streamingData ? {
        expires: new Date(Date.now() + parseInt(e.streamingData.expiresInSeconds) * 1e3),
        formats: y.parseFormats(e.streamingData.formats),
        adaptive_formats: y.parseFormats(e.streamingData.adaptiveFormats),
        dash_manifest_url: ((s = e.streamingData) === null || s === void 0 ? void 0 : s.dashManifestUrl) || null,
        dls_manifest_url: ((r = e.streamingData) === null || r === void 0 ? void 0 : r.dashManifestUrl) || null
      } : void 0,
      current_video_endpoint: e.currentVideoEndpoint ? new B(e.currentVideoEndpoint) : null,
      captions: y.parseItem(e.captions, t_),
      video_details: e.videoDetails ? new E7(e.videoDetails) : void 0,
      annotations: y.parseArray(e.annotations, e_),
      storyboards: y.parseItem(e.storyboards, [r_, i_]),
      endscreen: y.parseItem(e.endscreen, fy),
      cards: y.parseItem(e.cards, Zg)
    };
  }
  static parseC(e) {
    if (e.timedContinuationData)
      return new hu(e.timedContinuationData);
  }
  static parseLC(e) {
    if (e.sectionListContinuation)
      return new Es(e.sectionListContinuation);
    if (e.liveChatContinuation)
      return new du(e.liveChatContinuation);
    if (e.musicPlaylistShelfContinuation)
      return new lu(e.musicPlaylistShelfContinuation);
    if (e.musicShelfContinuation)
      return new oa(e.musicShelfContinuation);
    if (e.gridContinuation)
      return new uu(e.gridContinuation);
    if (e.playlistPanelContinuation)
      return new cu(e.playlistPanelContinuation);
  }
  static parseRR(e) {
    return Qt(e.map((t) => {
      if (t.reloadContinuationItemsCommand)
        return new au(t.reloadContinuationItemsCommand);
      if (t.appendContinuationItemsAction)
        return new Sm(t.appendContinuationItemsAction);
    }).filter((t) => t));
  }
  static parseActions(e) {
    return Array.isArray(e) ? y.parse(e.map((t) => (delete t.clickTrackingParams, t))) : new lr(y.parseItem(e));
  }
  static parseFormats(e) {
    return e?.map((t) => new x7(t)) || [];
  }
  static parseItem(e, t) {
    if (!e)
      return null;
    const i = Object.keys(e), n = this.sanitizeClassName(i[0]);
    if (!this.shouldIgnore(n))
      try {
        const s = F_(n);
        if (t) {
          if (Array.isArray(t)) {
            if (!t.some((a) => a.type === s.type))
              throw new nn(`Type mismatch, got ${n} but expected one of ${t.map((a) => a.type).join(", ")}`);
          } else if (s.type !== t.type)
            throw new nn(`Type mismatch, got ${n} but expected ${t.type}`);
        }
        const r = new s(e[i[0]]);
        return tt(this, Ke, "m", V_).call(this, n, r), r;
      } catch (s) {
        return this.formatError({ classname: n, classdata: e[i[0]], err: s }), null;
      }
    return null;
  }
  static parseArray(e, t) {
    if (Array.isArray(e)) {
      const i = [];
      for (const n of e) {
        const s = this.parseItem(n, t);
        s && i.push(s);
      }
      return Qt(i);
    } else if (!e)
      return Qt([]);
    throw new nn("Expected array but got a single item");
  }
  static parse(e, t, i) {
    if (!e)
      return null;
    if (Array.isArray(e)) {
      const n = [];
      for (const r of e) {
        const a = this.parseItem(r, i);
        a && n.push(a);
      }
      const s = Qt(n);
      return t ? s : new lr(Qt(n));
    } else if (t)
      throw new nn("Expected array but got a single item");
    return new lr(this.parseItem(e, i));
  }
  static applyMutations(e, t) {
    var i;
    const n = e.getType(Dp);
    if (n.length > 0 && !t)
      console.warn(new x(`Mutation data required for processing MusicMultiSelectMenuItems, but none found.
This is a bug, please report it at ${jr.bugs.url}`));
    else {
      const s = [];
      for (const r of n) {
        const a = t.find((c) => {
          var h, p;
          return ((p = (h = c.payload) === null || h === void 0 ? void 0 : h.musicFormBooleanChoice) === null || p === void 0 ? void 0 : p.id) === r.form_item_entity_key;
        }), u = a?.payload.musicFormBooleanChoice;
        u?.selected !== void 0 && u?.opaqueToken ? (r.selected = u.selected, !((i = r.endpoint) === null || i === void 0) && i.browse && (r.endpoint.browse.form_data = {
          selectedValues: [u.opaqueToken]
        })) : s.push(`'${r.title}'`);
      }
      s.length > 0 && console.warn(new x(`Mutation data missing or invalid for ${s.length} out of ${n.length} MusicMultiSelectMenuItems. The titles of the failed items are: ${s.join(", ")}.
This is a bug, please report it at ${jr.bugs.url}`));
    }
  }
  static formatError({ classname: e, classdata: t, err: i }) {
    if (i.code == "MODULE_NOT_FOUND")
      return console.warn(new x(`${e} not found!
This is a bug, please report it at ${jr.bugs.url}`, t));
    console.warn(new x(`Something went wrong at ${e}!
This is a bug, please report it at ${jr.bugs.url}`, { stack: i.stack }));
  }
  static sanitizeClassName(e) {
    return (e.charAt(0).toUpperCase() + e.slice(1)).replace(/Renderer|Model/g, "").replace(/Radio/g, "Mix").trim();
  }
  static shouldIgnore(e) {
    return this.ignore_list.has(e);
  }
};
l(y, "Parser");
Ke = y, Gs = /* @__PURE__ */ l(function() {
  D5(y, Ke, null, "f", vn);
}, "_Parser_clearMemo"), qs = /* @__PURE__ */ l(function() {
  D5(y, Ke, new Lg(), "f", vn);
}, "_Parser_createMemo"), V_ = /* @__PURE__ */ l(function(t, i) {
  if (!tt(y, Ke, "f", vn))
    return;
  const n = tt(y, Ke, "f", vn).get(t);
  if (!n)
    return tt(y, Ke, "f", vn).set(t, [i]);
  n.push(i);
}, "_Parser_addToMemo"), Ks = /* @__PURE__ */ l(function() {
  if (!tt(y, Ke, "f", vn))
    throw new Error("Parser#getMemo() called before Parser#createMemo()");
  return tt(y, Ke, "f", vn);
}, "_Parser_getMemo");
vn = { value: null };
y.ignore_list = /* @__PURE__ */ new Set([
  "DisplayAd",
  "SearchPyv",
  "MealbarPromo",
  "BackgroundPromo",
  "PromotedSparklesWeb",
  "RunAttestationCommand",
  "CompactPromotedVideo",
  "StatementBanner"
]);
var rt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Y8 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, se = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Qe, Ae, ht, uc, U_ = class {
  constructor(e) {
    Qe.add(this), Ae.set(this, void 0), Y8(this, Ae, e, "f");
  }
  get session() {
    return se(this, Ae, "f");
  }
  browse(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (se(this, Qe, "m", uc).call(this, e) && !se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      t.params && (i.params = t.params), t.is_ctoken ? i.continuation = e : i.browseId = e, t.form_data && (i.formData = t.form_data), t.client && (i.client = t.client);
      const n = yield se(this, Ae, "f").http.fetch("/browse", {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  engage(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in && !t.hasOwnProperty("text"))
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "like/like":
        case "like/dislike":
        case "like/removelike":
          if (!Xi(t, "video_id"))
            throw new mi("Arguments lacks video_id");
          i.target = {}, i.target.videoId = t.video_id, t.params && (i.params = t.params);
          break;
        case "subscription/subscribe":
        case "subscription/unsubscribe":
          if (!Xi(t, "channel_id"))
            throw new mi("Arguments lacks channel_id");
          i.channelIds = [t.channel_id], i.params = e === "subscription/subscribe" ? "EgIIAhgA" : "CgIIAhgA";
          break;
        case "comment/create_comment":
          if (i.commentText = t.text, !Xi(t, "video_id"))
            throw new mi("Arguments lacks video_id");
          i.createCommentParams = Vt.encodeCommentParams(t.video_id);
          break;
        case "comment/create_comment_reply":
          if (!Xi(t, "comment_id", "video_id", "text"))
            throw new mi("Arguments lacks comment_id, video_id or text");
          i.createReplyParams = Vt.encodeCommentReplyParams(t.comment_id, t.video_id), i.commentText = t.text;
          break;
        case "comment/perform_comment_action":
          const s = (() => {
            switch (t.comment_action) {
              case "like":
                return Vt.encodeCommentActionParams(5, t);
              case "dislike":
                return Vt.encodeCommentActionParams(4, t);
              case "translate":
                return Vt.encodeCommentActionParams(22, t);
            }
          })();
          i.actions = [s];
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  account(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = { client: t.client };
      switch (e) {
        case "account/set_setting":
          i.newValue = {
            boolValue: t.new_value
          }, i.settingItemId = t.setting_item_id;
          break;
        case "account/accounts_list":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  search(e = {}) {
    var t;
    return rt(this, void 0, void 0, function* () {
      const i = { client: e.client };
      e.query && (i.query = e.query), e.ctoken && (i.continuation = e.ctoken), e.params && (i.params = e.params), e.filters && (e.client == "YTMUSIC" && ((t = e.filters) === null || t === void 0 ? void 0 : t.type) && e.filters.type !== "all" ? i.params = Vt.encodeMusicSearchFilters(e.filters) : i.params = Vt.encodeSearchFilters(e.filters));
      const n = yield se(this, Ae, "f").http.fetch("/search", {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  searchSound(e) {
    return rt(this, void 0, void 0, function* () {
      const t = {
        query: e.query,
        client: "ANDROID"
      }, i = yield se(this, Ae, "f").http.fetch("/sfv/search", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, i);
    });
  }
  channel(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = { client: t.client || "ANDROID" };
      switch (e) {
        case "channel/edit_name":
          i.givenName = t.new_name;
          break;
        case "channel/edit_description":
          i.description = t.new_description;
          break;
        case "channel/get_profile_editor":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  playlist(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "playlist/create":
          i.title = t.title, i.videoIds = t.ids;
          break;
        case "playlist/delete":
          i.playlistId = t.playlist_id;
          break;
        case "browse/edit_playlist":
          if (!Xi(t, "ids"))
            throw new mi("Arguments lacks ids");
          i.playlistId = t.playlist_id, i.actions = t.ids.map((s) => {
            switch (t.action) {
              case "ACTION_ADD_VIDEO":
                return {
                  action: t.action,
                  addedVideoId: s
                };
              case "ACTION_REMOVE_VIDEO":
                return {
                  action: t.action,
                  setVideoId: s
                };
            }
          });
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  notifications(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "modify_channel_preference":
          if (!Xi(t, "channel_id", "pref"))
            throw new mi("Arguments lacks channel_id or pref");
          const s = {
            PERSONALIZED: 1,
            ALL: 2,
            NONE: 3
          };
          if (!Object.keys(s).includes(t.pref.toUpperCase()))
            throw new x("Invalid preference type", t.pref);
          i.params = Vt.encodeNotificationPref(t.channel_id, s[t.pref.toUpperCase()]);
          break;
        case "get_notification_menu":
          i.notificationsMenuRequestType = "NOTIFICATIONS_MENU_REQUEST_TYPE_INBOX", t.ctoken && (i.ctoken = t.ctoken);
          break;
        case "record_interactions":
          i.serializedRecordNotificationInteractionsRequest = t.params;
          break;
        case "get_unseen_count":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/notification/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  livechat(e, t = {}) {
    return rt(this, void 0, void 0, function* () {
      const i = { client: t.client };
      switch (e) {
        case "live_chat/get_live_chat":
        case "live_chat/get_live_chat_replay":
          i.continuation = t.ctoken;
          break;
        case "live_chat/send_message":
          if (!Xi(t, "channel_id", "video_id", "text"))
            throw new mi("Arguments lacks channel_id, video_id or text");
          i.params = Vt.encodeMessageParams(t.channel_id, t.video_id), i.clientMessageId = hr(), i.richMessage = {
            textSegments: [{
              text: t.text
            }]
          };
          break;
        case "live_chat/get_item_context_menu":
          break;
        case "live_chat/moderate":
          i.params = t.params;
          break;
        case "updated_metadata":
          i.videoId = t.video_id, t.ctoken && (i.continuation = t.ctoken);
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  thumbnails(e) {
    return rt(this, void 0, void 0, function* () {
      const t = {
        client: "ANDROID",
        videoId: e.video_id
      }, i = yield se(this, Ae, "f").http.fetch("/thumbnails", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, i);
    });
  }
  geo(e, t) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = {
        input: t.input,
        client: "ANDROID"
      }, n = yield se(this, Ae, "f").http.fetch(`/geo/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  flag(e, t) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "flag/flag":
          i.action = t.action;
          break;
        case "flag/get_form":
          i.params = t.params;
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield se(this, Ae, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  music(e, t) {
    return rt(this, void 0, void 0, function* () {
      const i = {
        input: t.input || "",
        client: "YTMUSIC"
      }, n = yield se(this, Ae, "f").http.fetch(`/music/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, n);
    });
  }
  next(e = {}) {
    return rt(this, void 0, void 0, function* () {
      const t = { client: e.client };
      e.ctoken && (t.continuation = e.ctoken), e.video_id && (t.videoId = e.video_id), e.playlist_id && (t.playlistId = e.playlist_id), e.params && (t.params = e.params);
      const i = yield se(this, Ae, "f").http.fetch("/next", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, i);
    });
  }
  getVideoInfo(e, t, i, n) {
    return rt(this, void 0, void 0, function* () {
      const s = {
        playbackContext: {
          contentPlaybackContext: {
            vis: 0,
            splay: !1,
            referer: "https://www.youtube.com",
            currentUrl: `/watch?v=${e}`,
            autonavState: "STATE_OFF",
            signatureTimestamp: se(this, Ae, "f").player.sts,
            autoCaptionsDefaultOn: !1,
            html5Preference: "HTML5_PREF_WANTS",
            lactMilliseconds: "-1"
          }
        },
        attestationRequest: {
          omitBotguardData: !0
        },
        videoId: e
      };
      i && (s.client = i), t && (s.cpn = t), n && (s.playlistId = n);
      const r = yield se(this, Ae, "f").http.fetch("/player", {
        method: "POST",
        body: JSON.stringify(s),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, r);
    });
  }
  getUserMentionSuggestions(e) {
    return rt(this, void 0, void 0, function* () {
      if (!se(this, Ae, "f").logged_in)
        throw new x("You are not signed in");
      const t = {
        input: e.input,
        client: "ANDROID"
      }, i = yield se(this, Ae, "f").http.fetch("/get_user_mention_suggestions", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return se(this, Qe, "m", ht).call(this, i);
    });
  }
  stats(e, t, i) {
    return rt(this, void 0, void 0, function* () {
      const n = new URL(e);
      n.searchParams.set("ver", "2"), n.searchParams.set("c", t.client_name.toLowerCase()), n.searchParams.set("cbrver", t.client_version), n.searchParams.set("cver", t.client_version);
      for (const r of Object.keys(i))
        n.searchParams.set(r, i[r]);
      return yield se(this, Ae, "f").http.fetch(n);
    });
  }
  execute(e, t) {
    return rt(this, void 0, void 0, function* () {
      let i;
      if (t.protobuf)
        i = t.serialized_data;
      else {
        if (i = Object.assign({}, t), Reflect.has(i, "browseId") && se(this, Qe, "m", uc).call(this, i.browseId) && !se(this, Ae, "f").logged_in)
          throw new x("You are not signed in");
        Reflect.has(i, "override_endpoint") && delete i.override_endpoint, Reflect.has(i, "parse") && delete i.parse, Reflect.has(i, "request") && delete i.request, Reflect.has(i, "clientActions") && delete i.clientActions, Reflect.has(i, "settingItemIdForClient") && delete i.settingItemIdForClient, Reflect.has(i, "action") && (i.actions = [i.action], delete i.action), Reflect.has(i, "boolValue") && (i.newValue = { boolValue: i.boolValue }, delete i.boolValue), Reflect.has(i, "token") && (i.continuation = i.token, delete i.token), i?.client === "YTMUSIC" && (i.isAudioOnly = !0);
      }
      const n = Reflect.has(t, "override_endpoint") ? t.override_endpoint : e, s = yield se(this, Ae, "f").http.fetch(n, {
        method: "POST",
        body: t.protobuf ? i : JSON.stringify(i),
        headers: {
          "Content-Type": t.protobuf ? "application/x-protobuf" : "application/json"
        }
      });
      return t.parse ? y.parseResponse(yield s.json()) : se(this, Qe, "m", ht).call(this, s);
    });
  }
};
l(U_, "Actions");
Ae = /* @__PURE__ */ new WeakMap(), Qe = /* @__PURE__ */ new WeakSet(), ht = /* @__PURE__ */ l(function(t) {
  return rt(this, void 0, void 0, function* () {
    return {
      success: t.ok,
      status_code: t.status,
      data: JSON.parse(yield t.text())
    };
  });
}, "_Actions_wrap"), uc = /* @__PURE__ */ l(function(t) {
  return [
    "FElibrary",
    "FEhistory",
    "FEsubscriptions",
    "FEmusic_listening_review",
    "SPaccount_notifications",
    "SPaccount_privacy",
    "SPtime_watched"
  ].includes(t);
}, "_Actions_needsLogin");
var X8 = U_, J8 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Kr = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Aa, zs;
if (!Reflect.has(globalThis, "CustomEvent")) {
  class e extends Event {
    constructor(i, n) {
      var s;
      super(i, n), Aa.set(this, void 0), J8(this, Aa, (s = n?.detail) !== null && s !== void 0 ? s : null, "f");
    }
    get detail() {
      return Kr(this, Aa, "f");
    }
  }
  l(e, "CustomEvent"), Aa = /* @__PURE__ */ new WeakMap(), Reflect.set(globalThis, "CustomEvent", e);
}
var Cm = class extends EventTarget {
  constructor() {
    super(), zs.set(this, /* @__PURE__ */ new Map());
  }
  emit(e, ...t) {
    const i = new CustomEvent(e, { detail: t });
    this.dispatchEvent(i);
  }
  on(e, t) {
    const i = /* @__PURE__ */ l((n) => {
      n instanceof CustomEvent ? t(...n.detail) : t(n);
    }, "wrapper");
    Kr(this, zs, "f").set(t, i), this.addEventListener(e, i);
  }
  once(e, t) {
    const i = /* @__PURE__ */ l((n) => {
      n instanceof CustomEvent ? t(...n.detail) : t(n), this.off(e, t);
    }, "wrapper");
    Kr(this, zs, "f").set(t, i), this.addEventListener(e, i);
  }
  off(e, t) {
    const i = Kr(this, zs, "f").get(t);
    i && (this.removeEventListener(e, i), Kr(this, zs, "f").delete(t));
  }
};
l(Cm, "EventEmitterLike");
zs = /* @__PURE__ */ new WeakMap();
var Z8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, R1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Dt = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, cc, pi, Ys, zr, j_, H_ = class {
  constructor(e, t, i) {
    cc.add(this), pi.set(this, void 0), Ys.set(this, void 0), zr.set(this, void 0), R1(this, pi, e, "f"), R1(this, Ys, t, "f"), R1(this, zr, i || globalThis.fetch, "f");
  }
  get fetch_function() {
    return Dt(this, zr, "f");
  }
  fetch(e, t) {
    return Z8(this, void 0, void 0, function* () {
      const i = ve.URLS.API.PRODUCTION_1 + Dt(this, pi, "f").api_version, n = t?.baseURL || i, s = typeof e == "string" ? !n.endsWith("/") && !e.startsWith("/") ? new URL(`${n}/${e}`) : new URL(n + e) : e instanceof URL ? e : new URL(e.url, n), r = t?.headers || (e instanceof Request ? e.headers : new Headers()) || new Headers(), a = t?.body || (e instanceof Request ? e.body : void 0), u = new Headers(r);
      u.set("Accept", "*/*"), u.set("Accept-Language", `en-${Dt(this, pi, "f").context.client.gl || "US"}`), u.set("x-goog-visitor-id", Dt(this, pi, "f").context.client.visitorData || ""), u.set("x-origin", s.origin), u.set("x-youtube-client-version", Dt(this, pi, "f").context.client.clientVersion || ""), Wc() && (u.set("User-Agent", Qo("desktop")), u.set("origin", s.origin)), s.searchParams.set("key", Dt(this, pi, "f").key), s.searchParams.set("prettyPrint", "false"), s.searchParams.set("alt", "json");
      const c = u.get("Content-Type");
      let h = a;
      const p = n === i || n === ve.URLS.YT_UPLOAD;
      if (c === "application/json" && p && typeof a == "string") {
        const C = JSON.parse(a), E = Object.assign(Object.assign({}, C), {
          context: JSON.parse(JSON.stringify(Dt(this, pi, "f").context))
        });
        Dt(this, cc, "m", j_).call(this, E.context, E.client), u.set("x-youtube-client-version", E.context.client.clientVersion), delete E.client, h = JSON.stringify(E);
      }
      if (Dt(this, pi, "f").logged_in && p) {
        const C = Dt(this, pi, "f").oauth;
        if (C.validateCredentials() && (yield C.refreshIfRequired(), u.set("authorization", `Bearer ${C.credentials.access_token}`), s.searchParams.delete("key")), Dt(this, Ys, "f")) {
          const E = Li(Dt(this, Ys, "f"), "PAPISID=", ";");
          E && u.set("authorization", yield Hc(E)), u.set("cookie", Dt(this, Ys, "f"));
        }
      }
      const f = new Request(s, e instanceof Request ? e : t), _ = yield Dt(this, zr, "f").call(this, f, {
        body: h,
        headers: u,
        credentials: "include",
        redirect: e instanceof Request ? e.redirect : t?.redirect || "follow"
      });
      if (_.ok)
        return _;
      throw new x(`Request to ${_.url} failed with status ${_.status}`, yield _.text());
    });
  }
};
l(H_, "HTTPClient");
pi = /* @__PURE__ */ new WeakMap(), Ys = /* @__PURE__ */ new WeakMap(), zr = /* @__PURE__ */ new WeakMap(), cc = /* @__PURE__ */ new WeakSet(), j_ = /* @__PURE__ */ l(function(t, i) {
  switch (i) {
    case "YTMUSIC":
      t.client.clientVersion = ve.CLIENTS.YTMUSIC.VERSION, t.client.clientName = ve.CLIENTS.YTMUSIC.NAME;
      break;
    case "ANDROID":
      t.client.clientVersion = ve.CLIENTS.ANDROID.VERSION, t.client.clientFormFactor = "SMALL_FORM_FACTOR", t.client.clientName = ve.CLIENTS.ANDROID.NAME, t.client.androidSdkVersion = ve.CLIENTS.ANDROID.SDK_VERSION;
      break;
    case "YTMUSIC_ANDROID":
      t.client.clientVersion = ve.CLIENTS.YTMUSIC_ANDROID.VERSION, t.client.clientFormFactor = "SMALL_FORM_FACTOR", t.client.clientName = ve.CLIENTS.YTMUSIC_ANDROID.NAME, t.client.androidSdkVersion = ve.CLIENTS.ANDROID.SDK_VERSION;
      break;
    case "TV_EMBEDDED":
      t.client.clientVersion = ve.CLIENTS.TV_EMBEDDED.VERSION, t.client.clientName = ve.CLIENTS.TV_EMBEDDED.NAME, t.client.clientScreen = "EMBED", t.thirdParty = { embedUrl: ve.URLS.YT_BASE };
      break;
  }
}, "_HTTPClient_adjustContext");
var Di = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, An = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ue = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Qi, ns, nt, ze, Xa, W_, hc, B5, $_, L1, G_ = class {
  constructor(e) {
    Qi.add(this), ns.set(this, void 0), nt.set(this, void 0), ze.set(this, void 0), Xa.set(this, 5), An(this, nt, e, "f");
  }
  init(e) {
    return Di(this, void 0, void 0, function* () {
      An(this, ze, e, "f"), this.validateCredentials() ? this.has_access_token_expired || ue(this, nt, "f").emit("auth", {
        credentials: ue(this, ze, "f"),
        status: "SUCCESS"
      }) : (yield ue(this, Qi, "m", W_).call(this)) || (yield ue(this, Qi, "m", hc).call(this));
    });
  }
  cacheCredentials() {
    var e;
    return Di(this, void 0, void 0, function* () {
      const i = new TextEncoder().encode(JSON.stringify(ue(this, ze, "f")));
      yield (e = ue(this, nt, "f").cache) === null || e === void 0 ? void 0 : e.set("youtubei_oauth_credentials", i.buffer);
    });
  }
  removeCache() {
    var e;
    return Di(this, void 0, void 0, function* () {
      yield (e = ue(this, nt, "f").cache) === null || e === void 0 ? void 0 : e.remove("youtubei_oauth_credentials");
    });
  }
  refreshIfRequired() {
    return Di(this, void 0, void 0, function* () {
      this.has_access_token_expired && (yield ue(this, Qi, "m", $_).call(this));
    });
  }
  revokeCredentials() {
    return Di(this, void 0, void 0, function* () {
      if (!!ue(this, ze, "f"))
        return yield this.removeCache(), ue(this, nt, "f").http.fetch_function(new URL(`/o/oauth2/revoke?token=${encodeURIComponent(ue(this, ze, "f").access_token)}`, ve.URLS.YT_BASE), {
          method: "post"
        });
    });
  }
  get credentials() {
    return ue(this, ze, "f");
  }
  get has_access_token_expired() {
    const e = ue(this, ze, "f") ? new Date(ue(this, ze, "f").expires).getTime() : -1 / 0;
    return new Date().getTime() > e;
  }
  validateCredentials() {
    return ue(this, ze, "f") && Reflect.has(ue(this, ze, "f"), "access_token") && Reflect.has(ue(this, ze, "f"), "refresh_token") && Reflect.has(ue(this, ze, "f"), "expires") || !1;
  }
};
l(G_, "OAuth");
ns = /* @__PURE__ */ new WeakMap(), nt = /* @__PURE__ */ new WeakMap(), ze = /* @__PURE__ */ new WeakMap(), Xa = /* @__PURE__ */ new WeakMap(), Qi = /* @__PURE__ */ new WeakSet(), W_ = /* @__PURE__ */ l(function() {
  var t;
  return Di(this, void 0, void 0, function* () {
    const i = yield (t = ue(this, nt, "f").cache) === null || t === void 0 ? void 0 : t.get("youtubei_oauth_credentials");
    if (!i)
      return !1;
    const n = new TextDecoder(), s = JSON.parse(n.decode(i));
    return An(this, ze, {
      access_token: s.access_token,
      refresh_token: s.refresh_token,
      expires: new Date(s.expires)
    }, "f"), ue(this, nt, "f").emit("auth", {
      credentials: ue(this, ze, "f"),
      status: "SUCCESS"
    }), !0;
  });
}, "_OAuth_loadCachedCredentials"), hc = /* @__PURE__ */ l(function() {
  return Di(this, void 0, void 0, function* () {
    An(this, ns, yield ue(this, Qi, "m", L1).call(this), "f");
    const t = {
      client_id: ue(this, ns, "f").client_id,
      scope: ve.OAUTH.SCOPE,
      device_id: hr(),
      model_name: ve.OAUTH.MODEL_NAME
    }, n = yield (yield ue(this, nt, "f").http.fetch_function(new URL("/o/oauth2/device/code", ve.URLS.YT_BASE), {
      body: JSON.stringify(t),
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      }
    })).json();
    ue(this, nt, "f").emit("auth-pending", n), An(this, Xa, n.interval, "f"), ue(this, Qi, "m", B5).call(this, n.device_code);
  });
}, "_OAuth_getUserCode"), B5 = /* @__PURE__ */ l(function(t) {
  const i = setInterval(() => Di(this, void 0, void 0, function* () {
    const n = Object.assign(Object.assign({}, ue(this, ns, "f")), { code: t, grant_type: ve.OAUTH.GRANT_TYPE });
    try {
      const r = yield (yield ue(this, nt, "f").http.fetch_function(new URL("/o/oauth2/token", ve.URLS.YT_BASE), {
        body: JSON.stringify(n),
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        }
      })).json();
      if (r.error) {
        switch (r.error) {
          case "access_denied":
            ue(this, nt, "f").emit("auth-error", new ls("Access was denied.", { status: "ACCESS_DENIED" }));
            break;
          case "expired_token":
            ue(this, nt, "f").emit("auth-error", new ls("The device code has expired, restarting auth flow.", { status: "DEVICE_CODE_EXPIRED" })), clearInterval(i), ue(this, Qi, "m", hc).call(this);
            break;
          default:
            break;
        }
        return;
      }
      const a = new Date(new Date().getTime() + r.expires_in * 1e3);
      An(this, ze, {
        access_token: r.access_token,
        refresh_token: r.refresh_token,
        expires: a
      }, "f"), ue(this, nt, "f").emit("auth", {
        credentials: ue(this, ze, "f"),
        status: "SUCCESS"
      }), clearInterval(i);
    } catch (s) {
      return clearInterval(i), ue(this, nt, "f").emit("auth-error", new ls("Could not obtain user code.", { status: "FAILED", error: s }));
    }
  }), ue(this, Xa, "f") * 1e3);
}, "_OAuth_startPolling"), $_ = /* @__PURE__ */ l(function() {
  return Di(this, void 0, void 0, function* () {
    if (!ue(this, ze, "f"))
      return;
    An(this, ns, yield ue(this, Qi, "m", L1).call(this), "f");
    const t = Object.assign(Object.assign({}, ue(this, ns, "f")), { refresh_token: ue(this, ze, "f").refresh_token, grant_type: "refresh_token" }), n = yield (yield ue(this, nt, "f").http.fetch_function(new URL("/o/oauth2/token", ve.URLS.YT_BASE), {
      body: JSON.stringify(t),
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      }
    })).json(), s = new Date(new Date().getTime() + n.expires_in * 1e3);
    An(this, ze, {
      access_token: n.access_token,
      refresh_token: n.refresh_token || ue(this, ze, "f").refresh_token,
      expires: s
    }, "f"), ue(this, nt, "f").emit("update-credentials", {
      credentials: ue(this, ze, "f"),
      status: "SUCCESS"
    });
  });
}, "_OAuth_refreshAccessToken"), L1 = /* @__PURE__ */ l(function() {
  var t;
  return Di(this, void 0, void 0, function* () {
    const n = yield (yield ue(this, nt, "f").http.fetch_function(new URL("/tv", ve.URLS.YT_BASE), { headers: ve.OAUTH.HEADERS })).text(), s = (t = ve.OAUTH.REGEX.AUTH_SCRIPT.exec(n)) === null || t === void 0 ? void 0 : t[1];
    if (!s)
      throw new ls("Could not obtain script url.", { status: "FAILED" });
    const a = (yield (yield ue(this, nt, "f").http.fetch(s, { baseURL: ve.URLS.YT_BASE })).text()).replace(/\n/g, "").match(ve.OAUTH.REGEX.CLIENT_IDENTITY), u = a?.groups;
    if (!u)
      throw new ls("Could not obtain client identity.", { status: "FAILED" });
    return u;
  });
}, "_OAuth_getClientIdentity");
var Q8 = G_, Nr = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ia = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, zn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ja, Za, ss, Qa, dc;
(function(e) {
  e.WEB = "WEB", e.MUSIC = "WEB_REMIX", e.ANDROID = "ANDROID", e.ANDROID_MUSIC = "ANDROID_MUSIC";
})(dc || (dc = {}));
var Ol = class extends Cm {
  constructor(e, t, i, n, s, r, a) {
    super(), Ja.set(this, void 0), Za.set(this, void 0), ss.set(this, void 0), Qa.set(this, void 0), Ia(this, ss, e, "f"), Ia(this, Za, t, "f"), Ia(this, Ja, i, "f"), Ia(this, Qa, n, "f"), this.http = new H_(this, s, r), this.actions = new X8(this), this.oauth = new Q8(this), this.logged_in = !!s, this.cache = a;
  }
  on(e, t) {
    super.on(e, t);
  }
  once(e, t) {
    super.once(e, t);
  }
  static create(e = {}) {
    return Nr(this, void 0, void 0, function* () {
      const { context: t, api_key: i, api_version: n } = yield Ol.getSessionData(e.lang, e.device_category, e.client_type, e.timezone, e.fetch);
      return new Ol(t, i, n, yield kn.create(e.cache, e.fetch), e.cookie, e.fetch, e.cache);
    });
  }
  static getSessionData(e = "en-US", t = "desktop", i = dc.WEB, n = Intl.DateTimeFormat().resolvedOptions().timeZone, s = globalThis.fetch) {
    return Nr(this, void 0, void 0, function* () {
      const r = new URL("/sw.js_data", ve.URLS.YT_BASE), a = yield s(r, {
        headers: {
          "accept-language": e,
          "user-agent": Qo("desktop"),
          accept: "*/*",
          referer: "https://www.youtube.com/sw.js",
          cookie: `PREF=tz=${n.replace("/", ".")}`
        }
      });
      if (!a.ok)
        throw new Uc(`Failed to get session data: ${a.status}`);
      const u = yield a.text(), h = JSON.parse(u.replace(/^\)\]\}'/, ""))[0][2], p = `v${h[0][0][6]}`, [[f], _] = h, C = Cs(11), E = Math.floor(Date.now() / 1e3), P = Vt.encodeVisitorData(C, E);
      return { context: {
        client: {
          hl: f[0],
          gl: f[2],
          remoteHost: f[3],
          visitorData: P,
          userAgent: f[14],
          clientName: i,
          clientVersion: f[16],
          osName: f[17],
          osVersion: f[18],
          platform: t.toUpperCase(),
          clientFormFactor: "UNKNOWN_FORM_FACTOR",
          userInterfaceTheme: "USER_INTERFACE_THEME_LIGHT",
          timeZone: f[79],
          browserName: f[86],
          browserVersion: f[87],
          originalUrl: ve.URLS.API.BASE,
          deviceMake: f[11],
          deviceModel: f[12],
          utcOffsetMinutes: new Date().getTimezoneOffset()
        },
        user: {
          lockedSafetyMode: !1
        },
        request: {
          useSsl: !0
        }
      }, api_key: _, api_version: p };
    });
  }
  signIn(e) {
    return Nr(this, void 0, void 0, function* () {
      return new Promise((t, i) => Nr(this, void 0, void 0, function* () {
        const n = /* @__PURE__ */ l((s) => i(s), "error_handler");
        this.once("auth", (s) => {
          this.off("auth-error", n), s.status === "SUCCESS" && (this.logged_in = !0, t()), i(s);
        }), this.once("auth-error", n);
        try {
          yield this.oauth.init(e), this.oauth.validateCredentials() && (yield this.oauth.refreshIfRequired(), this.logged_in = !0, t());
        } catch (s) {
          i(s);
        }
      }));
    });
  }
  signOut() {
    return Nr(this, void 0, void 0, function* () {
      if (!this.logged_in)
        throw new x("You are not signed in");
      const e = yield this.oauth.revokeCredentials();
      return this.logged_in = !1, e;
    });
  }
  get key() {
    return zn(this, Za, "f");
  }
  get api_version() {
    return zn(this, Ja, "f");
  }
  get client_version() {
    return zn(this, ss, "f").client.clientVersion;
  }
  get client_name() {
    return zn(this, ss, "f").client.clientName;
  }
  get context() {
    return zn(this, ss, "f");
  }
  get player() {
    return zn(this, Qa, "f");
  }
  get lang() {
    return zn(this, ss, "f").client.hl;
  }
};
l(Ol, "Session");
Ja = /* @__PURE__ */ new WeakMap(), Za = /* @__PURE__ */ new WeakMap(), ss = /* @__PURE__ */ new WeakMap(), Qa = /* @__PURE__ */ new WeakMap();
var O5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Rr = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, De = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, At, gn, Yr, Ot, Mo = class {
  constructor(e, t, i = !1) {
    At.set(this, void 0), gn.set(this, void 0), Yr.set(this, void 0), Ot.set(this, void 0), t.on_response_received_actions || t.on_response_received_endpoints || i ? Rr(this, At, t, "f") : Rr(this, At, y.parseResponse(t), "f");
    const n = De(this, At, "f").on_response_received_commands ? De(this, At, "f").on_response_received_commands_memo : De(this, At, "f").on_response_received_endpoints ? De(this, At, "f").on_response_received_endpoints_memo : De(this, At, "f").contents ? De(this, At, "f").contents_memo : De(this, At, "f").on_response_received_actions ? De(this, At, "f").on_response_received_actions_memo : void 0;
    if (!n)
      throw new x("No memo found in feed");
    Rr(this, Ot, n, "f"), Rr(this, Yr, e, "f");
  }
  static getVideosFromMemo(e) {
    return e.getType([
      M_,
      by,
      hy,
      h_,
      l_,
      D_
    ]);
  }
  static getPlaylistsFromMemo(e) {
    return e.getType([ea, _y]);
  }
  get videos() {
    return Mo.getVideosFromMemo(De(this, Ot, "f"));
  }
  get posts() {
    return De(this, Ot, "f").getType([Th, p_]);
  }
  get channels() {
    return De(this, Ot, "f").getType([Qg, yy]);
  }
  get playlists() {
    return Mo.getPlaylistsFromMemo(De(this, Ot, "f"));
  }
  get memo() {
    return De(this, Ot, "f");
  }
  get contents() {
    var e, t, i, n;
    const s = (t = (e = De(this, Ot, "f").getType(jt)) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.content, r = (i = De(this, Ot, "f").getType(au)) === null || i === void 0 ? void 0 : i[0], a = (n = De(this, Ot, "f").getType($g)) === null || n === void 0 ? void 0 : n[0];
    return s || r || a;
  }
  get shelves() {
    return De(this, Ot, "f").getType([E0, b_, v_]);
  }
  getShelf(e) {
    return this.shelves.find((t) => t.title.toString() === e);
  }
  get secondary_contents() {
    if (!De(this, At, "f").contents.is_node)
      return;
    const e = De(this, At, "f").contents.item();
    if (!!e.is(ra, am))
      return e.secondary_contents;
  }
  get actions() {
    return De(this, Yr, "f");
  }
  get page() {
    return De(this, At, "f");
  }
  get has_continuation() {
    return (De(this, Ot, "f").get("ContinuationItem") || []).length > 0;
  }
  getContinuationData() {
    return O5(this, void 0, void 0, function* () {
      if (De(this, gn, "f")) {
        if (De(this, gn, "f").length > 1)
          throw new x("There are too many continuations, you'll need to find the correct one yourself in this.page");
        if (De(this, gn, "f").length === 0)
          throw new x("There are no continuations");
        return yield De(this, gn, "f")[0].endpoint.call(De(this, Yr, "f"), void 0, !0);
      }
      if (Rr(this, gn, De(this, Ot, "f").getType(sn), "f"), De(this, gn, "f"))
        return this.getContinuationData();
    });
  }
  getContinuation() {
    return O5(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new Mo(this.actions, e, !0);
    });
  }
};
l(Mo, "Feed");
At = /* @__PURE__ */ new WeakMap(), gn = /* @__PURE__ */ new WeakMap(), Yr = /* @__PURE__ */ new WeakMap(), Ot = /* @__PURE__ */ new WeakMap();
var Un = Mo, F5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Fl = class extends Un {
  constructor(e, t, i = !1) {
    var n, s, r, a, u, c, h;
    super(e, t, i);
    const p = ((s = (n = this.page.contents) === null || n === void 0 ? void 0 : n.item().as(am).primary_contents) === null || s === void 0 ? void 0 : s.item().as(ft).contents.array()) || ((r = this.page.on_response_received_commands) === null || r === void 0 ? void 0 : r[0].contents), f = (a = this.page.contents) === null || a === void 0 ? void 0 : a.item().key("secondary_contents"), _ = f?.isParsed() ? f.parsed().item().key("contents").parsed().array() : void 0;
    this.results = (u = p.firstOfType(Hi)) === null || u === void 0 ? void 0 : u.contents;
    const C = (h = (c = this.results) === null || c === void 0 ? void 0 : c.get({ type: "HorizontalCardList" }, !0)) === null || h === void 0 ? void 0 : h.as(Sy), E = _?.firstOfType(P_);
    this.refinements = this.page.refinements || [], this.estimated_results = this.page.estimated_results, this.watch_card = {
      header: E?.header.item() || null,
      call_to_action: E?.call_to_action.item().as(B_) || null,
      sections: E?.sections.array().filterType(O_) || []
    }, this.refinement_cards = {
      header: C?.header.item().as(__) || null,
      cards: C?.cards.array().filterType(w_) || Qt([])
    };
  }
  selectRefinementCard(e) {
    return F5(this, void 0, void 0, function* () {
      let t;
      if (typeof e == "string") {
        if (t = this.refinement_cards.cards.get({ query: e }), !t)
          throw new x(`Refinement card "${e}" not found`, { available_cards: this.refinement_card_queries });
      } else if (e.type === "SearchRefinementCard")
        t = e;
      else
        throw new x("Invalid refinement card!");
      const i = yield t.endpoint.call(this.actions, void 0, !0);
      return new Fl(this.actions, i, !0);
    });
  }
  get refinement_card_queries() {
    return this.refinement_cards.cards.map((e) => e.query);
  }
  getContinuation() {
    return F5(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new Fl(this.actions, e, !0);
    });
  }
};
l(Fl, "Search");
var eC = Fl, tC = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, V5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Pa = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Xr, Jr, Tm = class extends Un {
  constructor(e, t, i = !1) {
    super(e, t, i), Xr.set(this, void 0), Jr.set(this, void 0), V5(this, Jr, e, "f"), V5(this, Xr, this.page.contents_memo.getType(jt), "f");
  }
  get tabs() {
    return Pa(this, Xr, "f").map((e) => e.title.toString());
  }
  getTab(e) {
    return tC(this, void 0, void 0, function* () {
      const t = Pa(this, Xr, "f").find((n) => n.title.toLowerCase() === e.toLowerCase());
      if (!t)
        throw new x(`Tab "${e}" not found`);
      if (t.selected)
        return this;
      const i = yield t.endpoint.call(Pa(this, Jr, "f"));
      if (!i)
        throw new x("Failed to call endpoint");
      return new Tm(Pa(this, Jr, "f"), i.data, !1);
    });
  }
  get title() {
    var e, t;
    return (t = (e = this.page.contents_memo.getType(jt)) === null || e === void 0 ? void 0 : e.find((i) => i.selected)) === null || t === void 0 ? void 0 : t.title.toString();
  }
};
l(Tm, "TabbedFeed");
Xr = /* @__PURE__ */ new WeakMap(), Jr = /* @__PURE__ */ new WeakMap();
var q_ = Tm, Os = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, us = class extends q_ {
  constructor(e, t, i = !1) {
    var n;
    super(e, t, i), this.header = this.page.header.item().as(Jg);
    const s = this.page.metadata.item().as(ty), r = (n = this.page.microformat) === null || n === void 0 ? void 0 : n.as(ia);
    this.metadata = Object.assign(Object.assign({}, s), r || {}), this.sponsor_button = this.header.sponsor_button, this.subscribe_button = this.header.subscribe_button;
    const a = this.page.contents.item().key("tabs").parsed().array().filterType(jt).get({ selected: !0 });
    this.current_tab = a;
  }
  getVideos() {
    return Os(this, void 0, void 0, function* () {
      const e = yield this.getTab("Videos");
      return new us(this.actions, e.page, !0);
    });
  }
  getPlaylists() {
    return Os(this, void 0, void 0, function* () {
      const e = yield this.getTab("Playlists");
      return new us(this.actions, e.page, !0);
    });
  }
  getHome() {
    return Os(this, void 0, void 0, function* () {
      const e = yield this.getTab("Home");
      return new us(this.actions, e.page, !0);
    });
  }
  getCommunity() {
    return Os(this, void 0, void 0, function* () {
      const e = yield this.getTab("Community");
      return new us(this.actions, e.page, !0);
    });
  }
  getChannels() {
    return Os(this, void 0, void 0, function* () {
      const e = yield this.getTab("Channels");
      return new us(this.actions, e.page, !0);
    });
  }
  getAbout() {
    var e;
    return Os(this, void 0, void 0, function* () {
      return (e = (yield this.getTab("About")).memo.getType(ey)) === null || e === void 0 ? void 0 : e[0];
    });
  }
};
l(us, "Channel");
var iC = us, D1 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Zr, el, K_ = class extends Un {
  constructor(e, t, i = !1) {
    var n, s;
    super(e, t, i), Zr.add(this);
    const r = this.page.header.item().as(o_), a = (n = this.page.sidebar) === null || n === void 0 ? void 0 : n.as(ac).contents.array().firstOfType(u_), u = (s = this.page.sidebar) === null || s === void 0 ? void 0 : s.as(ac).contents.array().firstOfType(c_);
    this.info = Object.assign(Object.assign({}, this.page.metadata.item().as(a_)), {
      author: u?.owner.item().as(N_).author,
      thumbnails: a?.thumbnail_renderer.item().as(d_).thumbnail,
      total_items: D1(this, Zr, "m", el).call(this, 0, a),
      views: D1(this, Zr, "m", el).call(this, 1, a),
      last_updated: D1(this, Zr, "m", el).call(this, 2, a),
      can_share: r.can_share,
      can_delete: r.can_delete,
      is_editable: r.is_editable,
      privacy: r.privacy
    }), this.menu = a?.menu, this.endpoint = a?.endpoint;
  }
  get items() {
    return this.videos;
  }
};
l(K_, "Playlist");
Zr = /* @__PURE__ */ new WeakSet(), el = /* @__PURE__ */ l(function(t, i) {
  var n;
  return !i || !i.stats ? "N/A" : ((n = i.stats[t]) === null || n === void 0 ? void 0 : n.toString()) || "N/A";
}, "_Playlist_getStat");
var Vl = K_, nC = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, xm = class extends Un {
  constructor(e, t, i = !1) {
    var n, s;
    super(e, t, i), this.sections = this.memo.get("ItemSection"), this.feed_actions = ((s = (n = this.memo.get("BrowseFeedActions")) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.as(Xg)) || [];
  }
  getContinuation() {
    return nC(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new xm(this.actions, e, !0);
    });
  }
};
l(xm, "History");
var z_ = xm, sC = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, U5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ms = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, pc, cs, Qr, Y_, X_ = class {
  constructor(e, t) {
    var i, n;
    pc.add(this), cs.set(this, void 0), Qr.set(this, void 0), U5(this, cs, t, "f"), U5(this, Qr, y.parseResponse(e), "f");
    const s = ms(this, Qr, "f").contents.item().as(ra);
    if (!s)
      throw new x("Response did not have a TwoColumnBrowseResults.");
    const r = s.tabs.array().as(jt).get({ selected: !0 });
    if (!r)
      throw new x("Could not find target tab.");
    const a = ((i = s.secondary_contents.item().as(lc).items.array().get({ type: "ProfileColumnStats" })) === null || i === void 0 ? void 0 : i.as(f_)) || null, u = ((n = s.secondary_contents.item().as(lc).items.array().get({ type: "ProfileColumnUserInfo" })) === null || n === void 0 ? void 0 : n.as(m_)) || null;
    if (this.profile = { stats: a, user_info: u }, !r.content)
      throw new x("Target tab did not have any content.");
    const c = r.content.as(ft).contents.array().as(Hi).map((h) => {
      var p;
      return (p = h.contents) === null || p === void 0 ? void 0 : p.firstOfType(E0);
    });
    this.sections = c.map((h) => {
      var p;
      return {
        type: h.icon_type,
        title: h.title,
        contents: ((p = h.content) === null || p === void 0 ? void 0 : p.item().items.array()) || [],
        getAll: () => ms(this, pc, "m", Y_).call(this, h)
      };
    });
  }
  get history() {
    return this.sections.find((e) => e.type === "WATCH_HISTORY");
  }
  get watch_later() {
    return this.sections.find((e) => e.type === "WATCH_LATER");
  }
  get liked_videos() {
    return this.sections.find((e) => e.type === "LIKE");
  }
  get playlists() {
    return this.sections.find((e) => e.type === "PLAYLISTS");
  }
  get clips() {
    return this.sections.find((e) => e.type === "CONTENT_CUT");
  }
  get page() {
    return ms(this, Qr, "f");
  }
};
l(X_, "Library");
cs = /* @__PURE__ */ new WeakMap(), Qr = /* @__PURE__ */ new WeakMap(), pc = /* @__PURE__ */ new WeakSet(), Y_ = /* @__PURE__ */ l(function(t) {
  var i;
  return sC(this, void 0, void 0, function* () {
    if (!(!((i = t.menu) === null || i === void 0) && i.item().as(rn).hasKey("top_level_buttons")))
      throw new x(`The ${t.title.text} shelf doesn't have more items`);
    const n = yield t.menu.item().as(rn).top_level_buttons.get({ text: "See all" });
    if (!n)
      throw new x("Did not find target button.");
    const s = yield n.as(ut).endpoint.callTest(ms(this, cs, "f"), { parse: !0 });
    switch (t.icon_type) {
      case "LIKE":
      case "WATCH_LATER":
        return new Vl(ms(this, cs, "f"), s, !0);
      case "WATCH_HISTORY":
        return new z_(ms(this, cs, "f"), s, !0);
      case "CONTENT_CUT":
        return new Un(ms(this, cs, "f"), s, !0);
      default:
        throw new x("Target shelf not implemented.");
    }
  });
}, "_Library_getAll");
var rC = X_, j5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, B1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ei = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Xs, yn, eo, Em = class {
  constructor(e, t, i = !1) {
    var n, s, r, a, u;
    Xs.set(this, void 0), yn.set(this, void 0), eo.set(this, void 0), B1(this, Xs, i ? t : y.parseResponse(t), "f"), B1(this, yn, e, "f");
    const c = Ei(this, Xs, "f").on_response_received_endpoints;
    if (!c)
      throw new x("Comments page did not have any content.");
    this.header = (s = (n = c[0].contents) === null || n === void 0 ? void 0 : n.get({ type: "CommentsHeader" })) === null || s === void 0 ? void 0 : s.as(oy);
    const h = ((r = c[1].contents) === null || r === void 0 ? void 0 : r.filterType(ly)) || [];
    this.contents = h.map((p) => {
      var f;
      return (f = p.comment) === null || f === void 0 || f.setActions(Ei(this, yn, "f")), p.setActions(Ei(this, yn, "f")), p;
    }), B1(this, eo, (u = (a = c[1].contents) === null || a === void 0 ? void 0 : a.get({ type: "ContinuationItem" })) === null || u === void 0 ? void 0 : u.as(sn), "f");
  }
  createComment(e) {
    var t;
    return j5(this, void 0, void 0, function* () {
      if (!this.header)
        throw new x("Page header is missing.");
      const i = (t = this.header.create_renderer) === null || t === void 0 ? void 0 : t.as(ay).submit_button.item().as(ut);
      if (!i)
        throw new x("Could not find target button.");
      return yield i.endpoint.callTest(Ei(this, yn, "f"), {
        commentText: e
      });
    });
  }
  getContinuation() {
    return j5(this, void 0, void 0, function* () {
      if (!Ei(this, eo, "f"))
        throw new x("Continuation not found");
      const e = yield Ei(this, eo, "f").endpoint.callTest(Ei(this, yn, "f"), { parse: !0 }), t = Object.assign({}, Ei(this, Xs, "f"));
      if (!t.on_response_received_endpoints || !e.on_response_received_endpoints)
        throw new x("Invalid reponse format, missing on_response_received_endpoints");
      return t.on_response_received_endpoints.pop(), t.on_response_received_endpoints.push(e.on_response_received_endpoints[0]), new Em(Ei(this, yn, "f"), t, !0);
    });
  }
  get page() {
    return Ei(this, Xs, "f");
  }
};
l(Em, "Comments");
Xs = /* @__PURE__ */ new WeakMap(), yn = /* @__PURE__ */ new WeakMap(), eo = /* @__PURE__ */ new WeakMap();
var oC = Em, aC = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, H5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Lr = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Js, to, km = class {
  constructor(e, t) {
    var i, n;
    Js.set(this, void 0), to.set(this, void 0), H5(this, to, e, "f"), H5(this, Js, y.parseResponse(t.data), "f"), this.header = ((n = (i = Lr(this, Js, "f").actions_memo.get("SimpleMenuHeader")) === null || i === void 0 ? void 0 : i[0]) === null || n === void 0 ? void 0 : n.as(Oy)) || null, this.contents = Lr(this, Js, "f").actions_memo.get("Notification");
  }
  getContinuation() {
    var e;
    return aC(this, void 0, void 0, function* () {
      const t = (e = Lr(this, Js, "f").actions_memo.get("ContinuationItem")) === null || e === void 0 ? void 0 : e[0].as(sn);
      if (!t)
        throw new x("Continuation not found");
      const i = yield t.endpoint.callTest(Lr(this, to, "f"), { parse: !1 });
      return new km(Lr(this, to, "f"), i);
    });
  }
};
l(km, "NotificationsMenu");
Js = /* @__PURE__ */ new WeakMap(), to = /* @__PURE__ */ new WeakMap();
var lC = km, io = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, vs = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, dt = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, In, ur, rr, No, no, tl, so, J_, W5, Z_, $5, Q_ = class extends Cm {
  constructor(e) {
    var t, i;
    super(), In.add(this), ur.set(this, void 0), rr.set(this, void 0), No.set(this, void 0), no.set(this, void 0), tl.set(this, 1e3), so.set(this, 5e3), this.running = !1, this.is_replay = !1, vs(this, rr, e, "f"), vs(this, ur, e.actions, "f"), vs(this, No, ((t = e.livechat) === null || t === void 0 ? void 0 : t.continuation) || void 0, "f"), this.is_replay = ((i = e.livechat) === null || i === void 0 ? void 0 : i.is_replay) || !1;
  }
  start() {
    this.running || (this.running = !0, dt(this, In, "m", J_).call(this), dt(this, In, "m", Z_).call(this));
  }
  stop() {
    this.running = !1;
  }
  sendMessage(e) {
    return io(this, void 0, void 0, function* () {
      const t = yield dt(this, ur, "f").livechat("live_chat/send_message", Object.assign({ text: e }, {
        video_id: dt(this, rr, "f").basic_info.id,
        channel_id: dt(this, rr, "f").basic_info.channel_id
      })), i = y.parseResponse(t.data);
      if (!i.actions)
        throw new x('Response did not have an "actions" property. The call may have failed.');
      return i.actions.array().as(Ay);
    });
  }
};
l(Q_, "LiveChat");
ur = /* @__PURE__ */ new WeakMap(), rr = /* @__PURE__ */ new WeakMap(), No = /* @__PURE__ */ new WeakMap(), no = /* @__PURE__ */ new WeakMap(), tl = /* @__PURE__ */ new WeakMap(), so = /* @__PURE__ */ new WeakMap(), In = /* @__PURE__ */ new WeakSet(), J_ = /* @__PURE__ */ l(function e() {
  const t = setTimeout(() => {
    (() => io(this, void 0, void 0, function* () {
      const i = this.is_replay ? "live_chat/get_live_chat_replay" : "live_chat/get_live_chat", n = yield dt(this, ur, "f").livechat(i, { ctoken: dt(this, No, "f") }), r = y.parseResponse(n.data).continuation_contents;
      if (!(r instanceof du))
        throw new x("Continuation is not a LiveChatContinuation");
      vs(this, No, r.continuation.token, "f"), vs(this, tl, r.continuation.timeout_ms, "f"), r.header ? (this.initial_info = r, this.emit("start", r)) : yield dt(this, In, "m", W5).call(this, r.actions), clearTimeout(t), this.running && dt(this, In, "m", e).call(this);
    }))().catch((i) => Promise.reject(i));
  }, dt(this, tl, "f"));
}, "_LiveChat_pollLivechat"), W5 = /* @__PURE__ */ l(function(t) {
  return io(this, void 0, void 0, function* () {
    let n = t.length < 125 ? 1 : 0;
    const s = n == 1 ? (n = 1e4 / t.length, n *= Math.random() + 0.5, n = Math.min(1e3, n), n = Math.max(80, n)) : n = 80;
    for (const r of t)
      yield dt(this, In, "m", $5).call(this, s), this.emit("chat-update", r);
  });
}, "_LiveChat_emitSmoothedActions"), Z_ = /* @__PURE__ */ l(function e() {
  const t = setTimeout(() => {
    (() => io(this, void 0, void 0, function* () {
      var i, n, s, r, a, u, c, h, p, f, _, C;
      const E = {
        video_id: dt(this, rr, "f").basic_info.id,
        ctoken: void 0
      };
      dt(this, no, "f") && (E.ctoken = dt(this, no, "f"));
      const P = yield dt(this, ur, "f").livechat("updated_metadata", E), A = y.parseResponse(P.data);
      vs(this, no, (i = A.continuation) === null || i === void 0 ? void 0 : i.token, "f"), vs(this, so, ((n = A.continuation) === null || n === void 0 ? void 0 : n.timeout_ms) || dt(this, so, "f"), "f"), this.metadata = {
        title: ((s = A.actions) === null || s === void 0 ? void 0 : s.array().firstOfType(Ny)) || ((r = this.metadata) === null || r === void 0 ? void 0 : r.title),
        description: ((a = A.actions) === null || a === void 0 ? void 0 : a.array().firstOfType(My)) || ((u = this.metadata) === null || u === void 0 ? void 0 : u.description),
        views: ((c = A.actions) === null || c === void 0 ? void 0 : c.array().firstOfType(Ly)) || ((h = this.metadata) === null || h === void 0 ? void 0 : h.views),
        likes: ((p = A.actions) === null || p === void 0 ? void 0 : p.array().firstOfType(Ry)) || ((f = this.metadata) === null || f === void 0 ? void 0 : f.likes),
        date: ((_ = A.actions) === null || _ === void 0 ? void 0 : _.array().firstOfType(Py)) || ((C = this.metadata) === null || C === void 0 ? void 0 : C.date)
      }, this.emit("metadata-update", this.metadata), clearTimeout(t), this.running && dt(this, In, "m", e).call(this);
    }))().catch((i) => Promise.reject(i));
  }, dt(this, so, "f"));
}, "_LiveChat_pollMetadata"), $5 = /* @__PURE__ */ l(function(t) {
  return io(this, void 0, void 0, function* () {
    return new Promise((i) => setTimeout(() => i(), t));
  });
}, "_LiveChat_wait");
var uC = Q_, Ul = Symbol("changed"), Zs = Symbol("classList"), vi = Symbol("CustomElements"), Ma = Symbol("content"), O1 = Symbol("dataset"), Yn = Symbol("doctype"), fc = Symbol("DOMParser"), re = Symbol("end"), Dr = Symbol("EventTarget"), il = Symbol("globals"), gi = Symbol("image"), br = Symbol("mime"), Mn = Symbol("MutationObserver"), G = Symbol("next"), eb = Symbol("ownerElement"), pt = Symbol("prev"), bt = Symbol("private"), Fs = Symbol("sheet"), Ut = Symbol("start"), F1 = Symbol("style"), Ro = Symbol("upgrade"), Ge = Symbol("value"), tb = {};
Jo(tb, {
  DefaultHandler: () => $o,
  DomHandler: () => $o,
  DomUtils: () => gu,
  ElementType: () => rb,
  Parser: () => pu,
  Tokenizer: () => Pm,
  createDomStream: () => zb,
  getFeed: () => wu,
  parseDOM: () => Xm,
  parseDocument: () => Ym,
  parseFeed: () => Yb
});
var cC = new Uint16Array([7489, 60, 213, 305, 650, 1181, 1403, 1488, 1653, 1758, 1954, 2006, 2063, 2634, 2705, 3489, 3693, 3849, 3878, 4298, 4648, 4833, 5141, 5277, 5315, 5343, 5413, 0, 0, 0, 0, 0, 0, 5483, 5837, 6541, 7186, 7645, 8062, 8288, 8624, 8845, 9152, 9211, 9282, 10276, 10514, 11528, 11848, 12238, 12310, 12986, 13881, 14252, 14590, 14888, 14961, 15072, 15150, 2048, 69, 77, 97, 98, 99, 102, 103, 108, 109, 110, 111, 112, 114, 115, 116, 117, 92, 98, 102, 109, 115, 127, 132, 139, 144, 149, 152, 166, 179, 185, 200, 207, 108, 105, 103, 32827, 198, 16582, 80, 32827, 38, 16422, 99, 117, 116, 101, 32827, 193, 16577, 114, 101, 118, 101, 59, 16642, 256, 105, 121, 120, 125, 114, 99, 32827, 194, 16578, 59, 17424, 114, 59, 49152, 55349, 56580, 114, 97, 118, 101, 32827, 192, 16576, 112, 104, 97, 59, 17297, 97, 99, 114, 59, 16640, 100, 59, 27219, 256, 103, 112, 157, 161, 111, 110, 59, 16644, 102, 59, 49152, 55349, 56632, 112, 108, 121, 70, 117, 110, 99, 116, 105, 111, 110, 59, 24673, 105, 110, 103, 32827, 197, 16581, 256, 99, 115, 190, 195, 114, 59, 49152, 55349, 56476, 105, 103, 110, 59, 25172, 105, 108, 100, 101, 32827, 195, 16579, 109, 108, 32827, 196, 16580, 1024, 97, 99, 101, 102, 111, 114, 115, 117, 229, 251, 254, 279, 284, 290, 295, 298, 256, 99, 114, 234, 242, 107, 115, 108, 97, 115, 104, 59, 25110, 374, 246, 248, 59, 27367, 101, 100, 59, 25350, 121, 59, 17425, 384, 99, 114, 116, 261, 267, 276, 97, 117, 115, 101, 59, 25141, 110, 111, 117, 108, 108, 105, 115, 59, 24876, 97, 59, 17298, 114, 59, 49152, 55349, 56581, 112, 102, 59, 49152, 55349, 56633, 101, 118, 101, 59, 17112, 99, 242, 275, 109, 112, 101, 113, 59, 25166, 1792, 72, 79, 97, 99, 100, 101, 102, 104, 105, 108, 111, 114, 115, 117, 333, 337, 342, 384, 414, 418, 437, 439, 442, 476, 533, 627, 632, 638, 99, 121, 59, 17447, 80, 89, 32827, 169, 16553, 384, 99, 112, 121, 349, 354, 378, 117, 116, 101, 59, 16646, 256, 59, 105, 359, 360, 25298, 116, 97, 108, 68, 105, 102, 102, 101, 114, 101, 110, 116, 105, 97, 108, 68, 59, 24901, 108, 101, 121, 115, 59, 24877, 512, 97, 101, 105, 111, 393, 398, 404, 408, 114, 111, 110, 59, 16652, 100, 105, 108, 32827, 199, 16583, 114, 99, 59, 16648, 110, 105, 110, 116, 59, 25136, 111, 116, 59, 16650, 256, 100, 110, 423, 429, 105, 108, 108, 97, 59, 16568, 116, 101, 114, 68, 111, 116, 59, 16567, 242, 383, 105, 59, 17319, 114, 99, 108, 101, 512, 68, 77, 80, 84, 455, 459, 465, 470, 111, 116, 59, 25241, 105, 110, 117, 115, 59, 25238, 108, 117, 115, 59, 25237, 105, 109, 101, 115, 59, 25239, 111, 256, 99, 115, 482, 504, 107, 119, 105, 115, 101, 67, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25138, 101, 67, 117, 114, 108, 121, 256, 68, 81, 515, 527, 111, 117, 98, 108, 101, 81, 117, 111, 116, 101, 59, 24605, 117, 111, 116, 101, 59, 24601, 512, 108, 110, 112, 117, 542, 552, 583, 597, 111, 110, 256, 59, 101, 549, 550, 25143, 59, 27252, 384, 103, 105, 116, 559, 566, 570, 114, 117, 101, 110, 116, 59, 25185, 110, 116, 59, 25135, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25134, 256, 102, 114, 588, 590, 59, 24834, 111, 100, 117, 99, 116, 59, 25104, 110, 116, 101, 114, 67, 108, 111, 99, 107, 119, 105, 115, 101, 67, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25139, 111, 115, 115, 59, 27183, 99, 114, 59, 49152, 55349, 56478, 112, 256, 59, 67, 644, 645, 25299, 97, 112, 59, 25165, 1408, 68, 74, 83, 90, 97, 99, 101, 102, 105, 111, 115, 672, 684, 688, 692, 696, 715, 727, 737, 742, 819, 1165, 256, 59, 111, 377, 677, 116, 114, 97, 104, 100, 59, 26897, 99, 121, 59, 17410, 99, 121, 59, 17413, 99, 121, 59, 17423, 384, 103, 114, 115, 703, 708, 711, 103, 101, 114, 59, 24609, 114, 59, 24993, 104, 118, 59, 27364, 256, 97, 121, 720, 725, 114, 111, 110, 59, 16654, 59, 17428, 108, 256, 59, 116, 733, 734, 25095, 97, 59, 17300, 114, 59, 49152, 55349, 56583, 256, 97, 102, 747, 807, 256, 99, 109, 752, 802, 114, 105, 116, 105, 99, 97, 108, 512, 65, 68, 71, 84, 768, 774, 790, 796, 99, 117, 116, 101, 59, 16564, 111, 372, 779, 781, 59, 17113, 98, 108, 101, 65, 99, 117, 116, 101, 59, 17117, 114, 97, 118, 101, 59, 16480, 105, 108, 100, 101, 59, 17116, 111, 110, 100, 59, 25284, 102, 101, 114, 101, 110, 116, 105, 97, 108, 68, 59, 24902, 1136, 829, 0, 0, 0, 834, 852, 0, 1029, 102, 59, 49152, 55349, 56635, 384, 59, 68, 69, 840, 841, 845, 16552, 111, 116, 59, 24796, 113, 117, 97, 108, 59, 25168, 98, 108, 101, 768, 67, 68, 76, 82, 85, 86, 867, 882, 898, 975, 994, 1016, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 236, 569, 111, 628, 889, 0, 0, 891, 187, 841, 110, 65, 114, 114, 111, 119, 59, 25043, 256, 101, 111, 903, 932, 102, 116, 384, 65, 82, 84, 912, 918, 929, 114, 114, 111, 119, 59, 25040, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 25044, 101, 229, 714, 110, 103, 256, 76, 82, 939, 964, 101, 102, 116, 256, 65, 82, 947, 953, 114, 114, 111, 119, 59, 26616, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26618, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26617, 105, 103, 104, 116, 256, 65, 84, 984, 990, 114, 114, 111, 119, 59, 25042, 101, 101, 59, 25256, 112, 577, 1001, 0, 0, 1007, 114, 114, 111, 119, 59, 25041, 111, 119, 110, 65, 114, 114, 111, 119, 59, 25045, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25125, 110, 768, 65, 66, 76, 82, 84, 97, 1042, 1066, 1072, 1118, 1151, 892, 114, 114, 111, 119, 384, 59, 66, 85, 1053, 1054, 1058, 24979, 97, 114, 59, 26899, 112, 65, 114, 114, 111, 119, 59, 25077, 114, 101, 118, 101, 59, 17169, 101, 102, 116, 722, 1082, 0, 1094, 0, 1104, 105, 103, 104, 116, 86, 101, 99, 116, 111, 114, 59, 26960, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26974, 101, 99, 116, 111, 114, 256, 59, 66, 1113, 1114, 25021, 97, 114, 59, 26966, 105, 103, 104, 116, 468, 1127, 0, 1137, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26975, 101, 99, 116, 111, 114, 256, 59, 66, 1146, 1147, 25025, 97, 114, 59, 26967, 101, 101, 256, 59, 65, 1158, 1159, 25252, 114, 114, 111, 119, 59, 24999, 256, 99, 116, 1170, 1175, 114, 59, 49152, 55349, 56479, 114, 111, 107, 59, 16656, 2048, 78, 84, 97, 99, 100, 102, 103, 108, 109, 111, 112, 113, 115, 116, 117, 120, 1213, 1216, 1220, 1227, 1246, 1250, 1255, 1262, 1269, 1313, 1327, 1334, 1362, 1373, 1376, 1381, 71, 59, 16714, 72, 32827, 208, 16592, 99, 117, 116, 101, 32827, 201, 16585, 384, 97, 105, 121, 1234, 1239, 1244, 114, 111, 110, 59, 16666, 114, 99, 32827, 202, 16586, 59, 17453, 111, 116, 59, 16662, 114, 59, 49152, 55349, 56584, 114, 97, 118, 101, 32827, 200, 16584, 101, 109, 101, 110, 116, 59, 25096, 256, 97, 112, 1274, 1278, 99, 114, 59, 16658, 116, 121, 595, 1286, 0, 0, 1298, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26107, 101, 114, 121, 83, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26027, 256, 103, 112, 1318, 1322, 111, 110, 59, 16664, 102, 59, 49152, 55349, 56636, 115, 105, 108, 111, 110, 59, 17301, 117, 256, 97, 105, 1340, 1353, 108, 256, 59, 84, 1346, 1347, 27253, 105, 108, 100, 101, 59, 25154, 108, 105, 98, 114, 105, 117, 109, 59, 25036, 256, 99, 105, 1367, 1370, 114, 59, 24880, 109, 59, 27251, 97, 59, 17303, 109, 108, 32827, 203, 16587, 256, 105, 112, 1386, 1391, 115, 116, 115, 59, 25091, 111, 110, 101, 110, 116, 105, 97, 108, 69, 59, 24903, 640, 99, 102, 105, 111, 115, 1413, 1416, 1421, 1458, 1484, 121, 59, 17444, 114, 59, 49152, 55349, 56585, 108, 108, 101, 100, 595, 1431, 0, 0, 1443, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26108, 101, 114, 121, 83, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26026, 880, 1466, 0, 1471, 0, 0, 1476, 102, 59, 49152, 55349, 56637, 65, 108, 108, 59, 25088, 114, 105, 101, 114, 116, 114, 102, 59, 24881, 99, 242, 1483, 1536, 74, 84, 97, 98, 99, 100, 102, 103, 111, 114, 115, 116, 1512, 1516, 1519, 1530, 1536, 1554, 1558, 1563, 1565, 1571, 1644, 1650, 99, 121, 59, 17411, 32827, 62, 16446, 109, 109, 97, 256, 59, 100, 1527, 1528, 17299, 59, 17372, 114, 101, 118, 101, 59, 16670, 384, 101, 105, 121, 1543, 1548, 1552, 100, 105, 108, 59, 16674, 114, 99, 59, 16668, 59, 17427, 111, 116, 59, 16672, 114, 59, 49152, 55349, 56586, 59, 25305, 112, 102, 59, 49152, 55349, 56638, 101, 97, 116, 101, 114, 768, 69, 70, 71, 76, 83, 84, 1589, 1604, 1614, 1622, 1627, 1638, 113, 117, 97, 108, 256, 59, 76, 1598, 1599, 25189, 101, 115, 115, 59, 25307, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25191, 114, 101, 97, 116, 101, 114, 59, 27298, 101, 115, 115, 59, 25207, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 27262, 105, 108, 100, 101, 59, 25203, 99, 114, 59, 49152, 55349, 56482, 59, 25195, 1024, 65, 97, 99, 102, 105, 111, 115, 117, 1669, 1675, 1686, 1691, 1694, 1706, 1726, 1738, 82, 68, 99, 121, 59, 17450, 256, 99, 116, 1680, 1684, 101, 107, 59, 17095, 59, 16478, 105, 114, 99, 59, 16676, 114, 59, 24844, 108, 98, 101, 114, 116, 83, 112, 97, 99, 101, 59, 24843, 496, 1711, 0, 1714, 102, 59, 24845, 105, 122, 111, 110, 116, 97, 108, 76, 105, 110, 101, 59, 25856, 256, 99, 116, 1731, 1733, 242, 1705, 114, 111, 107, 59, 16678, 109, 112, 324, 1744, 1752, 111, 119, 110, 72, 117, 109, 240, 303, 113, 117, 97, 108, 59, 25167, 1792, 69, 74, 79, 97, 99, 100, 102, 103, 109, 110, 111, 115, 116, 117, 1786, 1790, 1795, 1799, 1806, 1818, 1822, 1825, 1832, 1860, 1912, 1931, 1935, 1941, 99, 121, 59, 17429, 108, 105, 103, 59, 16690, 99, 121, 59, 17409, 99, 117, 116, 101, 32827, 205, 16589, 256, 105, 121, 1811, 1816, 114, 99, 32827, 206, 16590, 59, 17432, 111, 116, 59, 16688, 114, 59, 24849, 114, 97, 118, 101, 32827, 204, 16588, 384, 59, 97, 112, 1824, 1839, 1855, 256, 99, 103, 1844, 1847, 114, 59, 16682, 105, 110, 97, 114, 121, 73, 59, 24904, 108, 105, 101, 243, 989, 500, 1865, 0, 1890, 256, 59, 101, 1869, 1870, 25132, 256, 103, 114, 1875, 1880, 114, 97, 108, 59, 25131, 115, 101, 99, 116, 105, 111, 110, 59, 25282, 105, 115, 105, 98, 108, 101, 256, 67, 84, 1900, 1906, 111, 109, 109, 97, 59, 24675, 105, 109, 101, 115, 59, 24674, 384, 103, 112, 116, 1919, 1923, 1928, 111, 110, 59, 16686, 102, 59, 49152, 55349, 56640, 97, 59, 17305, 99, 114, 59, 24848, 105, 108, 100, 101, 59, 16680, 491, 1946, 0, 1950, 99, 121, 59, 17414, 108, 32827, 207, 16591, 640, 99, 102, 111, 115, 117, 1964, 1975, 1980, 1986, 2e3, 256, 105, 121, 1969, 1973, 114, 99, 59, 16692, 59, 17433, 114, 59, 49152, 55349, 56589, 112, 102, 59, 49152, 55349, 56641, 483, 1991, 0, 1996, 114, 59, 49152, 55349, 56485, 114, 99, 121, 59, 17416, 107, 99, 121, 59, 17412, 896, 72, 74, 97, 99, 102, 111, 115, 2020, 2024, 2028, 2033, 2045, 2050, 2056, 99, 121, 59, 17445, 99, 121, 59, 17420, 112, 112, 97, 59, 17306, 256, 101, 121, 2038, 2043, 100, 105, 108, 59, 16694, 59, 17434, 114, 59, 49152, 55349, 56590, 112, 102, 59, 49152, 55349, 56642, 99, 114, 59, 49152, 55349, 56486, 1408, 74, 84, 97, 99, 101, 102, 108, 109, 111, 115, 116, 2085, 2089, 2092, 2128, 2147, 2483, 2488, 2503, 2509, 2615, 2631, 99, 121, 59, 17417, 32827, 60, 16444, 640, 99, 109, 110, 112, 114, 2103, 2108, 2113, 2116, 2125, 117, 116, 101, 59, 16697, 98, 100, 97, 59, 17307, 103, 59, 26602, 108, 97, 99, 101, 116, 114, 102, 59, 24850, 114, 59, 24990, 384, 97, 101, 121, 2135, 2140, 2145, 114, 111, 110, 59, 16701, 100, 105, 108, 59, 16699, 59, 17435, 256, 102, 115, 2152, 2416, 116, 1280, 65, 67, 68, 70, 82, 84, 85, 86, 97, 114, 2174, 2217, 2225, 2272, 2278, 2300, 2351, 2395, 912, 2410, 256, 110, 114, 2179, 2191, 103, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26600, 114, 111, 119, 384, 59, 66, 82, 2201, 2202, 2206, 24976, 97, 114, 59, 25060, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 25030, 101, 105, 108, 105, 110, 103, 59, 25352, 111, 501, 2231, 0, 2243, 98, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26598, 110, 468, 2248, 0, 2258, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26977, 101, 99, 116, 111, 114, 256, 59, 66, 2267, 2268, 25027, 97, 114, 59, 26969, 108, 111, 111, 114, 59, 25354, 105, 103, 104, 116, 256, 65, 86, 2287, 2293, 114, 114, 111, 119, 59, 24980, 101, 99, 116, 111, 114, 59, 26958, 256, 101, 114, 2305, 2327, 101, 384, 59, 65, 86, 2313, 2314, 2320, 25251, 114, 114, 111, 119, 59, 24996, 101, 99, 116, 111, 114, 59, 26970, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 2340, 2341, 2345, 25266, 97, 114, 59, 27087, 113, 117, 97, 108, 59, 25268, 112, 384, 68, 84, 86, 2359, 2370, 2380, 111, 119, 110, 86, 101, 99, 116, 111, 114, 59, 26961, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26976, 101, 99, 116, 111, 114, 256, 59, 66, 2390, 2391, 25023, 97, 114, 59, 26968, 101, 99, 116, 111, 114, 256, 59, 66, 2405, 2406, 25020, 97, 114, 59, 26962, 105, 103, 104, 116, 225, 924, 115, 768, 69, 70, 71, 76, 83, 84, 2430, 2443, 2453, 2461, 2466, 2477, 113, 117, 97, 108, 71, 114, 101, 97, 116, 101, 114, 59, 25306, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25190, 114, 101, 97, 116, 101, 114, 59, 25206, 101, 115, 115, 59, 27297, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 27261, 105, 108, 100, 101, 59, 25202, 114, 59, 49152, 55349, 56591, 256, 59, 101, 2493, 2494, 25304, 102, 116, 97, 114, 114, 111, 119, 59, 25050, 105, 100, 111, 116, 59, 16703, 384, 110, 112, 119, 2516, 2582, 2587, 103, 512, 76, 82, 108, 114, 2526, 2551, 2562, 2576, 101, 102, 116, 256, 65, 82, 2534, 2540, 114, 114, 111, 119, 59, 26613, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26615, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26614, 101, 102, 116, 256, 97, 114, 947, 2570, 105, 103, 104, 116, 225, 959, 105, 103, 104, 116, 225, 970, 102, 59, 49152, 55349, 56643, 101, 114, 256, 76, 82, 2594, 2604, 101, 102, 116, 65, 114, 114, 111, 119, 59, 24985, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 24984, 384, 99, 104, 116, 2622, 2624, 2626, 242, 2124, 59, 25008, 114, 111, 107, 59, 16705, 59, 25194, 1024, 97, 99, 101, 102, 105, 111, 115, 117, 2650, 2653, 2656, 2679, 2684, 2693, 2699, 2702, 112, 59, 26885, 121, 59, 17436, 256, 100, 108, 2661, 2671, 105, 117, 109, 83, 112, 97, 99, 101, 59, 24671, 108, 105, 110, 116, 114, 102, 59, 24883, 114, 59, 49152, 55349, 56592, 110, 117, 115, 80, 108, 117, 115, 59, 25107, 112, 102, 59, 49152, 55349, 56644, 99, 242, 2678, 59, 17308, 1152, 74, 97, 99, 101, 102, 111, 115, 116, 117, 2723, 2727, 2733, 2752, 2836, 2841, 3473, 3479, 3486, 99, 121, 59, 17418, 99, 117, 116, 101, 59, 16707, 384, 97, 101, 121, 2740, 2745, 2750, 114, 111, 110, 59, 16711, 100, 105, 108, 59, 16709, 59, 17437, 384, 103, 115, 119, 2759, 2800, 2830, 97, 116, 105, 118, 101, 384, 77, 84, 86, 2771, 2783, 2792, 101, 100, 105, 117, 109, 83, 112, 97, 99, 101, 59, 24587, 104, 105, 256, 99, 110, 2790, 2776, 235, 2777, 101, 114, 121, 84, 104, 105, 238, 2777, 116, 101, 100, 256, 71, 76, 2808, 2822, 114, 101, 97, 116, 101, 114, 71, 114, 101, 97, 116, 101, 242, 1651, 101, 115, 115, 76, 101, 115, 243, 2632, 76, 105, 110, 101, 59, 16394, 114, 59, 49152, 55349, 56593, 512, 66, 110, 112, 116, 2850, 2856, 2871, 2874, 114, 101, 97, 107, 59, 24672, 66, 114, 101, 97, 107, 105, 110, 103, 83, 112, 97, 99, 101, 59, 16544, 102, 59, 24853, 1664, 59, 67, 68, 69, 71, 72, 76, 78, 80, 82, 83, 84, 86, 2901, 2902, 2922, 2940, 2977, 3051, 3076, 3166, 3204, 3238, 3288, 3425, 3461, 27372, 256, 111, 117, 2907, 2916, 110, 103, 114, 117, 101, 110, 116, 59, 25186, 112, 67, 97, 112, 59, 25197, 111, 117, 98, 108, 101, 86, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25126, 384, 108, 113, 120, 2947, 2954, 2971, 101, 109, 101, 110, 116, 59, 25097, 117, 97, 108, 256, 59, 84, 2962, 2963, 25184, 105, 108, 100, 101, 59, 49152, 8770, 824, 105, 115, 116, 115, 59, 25092, 114, 101, 97, 116, 101, 114, 896, 59, 69, 70, 71, 76, 83, 84, 2998, 2999, 3005, 3017, 3027, 3032, 3045, 25199, 113, 117, 97, 108, 59, 25201, 117, 108, 108, 69, 113, 117, 97, 108, 59, 49152, 8807, 824, 114, 101, 97, 116, 101, 114, 59, 49152, 8811, 824, 101, 115, 115, 59, 25209, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 49152, 10878, 824, 105, 108, 100, 101, 59, 25205, 117, 109, 112, 324, 3058, 3069, 111, 119, 110, 72, 117, 109, 112, 59, 49152, 8782, 824, 113, 117, 97, 108, 59, 49152, 8783, 824, 101, 256, 102, 115, 3082, 3111, 116, 84, 114, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 3098, 3099, 3105, 25322, 97, 114, 59, 49152, 10703, 824, 113, 117, 97, 108, 59, 25324, 115, 768, 59, 69, 71, 76, 83, 84, 3125, 3126, 3132, 3140, 3147, 3160, 25198, 113, 117, 97, 108, 59, 25200, 114, 101, 97, 116, 101, 114, 59, 25208, 101, 115, 115, 59, 49152, 8810, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 49152, 10877, 824, 105, 108, 100, 101, 59, 25204, 101, 115, 116, 101, 100, 256, 71, 76, 3176, 3193, 114, 101, 97, 116, 101, 114, 71, 114, 101, 97, 116, 101, 114, 59, 49152, 10914, 824, 101, 115, 115, 76, 101, 115, 115, 59, 49152, 10913, 824, 114, 101, 99, 101, 100, 101, 115, 384, 59, 69, 83, 3218, 3219, 3227, 25216, 113, 117, 97, 108, 59, 49152, 10927, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25312, 256, 101, 105, 3243, 3257, 118, 101, 114, 115, 101, 69, 108, 101, 109, 101, 110, 116, 59, 25100, 103, 104, 116, 84, 114, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 3275, 3276, 3282, 25323, 97, 114, 59, 49152, 10704, 824, 113, 117, 97, 108, 59, 25325, 256, 113, 117, 3293, 3340, 117, 97, 114, 101, 83, 117, 256, 98, 112, 3304, 3321, 115, 101, 116, 256, 59, 69, 3312, 3315, 49152, 8847, 824, 113, 117, 97, 108, 59, 25314, 101, 114, 115, 101, 116, 256, 59, 69, 3331, 3334, 49152, 8848, 824, 113, 117, 97, 108, 59, 25315, 384, 98, 99, 112, 3347, 3364, 3406, 115, 101, 116, 256, 59, 69, 3355, 3358, 49152, 8834, 8402, 113, 117, 97, 108, 59, 25224, 99, 101, 101, 100, 115, 512, 59, 69, 83, 84, 3378, 3379, 3387, 3398, 25217, 113, 117, 97, 108, 59, 49152, 10928, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25313, 105, 108, 100, 101, 59, 49152, 8831, 824, 101, 114, 115, 101, 116, 256, 59, 69, 3416, 3419, 49152, 8835, 8402, 113, 117, 97, 108, 59, 25225, 105, 108, 100, 101, 512, 59, 69, 70, 84, 3438, 3439, 3445, 3455, 25153, 113, 117, 97, 108, 59, 25156, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25159, 105, 108, 100, 101, 59, 25161, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25124, 99, 114, 59, 49152, 55349, 56489, 105, 108, 100, 101, 32827, 209, 16593, 59, 17309, 1792, 69, 97, 99, 100, 102, 103, 109, 111, 112, 114, 115, 116, 117, 118, 3517, 3522, 3529, 3541, 3547, 3552, 3559, 3580, 3586, 3616, 3618, 3634, 3647, 3652, 108, 105, 103, 59, 16722, 99, 117, 116, 101, 32827, 211, 16595, 256, 105, 121, 3534, 3539, 114, 99, 32827, 212, 16596, 59, 17438, 98, 108, 97, 99, 59, 16720, 114, 59, 49152, 55349, 56594, 114, 97, 118, 101, 32827, 210, 16594, 384, 97, 101, 105, 3566, 3570, 3574, 99, 114, 59, 16716, 103, 97, 59, 17321, 99, 114, 111, 110, 59, 17311, 112, 102, 59, 49152, 55349, 56646, 101, 110, 67, 117, 114, 108, 121, 256, 68, 81, 3598, 3610, 111, 117, 98, 108, 101, 81, 117, 111, 116, 101, 59, 24604, 117, 111, 116, 101, 59, 24600, 59, 27220, 256, 99, 108, 3623, 3628, 114, 59, 49152, 55349, 56490, 97, 115, 104, 32827, 216, 16600, 105, 364, 3639, 3644, 100, 101, 32827, 213, 16597, 101, 115, 59, 27191, 109, 108, 32827, 214, 16598, 101, 114, 256, 66, 80, 3659, 3680, 256, 97, 114, 3664, 3667, 114, 59, 24638, 97, 99, 256, 101, 107, 3674, 3676, 59, 25566, 101, 116, 59, 25524, 97, 114, 101, 110, 116, 104, 101, 115, 105, 115, 59, 25564, 1152, 97, 99, 102, 104, 105, 108, 111, 114, 115, 3711, 3719, 3722, 3727, 3730, 3732, 3741, 3760, 3836, 114, 116, 105, 97, 108, 68, 59, 25090, 121, 59, 17439, 114, 59, 49152, 55349, 56595, 105, 59, 17318, 59, 17312, 117, 115, 77, 105, 110, 117, 115, 59, 16561, 256, 105, 112, 3746, 3757, 110, 99, 97, 114, 101, 112, 108, 97, 110, 229, 1693, 102, 59, 24857, 512, 59, 101, 105, 111, 3769, 3770, 3808, 3812, 27323, 99, 101, 100, 101, 115, 512, 59, 69, 83, 84, 3784, 3785, 3791, 3802, 25210, 113, 117, 97, 108, 59, 27311, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25212, 105, 108, 100, 101, 59, 25214, 109, 101, 59, 24627, 256, 100, 112, 3817, 3822, 117, 99, 116, 59, 25103, 111, 114, 116, 105, 111, 110, 256, 59, 97, 549, 3833, 108, 59, 25117, 256, 99, 105, 3841, 3846, 114, 59, 49152, 55349, 56491, 59, 17320, 512, 85, 102, 111, 115, 3857, 3862, 3867, 3871, 79, 84, 32827, 34, 16418, 114, 59, 49152, 55349, 56596, 112, 102, 59, 24858, 99, 114, 59, 49152, 55349, 56492, 1536, 66, 69, 97, 99, 101, 102, 104, 105, 111, 114, 115, 117, 3902, 3907, 3911, 3936, 3955, 4007, 4010, 4013, 4246, 4265, 4276, 4286, 97, 114, 114, 59, 26896, 71, 32827, 174, 16558, 384, 99, 110, 114, 3918, 3923, 3926, 117, 116, 101, 59, 16724, 103, 59, 26603, 114, 256, 59, 116, 3932, 3933, 24992, 108, 59, 26902, 384, 97, 101, 121, 3943, 3948, 3953, 114, 111, 110, 59, 16728, 100, 105, 108, 59, 16726, 59, 17440, 256, 59, 118, 3960, 3961, 24860, 101, 114, 115, 101, 256, 69, 85, 3970, 3993, 256, 108, 113, 3975, 3982, 101, 109, 101, 110, 116, 59, 25099, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 25035, 112, 69, 113, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 26991, 114, 187, 3961, 111, 59, 17313, 103, 104, 116, 1024, 65, 67, 68, 70, 84, 85, 86, 97, 4033, 4075, 4083, 4130, 4136, 4187, 4231, 984, 256, 110, 114, 4038, 4050, 103, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26601, 114, 111, 119, 384, 59, 66, 76, 4060, 4061, 4065, 24978, 97, 114, 59, 25061, 101, 102, 116, 65, 114, 114, 111, 119, 59, 25028, 101, 105, 108, 105, 110, 103, 59, 25353, 111, 501, 4089, 0, 4101, 98, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26599, 110, 468, 4106, 0, 4116, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26973, 101, 99, 116, 111, 114, 256, 59, 66, 4125, 4126, 25026, 97, 114, 59, 26965, 108, 111, 111, 114, 59, 25355, 256, 101, 114, 4141, 4163, 101, 384, 59, 65, 86, 4149, 4150, 4156, 25250, 114, 114, 111, 119, 59, 24998, 101, 99, 116, 111, 114, 59, 26971, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 4176, 4177, 4181, 25267, 97, 114, 59, 27088, 113, 117, 97, 108, 59, 25269, 112, 384, 68, 84, 86, 4195, 4206, 4216, 111, 119, 110, 86, 101, 99, 116, 111, 114, 59, 26959, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26972, 101, 99, 116, 111, 114, 256, 59, 66, 4226, 4227, 25022, 97, 114, 59, 26964, 101, 99, 116, 111, 114, 256, 59, 66, 4241, 4242, 25024, 97, 114, 59, 26963, 256, 112, 117, 4251, 4254, 102, 59, 24861, 110, 100, 73, 109, 112, 108, 105, 101, 115, 59, 26992, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25051, 256, 99, 104, 4281, 4284, 114, 59, 24859, 59, 25009, 108, 101, 68, 101, 108, 97, 121, 101, 100, 59, 27124, 1664, 72, 79, 97, 99, 102, 104, 105, 109, 111, 113, 115, 116, 117, 4324, 4337, 4343, 4349, 4377, 4382, 4433, 4438, 4449, 4455, 4533, 4539, 4543, 256, 67, 99, 4329, 4334, 72, 99, 121, 59, 17449, 121, 59, 17448, 70, 84, 99, 121, 59, 17452, 99, 117, 116, 101, 59, 16730, 640, 59, 97, 101, 105, 121, 4360, 4361, 4366, 4371, 4375, 27324, 114, 111, 110, 59, 16736, 100, 105, 108, 59, 16734, 114, 99, 59, 16732, 59, 17441, 114, 59, 49152, 55349, 56598, 111, 114, 116, 512, 68, 76, 82, 85, 4394, 4404, 4414, 4425, 111, 119, 110, 65, 114, 114, 111, 119, 187, 1054, 101, 102, 116, 65, 114, 114, 111, 119, 187, 2202, 105, 103, 104, 116, 65, 114, 114, 111, 119, 187, 4061, 112, 65, 114, 114, 111, 119, 59, 24977, 103, 109, 97, 59, 17315, 97, 108, 108, 67, 105, 114, 99, 108, 101, 59, 25112, 112, 102, 59, 49152, 55349, 56650, 626, 4461, 0, 0, 4464, 116, 59, 25114, 97, 114, 101, 512, 59, 73, 83, 85, 4475, 4476, 4489, 4527, 26017, 110, 116, 101, 114, 115, 101, 99, 116, 105, 111, 110, 59, 25235, 117, 256, 98, 112, 4495, 4510, 115, 101, 116, 256, 59, 69, 4503, 4504, 25231, 113, 117, 97, 108, 59, 25233, 101, 114, 115, 101, 116, 256, 59, 69, 4520, 4521, 25232, 113, 117, 97, 108, 59, 25234, 110, 105, 111, 110, 59, 25236, 99, 114, 59, 49152, 55349, 56494, 97, 114, 59, 25286, 512, 98, 99, 109, 112, 4552, 4571, 4617, 4619, 256, 59, 115, 4557, 4558, 25296, 101, 116, 256, 59, 69, 4557, 4565, 113, 117, 97, 108, 59, 25222, 256, 99, 104, 4576, 4613, 101, 101, 100, 115, 512, 59, 69, 83, 84, 4589, 4590, 4596, 4607, 25211, 113, 117, 97, 108, 59, 27312, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25213, 105, 108, 100, 101, 59, 25215, 84, 104, 225, 3980, 59, 25105, 384, 59, 101, 115, 4626, 4627, 4643, 25297, 114, 115, 101, 116, 256, 59, 69, 4636, 4637, 25219, 113, 117, 97, 108, 59, 25223, 101, 116, 187, 4627, 1408, 72, 82, 83, 97, 99, 102, 104, 105, 111, 114, 115, 4670, 4676, 4681, 4693, 4702, 4721, 4726, 4767, 4802, 4808, 4817, 79, 82, 78, 32827, 222, 16606, 65, 68, 69, 59, 24866, 256, 72, 99, 4686, 4690, 99, 121, 59, 17419, 121, 59, 17446, 256, 98, 117, 4698, 4700, 59, 16393, 59, 17316, 384, 97, 101, 121, 4709, 4714, 4719, 114, 111, 110, 59, 16740, 100, 105, 108, 59, 16738, 59, 17442, 114, 59, 49152, 55349, 56599, 256, 101, 105, 4731, 4745, 498, 4736, 0, 4743, 101, 102, 111, 114, 101, 59, 25140, 97, 59, 17304, 256, 99, 110, 4750, 4760, 107, 83, 112, 97, 99, 101, 59, 49152, 8287, 8202, 83, 112, 97, 99, 101, 59, 24585, 108, 100, 101, 512, 59, 69, 70, 84, 4779, 4780, 4786, 4796, 25148, 113, 117, 97, 108, 59, 25155, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25157, 105, 108, 100, 101, 59, 25160, 112, 102, 59, 49152, 55349, 56651, 105, 112, 108, 101, 68, 111, 116, 59, 24795, 256, 99, 116, 4822, 4827, 114, 59, 49152, 55349, 56495, 114, 111, 107, 59, 16742, 2785, 4855, 4878, 4890, 4902, 0, 4908, 4913, 0, 0, 0, 0, 0, 4920, 4925, 4983, 4997, 0, 5119, 5124, 5130, 5136, 256, 99, 114, 4859, 4865, 117, 116, 101, 32827, 218, 16602, 114, 256, 59, 111, 4871, 4872, 24991, 99, 105, 114, 59, 26953, 114, 483, 4883, 0, 4886, 121, 59, 17422, 118, 101, 59, 16748, 256, 105, 121, 4894, 4899, 114, 99, 32827, 219, 16603, 59, 17443, 98, 108, 97, 99, 59, 16752, 114, 59, 49152, 55349, 56600, 114, 97, 118, 101, 32827, 217, 16601, 97, 99, 114, 59, 16746, 256, 100, 105, 4929, 4969, 101, 114, 256, 66, 80, 4936, 4957, 256, 97, 114, 4941, 4944, 114, 59, 16479, 97, 99, 256, 101, 107, 4951, 4953, 59, 25567, 101, 116, 59, 25525, 97, 114, 101, 110, 116, 104, 101, 115, 105, 115, 59, 25565, 111, 110, 256, 59, 80, 4976, 4977, 25283, 108, 117, 115, 59, 25230, 256, 103, 112, 4987, 4991, 111, 110, 59, 16754, 102, 59, 49152, 55349, 56652, 1024, 65, 68, 69, 84, 97, 100, 112, 115, 5013, 5038, 5048, 5060, 1e3, 5074, 5079, 5107, 114, 114, 111, 119, 384, 59, 66, 68, 4432, 5024, 5028, 97, 114, 59, 26898, 111, 119, 110, 65, 114, 114, 111, 119, 59, 25029, 111, 119, 110, 65, 114, 114, 111, 119, 59, 24981, 113, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 26990, 101, 101, 256, 59, 65, 5067, 5068, 25253, 114, 114, 111, 119, 59, 24997, 111, 119, 110, 225, 1011, 101, 114, 256, 76, 82, 5086, 5096, 101, 102, 116, 65, 114, 114, 111, 119, 59, 24982, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 24983, 105, 256, 59, 108, 5113, 5114, 17362, 111, 110, 59, 17317, 105, 110, 103, 59, 16750, 99, 114, 59, 49152, 55349, 56496, 105, 108, 100, 101, 59, 16744, 109, 108, 32827, 220, 16604, 1152, 68, 98, 99, 100, 101, 102, 111, 115, 118, 5159, 5164, 5168, 5171, 5182, 5253, 5258, 5264, 5270, 97, 115, 104, 59, 25259, 97, 114, 59, 27371, 121, 59, 17426, 97, 115, 104, 256, 59, 108, 5179, 5180, 25257, 59, 27366, 256, 101, 114, 5187, 5189, 59, 25281, 384, 98, 116, 121, 5196, 5200, 5242, 97, 114, 59, 24598, 256, 59, 105, 5199, 5205, 99, 97, 108, 512, 66, 76, 83, 84, 5217, 5221, 5226, 5236, 97, 114, 59, 25123, 105, 110, 101, 59, 16508, 101, 112, 97, 114, 97, 116, 111, 114, 59, 26456, 105, 108, 100, 101, 59, 25152, 84, 104, 105, 110, 83, 112, 97, 99, 101, 59, 24586, 114, 59, 49152, 55349, 56601, 112, 102, 59, 49152, 55349, 56653, 99, 114, 59, 49152, 55349, 56497, 100, 97, 115, 104, 59, 25258, 640, 99, 101, 102, 111, 115, 5287, 5292, 5297, 5302, 5308, 105, 114, 99, 59, 16756, 100, 103, 101, 59, 25280, 114, 59, 49152, 55349, 56602, 112, 102, 59, 49152, 55349, 56654, 99, 114, 59, 49152, 55349, 56498, 512, 102, 105, 111, 115, 5323, 5328, 5330, 5336, 114, 59, 49152, 55349, 56603, 59, 17310, 112, 102, 59, 49152, 55349, 56655, 99, 114, 59, 49152, 55349, 56499, 1152, 65, 73, 85, 97, 99, 102, 111, 115, 117, 5361, 5365, 5369, 5373, 5380, 5391, 5396, 5402, 5408, 99, 121, 59, 17455, 99, 121, 59, 17415, 99, 121, 59, 17454, 99, 117, 116, 101, 32827, 221, 16605, 256, 105, 121, 5385, 5389, 114, 99, 59, 16758, 59, 17451, 114, 59, 49152, 55349, 56604, 112, 102, 59, 49152, 55349, 56656, 99, 114, 59, 49152, 55349, 56500, 109, 108, 59, 16760, 1024, 72, 97, 99, 100, 101, 102, 111, 115, 5429, 5433, 5439, 5451, 5455, 5469, 5472, 5476, 99, 121, 59, 17430, 99, 117, 116, 101, 59, 16761, 256, 97, 121, 5444, 5449, 114, 111, 110, 59, 16765, 59, 17431, 111, 116, 59, 16763, 498, 5460, 0, 5467, 111, 87, 105, 100, 116, 232, 2777, 97, 59, 17302, 114, 59, 24872, 112, 102, 59, 24868, 99, 114, 59, 49152, 55349, 56501, 3041, 5507, 5514, 5520, 0, 5552, 5558, 5567, 0, 0, 0, 0, 5574, 5595, 5611, 5727, 5741, 0, 5781, 5787, 5810, 5817, 0, 5822, 99, 117, 116, 101, 32827, 225, 16609, 114, 101, 118, 101, 59, 16643, 768, 59, 69, 100, 105, 117, 121, 5532, 5533, 5537, 5539, 5544, 5549, 25150, 59, 49152, 8766, 819, 59, 25151, 114, 99, 32827, 226, 16610, 116, 101, 32955, 180, 774, 59, 17456, 108, 105, 103, 32827, 230, 16614, 256, 59, 114, 178, 5562, 59, 49152, 55349, 56606, 114, 97, 118, 101, 32827, 224, 16608, 256, 101, 112, 5578, 5590, 256, 102, 112, 5583, 5588, 115, 121, 109, 59, 24885, 232, 5587, 104, 97, 59, 17329, 256, 97, 112, 5599, 99, 256, 99, 108, 5604, 5607, 114, 59, 16641, 103, 59, 27199, 612, 5616, 0, 0, 5642, 640, 59, 97, 100, 115, 118, 5626, 5627, 5631, 5633, 5639, 25127, 110, 100, 59, 27221, 59, 27228, 108, 111, 112, 101, 59, 27224, 59, 27226, 896, 59, 101, 108, 109, 114, 115, 122, 5656, 5657, 5659, 5662, 5695, 5711, 5721, 25120, 59, 27044, 101, 187, 5657, 115, 100, 256, 59, 97, 5669, 5670, 25121, 1121, 5680, 5682, 5684, 5686, 5688, 5690, 5692, 5694, 59, 27048, 59, 27049, 59, 27050, 59, 27051, 59, 27052, 59, 27053, 59, 27054, 59, 27055, 116, 256, 59, 118, 5701, 5702, 25119, 98, 256, 59, 100, 5708, 5709, 25278, 59, 27037, 256, 112, 116, 5716, 5719, 104, 59, 25122, 187, 185, 97, 114, 114, 59, 25468, 256, 103, 112, 5731, 5735, 111, 110, 59, 16645, 102, 59, 49152, 55349, 56658, 896, 59, 69, 97, 101, 105, 111, 112, 4801, 5755, 5757, 5762, 5764, 5767, 5770, 59, 27248, 99, 105, 114, 59, 27247, 59, 25162, 100, 59, 25163, 115, 59, 16423, 114, 111, 120, 256, 59, 101, 4801, 5778, 241, 5763, 105, 110, 103, 32827, 229, 16613, 384, 99, 116, 121, 5793, 5798, 5800, 114, 59, 49152, 55349, 56502, 59, 16426, 109, 112, 256, 59, 101, 4801, 5807, 241, 648, 105, 108, 100, 101, 32827, 227, 16611, 109, 108, 32827, 228, 16612, 256, 99, 105, 5826, 5832, 111, 110, 105, 110, 244, 626, 110, 116, 59, 27153, 2048, 78, 97, 98, 99, 100, 101, 102, 105, 107, 108, 110, 111, 112, 114, 115, 117, 5869, 5873, 5936, 5948, 5955, 5960, 6008, 6013, 6112, 6118, 6201, 6224, 5901, 6461, 6472, 6512, 111, 116, 59, 27373, 256, 99, 114, 5878, 5918, 107, 512, 99, 101, 112, 115, 5888, 5893, 5901, 5907, 111, 110, 103, 59, 25164, 112, 115, 105, 108, 111, 110, 59, 17398, 114, 105, 109, 101, 59, 24629, 105, 109, 256, 59, 101, 5914, 5915, 25149, 113, 59, 25293, 374, 5922, 5926, 101, 101, 59, 25277, 101, 100, 256, 59, 103, 5932, 5933, 25349, 101, 187, 5933, 114, 107, 256, 59, 116, 4956, 5943, 98, 114, 107, 59, 25526, 256, 111, 121, 5889, 5953, 59, 17457, 113, 117, 111, 59, 24606, 640, 99, 109, 112, 114, 116, 5971, 5979, 5985, 5988, 5992, 97, 117, 115, 256, 59, 101, 266, 265, 112, 116, 121, 118, 59, 27056, 115, 233, 5900, 110, 111, 245, 275, 384, 97, 104, 119, 5999, 6001, 6003, 59, 17330, 59, 24886, 101, 101, 110, 59, 25196, 114, 59, 49152, 55349, 56607, 103, 896, 99, 111, 115, 116, 117, 118, 119, 6029, 6045, 6067, 6081, 6101, 6107, 6110, 384, 97, 105, 117, 6036, 6038, 6042, 240, 1888, 114, 99, 59, 26095, 112, 187, 4977, 384, 100, 112, 116, 6052, 6056, 6061, 111, 116, 59, 27136, 108, 117, 115, 59, 27137, 105, 109, 101, 115, 59, 27138, 625, 6073, 0, 0, 6078, 99, 117, 112, 59, 27142, 97, 114, 59, 26117, 114, 105, 97, 110, 103, 108, 101, 256, 100, 117, 6093, 6098, 111, 119, 110, 59, 26045, 112, 59, 26035, 112, 108, 117, 115, 59, 27140, 101, 229, 5188, 229, 5293, 97, 114, 111, 119, 59, 26893, 384, 97, 107, 111, 6125, 6182, 6197, 256, 99, 110, 6130, 6179, 107, 384, 108, 115, 116, 6138, 1451, 6146, 111, 122, 101, 110, 103, 101, 59, 27115, 114, 105, 97, 110, 103, 108, 101, 512, 59, 100, 108, 114, 6162, 6163, 6168, 6173, 26036, 111, 119, 110, 59, 26046, 101, 102, 116, 59, 26050, 105, 103, 104, 116, 59, 26040, 107, 59, 25635, 433, 6187, 0, 6195, 434, 6191, 0, 6193, 59, 26002, 59, 26001, 52, 59, 26003, 99, 107, 59, 25992, 256, 101, 111, 6206, 6221, 256, 59, 113, 6211, 6214, 49152, 61, 8421, 117, 105, 118, 59, 49152, 8801, 8421, 116, 59, 25360, 512, 112, 116, 119, 120, 6233, 6238, 6247, 6252, 102, 59, 49152, 55349, 56659, 256, 59, 116, 5067, 6243, 111, 109, 187, 5068, 116, 105, 101, 59, 25288, 1536, 68, 72, 85, 86, 98, 100, 104, 109, 112, 116, 117, 118, 6277, 6294, 6314, 6331, 6359, 6363, 6380, 6399, 6405, 6410, 6416, 6433, 512, 76, 82, 108, 114, 6286, 6288, 6290, 6292, 59, 25943, 59, 25940, 59, 25942, 59, 25939, 640, 59, 68, 85, 100, 117, 6305, 6306, 6308, 6310, 6312, 25936, 59, 25958, 59, 25961, 59, 25956, 59, 25959, 512, 76, 82, 108, 114, 6323, 6325, 6327, 6329, 59, 25949, 59, 25946, 59, 25948, 59, 25945, 896, 59, 72, 76, 82, 104, 108, 114, 6346, 6347, 6349, 6351, 6353, 6355, 6357, 25937, 59, 25964, 59, 25955, 59, 25952, 59, 25963, 59, 25954, 59, 25951, 111, 120, 59, 27081, 512, 76, 82, 108, 114, 6372, 6374, 6376, 6378, 59, 25941, 59, 25938, 59, 25872, 59, 25868, 640, 59, 68, 85, 100, 117, 1725, 6391, 6393, 6395, 6397, 59, 25957, 59, 25960, 59, 25900, 59, 25908, 105, 110, 117, 115, 59, 25247, 108, 117, 115, 59, 25246, 105, 109, 101, 115, 59, 25248, 512, 76, 82, 108, 114, 6425, 6427, 6429, 6431, 59, 25947, 59, 25944, 59, 25880, 59, 25876, 896, 59, 72, 76, 82, 104, 108, 114, 6448, 6449, 6451, 6453, 6455, 6457, 6459, 25858, 59, 25962, 59, 25953, 59, 25950, 59, 25916, 59, 25892, 59, 25884, 256, 101, 118, 291, 6466, 98, 97, 114, 32827, 166, 16550, 512, 99, 101, 105, 111, 6481, 6486, 6490, 6496, 114, 59, 49152, 55349, 56503, 109, 105, 59, 24655, 109, 256, 59, 101, 5914, 5916, 108, 384, 59, 98, 104, 6504, 6505, 6507, 16476, 59, 27077, 115, 117, 98, 59, 26568, 364, 6516, 6526, 108, 256, 59, 101, 6521, 6522, 24610, 116, 187, 6522, 112, 384, 59, 69, 101, 303, 6533, 6535, 59, 27310, 256, 59, 113, 1756, 1755, 3297, 6567, 0, 6632, 6673, 6677, 6706, 0, 6711, 6736, 0, 0, 6836, 0, 0, 6849, 0, 0, 6945, 6958, 6989, 6994, 0, 7165, 0, 7180, 384, 99, 112, 114, 6573, 6578, 6621, 117, 116, 101, 59, 16647, 768, 59, 97, 98, 99, 100, 115, 6591, 6592, 6596, 6602, 6613, 6617, 25129, 110, 100, 59, 27204, 114, 99, 117, 112, 59, 27209, 256, 97, 117, 6607, 6610, 112, 59, 27211, 112, 59, 27207, 111, 116, 59, 27200, 59, 49152, 8745, 65024, 256, 101, 111, 6626, 6629, 116, 59, 24641, 238, 1683, 512, 97, 101, 105, 117, 6640, 6651, 6657, 6661, 496, 6645, 0, 6648, 115, 59, 27213, 111, 110, 59, 16653, 100, 105, 108, 32827, 231, 16615, 114, 99, 59, 16649, 112, 115, 256, 59, 115, 6668, 6669, 27212, 109, 59, 27216, 111, 116, 59, 16651, 384, 100, 109, 110, 6683, 6688, 6694, 105, 108, 32955, 184, 429, 112, 116, 121, 118, 59, 27058, 116, 33024, 162, 59, 101, 6701, 6702, 16546, 114, 228, 434, 114, 59, 49152, 55349, 56608, 384, 99, 101, 105, 6717, 6720, 6733, 121, 59, 17479, 99, 107, 256, 59, 109, 6727, 6728, 26387, 97, 114, 107, 187, 6728, 59, 17351, 114, 896, 59, 69, 99, 101, 102, 109, 115, 6751, 6752, 6754, 6763, 6820, 6826, 6830, 26059, 59, 27075, 384, 59, 101, 108, 6761, 6762, 6765, 17094, 113, 59, 25175, 101, 609, 6772, 0, 0, 6792, 114, 114, 111, 119, 256, 108, 114, 6780, 6785, 101, 102, 116, 59, 25018, 105, 103, 104, 116, 59, 25019, 640, 82, 83, 97, 99, 100, 6802, 6804, 6806, 6810, 6815, 187, 3911, 59, 25800, 115, 116, 59, 25243, 105, 114, 99, 59, 25242, 97, 115, 104, 59, 25245, 110, 105, 110, 116, 59, 27152, 105, 100, 59, 27375, 99, 105, 114, 59, 27074, 117, 98, 115, 256, 59, 117, 6843, 6844, 26211, 105, 116, 187, 6844, 748, 6855, 6868, 6906, 0, 6922, 111, 110, 256, 59, 101, 6861, 6862, 16442, 256, 59, 113, 199, 198, 621, 6873, 0, 0, 6882, 97, 256, 59, 116, 6878, 6879, 16428, 59, 16448, 384, 59, 102, 108, 6888, 6889, 6891, 25089, 238, 4448, 101, 256, 109, 120, 6897, 6902, 101, 110, 116, 187, 6889, 101, 243, 589, 487, 6910, 0, 6919, 256, 59, 100, 4795, 6914, 111, 116, 59, 27245, 110, 244, 582, 384, 102, 114, 121, 6928, 6932, 6935, 59, 49152, 55349, 56660, 111, 228, 596, 33024, 169, 59, 115, 341, 6941, 114, 59, 24855, 256, 97, 111, 6949, 6953, 114, 114, 59, 25013, 115, 115, 59, 26391, 256, 99, 117, 6962, 6967, 114, 59, 49152, 55349, 56504, 256, 98, 112, 6972, 6980, 256, 59, 101, 6977, 6978, 27343, 59, 27345, 256, 59, 101, 6985, 6986, 27344, 59, 27346, 100, 111, 116, 59, 25327, 896, 100, 101, 108, 112, 114, 118, 119, 7008, 7020, 7031, 7042, 7084, 7124, 7161, 97, 114, 114, 256, 108, 114, 7016, 7018, 59, 26936, 59, 26933, 624, 7026, 0, 0, 7029, 114, 59, 25310, 99, 59, 25311, 97, 114, 114, 256, 59, 112, 7039, 7040, 25014, 59, 26941, 768, 59, 98, 99, 100, 111, 115, 7055, 7056, 7062, 7073, 7077, 7080, 25130, 114, 99, 97, 112, 59, 27208, 256, 97, 117, 7067, 7070, 112, 59, 27206, 112, 59, 27210, 111, 116, 59, 25229, 114, 59, 27205, 59, 49152, 8746, 65024, 512, 97, 108, 114, 118, 7093, 7103, 7134, 7139, 114, 114, 256, 59, 109, 7100, 7101, 25015, 59, 26940, 121, 384, 101, 118, 119, 7111, 7124, 7128, 113, 624, 7118, 0, 0, 7122, 114, 101, 227, 7027, 117, 227, 7029, 101, 101, 59, 25294, 101, 100, 103, 101, 59, 25295, 101, 110, 32827, 164, 16548, 101, 97, 114, 114, 111, 119, 256, 108, 114, 7150, 7155, 101, 102, 116, 187, 7040, 105, 103, 104, 116, 187, 7101, 101, 228, 7133, 256, 99, 105, 7169, 7175, 111, 110, 105, 110, 244, 503, 110, 116, 59, 25137, 108, 99, 116, 121, 59, 25389, 2432, 65, 72, 97, 98, 99, 100, 101, 102, 104, 105, 106, 108, 111, 114, 115, 116, 117, 119, 122, 7224, 7227, 7231, 7261, 7273, 7285, 7306, 7326, 7340, 7351, 7419, 7423, 7437, 7547, 7569, 7595, 7611, 7622, 7629, 114, 242, 897, 97, 114, 59, 26981, 512, 103, 108, 114, 115, 7240, 7245, 7250, 7252, 103, 101, 114, 59, 24608, 101, 116, 104, 59, 24888, 242, 4403, 104, 256, 59, 118, 7258, 7259, 24592, 187, 2314, 363, 7265, 7271, 97, 114, 111, 119, 59, 26895, 97, 227, 789, 256, 97, 121, 7278, 7283, 114, 111, 110, 59, 16655, 59, 17460, 384, 59, 97, 111, 818, 7292, 7300, 256, 103, 114, 703, 7297, 114, 59, 25034, 116, 115, 101, 113, 59, 27255, 384, 103, 108, 109, 7313, 7316, 7320, 32827, 176, 16560, 116, 97, 59, 17332, 112, 116, 121, 118, 59, 27057, 256, 105, 114, 7331, 7336, 115, 104, 116, 59, 27007, 59, 49152, 55349, 56609, 97, 114, 256, 108, 114, 7347, 7349, 187, 2268, 187, 4126, 640, 97, 101, 103, 115, 118, 7362, 888, 7382, 7388, 7392, 109, 384, 59, 111, 115, 806, 7370, 7380, 110, 100, 256, 59, 115, 806, 7377, 117, 105, 116, 59, 26214, 97, 109, 109, 97, 59, 17373, 105, 110, 59, 25330, 384, 59, 105, 111, 7399, 7400, 7416, 16631, 100, 101, 33024, 247, 59, 111, 7399, 7408, 110, 116, 105, 109, 101, 115, 59, 25287, 110, 248, 7415, 99, 121, 59, 17490, 99, 623, 7430, 0, 0, 7434, 114, 110, 59, 25374, 111, 112, 59, 25357, 640, 108, 112, 116, 117, 119, 7448, 7453, 7458, 7497, 7509, 108, 97, 114, 59, 16420, 102, 59, 49152, 55349, 56661, 640, 59, 101, 109, 112, 115, 779, 7469, 7479, 7485, 7490, 113, 256, 59, 100, 850, 7475, 111, 116, 59, 25169, 105, 110, 117, 115, 59, 25144, 108, 117, 115, 59, 25108, 113, 117, 97, 114, 101, 59, 25249, 98, 108, 101, 98, 97, 114, 119, 101, 100, 103, 229, 250, 110, 384, 97, 100, 104, 4398, 7517, 7527, 111, 119, 110, 97, 114, 114, 111, 119, 243, 7299, 97, 114, 112, 111, 111, 110, 256, 108, 114, 7538, 7542, 101, 102, 244, 7348, 105, 103, 104, 244, 7350, 354, 7551, 7557, 107, 97, 114, 111, 247, 3906, 623, 7562, 0, 0, 7566, 114, 110, 59, 25375, 111, 112, 59, 25356, 384, 99, 111, 116, 7576, 7587, 7590, 256, 114, 121, 7581, 7585, 59, 49152, 55349, 56505, 59, 17493, 108, 59, 27126, 114, 111, 107, 59, 16657, 256, 100, 114, 7600, 7604, 111, 116, 59, 25329, 105, 256, 59, 102, 7610, 6166, 26047, 256, 97, 104, 7616, 7619, 114, 242, 1065, 97, 242, 4006, 97, 110, 103, 108, 101, 59, 27046, 256, 99, 105, 7634, 7637, 121, 59, 17503, 103, 114, 97, 114, 114, 59, 26623, 2304, 68, 97, 99, 100, 101, 102, 103, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 120, 7681, 7689, 7705, 7736, 1400, 7740, 7753, 7777, 7806, 7845, 7855, 7869, 7905, 7978, 7991, 8004, 8014, 8026, 256, 68, 111, 7686, 7476, 111, 244, 7305, 256, 99, 115, 7694, 7700, 117, 116, 101, 32827, 233, 16617, 116, 101, 114, 59, 27246, 512, 97, 105, 111, 121, 7714, 7719, 7729, 7734, 114, 111, 110, 59, 16667, 114, 256, 59, 99, 7725, 7726, 25174, 32827, 234, 16618, 108, 111, 110, 59, 25173, 59, 17485, 111, 116, 59, 16663, 256, 68, 114, 7745, 7749, 111, 116, 59, 25170, 59, 49152, 55349, 56610, 384, 59, 114, 115, 7760, 7761, 7767, 27290, 97, 118, 101, 32827, 232, 16616, 256, 59, 100, 7772, 7773, 27286, 111, 116, 59, 27288, 512, 59, 105, 108, 115, 7786, 7787, 7794, 7796, 27289, 110, 116, 101, 114, 115, 59, 25575, 59, 24851, 256, 59, 100, 7801, 7802, 27285, 111, 116, 59, 27287, 384, 97, 112, 115, 7813, 7817, 7831, 99, 114, 59, 16659, 116, 121, 384, 59, 115, 118, 7826, 7827, 7829, 25093, 101, 116, 187, 7827, 112, 256, 49, 59, 7837, 7844, 307, 7841, 7843, 59, 24580, 59, 24581, 24579, 256, 103, 115, 7850, 7852, 59, 16715, 112, 59, 24578, 256, 103, 112, 7860, 7864, 111, 110, 59, 16665, 102, 59, 49152, 55349, 56662, 384, 97, 108, 115, 7876, 7886, 7890, 114, 256, 59, 115, 7882, 7883, 25301, 108, 59, 27107, 117, 115, 59, 27249, 105, 384, 59, 108, 118, 7898, 7899, 7903, 17333, 111, 110, 187, 7899, 59, 17397, 512, 99, 115, 117, 118, 7914, 7923, 7947, 7971, 256, 105, 111, 7919, 7729, 114, 99, 187, 7726, 617, 7929, 0, 0, 7931, 237, 1352, 97, 110, 116, 256, 103, 108, 7938, 7942, 116, 114, 187, 7773, 101, 115, 115, 187, 7802, 384, 97, 101, 105, 7954, 7958, 7962, 108, 115, 59, 16445, 115, 116, 59, 25183, 118, 256, 59, 68, 565, 7968, 68, 59, 27256, 112, 97, 114, 115, 108, 59, 27109, 256, 68, 97, 7983, 7987, 111, 116, 59, 25171, 114, 114, 59, 26993, 384, 99, 100, 105, 7998, 8001, 7928, 114, 59, 24879, 111, 244, 850, 256, 97, 104, 8009, 8011, 59, 17335, 32827, 240, 16624, 256, 109, 114, 8019, 8023, 108, 32827, 235, 16619, 111, 59, 24748, 384, 99, 105, 112, 8033, 8036, 8039, 108, 59, 16417, 115, 244, 1390, 256, 101, 111, 8044, 8052, 99, 116, 97, 116, 105, 111, 238, 1369, 110, 101, 110, 116, 105, 97, 108, 229, 1401, 2529, 8082, 0, 8094, 0, 8097, 8103, 0, 0, 8134, 8140, 0, 8147, 0, 8166, 8170, 8192, 0, 8200, 8282, 108, 108, 105, 110, 103, 100, 111, 116, 115, 101, 241, 7748, 121, 59, 17476, 109, 97, 108, 101, 59, 26176, 384, 105, 108, 114, 8109, 8115, 8129, 108, 105, 103, 59, 32768, 64259, 617, 8121, 0, 0, 8125, 103, 59, 32768, 64256, 105, 103, 59, 32768, 64260, 59, 49152, 55349, 56611, 108, 105, 103, 59, 32768, 64257, 108, 105, 103, 59, 49152, 102, 106, 384, 97, 108, 116, 8153, 8156, 8161, 116, 59, 26221, 105, 103, 59, 32768, 64258, 110, 115, 59, 26033, 111, 102, 59, 16786, 496, 8174, 0, 8179, 102, 59, 49152, 55349, 56663, 256, 97, 107, 1471, 8183, 256, 59, 118, 8188, 8189, 25300, 59, 27353, 97, 114, 116, 105, 110, 116, 59, 27149, 256, 97, 111, 8204, 8277, 256, 99, 115, 8209, 8274, 945, 8218, 8240, 8248, 8261, 8264, 0, 8272, 946, 8226, 8229, 8231, 8234, 8236, 0, 8238, 32827, 189, 16573, 59, 24915, 32827, 188, 16572, 59, 24917, 59, 24921, 59, 24923, 435, 8244, 0, 8246, 59, 24916, 59, 24918, 692, 8254, 8257, 0, 0, 8259, 32827, 190, 16574, 59, 24919, 59, 24924, 53, 59, 24920, 438, 8268, 0, 8270, 59, 24922, 59, 24925, 56, 59, 24926, 108, 59, 24644, 119, 110, 59, 25378, 99, 114, 59, 49152, 55349, 56507, 2176, 69, 97, 98, 99, 100, 101, 102, 103, 105, 106, 108, 110, 111, 114, 115, 116, 118, 8322, 8329, 8351, 8357, 8368, 8372, 8432, 8437, 8442, 8447, 8451, 8466, 8504, 791, 8510, 8530, 8606, 256, 59, 108, 1613, 8327, 59, 27276, 384, 99, 109, 112, 8336, 8341, 8349, 117, 116, 101, 59, 16885, 109, 97, 256, 59, 100, 8348, 7386, 17331, 59, 27270, 114, 101, 118, 101, 59, 16671, 256, 105, 121, 8362, 8366, 114, 99, 59, 16669, 59, 17459, 111, 116, 59, 16673, 512, 59, 108, 113, 115, 1598, 1602, 8381, 8393, 384, 59, 113, 115, 1598, 1612, 8388, 108, 97, 110, 244, 1637, 512, 59, 99, 100, 108, 1637, 8402, 8405, 8421, 99, 59, 27305, 111, 116, 256, 59, 111, 8412, 8413, 27264, 256, 59, 108, 8418, 8419, 27266, 59, 27268, 256, 59, 101, 8426, 8429, 49152, 8923, 65024, 115, 59, 27284, 114, 59, 49152, 55349, 56612, 256, 59, 103, 1651, 1563, 109, 101, 108, 59, 24887, 99, 121, 59, 17491, 512, 59, 69, 97, 106, 1626, 8460, 8462, 8464, 59, 27282, 59, 27301, 59, 27300, 512, 69, 97, 101, 115, 8475, 8477, 8489, 8500, 59, 25193, 112, 256, 59, 112, 8483, 8484, 27274, 114, 111, 120, 187, 8484, 256, 59, 113, 8494, 8495, 27272, 256, 59, 113, 8494, 8475, 105, 109, 59, 25319, 112, 102, 59, 49152, 55349, 56664, 256, 99, 105, 8515, 8518, 114, 59, 24842, 109, 384, 59, 101, 108, 1643, 8526, 8528, 59, 27278, 59, 27280, 33536, 62, 59, 99, 100, 108, 113, 114, 1518, 8544, 8554, 8558, 8563, 8569, 256, 99, 105, 8549, 8551, 59, 27303, 114, 59, 27258, 111, 116, 59, 25303, 80, 97, 114, 59, 27029, 117, 101, 115, 116, 59, 27260, 640, 97, 100, 101, 108, 115, 8580, 8554, 8592, 1622, 8603, 496, 8585, 0, 8590, 112, 114, 111, 248, 8350, 114, 59, 27e3, 113, 256, 108, 113, 1599, 8598, 108, 101, 115, 243, 8328, 105, 237, 1643, 256, 101, 110, 8611, 8621, 114, 116, 110, 101, 113, 113, 59, 49152, 8809, 65024, 197, 8618, 1280, 65, 97, 98, 99, 101, 102, 107, 111, 115, 121, 8644, 8647, 8689, 8693, 8698, 8728, 8733, 8751, 8808, 8829, 114, 242, 928, 512, 105, 108, 109, 114, 8656, 8660, 8663, 8667, 114, 115, 240, 5252, 102, 187, 8228, 105, 108, 244, 1705, 256, 100, 114, 8672, 8676, 99, 121, 59, 17482, 384, 59, 99, 119, 2292, 8683, 8687, 105, 114, 59, 26952, 59, 25005, 97, 114, 59, 24847, 105, 114, 99, 59, 16677, 384, 97, 108, 114, 8705, 8718, 8723, 114, 116, 115, 256, 59, 117, 8713, 8714, 26213, 105, 116, 187, 8714, 108, 105, 112, 59, 24614, 99, 111, 110, 59, 25273, 114, 59, 49152, 55349, 56613, 115, 256, 101, 119, 8739, 8745, 97, 114, 111, 119, 59, 26917, 97, 114, 111, 119, 59, 26918, 640, 97, 109, 111, 112, 114, 8762, 8766, 8771, 8798, 8803, 114, 114, 59, 25087, 116, 104, 116, 59, 25147, 107, 256, 108, 114, 8777, 8787, 101, 102, 116, 97, 114, 114, 111, 119, 59, 25001, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25002, 102, 59, 49152, 55349, 56665, 98, 97, 114, 59, 24597, 384, 99, 108, 116, 8815, 8820, 8824, 114, 59, 49152, 55349, 56509, 97, 115, 232, 8692, 114, 111, 107, 59, 16679, 256, 98, 112, 8834, 8839, 117, 108, 108, 59, 24643, 104, 101, 110, 187, 7259, 2785, 8867, 0, 8874, 0, 8888, 8901, 8910, 0, 8917, 8947, 0, 0, 8952, 8994, 9063, 9058, 9087, 0, 9094, 9130, 9140, 99, 117, 116, 101, 32827, 237, 16621, 384, 59, 105, 121, 1905, 8880, 8885, 114, 99, 32827, 238, 16622, 59, 17464, 256, 99, 120, 8892, 8895, 121, 59, 17461, 99, 108, 32827, 161, 16545, 256, 102, 114, 927, 8905, 59, 49152, 55349, 56614, 114, 97, 118, 101, 32827, 236, 16620, 512, 59, 105, 110, 111, 1854, 8925, 8937, 8942, 256, 105, 110, 8930, 8934, 110, 116, 59, 27148, 116, 59, 25133, 102, 105, 110, 59, 27100, 116, 97, 59, 24873, 108, 105, 103, 59, 16691, 384, 97, 111, 112, 8958, 8986, 8989, 384, 99, 103, 116, 8965, 8968, 8983, 114, 59, 16683, 384, 101, 108, 112, 1823, 8975, 8979, 105, 110, 229, 1934, 97, 114, 244, 1824, 104, 59, 16689, 102, 59, 25271, 101, 100, 59, 16821, 640, 59, 99, 102, 111, 116, 1268, 9004, 9009, 9021, 9025, 97, 114, 101, 59, 24837, 105, 110, 256, 59, 116, 9016, 9017, 25118, 105, 101, 59, 27101, 100, 111, 244, 8985, 640, 59, 99, 101, 108, 112, 1879, 9036, 9040, 9051, 9057, 97, 108, 59, 25274, 256, 103, 114, 9045, 9049, 101, 114, 243, 5475, 227, 9037, 97, 114, 104, 107, 59, 27159, 114, 111, 100, 59, 27196, 512, 99, 103, 112, 116, 9071, 9074, 9078, 9083, 121, 59, 17489, 111, 110, 59, 16687, 102, 59, 49152, 55349, 56666, 97, 59, 17337, 117, 101, 115, 116, 32827, 191, 16575, 256, 99, 105, 9098, 9103, 114, 59, 49152, 55349, 56510, 110, 640, 59, 69, 100, 115, 118, 1268, 9115, 9117, 9121, 1267, 59, 25337, 111, 116, 59, 25333, 256, 59, 118, 9126, 9127, 25332, 59, 25331, 256, 59, 105, 1911, 9134, 108, 100, 101, 59, 16681, 491, 9144, 0, 9148, 99, 121, 59, 17494, 108, 32827, 239, 16623, 768, 99, 102, 109, 111, 115, 117, 9164, 9175, 9180, 9185, 9191, 9205, 256, 105, 121, 9169, 9173, 114, 99, 59, 16693, 59, 17465, 114, 59, 49152, 55349, 56615, 97, 116, 104, 59, 16951, 112, 102, 59, 49152, 55349, 56667, 483, 9196, 0, 9201, 114, 59, 49152, 55349, 56511, 114, 99, 121, 59, 17496, 107, 99, 121, 59, 17492, 1024, 97, 99, 102, 103, 104, 106, 111, 115, 9227, 9238, 9250, 9255, 9261, 9265, 9269, 9275, 112, 112, 97, 256, 59, 118, 9235, 9236, 17338, 59, 17392, 256, 101, 121, 9243, 9248, 100, 105, 108, 59, 16695, 59, 17466, 114, 59, 49152, 55349, 56616, 114, 101, 101, 110, 59, 16696, 99, 121, 59, 17477, 99, 121, 59, 17500, 112, 102, 59, 49152, 55349, 56668, 99, 114, 59, 49152, 55349, 56512, 2944, 65, 66, 69, 72, 97, 98, 99, 100, 101, 102, 103, 104, 106, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118, 9328, 9345, 9350, 9357, 9361, 9486, 9533, 9562, 9600, 9806, 9822, 9829, 9849, 9853, 9882, 9906, 9944, 10077, 10088, 10123, 10176, 10241, 10258, 384, 97, 114, 116, 9335, 9338, 9340, 114, 242, 2502, 242, 917, 97, 105, 108, 59, 26907, 97, 114, 114, 59, 26894, 256, 59, 103, 2452, 9355, 59, 27275, 97, 114, 59, 26978, 2403, 9381, 0, 9386, 0, 9393, 0, 0, 0, 0, 0, 9397, 9402, 0, 9414, 9416, 9421, 0, 9465, 117, 116, 101, 59, 16698, 109, 112, 116, 121, 118, 59, 27060, 114, 97, 238, 2124, 98, 100, 97, 59, 17339, 103, 384, 59, 100, 108, 2190, 9409, 9411, 59, 27025, 229, 2190, 59, 27269, 117, 111, 32827, 171, 16555, 114, 1024, 59, 98, 102, 104, 108, 112, 115, 116, 2201, 9438, 9446, 9449, 9451, 9454, 9457, 9461, 256, 59, 102, 2205, 9443, 115, 59, 26911, 115, 59, 26909, 235, 8786, 112, 59, 25003, 108, 59, 26937, 105, 109, 59, 26995, 108, 59, 24994, 384, 59, 97, 101, 9471, 9472, 9476, 27307, 105, 108, 59, 26905, 256, 59, 115, 9481, 9482, 27309, 59, 49152, 10925, 65024, 384, 97, 98, 114, 9493, 9497, 9501, 114, 114, 59, 26892, 114, 107, 59, 26482, 256, 97, 107, 9506, 9516, 99, 256, 101, 107, 9512, 9514, 59, 16507, 59, 16475, 256, 101, 115, 9521, 9523, 59, 27019, 108, 256, 100, 117, 9529, 9531, 59, 27023, 59, 27021, 512, 97, 101, 117, 121, 9542, 9547, 9558, 9560, 114, 111, 110, 59, 16702, 256, 100, 105, 9552, 9556, 105, 108, 59, 16700, 236, 2224, 226, 9513, 59, 17467, 512, 99, 113, 114, 115, 9571, 9574, 9581, 9597, 97, 59, 26934, 117, 111, 256, 59, 114, 3609, 5958, 256, 100, 117, 9586, 9591, 104, 97, 114, 59, 26983, 115, 104, 97, 114, 59, 26955, 104, 59, 25010, 640, 59, 102, 103, 113, 115, 9611, 9612, 2441, 9715, 9727, 25188, 116, 640, 97, 104, 108, 114, 116, 9624, 9636, 9655, 9666, 9704, 114, 114, 111, 119, 256, 59, 116, 2201, 9633, 97, 233, 9462, 97, 114, 112, 111, 111, 110, 256, 100, 117, 9647, 9652, 111, 119, 110, 187, 1114, 112, 187, 2406, 101, 102, 116, 97, 114, 114, 111, 119, 115, 59, 25031, 105, 103, 104, 116, 384, 97, 104, 115, 9677, 9686, 9694, 114, 114, 111, 119, 256, 59, 115, 2292, 2215, 97, 114, 112, 111, 111, 110, 243, 3992, 113, 117, 105, 103, 97, 114, 114, 111, 247, 8688, 104, 114, 101, 101, 116, 105, 109, 101, 115, 59, 25291, 384, 59, 113, 115, 9611, 2451, 9722, 108, 97, 110, 244, 2476, 640, 59, 99, 100, 103, 115, 2476, 9738, 9741, 9757, 9768, 99, 59, 27304, 111, 116, 256, 59, 111, 9748, 9749, 27263, 256, 59, 114, 9754, 9755, 27265, 59, 27267, 256, 59, 101, 9762, 9765, 49152, 8922, 65024, 115, 59, 27283, 640, 97, 100, 101, 103, 115, 9779, 9785, 9789, 9801, 9803, 112, 112, 114, 111, 248, 9414, 111, 116, 59, 25302, 113, 256, 103, 113, 9795, 9797, 244, 2441, 103, 116, 242, 9356, 244, 2459, 105, 237, 2482, 384, 105, 108, 114, 9813, 2273, 9818, 115, 104, 116, 59, 27004, 59, 49152, 55349, 56617, 256, 59, 69, 2460, 9827, 59, 27281, 353, 9833, 9846, 114, 256, 100, 117, 9650, 9838, 256, 59, 108, 2405, 9843, 59, 26986, 108, 107, 59, 25988, 99, 121, 59, 17497, 640, 59, 97, 99, 104, 116, 2632, 9864, 9867, 9873, 9878, 114, 242, 9665, 111, 114, 110, 101, 242, 7432, 97, 114, 100, 59, 26987, 114, 105, 59, 26106, 256, 105, 111, 9887, 9892, 100, 111, 116, 59, 16704, 117, 115, 116, 256, 59, 97, 9900, 9901, 25520, 99, 104, 101, 187, 9901, 512, 69, 97, 101, 115, 9915, 9917, 9929, 9940, 59, 25192, 112, 256, 59, 112, 9923, 9924, 27273, 114, 111, 120, 187, 9924, 256, 59, 113, 9934, 9935, 27271, 256, 59, 113, 9934, 9915, 105, 109, 59, 25318, 1024, 97, 98, 110, 111, 112, 116, 119, 122, 9961, 9972, 9975, 10010, 10031, 10049, 10055, 10064, 256, 110, 114, 9966, 9969, 103, 59, 26604, 114, 59, 25085, 114, 235, 2241, 103, 384, 108, 109, 114, 9983, 9997, 10004, 101, 102, 116, 256, 97, 114, 2534, 9991, 105, 103, 104, 116, 225, 2546, 97, 112, 115, 116, 111, 59, 26620, 105, 103, 104, 116, 225, 2557, 112, 97, 114, 114, 111, 119, 256, 108, 114, 10021, 10025, 101, 102, 244, 9453, 105, 103, 104, 116, 59, 25004, 384, 97, 102, 108, 10038, 10041, 10045, 114, 59, 27013, 59, 49152, 55349, 56669, 117, 115, 59, 27181, 105, 109, 101, 115, 59, 27188, 353, 10059, 10063, 115, 116, 59, 25111, 225, 4942, 384, 59, 101, 102, 10071, 10072, 6144, 26058, 110, 103, 101, 187, 10072, 97, 114, 256, 59, 108, 10084, 10085, 16424, 116, 59, 27027, 640, 97, 99, 104, 109, 116, 10099, 10102, 10108, 10117, 10119, 114, 242, 2216, 111, 114, 110, 101, 242, 7564, 97, 114, 256, 59, 100, 3992, 10115, 59, 26989, 59, 24590, 114, 105, 59, 25279, 768, 97, 99, 104, 105, 113, 116, 10136, 10141, 2624, 10146, 10158, 10171, 113, 117, 111, 59, 24633, 114, 59, 49152, 55349, 56513, 109, 384, 59, 101, 103, 2482, 10154, 10156, 59, 27277, 59, 27279, 256, 98, 117, 9514, 10163, 111, 256, 59, 114, 3615, 10169, 59, 24602, 114, 111, 107, 59, 16706, 33792, 60, 59, 99, 100, 104, 105, 108, 113, 114, 2091, 10194, 9785, 10204, 10208, 10213, 10218, 10224, 256, 99, 105, 10199, 10201, 59, 27302, 114, 59, 27257, 114, 101, 229, 9714, 109, 101, 115, 59, 25289, 97, 114, 114, 59, 26998, 117, 101, 115, 116, 59, 27259, 256, 80, 105, 10229, 10233, 97, 114, 59, 27030, 384, 59, 101, 102, 10240, 2349, 6171, 26051, 114, 256, 100, 117, 10247, 10253, 115, 104, 97, 114, 59, 26954, 104, 97, 114, 59, 26982, 256, 101, 110, 10263, 10273, 114, 116, 110, 101, 113, 113, 59, 49152, 8808, 65024, 197, 10270, 1792, 68, 97, 99, 100, 101, 102, 104, 105, 108, 110, 111, 112, 115, 117, 10304, 10309, 10370, 10382, 10387, 10400, 10405, 10408, 10458, 10466, 10468, 2691, 10483, 10498, 68, 111, 116, 59, 25146, 512, 99, 108, 112, 114, 10318, 10322, 10339, 10365, 114, 32827, 175, 16559, 256, 101, 116, 10327, 10329, 59, 26178, 256, 59, 101, 10334, 10335, 26400, 115, 101, 187, 10335, 256, 59, 115, 4155, 10344, 116, 111, 512, 59, 100, 108, 117, 4155, 10355, 10359, 10363, 111, 119, 238, 1164, 101, 102, 244, 2319, 240, 5073, 107, 101, 114, 59, 26030, 256, 111, 121, 10375, 10380, 109, 109, 97, 59, 27177, 59, 17468, 97, 115, 104, 59, 24596, 97, 115, 117, 114, 101, 100, 97, 110, 103, 108, 101, 187, 5670, 114, 59, 49152, 55349, 56618, 111, 59, 24871, 384, 99, 100, 110, 10415, 10420, 10441, 114, 111, 32827, 181, 16565, 512, 59, 97, 99, 100, 5220, 10429, 10432, 10436, 115, 244, 5799, 105, 114, 59, 27376, 111, 116, 32955, 183, 437, 117, 115, 384, 59, 98, 100, 10450, 6403, 10451, 25106, 256, 59, 117, 7484, 10456, 59, 27178, 355, 10462, 10465, 112, 59, 27355, 242, 8722, 240, 2689, 256, 100, 112, 10473, 10478, 101, 108, 115, 59, 25255, 102, 59, 49152, 55349, 56670, 256, 99, 116, 10488, 10493, 114, 59, 49152, 55349, 56514, 112, 111, 115, 187, 5533, 384, 59, 108, 109, 10505, 10506, 10509, 17340, 116, 105, 109, 97, 112, 59, 25272, 3072, 71, 76, 82, 86, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 108, 109, 111, 112, 114, 115, 116, 117, 118, 119, 10562, 10579, 10622, 10633, 10648, 10714, 10729, 10773, 10778, 10840, 10845, 10883, 10901, 10916, 10920, 11012, 11015, 11076, 11135, 11182, 11316, 11367, 11388, 11497, 256, 103, 116, 10567, 10571, 59, 49152, 8921, 824, 256, 59, 118, 10576, 3023, 49152, 8811, 8402, 384, 101, 108, 116, 10586, 10610, 10614, 102, 116, 256, 97, 114, 10593, 10599, 114, 114, 111, 119, 59, 25037, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25038, 59, 49152, 8920, 824, 256, 59, 118, 10619, 3143, 49152, 8810, 8402, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25039, 256, 68, 100, 10638, 10643, 97, 115, 104, 59, 25263, 97, 115, 104, 59, 25262, 640, 98, 99, 110, 112, 116, 10659, 10663, 10668, 10673, 10700, 108, 97, 187, 734, 117, 116, 101, 59, 16708, 103, 59, 49152, 8736, 8402, 640, 59, 69, 105, 111, 112, 3460, 10684, 10688, 10693, 10696, 59, 49152, 10864, 824, 100, 59, 49152, 8779, 824, 115, 59, 16713, 114, 111, 248, 3460, 117, 114, 256, 59, 97, 10707, 10708, 26222, 108, 256, 59, 115, 10707, 2872, 499, 10719, 0, 10723, 112, 32955, 160, 2871, 109, 112, 256, 59, 101, 3065, 3072, 640, 97, 101, 111, 117, 121, 10740, 10750, 10755, 10768, 10771, 496, 10745, 0, 10747, 59, 27203, 111, 110, 59, 16712, 100, 105, 108, 59, 16710, 110, 103, 256, 59, 100, 3454, 10762, 111, 116, 59, 49152, 10861, 824, 112, 59, 27202, 59, 17469, 97, 115, 104, 59, 24595, 896, 59, 65, 97, 100, 113, 115, 120, 2962, 10793, 10797, 10811, 10817, 10821, 10832, 114, 114, 59, 25047, 114, 256, 104, 114, 10803, 10806, 107, 59, 26916, 256, 59, 111, 5106, 5104, 111, 116, 59, 49152, 8784, 824, 117, 105, 246, 2915, 256, 101, 105, 10826, 10830, 97, 114, 59, 26920, 237, 2968, 105, 115, 116, 256, 59, 115, 2976, 2975, 114, 59, 49152, 55349, 56619, 512, 69, 101, 115, 116, 3013, 10854, 10873, 10876, 384, 59, 113, 115, 3004, 10861, 3041, 384, 59, 113, 115, 3004, 3013, 10868, 108, 97, 110, 244, 3042, 105, 237, 3050, 256, 59, 114, 2998, 10881, 187, 2999, 384, 65, 97, 112, 10890, 10893, 10897, 114, 242, 10609, 114, 114, 59, 25006, 97, 114, 59, 27378, 384, 59, 115, 118, 3981, 10908, 3980, 256, 59, 100, 10913, 10914, 25340, 59, 25338, 99, 121, 59, 17498, 896, 65, 69, 97, 100, 101, 115, 116, 10935, 10938, 10942, 10946, 10949, 10998, 11001, 114, 242, 10598, 59, 49152, 8806, 824, 114, 114, 59, 24986, 114, 59, 24613, 512, 59, 102, 113, 115, 3131, 10958, 10979, 10991, 116, 256, 97, 114, 10964, 10969, 114, 114, 111, 247, 10945, 105, 103, 104, 116, 97, 114, 114, 111, 247, 10896, 384, 59, 113, 115, 3131, 10938, 10986, 108, 97, 110, 244, 3157, 256, 59, 115, 3157, 10996, 187, 3126, 105, 237, 3165, 256, 59, 114, 3125, 11006, 105, 256, 59, 101, 3098, 3109, 105, 228, 3472, 256, 112, 116, 11020, 11025, 102, 59, 49152, 55349, 56671, 33152, 172, 59, 105, 110, 11033, 11034, 11062, 16556, 110, 512, 59, 69, 100, 118, 2953, 11044, 11048, 11054, 59, 49152, 8953, 824, 111, 116, 59, 49152, 8949, 824, 481, 2953, 11059, 11061, 59, 25335, 59, 25334, 105, 256, 59, 118, 3256, 11068, 481, 3256, 11073, 11075, 59, 25342, 59, 25341, 384, 97, 111, 114, 11083, 11107, 11113, 114, 512, 59, 97, 115, 116, 2939, 11093, 11098, 11103, 108, 108, 101, 236, 2939, 108, 59, 49152, 11005, 8421, 59, 49152, 8706, 824, 108, 105, 110, 116, 59, 27156, 384, 59, 99, 101, 3218, 11120, 11123, 117, 229, 3237, 256, 59, 99, 3224, 11128, 256, 59, 101, 3218, 11133, 241, 3224, 512, 65, 97, 105, 116, 11144, 11147, 11165, 11175, 114, 242, 10632, 114, 114, 384, 59, 99, 119, 11156, 11157, 11161, 24987, 59, 49152, 10547, 824, 59, 49152, 8605, 824, 103, 104, 116, 97, 114, 114, 111, 119, 187, 11157, 114, 105, 256, 59, 101, 3275, 3286, 896, 99, 104, 105, 109, 112, 113, 117, 11197, 11213, 11225, 11012, 2936, 11236, 11247, 512, 59, 99, 101, 114, 3378, 11206, 3383, 11209, 117, 229, 3397, 59, 49152, 55349, 56515, 111, 114, 116, 621, 11013, 0, 0, 11222, 97, 114, 225, 11094, 109, 256, 59, 101, 3438, 11231, 256, 59, 113, 3444, 3443, 115, 117, 256, 98, 112, 11243, 11245, 229, 3320, 229, 3339, 384, 98, 99, 112, 11254, 11281, 11289, 512, 59, 69, 101, 115, 11263, 11264, 3362, 11268, 25220, 59, 49152, 10949, 824, 101, 116, 256, 59, 101, 3355, 11275, 113, 256, 59, 113, 3363, 11264, 99, 256, 59, 101, 3378, 11287, 241, 3384, 512, 59, 69, 101, 115, 11298, 11299, 3423, 11303, 25221, 59, 49152, 10950, 824, 101, 116, 256, 59, 101, 3416, 11310, 113, 256, 59, 113, 3424, 11299, 512, 103, 105, 108, 114, 11325, 11327, 11333, 11335, 236, 3031, 108, 100, 101, 32827, 241, 16625, 231, 3139, 105, 97, 110, 103, 108, 101, 256, 108, 114, 11346, 11356, 101, 102, 116, 256, 59, 101, 3098, 11354, 241, 3110, 105, 103, 104, 116, 256, 59, 101, 3275, 11365, 241, 3287, 256, 59, 109, 11372, 11373, 17341, 384, 59, 101, 115, 11380, 11381, 11385, 16419, 114, 111, 59, 24854, 112, 59, 24583, 1152, 68, 72, 97, 100, 103, 105, 108, 114, 115, 11407, 11412, 11417, 11422, 11427, 11440, 11446, 11475, 11491, 97, 115, 104, 59, 25261, 97, 114, 114, 59, 26884, 112, 59, 49152, 8781, 8402, 97, 115, 104, 59, 25260, 256, 101, 116, 11432, 11436, 59, 49152, 8805, 8402, 59, 49152, 62, 8402, 110, 102, 105, 110, 59, 27102, 384, 65, 101, 116, 11453, 11457, 11461, 114, 114, 59, 26882, 59, 49152, 8804, 8402, 256, 59, 114, 11466, 11469, 49152, 60, 8402, 105, 101, 59, 49152, 8884, 8402, 256, 65, 116, 11480, 11484, 114, 114, 59, 26883, 114, 105, 101, 59, 49152, 8885, 8402, 105, 109, 59, 49152, 8764, 8402, 384, 65, 97, 110, 11504, 11508, 11522, 114, 114, 59, 25046, 114, 256, 104, 114, 11514, 11517, 107, 59, 26915, 256, 59, 111, 5095, 5093, 101, 97, 114, 59, 26919, 4691, 6805, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11565, 0, 11576, 11592, 11616, 11621, 11634, 11652, 6919, 0, 0, 11661, 11691, 0, 11720, 11726, 0, 11740, 11801, 11819, 11838, 11843, 256, 99, 115, 11569, 6807, 117, 116, 101, 32827, 243, 16627, 256, 105, 121, 11580, 11589, 114, 256, 59, 99, 6814, 11586, 32827, 244, 16628, 59, 17470, 640, 97, 98, 105, 111, 115, 6816, 11602, 11607, 456, 11610, 108, 97, 99, 59, 16721, 118, 59, 27192, 111, 108, 100, 59, 27068, 108, 105, 103, 59, 16723, 256, 99, 114, 11625, 11629, 105, 114, 59, 27071, 59, 49152, 55349, 56620, 879, 11641, 0, 0, 11644, 0, 11650, 110, 59, 17115, 97, 118, 101, 32827, 242, 16626, 59, 27073, 256, 98, 109, 11656, 3572, 97, 114, 59, 27061, 512, 97, 99, 105, 116, 11669, 11672, 11685, 11688, 114, 242, 6784, 256, 105, 114, 11677, 11680, 114, 59, 27070, 111, 115, 115, 59, 27067, 110, 229, 3666, 59, 27072, 384, 97, 101, 105, 11697, 11701, 11705, 99, 114, 59, 16717, 103, 97, 59, 17353, 384, 99, 100, 110, 11712, 11717, 461, 114, 111, 110, 59, 17343, 59, 27062, 112, 102, 59, 49152, 55349, 56672, 384, 97, 101, 108, 11732, 11735, 466, 114, 59, 27063, 114, 112, 59, 27065, 896, 59, 97, 100, 105, 111, 115, 118, 11754, 11755, 11758, 11784, 11789, 11792, 11798, 25128, 114, 242, 6790, 512, 59, 101, 102, 109, 11767, 11768, 11778, 11781, 27229, 114, 256, 59, 111, 11774, 11775, 24884, 102, 187, 11775, 32827, 170, 16554, 32827, 186, 16570, 103, 111, 102, 59, 25270, 114, 59, 27222, 108, 111, 112, 101, 59, 27223, 59, 27227, 384, 99, 108, 111, 11807, 11809, 11815, 242, 11777, 97, 115, 104, 32827, 248, 16632, 108, 59, 25240, 105, 364, 11823, 11828, 100, 101, 32827, 245, 16629, 101, 115, 256, 59, 97, 475, 11834, 115, 59, 27190, 109, 108, 32827, 246, 16630, 98, 97, 114, 59, 25405, 2785, 11870, 0, 11901, 0, 11904, 11933, 0, 11938, 11961, 0, 0, 11979, 3740, 0, 12051, 0, 0, 12075, 12220, 0, 12232, 114, 512, 59, 97, 115, 116, 1027, 11879, 11890, 3717, 33024, 182, 59, 108, 11885, 11886, 16566, 108, 101, 236, 1027, 617, 11896, 0, 0, 11899, 109, 59, 27379, 59, 27389, 121, 59, 17471, 114, 640, 99, 105, 109, 112, 116, 11915, 11919, 11923, 6245, 11927, 110, 116, 59, 16421, 111, 100, 59, 16430, 105, 108, 59, 24624, 101, 110, 107, 59, 24625, 114, 59, 49152, 55349, 56621, 384, 105, 109, 111, 11944, 11952, 11956, 256, 59, 118, 11949, 11950, 17350, 59, 17365, 109, 97, 244, 2678, 110, 101, 59, 26126, 384, 59, 116, 118, 11967, 11968, 11976, 17344, 99, 104, 102, 111, 114, 107, 187, 8189, 59, 17366, 256, 97, 117, 11983, 11999, 110, 256, 99, 107, 11989, 11997, 107, 256, 59, 104, 8692, 11995, 59, 24846, 246, 8692, 115, 1152, 59, 97, 98, 99, 100, 101, 109, 115, 116, 12019, 12020, 6408, 12025, 12029, 12036, 12038, 12042, 12046, 16427, 99, 105, 114, 59, 27171, 105, 114, 59, 27170, 256, 111, 117, 7488, 12034, 59, 27173, 59, 27250, 110, 32955, 177, 3741, 105, 109, 59, 27174, 119, 111, 59, 27175, 384, 105, 112, 117, 12057, 12064, 12069, 110, 116, 105, 110, 116, 59, 27157, 102, 59, 49152, 55349, 56673, 110, 100, 32827, 163, 16547, 1280, 59, 69, 97, 99, 101, 105, 110, 111, 115, 117, 3784, 12095, 12097, 12100, 12103, 12161, 12169, 12178, 12158, 12214, 59, 27315, 112, 59, 27319, 117, 229, 3801, 256, 59, 99, 3790, 12108, 768, 59, 97, 99, 101, 110, 115, 3784, 12121, 12127, 12134, 12136, 12158, 112, 112, 114, 111, 248, 12099, 117, 114, 108, 121, 101, 241, 3801, 241, 3790, 384, 97, 101, 115, 12143, 12150, 12154, 112, 112, 114, 111, 120, 59, 27321, 113, 113, 59, 27317, 105, 109, 59, 25320, 105, 237, 3807, 109, 101, 256, 59, 115, 12168, 3758, 24626, 384, 69, 97, 115, 12152, 12176, 12154, 240, 12149, 384, 100, 102, 112, 3820, 12185, 12207, 384, 97, 108, 115, 12192, 12197, 12202, 108, 97, 114, 59, 25390, 105, 110, 101, 59, 25362, 117, 114, 102, 59, 25363, 256, 59, 116, 3835, 12212, 239, 3835, 114, 101, 108, 59, 25264, 256, 99, 105, 12224, 12229, 114, 59, 49152, 55349, 56517, 59, 17352, 110, 99, 115, 112, 59, 24584, 768, 102, 105, 111, 112, 115, 117, 12250, 8930, 12255, 12261, 12267, 12273, 114, 59, 49152, 55349, 56622, 112, 102, 59, 49152, 55349, 56674, 114, 105, 109, 101, 59, 24663, 99, 114, 59, 49152, 55349, 56518, 384, 97, 101, 111, 12280, 12297, 12307, 116, 256, 101, 105, 12286, 12293, 114, 110, 105, 111, 110, 243, 1712, 110, 116, 59, 27158, 115, 116, 256, 59, 101, 12304, 12305, 16447, 241, 7961, 244, 3860, 2688, 65, 66, 72, 97, 98, 99, 100, 101, 102, 104, 105, 108, 109, 110, 111, 112, 114, 115, 116, 117, 120, 12352, 12369, 12373, 12377, 12512, 12558, 12587, 12615, 12642, 12658, 12686, 12806, 12821, 12836, 12841, 12888, 12910, 12914, 12944, 12976, 12983, 384, 97, 114, 116, 12359, 12362, 12364, 114, 242, 4275, 242, 989, 97, 105, 108, 59, 26908, 97, 114, 242, 7269, 97, 114, 59, 26980, 896, 99, 100, 101, 110, 113, 114, 116, 12392, 12405, 12408, 12415, 12431, 12436, 12492, 256, 101, 117, 12397, 12401, 59, 49152, 8765, 817, 116, 101, 59, 16725, 105, 227, 4462, 109, 112, 116, 121, 118, 59, 27059, 103, 512, 59, 100, 101, 108, 4049, 12425, 12427, 12429, 59, 27026, 59, 27045, 229, 4049, 117, 111, 32827, 187, 16571, 114, 1408, 59, 97, 98, 99, 102, 104, 108, 112, 115, 116, 119, 4060, 12460, 12463, 12471, 12473, 12476, 12478, 12480, 12483, 12487, 12490, 112, 59, 26997, 256, 59, 102, 4064, 12468, 115, 59, 26912, 59, 26931, 115, 59, 26910, 235, 8797, 240, 10030, 108, 59, 26949, 105, 109, 59, 26996, 108, 59, 24995, 59, 24989, 256, 97, 105, 12497, 12501, 105, 108, 59, 26906, 111, 256, 59, 110, 12507, 12508, 25142, 97, 108, 243, 3870, 384, 97, 98, 114, 12519, 12522, 12526, 114, 242, 6117, 114, 107, 59, 26483, 256, 97, 107, 12531, 12541, 99, 256, 101, 107, 12537, 12539, 59, 16509, 59, 16477, 256, 101, 115, 12546, 12548, 59, 27020, 108, 256, 100, 117, 12554, 12556, 59, 27022, 59, 27024, 512, 97, 101, 117, 121, 12567, 12572, 12583, 12585, 114, 111, 110, 59, 16729, 256, 100, 105, 12577, 12581, 105, 108, 59, 16727, 236, 4082, 226, 12538, 59, 17472, 512, 99, 108, 113, 115, 12596, 12599, 12605, 12612, 97, 59, 26935, 100, 104, 97, 114, 59, 26985, 117, 111, 256, 59, 114, 526, 525, 104, 59, 25011, 384, 97, 99, 103, 12622, 12639, 3908, 108, 512, 59, 105, 112, 115, 3960, 12632, 12635, 4252, 110, 229, 4283, 97, 114, 244, 4009, 116, 59, 26029, 384, 105, 108, 114, 12649, 4131, 12654, 115, 104, 116, 59, 27005, 59, 49152, 55349, 56623, 256, 97, 111, 12663, 12678, 114, 256, 100, 117, 12669, 12671, 187, 1147, 256, 59, 108, 4241, 12676, 59, 26988, 256, 59, 118, 12683, 12684, 17345, 59, 17393, 384, 103, 110, 115, 12693, 12793, 12796, 104, 116, 768, 97, 104, 108, 114, 115, 116, 12708, 12720, 12738, 12760, 12772, 12782, 114, 114, 111, 119, 256, 59, 116, 4060, 12717, 97, 233, 12488, 97, 114, 112, 111, 111, 110, 256, 100, 117, 12731, 12735, 111, 119, 238, 12670, 112, 187, 4242, 101, 102, 116, 256, 97, 104, 12746, 12752, 114, 114, 111, 119, 243, 4074, 97, 114, 112, 111, 111, 110, 243, 1361, 105, 103, 104, 116, 97, 114, 114, 111, 119, 115, 59, 25033, 113, 117, 105, 103, 97, 114, 114, 111, 247, 12491, 104, 114, 101, 101, 116, 105, 109, 101, 115, 59, 25292, 103, 59, 17114, 105, 110, 103, 100, 111, 116, 115, 101, 241, 7986, 384, 97, 104, 109, 12813, 12816, 12819, 114, 242, 4074, 97, 242, 1361, 59, 24591, 111, 117, 115, 116, 256, 59, 97, 12830, 12831, 25521, 99, 104, 101, 187, 12831, 109, 105, 100, 59, 27374, 512, 97, 98, 112, 116, 12850, 12861, 12864, 12882, 256, 110, 114, 12855, 12858, 103, 59, 26605, 114, 59, 25086, 114, 235, 4099, 384, 97, 102, 108, 12871, 12874, 12878, 114, 59, 27014, 59, 49152, 55349, 56675, 117, 115, 59, 27182, 105, 109, 101, 115, 59, 27189, 256, 97, 112, 12893, 12903, 114, 256, 59, 103, 12899, 12900, 16425, 116, 59, 27028, 111, 108, 105, 110, 116, 59, 27154, 97, 114, 242, 12771, 512, 97, 99, 104, 113, 12923, 12928, 4284, 12933, 113, 117, 111, 59, 24634, 114, 59, 49152, 55349, 56519, 256, 98, 117, 12539, 12938, 111, 256, 59, 114, 532, 531, 384, 104, 105, 114, 12951, 12955, 12960, 114, 101, 229, 12792, 109, 101, 115, 59, 25290, 105, 512, 59, 101, 102, 108, 12970, 4185, 6177, 12971, 26041, 116, 114, 105, 59, 27086, 108, 117, 104, 97, 114, 59, 26984, 59, 24862, 3425, 13013, 13019, 13023, 13100, 13112, 13169, 0, 13178, 13220, 0, 0, 13292, 13296, 0, 13352, 13384, 13402, 13485, 13489, 13514, 13553, 0, 13846, 0, 0, 13875, 99, 117, 116, 101, 59, 16731, 113, 117, 239, 10170, 1280, 59, 69, 97, 99, 101, 105, 110, 112, 115, 121, 4589, 13043, 13045, 13055, 13058, 13067, 13071, 13087, 13094, 13097, 59, 27316, 496, 13050, 0, 13052, 59, 27320, 111, 110, 59, 16737, 117, 229, 4606, 256, 59, 100, 4595, 13063, 105, 108, 59, 16735, 114, 99, 59, 16733, 384, 69, 97, 115, 13078, 13080, 13083, 59, 27318, 112, 59, 27322, 105, 109, 59, 25321, 111, 108, 105, 110, 116, 59, 27155, 105, 237, 4612, 59, 17473, 111, 116, 384, 59, 98, 101, 13108, 7495, 13109, 25285, 59, 27238, 896, 65, 97, 99, 109, 115, 116, 120, 13126, 13130, 13143, 13147, 13150, 13155, 13165, 114, 114, 59, 25048, 114, 256, 104, 114, 13136, 13138, 235, 8744, 256, 59, 111, 2614, 2612, 116, 32827, 167, 16551, 105, 59, 16443, 119, 97, 114, 59, 26921, 109, 256, 105, 110, 13161, 240, 110, 117, 243, 241, 116, 59, 26422, 114, 256, 59, 111, 13174, 8277, 49152, 55349, 56624, 512, 97, 99, 111, 121, 13186, 13190, 13201, 13216, 114, 112, 59, 26223, 256, 104, 121, 13195, 13199, 99, 121, 59, 17481, 59, 17480, 114, 116, 621, 13209, 0, 0, 13212, 105, 228, 5220, 97, 114, 97, 236, 11887, 32827, 173, 16557, 256, 103, 109, 13224, 13236, 109, 97, 384, 59, 102, 118, 13233, 13234, 13234, 17347, 59, 17346, 1024, 59, 100, 101, 103, 108, 110, 112, 114, 4779, 13253, 13257, 13262, 13270, 13278, 13281, 13286, 111, 116, 59, 27242, 256, 59, 113, 4785, 4784, 256, 59, 69, 13267, 13268, 27294, 59, 27296, 256, 59, 69, 13275, 13276, 27293, 59, 27295, 101, 59, 25158, 108, 117, 115, 59, 27172, 97, 114, 114, 59, 26994, 97, 114, 242, 4413, 512, 97, 101, 105, 116, 13304, 13320, 13327, 13335, 256, 108, 115, 13309, 13316, 108, 115, 101, 116, 109, 233, 13162, 104, 112, 59, 27187, 112, 97, 114, 115, 108, 59, 27108, 256, 100, 108, 5219, 13332, 101, 59, 25379, 256, 59, 101, 13340, 13341, 27306, 256, 59, 115, 13346, 13347, 27308, 59, 49152, 10924, 65024, 384, 102, 108, 112, 13358, 13363, 13378, 116, 99, 121, 59, 17484, 256, 59, 98, 13368, 13369, 16431, 256, 59, 97, 13374, 13375, 27076, 114, 59, 25407, 102, 59, 49152, 55349, 56676, 97, 256, 100, 114, 13389, 1026, 101, 115, 256, 59, 117, 13396, 13397, 26208, 105, 116, 187, 13397, 384, 99, 115, 117, 13408, 13433, 13471, 256, 97, 117, 13413, 13423, 112, 256, 59, 115, 4488, 13419, 59, 49152, 8851, 65024, 112, 256, 59, 115, 4532, 13429, 59, 49152, 8852, 65024, 117, 256, 98, 112, 13439, 13455, 384, 59, 101, 115, 4503, 4508, 13446, 101, 116, 256, 59, 101, 4503, 13453, 241, 4509, 384, 59, 101, 115, 4520, 4525, 13462, 101, 116, 256, 59, 101, 4520, 13469, 241, 4526, 384, 59, 97, 102, 4475, 13478, 1456, 114, 357, 13483, 1457, 187, 4476, 97, 114, 242, 4424, 512, 99, 101, 109, 116, 13497, 13502, 13506, 13509, 114, 59, 49152, 55349, 56520, 116, 109, 238, 241, 105, 236, 13333, 97, 114, 230, 4542, 256, 97, 114, 13518, 13525, 114, 256, 59, 102, 13524, 6079, 26118, 256, 97, 110, 13530, 13549, 105, 103, 104, 116, 256, 101, 112, 13539, 13546, 112, 115, 105, 108, 111, 238, 7904, 104, 233, 11951, 115, 187, 10322, 640, 98, 99, 109, 110, 112, 13563, 13662, 4617, 13707, 13710, 1152, 59, 69, 100, 101, 109, 110, 112, 114, 115, 13582, 13583, 13585, 13589, 13598, 13603, 13612, 13617, 13622, 25218, 59, 27333, 111, 116, 59, 27325, 256, 59, 100, 4570, 13594, 111, 116, 59, 27331, 117, 108, 116, 59, 27329, 256, 69, 101, 13608, 13610, 59, 27339, 59, 25226, 108, 117, 115, 59, 27327, 97, 114, 114, 59, 27001, 384, 101, 105, 117, 13629, 13650, 13653, 116, 384, 59, 101, 110, 13582, 13637, 13643, 113, 256, 59, 113, 4570, 13583, 101, 113, 256, 59, 113, 13611, 13608, 109, 59, 27335, 256, 98, 112, 13658, 13660, 59, 27349, 59, 27347, 99, 768, 59, 97, 99, 101, 110, 115, 4589, 13676, 13682, 13689, 13691, 13094, 112, 112, 114, 111, 248, 13050, 117, 114, 108, 121, 101, 241, 4606, 241, 4595, 384, 97, 101, 115, 13698, 13704, 13083, 112, 112, 114, 111, 248, 13082, 113, 241, 13079, 103, 59, 26218, 1664, 49, 50, 51, 59, 69, 100, 101, 104, 108, 109, 110, 112, 115, 13737, 13740, 13743, 4636, 13746, 13748, 13760, 13769, 13781, 13786, 13791, 13800, 13805, 32827, 185, 16569, 32827, 178, 16562, 32827, 179, 16563, 59, 27334, 256, 111, 115, 13753, 13756, 116, 59, 27326, 117, 98, 59, 27352, 256, 59, 100, 4642, 13765, 111, 116, 59, 27332, 115, 256, 111, 117, 13775, 13778, 108, 59, 26569, 98, 59, 27351, 97, 114, 114, 59, 27003, 117, 108, 116, 59, 27330, 256, 69, 101, 13796, 13798, 59, 27340, 59, 25227, 108, 117, 115, 59, 27328, 384, 101, 105, 117, 13812, 13833, 13836, 116, 384, 59, 101, 110, 4636, 13820, 13826, 113, 256, 59, 113, 4642, 13746, 101, 113, 256, 59, 113, 13799, 13796, 109, 59, 27336, 256, 98, 112, 13841, 13843, 59, 27348, 59, 27350, 384, 65, 97, 110, 13852, 13856, 13869, 114, 114, 59, 25049, 114, 256, 104, 114, 13862, 13864, 235, 8750, 256, 59, 111, 2603, 2601, 119, 97, 114, 59, 26922, 108, 105, 103, 32827, 223, 16607, 3041, 13905, 13917, 13920, 4814, 13939, 13945, 0, 13950, 14018, 0, 0, 0, 0, 0, 14043, 14083, 0, 14089, 14188, 0, 0, 0, 14215, 626, 13910, 0, 0, 13915, 103, 101, 116, 59, 25366, 59, 17348, 114, 235, 3679, 384, 97, 101, 121, 13926, 13931, 13936, 114, 111, 110, 59, 16741, 100, 105, 108, 59, 16739, 59, 17474, 108, 114, 101, 99, 59, 25365, 114, 59, 49152, 55349, 56625, 512, 101, 105, 107, 111, 13958, 13981, 14005, 14012, 498, 13963, 0, 13969, 101, 256, 52, 102, 4740, 4737, 97, 384, 59, 115, 118, 13976, 13977, 13979, 17336, 121, 109, 59, 17361, 256, 99, 110, 13986, 14002, 107, 256, 97, 115, 13992, 13998, 112, 112, 114, 111, 248, 4801, 105, 109, 187, 4780, 115, 240, 4766, 256, 97, 115, 14010, 13998, 240, 4801, 114, 110, 32827, 254, 16638, 492, 799, 14022, 8935, 101, 115, 33152, 215, 59, 98, 100, 14031, 14032, 14040, 16599, 256, 59, 97, 6415, 14037, 114, 59, 27185, 59, 27184, 384, 101, 112, 115, 14049, 14051, 14080, 225, 10829, 512, 59, 98, 99, 102, 1158, 14060, 14064, 14068, 111, 116, 59, 25398, 105, 114, 59, 27377, 256, 59, 111, 14073, 14076, 49152, 55349, 56677, 114, 107, 59, 27354, 225, 13154, 114, 105, 109, 101, 59, 24628, 384, 97, 105, 112, 14095, 14098, 14180, 100, 229, 4680, 896, 97, 100, 101, 109, 112, 115, 116, 14113, 14157, 14144, 14161, 14167, 14172, 14175, 110, 103, 108, 101, 640, 59, 100, 108, 113, 114, 14128, 14129, 14134, 14144, 14146, 26037, 111, 119, 110, 187, 7611, 101, 102, 116, 256, 59, 101, 10240, 14142, 241, 2350, 59, 25180, 105, 103, 104, 116, 256, 59, 101, 12970, 14155, 241, 4186, 111, 116, 59, 26092, 105, 110, 117, 115, 59, 27194, 108, 117, 115, 59, 27193, 98, 59, 27085, 105, 109, 101, 59, 27195, 101, 122, 105, 117, 109, 59, 25570, 384, 99, 104, 116, 14194, 14205, 14209, 256, 114, 121, 14199, 14203, 59, 49152, 55349, 56521, 59, 17478, 99, 121, 59, 17499, 114, 111, 107, 59, 16743, 256, 105, 111, 14219, 14222, 120, 244, 6007, 104, 101, 97, 100, 256, 108, 114, 14231, 14240, 101, 102, 116, 97, 114, 114, 111, 247, 2127, 105, 103, 104, 116, 97, 114, 114, 111, 119, 187, 3933, 2304, 65, 72, 97, 98, 99, 100, 102, 103, 104, 108, 109, 111, 112, 114, 115, 116, 117, 119, 14288, 14291, 14295, 14308, 14320, 14332, 14350, 14364, 14371, 14388, 14417, 14429, 14443, 14505, 14540, 14546, 14570, 14582, 114, 242, 1005, 97, 114, 59, 26979, 256, 99, 114, 14300, 14306, 117, 116, 101, 32827, 250, 16634, 242, 4432, 114, 483, 14314, 0, 14317, 121, 59, 17502, 118, 101, 59, 16749, 256, 105, 121, 14325, 14330, 114, 99, 32827, 251, 16635, 59, 17475, 384, 97, 98, 104, 14339, 14342, 14347, 114, 242, 5037, 108, 97, 99, 59, 16753, 97, 242, 5059, 256, 105, 114, 14355, 14360, 115, 104, 116, 59, 27006, 59, 49152, 55349, 56626, 114, 97, 118, 101, 32827, 249, 16633, 353, 14375, 14385, 114, 256, 108, 114, 14380, 14382, 187, 2391, 187, 4227, 108, 107, 59, 25984, 256, 99, 116, 14393, 14413, 623, 14399, 0, 0, 14410, 114, 110, 256, 59, 101, 14405, 14406, 25372, 114, 187, 14406, 111, 112, 59, 25359, 114, 105, 59, 26104, 256, 97, 108, 14422, 14426, 99, 114, 59, 16747, 32955, 168, 841, 256, 103, 112, 14434, 14438, 111, 110, 59, 16755, 102, 59, 49152, 55349, 56678, 768, 97, 100, 104, 108, 115, 117, 4427, 14456, 14461, 4978, 14481, 14496, 111, 119, 110, 225, 5043, 97, 114, 112, 111, 111, 110, 256, 108, 114, 14472, 14476, 101, 102, 244, 14381, 105, 103, 104, 244, 14383, 105, 384, 59, 104, 108, 14489, 14490, 14492, 17349, 187, 5114, 111, 110, 187, 14490, 112, 97, 114, 114, 111, 119, 115, 59, 25032, 384, 99, 105, 116, 14512, 14532, 14536, 623, 14518, 0, 0, 14529, 114, 110, 256, 59, 101, 14524, 14525, 25373, 114, 187, 14525, 111, 112, 59, 25358, 110, 103, 59, 16751, 114, 105, 59, 26105, 99, 114, 59, 49152, 55349, 56522, 384, 100, 105, 114, 14553, 14557, 14562, 111, 116, 59, 25328, 108, 100, 101, 59, 16745, 105, 256, 59, 102, 14128, 14568, 187, 6163, 256, 97, 109, 14575, 14578, 114, 242, 14504, 108, 32827, 252, 16636, 97, 110, 103, 108, 101, 59, 27047, 1920, 65, 66, 68, 97, 99, 100, 101, 102, 108, 110, 111, 112, 114, 115, 122, 14620, 14623, 14633, 14637, 14773, 14776, 14781, 14815, 14820, 14824, 14835, 14841, 14845, 14849, 14880, 114, 242, 1015, 97, 114, 256, 59, 118, 14630, 14631, 27368, 59, 27369, 97, 115, 232, 993, 256, 110, 114, 14642, 14647, 103, 114, 116, 59, 27036, 896, 101, 107, 110, 112, 114, 115, 116, 13539, 14662, 14667, 14674, 14685, 14692, 14742, 97, 112, 112, 225, 9237, 111, 116, 104, 105, 110, 231, 7830, 384, 104, 105, 114, 13547, 11976, 14681, 111, 112, 244, 12213, 256, 59, 104, 5047, 14690, 239, 12685, 256, 105, 117, 14697, 14701, 103, 109, 225, 13235, 256, 98, 112, 14706, 14724, 115, 101, 116, 110, 101, 113, 256, 59, 113, 14717, 14720, 49152, 8842, 65024, 59, 49152, 10955, 65024, 115, 101, 116, 110, 101, 113, 256, 59, 113, 14735, 14738, 49152, 8843, 65024, 59, 49152, 10956, 65024, 256, 104, 114, 14747, 14751, 101, 116, 225, 13980, 105, 97, 110, 103, 108, 101, 256, 108, 114, 14762, 14767, 101, 102, 116, 187, 2341, 105, 103, 104, 116, 187, 4177, 121, 59, 17458, 97, 115, 104, 187, 4150, 384, 101, 108, 114, 14788, 14802, 14807, 384, 59, 98, 101, 11754, 14795, 14799, 97, 114, 59, 25275, 113, 59, 25178, 108, 105, 112, 59, 25326, 256, 98, 116, 14812, 5224, 97, 242, 5225, 114, 59, 49152, 55349, 56627, 116, 114, 233, 14766, 115, 117, 256, 98, 112, 14831, 14833, 187, 3356, 187, 3417, 112, 102, 59, 49152, 55349, 56679, 114, 111, 240, 3835, 116, 114, 233, 14772, 256, 99, 117, 14854, 14859, 114, 59, 49152, 55349, 56523, 256, 98, 112, 14864, 14872, 110, 256, 69, 101, 14720, 14870, 187, 14718, 110, 256, 69, 101, 14738, 14878, 187, 14736, 105, 103, 122, 97, 103, 59, 27034, 896, 99, 101, 102, 111, 112, 114, 115, 14902, 14907, 14934, 14939, 14932, 14945, 14954, 105, 114, 99, 59, 16757, 256, 100, 105, 14912, 14929, 256, 98, 103, 14917, 14921, 97, 114, 59, 27231, 101, 256, 59, 113, 5626, 14927, 59, 25177, 101, 114, 112, 59, 24856, 114, 59, 49152, 55349, 56628, 112, 102, 59, 49152, 55349, 56680, 256, 59, 101, 5241, 14950, 97, 116, 232, 5241, 99, 114, 59, 49152, 55349, 56524, 2787, 6030, 14983, 0, 14987, 0, 14992, 15003, 0, 0, 15005, 15016, 15019, 15023, 0, 0, 15043, 15054, 0, 15064, 6108, 6111, 116, 114, 233, 6097, 114, 59, 49152, 55349, 56629, 256, 65, 97, 14996, 14999, 114, 242, 963, 114, 242, 2550, 59, 17342, 256, 65, 97, 15009, 15012, 114, 242, 952, 114, 242, 2539, 97, 240, 10003, 105, 115, 59, 25339, 384, 100, 112, 116, 6052, 15029, 15038, 256, 102, 108, 15034, 6057, 59, 49152, 55349, 56681, 105, 109, 229, 6066, 256, 65, 97, 15047, 15050, 114, 242, 974, 114, 242, 2561, 256, 99, 113, 15058, 6072, 114, 59, 49152, 55349, 56525, 256, 112, 116, 6102, 15068, 114, 233, 6100, 1024, 97, 99, 101, 102, 105, 111, 115, 117, 15088, 15101, 15112, 15116, 15121, 15125, 15131, 15137, 99, 256, 117, 121, 15094, 15099, 116, 101, 32827, 253, 16637, 59, 17487, 256, 105, 121, 15106, 15110, 114, 99, 59, 16759, 59, 17483, 110, 32827, 165, 16549, 114, 59, 49152, 55349, 56630, 99, 121, 59, 17495, 112, 102, 59, 49152, 55349, 56682, 99, 114, 59, 49152, 55349, 56526, 256, 99, 109, 15142, 15145, 121, 59, 17486, 108, 32827, 255, 16639, 1280, 97, 99, 100, 101, 102, 104, 105, 111, 115, 119, 15170, 15176, 15188, 15192, 15204, 15209, 15213, 15220, 15226, 15232, 99, 117, 116, 101, 59, 16762, 256, 97, 121, 15181, 15186, 114, 111, 110, 59, 16766, 59, 17463, 111, 116, 59, 16764, 256, 101, 116, 15197, 15201, 116, 114, 230, 5471, 97, 59, 17334, 114, 59, 49152, 55349, 56631, 99, 121, 59, 17462, 103, 114, 97, 114, 114, 59, 25053, 112, 102, 59, 49152, 55349, 56683, 99, 114, 59, 49152, 55349, 56527, 256, 106, 110, 15237, 15239, 59, 24589, 106, 59, 24588]), hC = new Uint16Array([512, 97, 103, 108, 113, 9, 21, 24, 27, 621, 15, 0, 0, 18, 112, 59, 16422, 111, 115, 59, 16423, 116, 59, 16446, 116, 59, 16444, 117, 111, 116, 59, 16418]), V1, dC = /* @__PURE__ */ new Map([
  [0, 65533],
  [128, 8364],
  [130, 8218],
  [131, 402],
  [132, 8222],
  [133, 8230],
  [134, 8224],
  [135, 8225],
  [136, 710],
  [137, 8240],
  [138, 352],
  [139, 8249],
  [140, 338],
  [142, 381],
  [145, 8216],
  [146, 8217],
  [147, 8220],
  [148, 8221],
  [149, 8226],
  [150, 8211],
  [151, 8212],
  [152, 732],
  [153, 8482],
  [154, 353],
  [155, 8250],
  [156, 339],
  [158, 382],
  [159, 376]
]), mc = (V1 = String.fromCodePoint) !== null && V1 !== void 0 ? V1 : function(e) {
  let t = "";
  return e > 65535 && (e -= 65536, t += String.fromCharCode(e >>> 10 & 1023 | 55296), e = 56320 | e & 1023), t += String.fromCharCode(e), t;
};
function Am(e) {
  var t;
  return e >= 55296 && e <= 57343 || e > 1114111 ? 65533 : (t = dC.get(e)) !== null && t !== void 0 ? t : e;
}
l(Am, "replaceCodePoint");
function ib(e) {
  return mc(Am(e));
}
l(ib, "decodeCodePoint");
var Xt;
(function(e) {
  e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_F = 102] = "LOWER_F", e[e.LOWER_X = 120] = "LOWER_X", e[e.To_LOWER_BIT = 32] = "To_LOWER_BIT";
})(Xt || (Xt = {}));
var Fi;
(function(e) {
  e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE";
})(Fi || (Fi = {}));
function pC(e) {
  return /* @__PURE__ */ l(function(i, n) {
    let s = "", r = 0, a = 0;
    for (; (a = i.indexOf("&", a)) >= 0; ) {
      if (s += i.slice(r, a), r = a, a += 1, i.charCodeAt(a) === Xt.NUM) {
        let f = a + 1, _ = 10, C = i.charCodeAt(f);
        (C | Xt.To_LOWER_BIT) === Xt.LOWER_X && (_ = 16, a += 1, f += 1);
        do
          C = i.charCodeAt(++a);
        while (C >= Xt.ZERO && C <= Xt.NINE || _ === 16 && (C | Xt.To_LOWER_BIT) >= Xt.LOWER_A && (C | Xt.To_LOWER_BIT) <= Xt.LOWER_F);
        if (f !== a) {
          const E = i.substring(f, a), P = parseInt(E, _);
          if (i.charCodeAt(a) === Xt.SEMI)
            a += 1;
          else if (n)
            continue;
          s += ib(P), r = a;
        }
        continue;
      }
      let u = 0, c = 1, h = 0, p = e[h];
      for (; a < i.length && (h = Im(e, p, h + 1, i.charCodeAt(a)), !(h < 0)); a++, c++) {
        p = e[h];
        const f = p & Fi.VALUE_LENGTH;
        if (f) {
          (!n || i.charCodeAt(a) === Xt.SEMI) && (u = h, c = 0);
          const _ = (f >> 14) - 1;
          if (_ === 0)
            break;
          h += _;
        }
      }
      if (u !== 0) {
        const f = (e[u] & Fi.VALUE_LENGTH) >> 14;
        s += f === 1 ? String.fromCharCode(e[u] & ~Fi.VALUE_LENGTH) : f === 2 ? String.fromCharCode(e[u + 1]) : String.fromCharCode(e[u + 1], e[u + 2]), r = a - c + 1;
      }
    }
    return s + i.slice(r);
  }, "decodeHTMLBinary");
}
l(pC, "getDecoder");
function Im(e, t, i, n) {
  const s = (t & Fi.BRANCH_LENGTH) >> 7, r = t & Fi.JUMP_TABLE;
  if (s === 0)
    return r !== 0 && n === r ? i : -1;
  if (r) {
    const c = n - r;
    return c < 0 || c >= s ? -1 : e[i + c] - 1;
  }
  let a = i, u = a + s - 1;
  for (; a <= u; ) {
    const c = a + u >>> 1, h = e[c];
    if (h < n)
      a = c + 1;
    else if (h > n)
      u = c - 1;
    else
      return e[c + s];
  }
  return -1;
}
l(Im, "determineBranch");
var K;
(function(e) {
  e[e.Tab = 9] = "Tab", e[e.NewLine = 10] = "NewLine", e[e.FormFeed = 12] = "FormFeed", e[e.CarriageReturn = 13] = "CarriageReturn", e[e.Space = 32] = "Space", e[e.ExclamationMark = 33] = "ExclamationMark", e[e.Num = 35] = "Num", e[e.Amp = 38] = "Amp", e[e.SingleQuote = 39] = "SingleQuote", e[e.DoubleQuote = 34] = "DoubleQuote", e[e.Dash = 45] = "Dash", e[e.Slash = 47] = "Slash", e[e.Zero = 48] = "Zero", e[e.Nine = 57] = "Nine", e[e.Semi = 59] = "Semi", e[e.Lt = 60] = "Lt", e[e.Eq = 61] = "Eq", e[e.Gt = 62] = "Gt", e[e.Questionmark = 63] = "Questionmark", e[e.UpperA = 65] = "UpperA", e[e.LowerA = 97] = "LowerA", e[e.UpperF = 70] = "UpperF", e[e.LowerF = 102] = "LowerF", e[e.UpperZ = 90] = "UpperZ", e[e.LowerZ = 122] = "LowerZ", e[e.LowerX = 120] = "LowerX", e[e.OpeningSquareBracket = 91] = "OpeningSquareBracket";
})(K || (K = {}));
var R;
(function(e) {
  e[e.Text = 1] = "Text", e[e.BeforeTagName = 2] = "BeforeTagName", e[e.InTagName = 3] = "InTagName", e[e.InSelfClosingTag = 4] = "InSelfClosingTag", e[e.BeforeClosingTagName = 5] = "BeforeClosingTagName", e[e.InClosingTagName = 6] = "InClosingTagName", e[e.AfterClosingTagName = 7] = "AfterClosingTagName", e[e.BeforeAttributeName = 8] = "BeforeAttributeName", e[e.InAttributeName = 9] = "InAttributeName", e[e.AfterAttributeName = 10] = "AfterAttributeName", e[e.BeforeAttributeValue = 11] = "BeforeAttributeValue", e[e.InAttributeValueDq = 12] = "InAttributeValueDq", e[e.InAttributeValueSq = 13] = "InAttributeValueSq", e[e.InAttributeValueNq = 14] = "InAttributeValueNq", e[e.BeforeDeclaration = 15] = "BeforeDeclaration", e[e.InDeclaration = 16] = "InDeclaration", e[e.InProcessingInstruction = 17] = "InProcessingInstruction", e[e.BeforeComment = 18] = "BeforeComment", e[e.CDATASequence = 19] = "CDATASequence", e[e.InSpecialComment = 20] = "InSpecialComment", e[e.InCommentLike = 21] = "InCommentLike", e[e.BeforeSpecialS = 22] = "BeforeSpecialS", e[e.SpecialStartSequence = 23] = "SpecialStartSequence", e[e.InSpecialTag = 24] = "InSpecialTag", e[e.BeforeEntity = 25] = "BeforeEntity", e[e.BeforeNumericEntity = 26] = "BeforeNumericEntity", e[e.InNamedEntity = 27] = "InNamedEntity", e[e.InNumericEntity = 28] = "InNumericEntity", e[e.InHexEntity = 29] = "InHexEntity";
})(R || (R = {}));
function Ni(e) {
  return e === K.Space || e === K.NewLine || e === K.Tab || e === K.FormFeed || e === K.CarriageReturn;
}
l(Ni, "isWhitespace");
function ro(e) {
  return e === K.Slash || e === K.Gt || Ni(e);
}
l(ro, "isEndOfTagSection");
function vc(e) {
  return e >= K.Zero && e <= K.Nine;
}
l(vc, "isNumber");
function nb(e) {
  return e >= K.LowerA && e <= K.LowerZ || e >= K.UpperA && e <= K.UpperZ;
}
l(nb, "isASCIIAlpha");
function sb(e) {
  return e >= K.UpperA && e <= K.UpperF || e >= K.LowerA && e <= K.LowerF;
}
l(sb, "isHexDigit");
var Bi;
(function(e) {
  e[e.NoValue = 0] = "NoValue", e[e.Unquoted = 1] = "Unquoted", e[e.Single = 2] = "Single", e[e.Double = 3] = "Double";
})(Bi || (Bi = {}));
var Bt = {
  Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
  CdataEnd: new Uint8Array([93, 93, 62]),
  CommentEnd: new Uint8Array([45, 45, 62]),
  ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
  StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
  TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101])
}, Pm = class {
  constructor({ xmlMode: e = !1, decodeEntities: t = !0 }, i) {
    this.cbs = i, this.state = R.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = R.Text, this.isSpecial = !1, this.running = !0, this.offset = 0, this.sequenceIndex = 0, this.trieIndex = 0, this.trieCurrent = 0, this.entityResult = 0, this.entityExcess = 0, this.xmlMode = e, this.decodeEntities = t, this.entityTrie = e ? hC : cC;
  }
  reset() {
    this.state = R.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = R.Text, this.currentSequence = void 0, this.running = !0, this.offset = 0;
  }
  write(e) {
    this.offset += this.buffer.length, this.buffer = e, this.parse();
  }
  end() {
    this.running && this.finish();
  }
  pause() {
    this.running = !1;
  }
  resume() {
    this.running = !0, this.index < this.buffer.length + this.offset && this.parse();
  }
  getIndex() {
    return this.index;
  }
  getSectionStart() {
    return this.sectionStart;
  }
  stateText(e) {
    e === K.Lt || !this.decodeEntities && this.fastForwardTo(K.Lt) ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = R.BeforeTagName, this.sectionStart = this.index) : this.decodeEntities && e === K.Amp && (this.state = R.BeforeEntity);
  }
  stateSpecialStartSequence(e) {
    const t = this.sequenceIndex === this.currentSequence.length;
    if (!(t ? ro(e) : (e | 32) === this.currentSequence[this.sequenceIndex]))
      this.isSpecial = !1;
    else if (!t) {
      this.sequenceIndex++;
      return;
    }
    this.sequenceIndex = 0, this.state = R.InTagName, this.stateInTagName(e);
  }
  stateInSpecialTag(e) {
    if (this.sequenceIndex === this.currentSequence.length) {
      if (e === K.Gt || Ni(e)) {
        const t = this.index - this.currentSequence.length;
        if (this.sectionStart < t) {
          const i = this.index;
          this.index = t, this.cbs.ontext(this.sectionStart, t), this.index = i;
        }
        this.isSpecial = !1, this.sectionStart = t + 2, this.stateInClosingTagName(e);
        return;
      }
      this.sequenceIndex = 0;
    }
    (e | 32) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : this.sequenceIndex === 0 ? this.currentSequence === Bt.TitleEnd ? this.decodeEntities && e === K.Amp && (this.state = R.BeforeEntity) : this.fastForwardTo(K.Lt) && (this.sequenceIndex = 1) : this.sequenceIndex = Number(e === K.Lt);
  }
  stateCDATASequence(e) {
    e === Bt.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === Bt.Cdata.length && (this.state = R.InCommentLike, this.currentSequence = Bt.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = R.InDeclaration, this.stateInDeclaration(e));
  }
  fastForwardTo(e) {
    for (; ++this.index < this.buffer.length + this.offset; )
      if (this.buffer.charCodeAt(this.index - this.offset) === e)
        return !0;
    return this.index = this.buffer.length + this.offset - 1, !1;
  }
  stateInCommentLike(e) {
    e === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === Bt.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index, 2) : this.cbs.oncomment(this.sectionStart, this.index, 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = R.Text) : this.sequenceIndex === 0 ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : e !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0);
  }
  isTagStartChar(e) {
    return this.xmlMode ? !ro(e) : nb(e);
  }
  startSpecial(e, t) {
    this.isSpecial = !0, this.currentSequence = e, this.sequenceIndex = t, this.state = R.SpecialStartSequence;
  }
  stateBeforeTagName(e) {
    if (e === K.ExclamationMark)
      this.state = R.BeforeDeclaration, this.sectionStart = this.index + 1;
    else if (e === K.Questionmark)
      this.state = R.InProcessingInstruction, this.sectionStart = this.index + 1;
    else if (this.isTagStartChar(e)) {
      const t = e | 32;
      this.sectionStart = this.index, !this.xmlMode && t === Bt.TitleEnd[2] ? this.startSpecial(Bt.TitleEnd, 3) : this.state = !this.xmlMode && t === Bt.ScriptEnd[2] ? R.BeforeSpecialS : R.InTagName;
    } else
      e === K.Slash ? this.state = R.BeforeClosingTagName : (this.state = R.Text, this.stateText(e));
  }
  stateInTagName(e) {
    ro(e) && (this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = R.BeforeAttributeName, this.stateBeforeAttributeName(e));
  }
  stateBeforeClosingTagName(e) {
    Ni(e) || (e === K.Gt ? this.state = R.Text : (this.state = this.isTagStartChar(e) ? R.InClosingTagName : R.InSpecialComment, this.sectionStart = this.index));
  }
  stateInClosingTagName(e) {
    (e === K.Gt || Ni(e)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = R.AfterClosingTagName, this.stateAfterClosingTagName(e));
  }
  stateAfterClosingTagName(e) {
    (e === K.Gt || this.fastForwardTo(K.Gt)) && (this.state = R.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeAttributeName(e) {
    e === K.Gt ? (this.cbs.onopentagend(this.index), this.isSpecial ? (this.state = R.InSpecialTag, this.sequenceIndex = 0) : this.state = R.Text, this.baseState = this.state, this.sectionStart = this.index + 1) : e === K.Slash ? this.state = R.InSelfClosingTag : Ni(e) || (this.state = R.InAttributeName, this.sectionStart = this.index);
  }
  stateInSelfClosingTag(e) {
    e === K.Gt ? (this.cbs.onselfclosingtag(this.index), this.state = R.Text, this.baseState = R.Text, this.sectionStart = this.index + 1, this.isSpecial = !1) : Ni(e) || (this.state = R.BeforeAttributeName, this.stateBeforeAttributeName(e));
  }
  stateInAttributeName(e) {
    (e === K.Eq || ro(e)) && (this.cbs.onattribname(this.sectionStart, this.index), this.sectionStart = -1, this.state = R.AfterAttributeName, this.stateAfterAttributeName(e));
  }
  stateAfterAttributeName(e) {
    e === K.Eq ? this.state = R.BeforeAttributeValue : e === K.Slash || e === K.Gt ? (this.cbs.onattribend(Bi.NoValue, this.index), this.state = R.BeforeAttributeName, this.stateBeforeAttributeName(e)) : Ni(e) || (this.cbs.onattribend(Bi.NoValue, this.index), this.state = R.InAttributeName, this.sectionStart = this.index);
  }
  stateBeforeAttributeValue(e) {
    e === K.DoubleQuote ? (this.state = R.InAttributeValueDq, this.sectionStart = this.index + 1) : e === K.SingleQuote ? (this.state = R.InAttributeValueSq, this.sectionStart = this.index + 1) : Ni(e) || (this.sectionStart = this.index, this.state = R.InAttributeValueNq, this.stateInAttributeValueNoQuotes(e));
  }
  handleInAttributeValue(e, t) {
    e === t || !this.decodeEntities && this.fastForwardTo(t) ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(t === K.DoubleQuote ? Bi.Double : Bi.Single, this.index), this.state = R.BeforeAttributeName) : this.decodeEntities && e === K.Amp && (this.baseState = this.state, this.state = R.BeforeEntity);
  }
  stateInAttributeValueDoubleQuotes(e) {
    this.handleInAttributeValue(e, K.DoubleQuote);
  }
  stateInAttributeValueSingleQuotes(e) {
    this.handleInAttributeValue(e, K.SingleQuote);
  }
  stateInAttributeValueNoQuotes(e) {
    Ni(e) || e === K.Gt ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(Bi.Unquoted, this.index), this.state = R.BeforeAttributeName, this.stateBeforeAttributeName(e)) : this.decodeEntities && e === K.Amp && (this.baseState = this.state, this.state = R.BeforeEntity);
  }
  stateBeforeDeclaration(e) {
    e === K.OpeningSquareBracket ? (this.state = R.CDATASequence, this.sequenceIndex = 0) : this.state = e === K.Dash ? R.BeforeComment : R.InDeclaration;
  }
  stateInDeclaration(e) {
    (e === K.Gt || this.fastForwardTo(K.Gt)) && (this.cbs.ondeclaration(this.sectionStart, this.index), this.state = R.Text, this.sectionStart = this.index + 1);
  }
  stateInProcessingInstruction(e) {
    (e === K.Gt || this.fastForwardTo(K.Gt)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = R.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeComment(e) {
    e === K.Dash ? (this.state = R.InCommentLike, this.currentSequence = Bt.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = R.InDeclaration;
  }
  stateInSpecialComment(e) {
    (e === K.Gt || this.fastForwardTo(K.Gt)) && (this.cbs.oncomment(this.sectionStart, this.index, 0), this.state = R.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeSpecialS(e) {
    const t = e | 32;
    t === Bt.ScriptEnd[3] ? this.startSpecial(Bt.ScriptEnd, 4) : t === Bt.StyleEnd[3] ? this.startSpecial(Bt.StyleEnd, 4) : (this.state = R.InTagName, this.stateInTagName(e));
  }
  stateBeforeEntity(e) {
    this.entityExcess = 1, this.entityResult = 0, e === K.Num ? this.state = R.BeforeNumericEntity : e === K.Amp || (this.trieIndex = 0, this.trieCurrent = this.entityTrie[0], this.state = R.InNamedEntity, this.stateInNamedEntity(e));
  }
  stateInNamedEntity(e) {
    if (this.entityExcess += 1, this.trieIndex = Im(this.entityTrie, this.trieCurrent, this.trieIndex + 1, e), this.trieIndex < 0) {
      this.emitNamedEntity(), this.index--;
      return;
    }
    this.trieCurrent = this.entityTrie[this.trieIndex];
    const t = this.trieCurrent & Fi.VALUE_LENGTH;
    if (t) {
      const i = (t >> 14) - 1;
      if (!this.allowLegacyEntity() && e !== K.Semi)
        this.trieIndex += i;
      else {
        const n = this.index - this.entityExcess + 1;
        n > this.sectionStart && this.emitPartial(this.sectionStart, n), this.entityResult = this.trieIndex, this.trieIndex += i, this.entityExcess = 0, this.sectionStart = this.index + 1, i === 0 && this.emitNamedEntity();
      }
    }
  }
  emitNamedEntity() {
    if (this.state = this.baseState, this.entityResult === 0)
      return;
    switch ((this.entityTrie[this.entityResult] & Fi.VALUE_LENGTH) >> 14) {
      case 1:
        this.emitCodePoint(this.entityTrie[this.entityResult] & ~Fi.VALUE_LENGTH);
        break;
      case 2:
        this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
        break;
      case 3:
        this.emitCodePoint(this.entityTrie[this.entityResult + 1]), this.emitCodePoint(this.entityTrie[this.entityResult + 2]);
    }
  }
  stateBeforeNumericEntity(e) {
    (e | 32) === K.LowerX ? (this.entityExcess++, this.state = R.InHexEntity) : (this.state = R.InNumericEntity, this.stateInNumericEntity(e));
  }
  emitNumericEntity(e) {
    const t = this.index - this.entityExcess - 1;
    t + 2 + Number(this.state === R.InHexEntity) !== this.index && (t > this.sectionStart && this.emitPartial(this.sectionStart, t), this.sectionStart = this.index + Number(e), this.emitCodePoint(Am(this.entityResult))), this.state = this.baseState;
  }
  stateInNumericEntity(e) {
    e === K.Semi ? this.emitNumericEntity(!0) : vc(e) ? (this.entityResult = this.entityResult * 10 + (e - K.Zero), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
  }
  stateInHexEntity(e) {
    e === K.Semi ? this.emitNumericEntity(!0) : vc(e) ? (this.entityResult = this.entityResult * 16 + (e - K.Zero), this.entityExcess++) : sb(e) ? (this.entityResult = this.entityResult * 16 + ((e | 32) - K.LowerA + 10), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
  }
  allowLegacyEntity() {
    return !this.xmlMode && (this.baseState === R.Text || this.baseState === R.InSpecialTag);
  }
  cleanup() {
    this.running && this.sectionStart !== this.index && (this.state === R.Text || this.state === R.InSpecialTag && this.sequenceIndex === 0 ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : (this.state === R.InAttributeValueDq || this.state === R.InAttributeValueSq || this.state === R.InAttributeValueNq) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index));
  }
  shouldContinue() {
    return this.index < this.buffer.length + this.offset && this.running;
  }
  parse() {
    for (; this.shouldContinue(); ) {
      const e = this.buffer.charCodeAt(this.index - this.offset);
      this.state === R.Text ? this.stateText(e) : this.state === R.SpecialStartSequence ? this.stateSpecialStartSequence(e) : this.state === R.InSpecialTag ? this.stateInSpecialTag(e) : this.state === R.CDATASequence ? this.stateCDATASequence(e) : this.state === R.InAttributeValueDq ? this.stateInAttributeValueDoubleQuotes(e) : this.state === R.InAttributeName ? this.stateInAttributeName(e) : this.state === R.InCommentLike ? this.stateInCommentLike(e) : this.state === R.InSpecialComment ? this.stateInSpecialComment(e) : this.state === R.BeforeAttributeName ? this.stateBeforeAttributeName(e) : this.state === R.InTagName ? this.stateInTagName(e) : this.state === R.InClosingTagName ? this.stateInClosingTagName(e) : this.state === R.BeforeTagName ? this.stateBeforeTagName(e) : this.state === R.AfterAttributeName ? this.stateAfterAttributeName(e) : this.state === R.InAttributeValueSq ? this.stateInAttributeValueSingleQuotes(e) : this.state === R.BeforeAttributeValue ? this.stateBeforeAttributeValue(e) : this.state === R.BeforeClosingTagName ? this.stateBeforeClosingTagName(e) : this.state === R.AfterClosingTagName ? this.stateAfterClosingTagName(e) : this.state === R.BeforeSpecialS ? this.stateBeforeSpecialS(e) : this.state === R.InAttributeValueNq ? this.stateInAttributeValueNoQuotes(e) : this.state === R.InSelfClosingTag ? this.stateInSelfClosingTag(e) : this.state === R.InDeclaration ? this.stateInDeclaration(e) : this.state === R.BeforeDeclaration ? this.stateBeforeDeclaration(e) : this.state === R.BeforeComment ? this.stateBeforeComment(e) : this.state === R.InProcessingInstruction ? this.stateInProcessingInstruction(e) : this.state === R.InNamedEntity ? this.stateInNamedEntity(e) : this.state === R.BeforeEntity ? this.stateBeforeEntity(e) : this.state === R.InHexEntity ? this.stateInHexEntity(e) : this.state === R.InNumericEntity ? this.stateInNumericEntity(e) : this.stateBeforeNumericEntity(e), this.index++;
    }
    this.cleanup();
  }
  finish() {
    this.state === R.InNamedEntity && this.emitNamedEntity(), this.sectionStart < this.index && this.handleTrailingData(), this.cbs.onend();
  }
  handleTrailingData() {
    const e = this.buffer.length + this.offset;
    this.state === R.InCommentLike ? this.currentSequence === Bt.CdataEnd ? this.cbs.oncdata(this.sectionStart, e, 0) : this.cbs.oncomment(this.sectionStart, e, 0) : this.state === R.InNumericEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === R.InHexEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === R.InTagName || this.state === R.BeforeAttributeName || this.state === R.BeforeAttributeValue || this.state === R.AfterAttributeName || this.state === R.InAttributeName || this.state === R.InAttributeValueSq || this.state === R.InAttributeValueDq || this.state === R.InAttributeValueNq || this.state === R.InClosingTagName || this.cbs.ontext(this.sectionStart, e);
  }
  emitPartial(e, t) {
    this.baseState !== R.Text && this.baseState !== R.InSpecialTag ? this.cbs.onattribdata(e, t) : this.cbs.ontext(e, t);
  }
  emitCodePoint(e) {
    this.baseState !== R.Text && this.baseState !== R.InSpecialTag ? this.cbs.onattribentity(e) : this.cbs.ontextentity(e);
  }
};
l(Pm, "Tokenizer");
var Vs = /* @__PURE__ */ new Set([
  "input",
  "option",
  "optgroup",
  "select",
  "button",
  "datalist",
  "textarea"
]), Fe = /* @__PURE__ */ new Set(["p"]), G5 = /* @__PURE__ */ new Set(["thead", "tbody"]), q5 = /* @__PURE__ */ new Set(["dd", "dt"]), K5 = /* @__PURE__ */ new Set(["rt", "rp"]), fC = /* @__PURE__ */ new Map([
  ["tr", /* @__PURE__ */ new Set(["tr", "th", "td"])],
  ["th", /* @__PURE__ */ new Set(["th"])],
  ["td", /* @__PURE__ */ new Set(["thead", "th", "td"])],
  ["body", /* @__PURE__ */ new Set(["head", "link", "script"])],
  ["li", /* @__PURE__ */ new Set(["li"])],
  ["p", Fe],
  ["h1", Fe],
  ["h2", Fe],
  ["h3", Fe],
  ["h4", Fe],
  ["h5", Fe],
  ["h6", Fe],
  ["select", Vs],
  ["input", Vs],
  ["output", Vs],
  ["button", Vs],
  ["datalist", Vs],
  ["textarea", Vs],
  ["option", /* @__PURE__ */ new Set(["option"])],
  ["optgroup", /* @__PURE__ */ new Set(["optgroup", "option"])],
  ["dd", q5],
  ["dt", q5],
  ["address", Fe],
  ["article", Fe],
  ["aside", Fe],
  ["blockquote", Fe],
  ["details", Fe],
  ["div", Fe],
  ["dl", Fe],
  ["fieldset", Fe],
  ["figcaption", Fe],
  ["figure", Fe],
  ["footer", Fe],
  ["form", Fe],
  ["header", Fe],
  ["hr", Fe],
  ["main", Fe],
  ["nav", Fe],
  ["ol", Fe],
  ["pre", Fe],
  ["section", Fe],
  ["table", Fe],
  ["ul", Fe],
  ["rt", K5],
  ["rp", K5],
  ["tbody", G5],
  ["tfoot", G5]
]), mC = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]), z5 = /* @__PURE__ */ new Set(["math", "svg"]), Y5 = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignobject",
  "desc",
  "title"
]), vC = /\s|\//, pu = class {
  constructor(e, t = {}) {
    var i, n, s, r, a;
    this.options = t, this.startIndex = 0, this.endIndex = 0, this.openTagStart = 0, this.tagname = "", this.attribname = "", this.attribvalue = "", this.attribs = null, this.stack = [], this.foreignContext = [], this.buffers = [], this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1, this.cbs = e ?? {}, this.lowerCaseTagNames = (i = t.lowerCaseTags) !== null && i !== void 0 ? i : !t.xmlMode, this.lowerCaseAttributeNames = (n = t.lowerCaseAttributeNames) !== null && n !== void 0 ? n : !t.xmlMode, this.tokenizer = new ((s = t.Tokenizer) !== null && s !== void 0 ? s : Pm)(this.options, this), (a = (r = this.cbs).onparserinit) === null || a === void 0 || a.call(r, this);
  }
  ontext(e, t) {
    var i, n;
    const s = this.getSlice(e, t);
    this.endIndex = t - 1, (n = (i = this.cbs).ontext) === null || n === void 0 || n.call(i, s), this.startIndex = t;
  }
  ontextentity(e) {
    var t, i;
    const n = this.tokenizer.getSectionStart();
    this.endIndex = n - 1, (i = (t = this.cbs).ontext) === null || i === void 0 || i.call(t, mc(e)), this.startIndex = n;
  }
  isVoidElement(e) {
    return !this.options.xmlMode && mC.has(e);
  }
  onopentagname(e, t) {
    this.endIndex = t;
    let i = this.getSlice(e, t);
    this.lowerCaseTagNames && (i = i.toLowerCase()), this.emitOpenTag(i);
  }
  emitOpenTag(e) {
    var t, i, n, s;
    this.openTagStart = this.startIndex, this.tagname = e;
    const r = !this.options.xmlMode && fC.get(e);
    if (r)
      for (; this.stack.length > 0 && r.has(this.stack[this.stack.length - 1]); ) {
        const a = this.stack.pop();
        (i = (t = this.cbs).onclosetag) === null || i === void 0 || i.call(t, a, !0);
      }
    this.isVoidElement(e) || (this.stack.push(e), z5.has(e) ? this.foreignContext.push(!0) : Y5.has(e) && this.foreignContext.push(!1)), (s = (n = this.cbs).onopentagname) === null || s === void 0 || s.call(n, e), this.cbs.onopentag && (this.attribs = {});
  }
  endOpenTag(e) {
    var t, i;
    this.startIndex = this.openTagStart, this.attribs && ((i = (t = this.cbs).onopentag) === null || i === void 0 || i.call(t, this.tagname, this.attribs, e), this.attribs = null), this.cbs.onclosetag && this.isVoidElement(this.tagname) && this.cbs.onclosetag(this.tagname, !0), this.tagname = "";
  }
  onopentagend(e) {
    this.endIndex = e, this.endOpenTag(!1), this.startIndex = e + 1;
  }
  onclosetag(e, t) {
    var i, n, s, r, a, u;
    this.endIndex = t;
    let c = this.getSlice(e, t);
    if (this.lowerCaseTagNames && (c = c.toLowerCase()), (z5.has(c) || Y5.has(c)) && this.foreignContext.pop(), this.isVoidElement(c))
      !this.options.xmlMode && c === "br" && ((n = (i = this.cbs).onopentagname) === null || n === void 0 || n.call(i, "br"), (r = (s = this.cbs).onopentag) === null || r === void 0 || r.call(s, "br", {}, !0), (u = (a = this.cbs).onclosetag) === null || u === void 0 || u.call(a, "br", !1));
    else {
      const h = this.stack.lastIndexOf(c);
      if (h !== -1)
        if (this.cbs.onclosetag) {
          let p = this.stack.length - h;
          for (; p--; )
            this.cbs.onclosetag(this.stack.pop(), p !== 0);
        } else
          this.stack.length = h;
      else
        !this.options.xmlMode && c === "p" && (this.emitOpenTag("p"), this.closeCurrentTag(!0));
    }
    this.startIndex = t + 1;
  }
  onselfclosingtag(e) {
    this.endIndex = e, this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1] ? (this.closeCurrentTag(!1), this.startIndex = e + 1) : this.onopentagend(e);
  }
  closeCurrentTag(e) {
    var t, i;
    const n = this.tagname;
    this.endOpenTag(e), this.stack[this.stack.length - 1] === n && ((i = (t = this.cbs).onclosetag) === null || i === void 0 || i.call(t, n, !e), this.stack.pop());
  }
  onattribname(e, t) {
    this.startIndex = e;
    const i = this.getSlice(e, t);
    this.attribname = this.lowerCaseAttributeNames ? i.toLowerCase() : i;
  }
  onattribdata(e, t) {
    this.attribvalue += this.getSlice(e, t);
  }
  onattribentity(e) {
    this.attribvalue += mc(e);
  }
  onattribend(e, t) {
    var i, n;
    this.endIndex = t, (n = (i = this.cbs).onattribute) === null || n === void 0 || n.call(i, this.attribname, this.attribvalue, e === Bi.Double ? '"' : e === Bi.Single ? "'" : e === Bi.NoValue ? void 0 : null), this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname) && (this.attribs[this.attribname] = this.attribvalue), this.attribvalue = "";
  }
  getInstructionName(e) {
    const t = e.search(vC);
    let i = t < 0 ? e : e.substr(0, t);
    return this.lowerCaseTagNames && (i = i.toLowerCase()), i;
  }
  ondeclaration(e, t) {
    this.endIndex = t;
    const i = this.getSlice(e, t);
    if (this.cbs.onprocessinginstruction) {
      const n = this.getInstructionName(i);
      this.cbs.onprocessinginstruction(`!${n}`, `!${i}`);
    }
    this.startIndex = t + 1;
  }
  onprocessinginstruction(e, t) {
    this.endIndex = t;
    const i = this.getSlice(e, t);
    if (this.cbs.onprocessinginstruction) {
      const n = this.getInstructionName(i);
      this.cbs.onprocessinginstruction(`?${n}`, `?${i}`);
    }
    this.startIndex = t + 1;
  }
  oncomment(e, t, i) {
    var n, s, r, a;
    this.endIndex = t, (s = (n = this.cbs).oncomment) === null || s === void 0 || s.call(n, this.getSlice(e, t - i)), (a = (r = this.cbs).oncommentend) === null || a === void 0 || a.call(r), this.startIndex = t + 1;
  }
  oncdata(e, t, i) {
    var n, s, r, a, u, c, h, p, f, _;
    this.endIndex = t;
    const C = this.getSlice(e, t - i);
    this.options.xmlMode || this.options.recognizeCDATA ? ((s = (n = this.cbs).oncdatastart) === null || s === void 0 || s.call(n), (a = (r = this.cbs).ontext) === null || a === void 0 || a.call(r, C), (c = (u = this.cbs).oncdataend) === null || c === void 0 || c.call(u)) : ((p = (h = this.cbs).oncomment) === null || p === void 0 || p.call(h, `[CDATA[${C}]]`), (_ = (f = this.cbs).oncommentend) === null || _ === void 0 || _.call(f)), this.startIndex = t + 1;
  }
  onend() {
    var e, t;
    if (this.cbs.onclosetag) {
      this.endIndex = this.startIndex;
      for (let i = this.stack.length; i > 0; this.cbs.onclosetag(this.stack[--i], !0))
        ;
    }
    (t = (e = this.cbs).onend) === null || t === void 0 || t.call(e);
  }
  reset() {
    var e, t, i, n;
    (t = (e = this.cbs).onreset) === null || t === void 0 || t.call(e), this.tokenizer.reset(), this.tagname = "", this.attribname = "", this.attribs = null, this.stack.length = 0, this.startIndex = 0, this.endIndex = 0, (n = (i = this.cbs).onparserinit) === null || n === void 0 || n.call(i, this), this.buffers.length = 0, this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1;
  }
  parseComplete(e) {
    this.reset(), this.end(e);
  }
  getSlice(e, t) {
    for (; e - this.bufferOffset >= this.buffers[0].length; )
      this.shiftBuffer();
    let i = this.buffers[0].slice(e - this.bufferOffset, t - this.bufferOffset);
    for (; t - this.bufferOffset > this.buffers[0].length; )
      this.shiftBuffer(), i += this.buffers[0].slice(0, t - this.bufferOffset);
    return i;
  }
  shiftBuffer() {
    this.bufferOffset += this.buffers[0].length, this.writeIndex--, this.buffers.shift();
  }
  write(e) {
    var t, i;
    if (this.ended) {
      (i = (t = this.cbs).onerror) === null || i === void 0 || i.call(t, new Error(".write() after done!"));
      return;
    }
    this.buffers.push(e), this.tokenizer.running && (this.tokenizer.write(e), this.writeIndex++);
  }
  end(e) {
    var t, i;
    if (this.ended) {
      (i = (t = this.cbs).onerror) === null || i === void 0 || i.call(t, Error(".end() after done!"));
      return;
    }
    e && this.write(e), this.ended = !0, this.tokenizer.end();
  }
  pause() {
    this.tokenizer.pause();
  }
  resume() {
    for (this.tokenizer.resume(); this.tokenizer.running && this.writeIndex < this.buffers.length; )
      this.tokenizer.write(this.buffers[this.writeIndex++]);
    this.ended && this.tokenizer.end();
  }
  parseChunk(e) {
    this.write(e);
  }
  done(e) {
    this.end(e);
  }
};
l(pu, "Parser");
var rb = {};
Jo(rb, {
  CDATA: () => pb,
  Comment: () => ub,
  Directive: () => lb,
  Doctype: () => fb,
  ElementType: () => Me,
  Root: () => ob,
  Script: () => cb,
  Style: () => hb,
  Tag: () => db,
  Text: () => ab,
  isTag: () => Mm
});
var Me;
(function(e) {
  e.Root = "root", e.Text = "text", e.Directive = "directive", e.Comment = "comment", e.Script = "script", e.Style = "style", e.Tag = "tag", e.CDATA = "cdata", e.Doctype = "doctype";
})(Me || (Me = {}));
function Mm(e) {
  return e.type === Me.Tag || e.type === Me.Script || e.type === Me.Style;
}
l(Mm, "isTag");
var ob = Me.Root, ab = Me.Text, lb = Me.Directive, ub = Me.Comment, cb = Me.Script, hb = Me.Style, db = Me.Tag, pb = Me.CDATA, fb = Me.Doctype, Nm = class {
  constructor() {
    this.parent = null, this.prev = null, this.next = null, this.startIndex = null, this.endIndex = null;
  }
  get parentNode() {
    return this.parent;
  }
  set parentNode(e) {
    this.parent = e;
  }
  get previousSibling() {
    return this.prev;
  }
  set previousSibling(e) {
    this.prev = e;
  }
  get nextSibling() {
    return this.next;
  }
  set nextSibling(e) {
    this.next = e;
  }
  cloneNode(e = !1) {
    return Fm(this, e);
  }
};
l(Nm, "Node");
var fu = class extends Nm {
  constructor(e) {
    super(), this.data = e;
  }
  get nodeValue() {
    return this.data;
  }
  set nodeValue(e) {
    this.data = e;
  }
};
l(fu, "DataNode");
var jl = class extends fu {
  constructor() {
    super(...arguments), this.type = Me.Text;
  }
  get nodeType() {
    return 3;
  }
};
l(jl, "Text");
var Rm = class extends fu {
  constructor() {
    super(...arguments), this.type = Me.Comment;
  }
  get nodeType() {
    return 8;
  }
};
l(Rm, "Comment");
var Lm = class extends fu {
  constructor(e, t) {
    super(t), this.name = e, this.type = Me.Directive;
  }
  get nodeType() {
    return 1;
  }
};
l(Lm, "ProcessingInstruction");
var mu = class extends Nm {
  constructor(e) {
    super(), this.children = e;
  }
  get firstChild() {
    var e;
    return (e = this.children[0]) !== null && e !== void 0 ? e : null;
  }
  get lastChild() {
    return this.children.length > 0 ? this.children[this.children.length - 1] : null;
  }
  get childNodes() {
    return this.children;
  }
  set childNodes(e) {
    this.children = e;
  }
};
l(mu, "NodeWithChildren");
var Dm = class extends mu {
  constructor() {
    super(...arguments), this.type = Me.CDATA;
  }
  get nodeType() {
    return 4;
  }
};
l(Dm, "CDATA");
var Hl = class extends mu {
  constructor() {
    super(...arguments), this.type = Me.Root;
  }
  get nodeType() {
    return 9;
  }
};
l(Hl, "Document");
var Bm = class extends mu {
  constructor(e, t, i = [], n = e === "script" ? Me.Script : e === "style" ? Me.Style : Me.Tag) {
    super(i), this.name = e, this.attribs = t, this.type = n;
  }
  get nodeType() {
    return 1;
  }
  get tagName() {
    return this.name;
  }
  set tagName(e) {
    this.name = e;
  }
  get attributes() {
    return Object.keys(this.attribs).map((e) => {
      var t, i;
      return {
        name: e,
        value: this.attribs[e],
        namespace: (t = this["x-attribsNamespace"]) === null || t === void 0 ? void 0 : t[e],
        prefix: (i = this["x-attribsPrefix"]) === null || i === void 0 ? void 0 : i[e]
      };
    });
  }
};
l(Bm, "Element");
function Mt(e) {
  return Mm(e);
}
l(Mt, "isTag");
function aa(e) {
  return e.type === Me.CDATA;
}
l(aa, "isCDATA");
function jn(e) {
  return e.type === Me.Text;
}
l(jn, "isText");
function vu(e) {
  return e.type === Me.Comment;
}
l(vu, "isComment");
function mb(e) {
  return e.type === Me.Directive;
}
l(mb, "isDirective");
function Om(e) {
  return e.type === Me.Root;
}
l(Om, "isDocument");
function on(e) {
  return Object.prototype.hasOwnProperty.call(e, "children");
}
l(on, "hasChildren");
function Fm(e, t = !1) {
  let i;
  if (jn(e))
    i = new jl(e.data);
  else if (vu(e))
    i = new Rm(e.data);
  else if (Mt(e)) {
    const n = t ? nl(e.children) : [], s = new Bm(e.name, xo({}, e.attribs), n);
    n.forEach((r) => r.parent = s), e.namespace != null && (s.namespace = e.namespace), e["x-attribsNamespace"] && (s["x-attribsNamespace"] = xo({}, e["x-attribsNamespace"])), e["x-attribsPrefix"] && (s["x-attribsPrefix"] = xo({}, e["x-attribsPrefix"])), i = s;
  } else if (aa(e)) {
    const n = t ? nl(e.children) : [], s = new Dm(n);
    n.forEach((r) => r.parent = s), i = s;
  } else if (Om(e)) {
    const n = t ? nl(e.children) : [], s = new Hl(n);
    n.forEach((r) => r.parent = s), e["x-mode"] && (s["x-mode"] = e["x-mode"]), i = s;
  } else if (mb(e)) {
    const n = new Lm(e.name, e.data);
    e["x-name"] != null && (n["x-name"] = e["x-name"], n["x-publicId"] = e["x-publicId"], n["x-systemId"] = e["x-systemId"]), i = n;
  } else
    throw new Error(`Not implemented yet: ${e.type}`);
  return i.startIndex = e.startIndex, i.endIndex = e.endIndex, e.sourceCodeLocation != null && (i.sourceCodeLocation = e.sourceCodeLocation), i;
}
l(Fm, "cloneNode");
function nl(e) {
  const t = e.map((i) => Fm(i, !0));
  for (let i = 1; i < t.length; i++)
    t[i].prev = t[i - 1], t[i - 1].next = t[i];
  return t;
}
l(nl, "cloneChildren");
var X5 = {
  withStartIndices: !1,
  withEndIndices: !1,
  xmlMode: !1
}, $o = class {
  constructor(e, t, i) {
    this.dom = [], this.root = new Hl(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null, typeof t == "function" && (i = t, t = X5), typeof e == "object" && (t = e, e = void 0), this.callback = e ?? null, this.options = t ?? X5, this.elementCB = i ?? null;
  }
  onparserinit(e) {
    this.parser = e;
  }
  onreset() {
    this.dom = [], this.root = new Hl(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null;
  }
  onend() {
    this.done || (this.done = !0, this.parser = null, this.handleCallback(null));
  }
  onerror(e) {
    this.handleCallback(e);
  }
  onclosetag() {
    this.lastNode = null;
    const e = this.tagStack.pop();
    this.options.withEndIndices && (e.endIndex = this.parser.endIndex), this.elementCB && this.elementCB(e);
  }
  onopentag(e, t) {
    const i = this.options.xmlMode ? Me.Tag : void 0, n = new Bm(e, t, void 0, i);
    this.addNode(n), this.tagStack.push(n);
  }
  ontext(e) {
    const { lastNode: t } = this;
    if (t && t.type === Me.Text)
      t.data += e, this.options.withEndIndices && (t.endIndex = this.parser.endIndex);
    else {
      const i = new jl(e);
      this.addNode(i), this.lastNode = i;
    }
  }
  oncomment(e) {
    if (this.lastNode && this.lastNode.type === Me.Comment) {
      this.lastNode.data += e;
      return;
    }
    const t = new Rm(e);
    this.addNode(t), this.lastNode = t;
  }
  oncommentend() {
    this.lastNode = null;
  }
  oncdatastart() {
    const e = new jl(""), t = new Dm([e]);
    this.addNode(t), e.parent = t, this.lastNode = e;
  }
  oncdataend() {
    this.lastNode = null;
  }
  onprocessinginstruction(e, t) {
    const i = new Lm(e, t);
    this.addNode(i);
  }
  handleCallback(e) {
    if (typeof this.callback == "function")
      this.callback(e, this.dom);
    else if (e)
      throw e;
  }
  addNode(e) {
    const t = this.tagStack[this.tagStack.length - 1], i = t.children[t.children.length - 1];
    this.options.withStartIndices && (e.startIndex = this.parser.startIndex), this.options.withEndIndices && (e.endIndex = this.parser.endIndex), t.children.push(e), i && (e.prev = i, i.next = e), e.parent = t, this.lastNode = null;
  }
};
l($o, "DomHandler");
var gu = {};
Jo(gu, {
  DocumentPosition: () => ai,
  append: () => Rb,
  appendChild: () => Nb,
  compareDocumentPosition: () => Km,
  existsOne: () => $m,
  filter: () => la,
  find: () => _u,
  findAll: () => Ob,
  findOne: () => bu,
  findOneChild: () => Bb,
  getAttributeValue: () => Eb,
  getChildren: () => Hm,
  getElementById: () => jb,
  getElements: () => Ub,
  getElementsByTagName: () => As,
  getElementsByTagType: () => Hb,
  getFeed: () => wu,
  getInnerHTML: () => Tb,
  getName: () => Ab,
  getOuterHTML: () => jm,
  getParent: () => Wm,
  getSiblings: () => xb,
  getText: () => Lo,
  hasAttrib: () => kb,
  hasChildren: () => on,
  innerText: () => Wl,
  isCDATA: () => aa,
  isComment: () => vu,
  isDocument: () => Om,
  isTag: () => Mt,
  isText: () => jn,
  nextElementSibling: () => Ib,
  prepend: () => Db,
  prependChild: () => Lb,
  prevElementSibling: () => Pb,
  removeElement: () => wr,
  removeSubsets: () => Wb,
  replaceElement: () => Mb,
  testElement: () => Vb,
  textContent: () => Go,
  uniqueSort: () => $b
});
var J5 = /["&'<>$\x80-\uFFFF]/g, gC = /* @__PURE__ */ new Map([
  [34, "&quot;"],
  [38, "&amp;"],
  [39, "&apos;"],
  [60, "&lt;"],
  [62, "&gt;"]
]), yC = String.prototype.codePointAt != null ? (e, t) => e.codePointAt(t) : (e, t) => (e.charCodeAt(t) & 64512) === 55296 ? (e.charCodeAt(t) - 55296) * 1024 + e.charCodeAt(t + 1) - 56320 + 65536 : e.charCodeAt(t);
function Vm(e) {
  let t = "", i = 0, n;
  for (; (n = J5.exec(e)) !== null; ) {
    const s = n.index, r = e.charCodeAt(s), a = gC.get(r);
    a !== void 0 ? (t += e.substring(i, s) + a, i = s + 1) : (t += `${e.substring(i, s)}&#x${yC(e, s).toString(16)};`, i = J5.lastIndex += Number((r & 64512) === 55296));
  }
  return t + e.substr(i);
}
l(Vm, "encodeXML");
function Um(e, t) {
  return /* @__PURE__ */ l(function(n) {
    let s, r = 0, a = "";
    for (; s = e.exec(n); )
      r !== s.index && (a += n.substring(r, s.index)), a += t.get(s[0].charCodeAt(0)), r = s.index + 1;
    return a + n.substring(r);
  }, "escape");
}
l(Um, "getEscaper");
var _C = Um(/["&\u00A0]/g, /* @__PURE__ */ new Map([
  [34, "&quot;"],
  [38, "&amp;"],
  [160, "&nbsp;"]
])), bC = Um(/[&<>\u00A0]/g, /* @__PURE__ */ new Map([
  [38, "&amp;"],
  [60, "&lt;"],
  [62, "&gt;"],
  [160, "&nbsp;"]
])), Z5;
(function(e) {
  e[e.XML = 0] = "XML", e[e.HTML = 1] = "HTML";
})(Z5 || (Z5 = {}));
var Q5;
(function(e) {
  e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict";
})(Q5 || (Q5 = {}));
var e2;
(function(e) {
  e[e.UTF8 = 0] = "UTF8", e[e.ASCII = 1] = "ASCII", e[e.Extensive = 2] = "Extensive", e[e.Attribute = 3] = "Attribute", e[e.Text = 4] = "Text";
})(e2 || (e2 = {}));
var wC = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map((e) => [e.toLowerCase(), e])), SC = new Map([
  "definitionURL",
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map((e) => [e.toLowerCase(), e])), CC = /* @__PURE__ */ new Set([
  "style",
  "script",
  "xmp",
  "iframe",
  "noembed",
  "noframes",
  "plaintext",
  "noscript"
]);
function vb(e) {
  return e.replace(/"/g, "&quot;");
}
l(vb, "replaceQuotes");
function gb(e, t) {
  var i;
  if (!e)
    return;
  const n = ((i = t.encodeEntities) !== null && i !== void 0 ? i : t.decodeEntities) === !1 ? vb : t.xmlMode || t.encodeEntities !== "utf8" ? Vm : _C;
  return Object.keys(e).map((s) => {
    var r, a;
    const u = (r = e[s]) !== null && r !== void 0 ? r : "";
    return t.xmlMode === "foreign" && (s = (a = SC.get(s)) !== null && a !== void 0 ? a : s), !t.emptyAttrs && !t.xmlMode && u === "" ? s : `${s}="${n(u)}"`;
  }).join(" ");
}
l(gb, "formatAttributes");
var t2 = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]);
function yu(e, t = {}) {
  const i = "length" in e ? e : [e];
  let n = "";
  for (let s = 0; s < i.length; s++)
    n += yb(i[s], t);
  return n;
}
l(yu, "render");
var TC = yu;
function yb(e, t) {
  switch (e.type) {
    case ob:
      return yu(e.children, t);
    case fb:
    case lb:
      return bb(e);
    case ub:
      return Cb(e);
    case pb:
      return Sb(e);
    case cb:
    case hb:
    case db:
      return _b(e, t);
    case ab:
      return wb(e, t);
  }
}
l(yb, "renderNode");
var xC = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignObject",
  "desc",
  "title"
]), EC = /* @__PURE__ */ new Set(["svg", "math"]);
function _b(e, t) {
  var i;
  t.xmlMode === "foreign" && (e.name = (i = wC.get(e.name)) !== null && i !== void 0 ? i : e.name, e.parent && xC.has(e.parent.name) && (t = T5(xo({}, t), { xmlMode: !1 }))), !t.xmlMode && EC.has(e.name) && (t = T5(xo({}, t), { xmlMode: "foreign" }));
  let n = `<${e.name}`;
  const s = gb(e.attribs, t);
  return s && (n += ` ${s}`), e.children.length === 0 && (t.xmlMode ? t.selfClosingTags !== !1 : t.selfClosingTags && t2.has(e.name)) ? (t.xmlMode || (n += " "), n += "/>") : (n += ">", e.children.length > 0 && (n += yu(e.children, t)), (t.xmlMode || !t2.has(e.name)) && (n += `</${e.name}>`)), n;
}
l(_b, "renderTag");
function bb(e) {
  return `<${e.data}>`;
}
l(bb, "renderDirective");
function wb(e, t) {
  var i;
  let n = e.data || "";
  return ((i = t.encodeEntities) !== null && i !== void 0 ? i : t.decodeEntities) !== !1 && !(!t.xmlMode && e.parent && CC.has(e.parent.name)) && (n = t.xmlMode || t.encodeEntities !== "utf8" ? Vm(n) : bC(n)), n;
}
l(wb, "renderText");
function Sb(e) {
  return `<![CDATA[${e.children[0].data}]]>`;
}
l(Sb, "renderCdata");
function Cb(e) {
  return `<!--${e.data}-->`;
}
l(Cb, "renderComment");
function jm(e, t) {
  return TC(e, t);
}
l(jm, "getOuterHTML");
function Tb(e, t) {
  return on(e) ? e.children.map((i) => jm(i, t)).join("") : "";
}
l(Tb, "getInnerHTML");
function Lo(e) {
  return Array.isArray(e) ? e.map(Lo).join("") : Mt(e) ? e.name === "br" ? `
` : Lo(e.children) : aa(e) ? Lo(e.children) : jn(e) ? e.data : "";
}
l(Lo, "getText");
function Go(e) {
  return Array.isArray(e) ? e.map(Go).join("") : on(e) && !vu(e) ? Go(e.children) : jn(e) ? e.data : "";
}
l(Go, "textContent");
function Wl(e) {
  return Array.isArray(e) ? e.map(Wl).join("") : on(e) && (e.type === Me.Tag || aa(e)) ? Wl(e.children) : jn(e) ? e.data : "";
}
l(Wl, "innerText");
function Hm(e) {
  return on(e) ? e.children : [];
}
l(Hm, "getChildren");
function Wm(e) {
  return e.parent || null;
}
l(Wm, "getParent");
function xb(e) {
  const t = Wm(e);
  if (t != null)
    return Hm(t);
  const i = [e];
  let { prev: n, next: s } = e;
  for (; n != null; )
    i.unshift(n), { prev: n } = n;
  for (; s != null; )
    i.push(s), { next: s } = s;
  return i;
}
l(xb, "getSiblings");
function Eb(e, t) {
  var i;
  return (i = e.attribs) === null || i === void 0 ? void 0 : i[t];
}
l(Eb, "getAttributeValue");
function kb(e, t) {
  return e.attribs != null && Object.prototype.hasOwnProperty.call(e.attribs, t) && e.attribs[t] != null;
}
l(kb, "hasAttrib");
function Ab(e) {
  return e.name;
}
l(Ab, "getName");
function Ib(e) {
  let { next: t } = e;
  for (; t !== null && !Mt(t); )
    ({ next: t } = t);
  return t;
}
l(Ib, "nextElementSibling");
function Pb(e) {
  let { prev: t } = e;
  for (; t !== null && !Mt(t); )
    ({ prev: t } = t);
  return t;
}
l(Pb, "prevElementSibling");
function wr(e) {
  if (e.prev && (e.prev.next = e.next), e.next && (e.next.prev = e.prev), e.parent) {
    const t = e.parent.children;
    t.splice(t.lastIndexOf(e), 1);
  }
}
l(wr, "removeElement");
function Mb(e, t) {
  const i = t.prev = e.prev;
  i && (i.next = t);
  const n = t.next = e.next;
  n && (n.prev = t);
  const s = t.parent = e.parent;
  if (s) {
    const r = s.children;
    r[r.lastIndexOf(e)] = t, e.parent = null;
  }
}
l(Mb, "replaceElement");
function Nb(e, t) {
  if (wr(t), t.next = null, t.parent = e, e.children.push(t) > 1) {
    const i = e.children[e.children.length - 2];
    i.next = t, t.prev = i;
  } else
    t.prev = null;
}
l(Nb, "appendChild");
function Rb(e, t) {
  wr(t);
  const { parent: i } = e, n = e.next;
  if (t.next = n, t.prev = e, e.next = t, t.parent = i, n) {
    if (n.prev = t, i) {
      const s = i.children;
      s.splice(s.lastIndexOf(n), 0, t);
    }
  } else
    i && i.children.push(t);
}
l(Rb, "append");
function Lb(e, t) {
  if (wr(t), t.parent = e, t.prev = null, e.children.unshift(t) !== 1) {
    const i = e.children[1];
    i.prev = t, t.next = i;
  } else
    t.next = null;
}
l(Lb, "prependChild");
function Db(e, t) {
  wr(t);
  const { parent: i } = e;
  if (i) {
    const n = i.children;
    n.splice(n.indexOf(e), 0, t);
  }
  e.prev && (e.prev.next = t), t.parent = i, t.prev = e.prev, t.next = e, e.prev = t;
}
l(Db, "prepend");
function la(e, t, i = !0, n = 1 / 0) {
  return Array.isArray(t) || (t = [t]), _u(e, t, i, n);
}
l(la, "filter");
function _u(e, t, i, n) {
  const s = [];
  for (const r of t) {
    if (e(r) && (s.push(r), --n <= 0))
      break;
    if (i && on(r) && r.children.length > 0) {
      const a = _u(e, r.children, i, n);
      if (s.push(...a), n -= a.length, n <= 0)
        break;
    }
  }
  return s;
}
l(_u, "find");
function Bb(e, t) {
  return t.find(e);
}
l(Bb, "findOneChild");
function bu(e, t, i = !0) {
  let n = null;
  for (let s = 0; s < t.length && !n; s++) {
    const r = t[s];
    if (Mt(r))
      e(r) ? n = r : i && r.children.length > 0 && (n = bu(e, r.children, !0));
    else
      continue;
  }
  return n;
}
l(bu, "findOne");
function $m(e, t) {
  return t.some((i) => Mt(i) && (e(i) || i.children.length > 0 && $m(e, i.children)));
}
l($m, "existsOne");
function Ob(e, t) {
  var i;
  const n = [], s = t.filter(Mt);
  let r;
  for (; r = s.shift(); ) {
    const a = (i = r.children) === null || i === void 0 ? void 0 : i.filter(Mt);
    a && a.length > 0 && s.unshift(...a), e(r) && n.push(r);
  }
  return n;
}
l(Ob, "findAll");
var $l = {
  tag_name(e) {
    return typeof e == "function" ? (t) => Mt(t) && e(t.name) : e === "*" ? Mt : (t) => Mt(t) && t.name === e;
  },
  tag_type(e) {
    return typeof e == "function" ? (t) => e(t.type) : (t) => t.type === e;
  },
  tag_contains(e) {
    return typeof e == "function" ? (t) => jn(t) && e(t.data) : (t) => jn(t) && t.data === e;
  }
};
function Gm(e, t) {
  return typeof t == "function" ? (i) => Mt(i) && t(i.attribs[e]) : (i) => Mt(i) && i.attribs[e] === t;
}
l(Gm, "getAttribCheck");
function Fb(e, t) {
  return (i) => e(i) || t(i);
}
l(Fb, "combineFuncs");
function qm(e) {
  const t = Object.keys(e).map((i) => {
    const n = e[i];
    return Object.prototype.hasOwnProperty.call($l, i) ? $l[i](n) : Gm(i, n);
  });
  return t.length === 0 ? null : t.reduce(Fb);
}
l(qm, "compileTest");
function Vb(e, t) {
  const i = qm(e);
  return i ? i(t) : !0;
}
l(Vb, "testElement");
function Ub(e, t, i, n = 1 / 0) {
  const s = qm(e);
  return s ? la(s, t, i, n) : [];
}
l(Ub, "getElements");
function jb(e, t, i = !0) {
  return Array.isArray(t) || (t = [t]), bu(Gm("id", e), t, i);
}
l(jb, "getElementById");
function As(e, t, i = !0, n = 1 / 0) {
  return la($l.tag_name(e), t, i, n);
}
l(As, "getElementsByTagName");
function Hb(e, t, i = !0, n = 1 / 0) {
  return la($l.tag_type(e), t, i, n);
}
l(Hb, "getElementsByTagType");
function Wb(e) {
  let t = e.length;
  for (; --t >= 0; ) {
    const i = e[t];
    if (t > 0 && e.lastIndexOf(i, t - 1) >= 0) {
      e.splice(t, 1);
      continue;
    }
    for (let n = i.parent; n; n = n.parent)
      if (e.includes(n)) {
        e.splice(t, 1);
        break;
      }
  }
  return e;
}
l(Wb, "removeSubsets");
var ai;
(function(e) {
  e[e.DISCONNECTED = 1] = "DISCONNECTED", e[e.PRECEDING = 2] = "PRECEDING", e[e.FOLLOWING = 4] = "FOLLOWING", e[e.CONTAINS = 8] = "CONTAINS", e[e.CONTAINED_BY = 16] = "CONTAINED_BY";
})(ai || (ai = {}));
function Km(e, t) {
  const i = [], n = [];
  if (e === t)
    return 0;
  let s = on(e) ? e : e.parent;
  for (; s; )
    i.unshift(s), s = s.parent;
  for (s = on(t) ? t : t.parent; s; )
    n.unshift(s), s = s.parent;
  const r = Math.min(i.length, n.length);
  let a = 0;
  for (; a < r && i[a] === n[a]; )
    a++;
  if (a === 0)
    return ai.DISCONNECTED;
  const u = i[a - 1], c = u.children, h = i[a], p = n[a];
  return c.indexOf(h) > c.indexOf(p) ? u === t ? ai.FOLLOWING | ai.CONTAINED_BY : ai.FOLLOWING : u === e ? ai.PRECEDING | ai.CONTAINS : ai.PRECEDING;
}
l(Km, "compareDocumentPosition");
function $b(e) {
  return e = e.filter((t, i, n) => !n.includes(t, i + 1)), e.sort((t, i) => {
    const n = Km(t, i);
    return n & ai.PRECEDING ? -1 : n & ai.FOLLOWING ? 1 : 0;
  }), e;
}
l($b, "uniqueSort");
function wu(e) {
  const t = qo(Kb, e);
  return t ? t.name === "feed" ? Gb(t) : qb(t) : null;
}
l(wu, "getFeed");
function Gb(e) {
  var t;
  const i = e.children, n = {
    type: "atom",
    items: As("entry", i).map((a) => {
      var u;
      const { children: c } = a, h = { media: zm(c) };
      It(h, "id", "id", c), It(h, "title", "title", c);
      const p = (u = qo("link", c)) === null || u === void 0 ? void 0 : u.attribs.href;
      p && (h.link = p);
      const f = Nn("summary", c) || Nn("content", c);
      f && (h.description = f);
      const _ = Nn("updated", c);
      return _ && (h.pubDate = new Date(_)), h;
    })
  };
  It(n, "id", "id", i), It(n, "title", "title", i);
  const s = (t = qo("link", i)) === null || t === void 0 ? void 0 : t.attribs.href;
  s && (n.link = s), It(n, "description", "subtitle", i);
  const r = Nn("updated", i);
  return r && (n.updated = new Date(r)), It(n, "author", "email", i, !0), n;
}
l(Gb, "getAtomFeed");
function qb(e) {
  var t, i;
  const n = (i = (t = qo("channel", e.children)) === null || t === void 0 ? void 0 : t.children) !== null && i !== void 0 ? i : [], s = {
    type: e.name.substr(0, 3),
    id: "",
    items: As("item", e.children).map((a) => {
      const { children: u } = a, c = { media: zm(u) };
      It(c, "id", "guid", u), It(c, "title", "title", u), It(c, "link", "link", u), It(c, "description", "description", u);
      const h = Nn("pubDate", u);
      return h && (c.pubDate = new Date(h)), c;
    })
  };
  It(s, "title", "title", n), It(s, "link", "link", n), It(s, "description", "description", n);
  const r = Nn("lastBuildDate", n);
  return r && (s.updated = new Date(r)), It(s, "author", "managingEditor", n, !0), s;
}
l(qb, "getRssFeed");
var kC = ["url", "type", "lang"], AC = [
  "fileSize",
  "bitrate",
  "framerate",
  "samplingrate",
  "channels",
  "duration",
  "height",
  "width"
];
function zm(e) {
  return As("media:content", e).map((t) => {
    const { attribs: i } = t, n = {
      medium: i.medium,
      isDefault: !!i.isDefault
    };
    for (const s of kC)
      i[s] && (n[s] = i[s]);
    for (const s of AC)
      i[s] && (n[s] = parseInt(i[s], 10));
    return i.expression && (n.expression = i.expression), n;
  });
}
l(zm, "getMediaElements");
function qo(e, t) {
  return As(e, t, !0, 1)[0];
}
l(qo, "getOneElement");
function Nn(e, t, i = !1) {
  return Go(As(e, t, i, 1)).trim();
}
l(Nn, "fetch");
function It(e, t, i, n, s = !1) {
  const r = Nn(i, n, s);
  r && (e[t] = r);
}
l(It, "addConditionally");
function Kb(e) {
  return e === "rss" || e === "feed" || e === "rdf:RDF";
}
l(Kb, "isValidFeed");
function Ym(e, t) {
  const i = new $o(void 0, t);
  return new pu(i, t).end(e), i.root;
}
l(Ym, "parseDocument");
function Xm(e, t) {
  return Ym(e, t).children;
}
l(Xm, "parseDOM");
function zb(e, t, i) {
  const n = new $o(e, t, i);
  return new pu(n, t);
}
l(zb, "createDomStream");
function Yb(e, t = { xmlMode: !0 }) {
  return wu(Xm(e, t));
}
l(Yb, "parseFeed");
var Hn = -1, Oe = 1, vt = 2, St = 3, an = 8, Pn = 9, fr = 10, Fn = 11, IC = /* @__PURE__ */ new Set(["ARTICLE", "ASIDE", "BLOCKQUOTE", "BODY", "BR", "BUTTON", "CANVAS", "CAPTION", "COL", "COLGROUP", "DD", "DIV", "DL", "DT", "EMBED", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", "LI", "UL", "OL", "P"]), PC = -1, MC = 1, NC = 4, RC = 128, LC = 1, i2 = 2, n2 = 4, DC = 8, BC = 16, OC = 32, Gl = "http://www.w3.org/2000/svg", {
  assign: FC,
  create: VC,
  defineProperties: UC,
  entries: jC,
  getOwnPropertyDescriptors: $E,
  keys: HC,
  setPrototypeOf: Gt
} = Object, Do = String, ei = /* @__PURE__ */ l((e) => e.nodeType === Oe ? e[re] : e, "getEnd"), ua = /* @__PURE__ */ l(({ ownerDocument: e }) => e[br].ignoreCase, "ignoreCase"), wi = /* @__PURE__ */ l((e, t) => {
  e[G] = t, t[pt] = e;
}, "knownAdjacent"), Xb = /* @__PURE__ */ l((e, t, i) => {
  wi(e, t), wi(ei(t), i);
}, "knownBoundaries"), WC = /* @__PURE__ */ l((e, t, i, n) => {
  wi(e, t), wi(ei(i), n);
}, "knownSegment"), Su = /* @__PURE__ */ l((e, t, i) => {
  wi(e, t), wi(t, i);
}, "knownSiblings"), gc = /* @__PURE__ */ l(({ localName: e, ownerDocument: t }) => t[br].ignoreCase ? e.toUpperCase() : e, "localCase"), Jb = /* @__PURE__ */ l((e, t) => {
  e && (e[G] = t), t && (t[pt] = e);
}, "setAdjacent"), Rn = /* @__PURE__ */ new WeakMap(), Cu = !1, ql = /* @__PURE__ */ new WeakMap(), ks = /* @__PURE__ */ new WeakMap(), Tu = /* @__PURE__ */ l((e, t, i, n) => {
  Cu && ks.has(e) && e.attributeChangedCallback && e.constructor.observedAttributes.includes(t) && e.attributeChangedCallback(t, i, n);
}, "attributeChangedCallback"), Zb = /* @__PURE__ */ l((e, t) => (i) => {
  if (ks.has(i)) {
    const n = ks.get(i);
    n.connected !== t && i.isConnected === t && (n.connected = t, e in i && i[e]());
  }
}, "createTrigger"), s2 = Zb("connectedCallback", !0), yc = /* @__PURE__ */ l((e) => {
  if (Cu) {
    s2(e), Rn.has(e) && (e = Rn.get(e).shadowRoot);
    let { [G]: t, [re]: i } = e;
    for (; t !== i; )
      t.nodeType === Oe && s2(t), t = t[G];
  }
}, "connectedCallback"), r2 = Zb("disconnectedCallback", !1), $C = /* @__PURE__ */ l((e) => {
  if (Cu) {
    r2(e), Rn.has(e) && (e = Rn.get(e).shadowRoot);
    let { [G]: t, [re]: i } = e;
    for (; t !== i; )
      t.nodeType === Oe && r2(t), t = t[G];
  }
}, "disconnectedCallback"), Qb = class {
  constructor(e) {
    this.ownerDocument = e, this.registry = /* @__PURE__ */ new Map(), this.waiting = /* @__PURE__ */ new Map(), this.active = !1;
  }
  define(e, t, i = {}) {
    const { ownerDocument: n, registry: s, waiting: r } = this;
    if (s.has(e))
      throw new Error("unable to redefine " + e);
    if (ql.has(t))
      throw new Error("unable to redefine the same class: " + t);
    this.active = Cu = !0;
    const { extends: a } = i;
    ql.set(t, {
      ownerDocument: n,
      options: { is: a ? e : "" },
      localName: a || e
    });
    const u = a ? (c) => c.localName === a && c.getAttribute("is") === e : (c) => c.localName === e;
    if (s.set(e, { Class: t, check: u }), r.has(e)) {
      for (const c of r.get(e))
        c(t);
      r.delete(e);
    }
    n.querySelectorAll(a ? `${a}[is="${e}"]` : e).forEach(this.upgrade, this);
  }
  upgrade(e) {
    if (ks.has(e))
      return;
    const { ownerDocument: t, registry: i } = this, n = e.getAttribute("is") || e.localName;
    if (i.has(n)) {
      const { Class: s, check: r } = i.get(n);
      if (r(e)) {
        const { attributes: a, isConnected: u } = e;
        for (const h of a)
          e.removeAttributeNode(h);
        const c = jC(e);
        for (const [h] of c)
          delete e[h];
        Gt(e, s.prototype), t[Ro] = { element: e, values: c }, new s(t, n), ks.set(e, { connected: u });
        for (const h of a)
          e.setAttributeNode(h);
        u && e.connectedCallback && e.connectedCallback();
      }
    }
  }
  whenDefined(e) {
    const { registry: t, waiting: i } = this;
    return new Promise((n) => {
      t.has(e) ? n(t.get(e).Class) : (i.has(e) || i.set(e, []), i.get(e).push(n));
    });
  }
  get(e) {
    const t = this.registry.get(e);
    return t && t.Class;
  }
};
l(Qb, "CustomElementRegistry");
var { Parser: GC } = tb, Us = /* @__PURE__ */ l((e, t, i) => {
  const n = e[re];
  return t.parentNode = e, Xb(n[pt], t, n), i && t.nodeType === Oe && yc(t), t;
}, "append"), qC = /* @__PURE__ */ l((e, t, i, n, s) => {
  i[Ge] = n, i.ownerElement = e, Su(t[pt], i, t), i.name === "class" && (e.className = n), s && Tu(e, i.name, null, n);
}, "attribute"), e4 = /* @__PURE__ */ l((e, t, i) => {
  const { active: n, registry: s } = e[vi];
  let r = e, a = null;
  const u = new GC({
    onprocessinginstruction(c, h) {
      c.toLowerCase() === "!doctype" && (e.doctype = h.slice(c.length).trim());
    },
    onopentag(c, h) {
      let p = !0;
      if (t) {
        if (a)
          r = Us(r, e.createElementNS(Gl, c), n), r.ownerSVGElement = a, p = !1;
        else if (c === "svg" || c === "SVG")
          a = e.createElementNS(Gl, c), r = Us(r, a, n), p = !1;
        else if (n) {
          const _ = c.includes("-") ? c : h.is || "";
          if (_ && s.has(_)) {
            const { Class: C } = s.get(_);
            r = Us(r, new C(), n), delete h.is, p = !1;
          }
        }
      }
      p && (r = Us(r, e.createElement(c), !1));
      let f = r[re];
      for (const _ of HC(h))
        qC(r, f, e.createAttribute(_), h[_], n);
    },
    oncomment(c) {
      Us(r, e.createComment(c), n);
    },
    ontext(c) {
      Us(r, e.createTextNode(c), n);
    },
    onclosetag() {
      t && r === a && (a = null), r = r.parentNode;
    }
  }, {
    lowerCaseAttributeNames: !1,
    decodeEntities: !0,
    xmlMode: !t
  });
  return u.write(i), u.end(), e;
}, "parseFromString"), Kl = /* @__PURE__ */ new Map(), Rt = /* @__PURE__ */ l((e, t) => {
  for (const i of [].concat(e))
    Kl.set(i, t), Kl.set(i.toUpperCase(), t);
}, "registerHTMLClass"), KC = Wi(t7(), 1), t4 = /* @__PURE__ */ l(({ [G]: e, [re]: t }, i) => {
  for (; e !== t; ) {
    switch (e.nodeType) {
      case vt:
        i4(e, i);
        break;
      case St:
      case an:
        n4(e, i);
        break;
      case Oe:
        r4(e, i), e = ei(e);
        break;
      case fr:
        s4(e, i);
        break;
    }
    e = e[G];
  }
  const n = i.length - 1, s = i[n];
  typeof s == "number" && s < 0 ? i[n] += Hn : i.push(Hn);
}, "loopSegment"), i4 = /* @__PURE__ */ l((e, t) => {
  t.push(vt, e.name);
  const i = e[Ge].trim();
  i && t.push(i);
}, "attrAsJSON"), n4 = /* @__PURE__ */ l((e, t) => {
  const i = e[Ge];
  i.trim() && t.push(e.nodeType, i);
}, "characterDataAsJSON"), zC = /* @__PURE__ */ l((e, t) => {
  t.push(e.nodeType), t4(e, t);
}, "nonElementAsJSON"), s4 = /* @__PURE__ */ l(({ name: e, publicId: t, systemId: i }, n) => {
  n.push(fr, e), t && n.push(t), i && n.push(i);
}, "documentTypeAsJSON"), r4 = /* @__PURE__ */ l((e, t) => {
  t.push(Oe, e.localName), t4(e, t);
}, "elementAsJSON"), o4 = /* @__PURE__ */ l((e, t, i, n, s, r) => ({ type: e, target: t, addedNodes: i, removedNodes: n, attributeName: s, oldValue: r }), "createRecord"), o2 = /* @__PURE__ */ l((e, t, i, n, s, r) => {
  if (!n || n.includes(i)) {
    const { callback: a, records: u, scheduled: c } = e;
    u.push(o4("attributes", t, [], [], i, s ? r : void 0)), c || (e.scheduled = !0, Promise.resolve().then(() => {
      e.scheduled = !1, a(u.splice(0), e);
    }));
  }
}, "queueAttribute"), Jm = /* @__PURE__ */ l((e, t, i) => {
  const { ownerDocument: n } = e, { active: s, observers: r } = n[Mn];
  if (s) {
    for (const a of r)
      for (const [
        u,
        {
          childList: c,
          subtree: h,
          attributes: p,
          attributeFilter: f,
          attributeOldValue: _
        }
      ] of a.nodes)
        if (c) {
          if (h && (u === n || u.contains(e)) || !h && u.children.includes(e)) {
            o2(a, e, t, f, _, i);
            break;
          }
        } else if (p && u === e) {
          o2(a, e, t, f, _, i);
          break;
        }
  }
}, "attributeChangedCallback"), Bo = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i } = e, { active: n, observers: s } = i[Mn];
  if (n) {
    for (const r of s)
      for (const [a, { subtree: u, childList: c, characterData: h }] of r.nodes)
        if (c && (t && (a === t || u && a.contains(t)) || !t && (u && (a === i || a.contains(e)) || !u && a[h ? "childNodes" : "children"].includes(e)))) {
          const { callback: p, records: f, scheduled: _ } = r;
          f.push(o4("childList", a, t ? [] : [e], t ? [e] : [])), _ || (r.scheduled = !0, Promise.resolve().then(() => {
            r.scheduled = !1, p(f.splice(0), r);
          }));
          break;
        }
  }
}, "moCallback"), a4 = class {
  constructor(e) {
    const t = /* @__PURE__ */ new Set();
    this.observers = t, this.active = !1, this.class = /* @__PURE__ */ l(class {
      constructor(n) {
        this.callback = n, this.nodes = /* @__PURE__ */ new Map(), this.records = [], this.scheduled = !1;
      }
      disconnect() {
        this.records.splice(0), this.nodes.clear(), t.delete(this), e[Mn].active = !!t.size;
      }
      observe(n, s = {
        subtree: !1,
        childList: !1,
        attributes: !1,
        attributeFilter: null,
        attributeOldValue: !1,
        characterData: !1
      }) {
        ("attributeOldValue" in s || "attributeFilter" in s) && (s.attributes = !0), s.childList = !!s.childList, s.subtree = !!s.subtree, this.nodes.set(n, s), t.add(this), e[Mn].active = !0;
      }
      takeRecords() {
        return this.records.splice(0);
      }
    }, "MutationObserver");
  }
};
l(a4, "MutationObserverClass");
var YC = /* @__PURE__ */ new Set([
  "allowfullscreen",
  "allowpaymentrequest",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "class",
  "contenteditable",
  "controls",
  "default",
  "defer",
  "disabled",
  "draggable",
  "formnovalidate",
  "hidden",
  "id",
  "ismap",
  "itemscope",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "playsinline",
  "readonly",
  "required",
  "reversed",
  "selected",
  "style",
  "truespeed"
]), _c = /* @__PURE__ */ l((e, t) => {
  const { [Ge]: i, name: n } = t;
  t.ownerElement = e, Su(e, t, e[G]), n === "class" && (e.className = i), Jm(e, n, null), Tu(e, n, null, i);
}, "setAttribute"), a2 = /* @__PURE__ */ l((e, t) => {
  const { [Ge]: i, name: n } = t;
  wi(t[pt], t[G]), t.ownerElement = t[pt] = t[G] = null, n === "class" && (e[Zs] = null), Jm(e, n, i), Tu(e, n, i, null);
}, "removeAttribute"), He = {
  get(e, t) {
    return e.hasAttribute(t);
  },
  set(e, t, i) {
    i ? e.setAttribute(t, "") : e.removeAttribute(t);
  }
}, Ln = {
  get(e, t) {
    return parseFloat(e.getAttribute(t) || 0);
  },
  set(e, t, i) {
    e.setAttribute(t, i);
  }
}, X = {
  get(e, t) {
    return e.getAttribute(t) || "";
  },
  set(e, t, i) {
    e.setAttribute(t, i);
  }
}, sl = /* @__PURE__ */ new WeakMap();
function l4(e, t) {
  return typeof t == "function" ? t.call(e.target, e) : t.handleEvent(e), e._stopImmediatePropagationFlag;
}
l(l4, "dispatch");
function u4({ currentTarget: e, target: t }) {
  const i = sl.get(e);
  if (i && i.has(this.type)) {
    const n = i.get(this.type);
    e === t ? this.eventPhase = this.AT_TARGET : this.eventPhase = this.BUBBLING_PHASE, this.currentTarget = e, this.target = t;
    for (const [s, r] of n)
      if (r && r.once && n.delete(s), l4(this, s))
        break;
    return delete this.currentTarget, delete this.target, this.cancelBubble;
  }
}
l(u4, "invokeListeners");
var xu = class {
  constructor() {
    sl.set(this, /* @__PURE__ */ new Map());
  }
  _getParent() {
    return null;
  }
  addEventListener(e, t, i) {
    const n = sl.get(this);
    n.has(e) || n.set(e, /* @__PURE__ */ new Map()), n.get(e).set(t, i);
  }
  removeEventListener(e, t) {
    const i = sl.get(this);
    if (i.has(e)) {
      const n = i.get(e);
      n.delete(t) && !n.size && i.delete(e);
    }
  }
  dispatchEvent(e) {
    let t = this;
    for (e.eventPhase = e.CAPTURING_PHASE; t; )
      t.dispatchEvent && e._path.push({ currentTarget: t, target: this }), t = e.bubbles && t._getParent && t._getParent();
    return e._path.some(u4, e), e._path = [], e.eventPhase = e.NONE, !e.defaultPrevented;
  }
};
l(xu, "DOMEventTarget");
var bi = class extends Array {
  item(e) {
    return e < this.length ? this[e] : null;
  }
};
l(bi, "NodeList");
var l2 = /* @__PURE__ */ l(({ parentNode: e }) => {
  let t = 0;
  for (; e; )
    t++, e = e.parentNode;
  return t;
}, "getParentNodeCount"), qn = class extends xu {
  static get ELEMENT_NODE() {
    return Oe;
  }
  static get ATTRIBUTE_NODE() {
    return vt;
  }
  static get TEXT_NODE() {
    return St;
  }
  static get COMMENT_NODE() {
    return an;
  }
  static get DOCUMENT_NODE() {
    return Pn;
  }
  static get DOCUMENT_FRAGMENT_NODE() {
    return Fn;
  }
  static get DOCUMENT_TYPE_NODE() {
    return fr;
  }
  constructor(e, t, i) {
    super(), this.ownerDocument = e, this.localName = t, this.nodeType = i, this.parentNode = null, this[G] = null, this[pt] = null;
  }
  get ELEMENT_NODE() {
    return Oe;
  }
  get ATTRIBUTE_NODE() {
    return vt;
  }
  get TEXT_NODE() {
    return St;
  }
  get COMMENT_NODE() {
    return an;
  }
  get DOCUMENT_NODE() {
    return Pn;
  }
  get DOCUMENT_FRAGMENT_NODE() {
    return Fn;
  }
  get DOCUMENT_TYPE_NODE() {
    return fr;
  }
  get baseURI() {
    const e = this.nodeType === Pn ? this : this.ownerDocument;
    if (e) {
      const t = e.querySelector("base");
      if (t)
        return t.getAttribute("href");
      const { location: i } = e.defaultView;
      if (i)
        return i.href;
    }
    return null;
  }
  get isConnected() {
    return !1;
  }
  get nodeName() {
    return this.localName;
  }
  get parentElement() {
    return null;
  }
  get previousSibling() {
    return null;
  }
  get previousElementSibling() {
    return null;
  }
  get nextSibling() {
    return null;
  }
  get nextElementSibling() {
    return null;
  }
  get childNodes() {
    return new bi();
  }
  get firstChild() {
    return null;
  }
  get lastChild() {
    return null;
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(e) {
  }
  get textContent() {
    return null;
  }
  set textContent(e) {
  }
  normalize() {
  }
  cloneNode() {
    return null;
  }
  contains() {
    return !1;
  }
  insertBefore(e, t) {
    return e;
  }
  appendChild(e) {
    return e;
  }
  replaceChild(e, t) {
    return t;
  }
  removeChild(e) {
    return e;
  }
  toString() {
    return "";
  }
  hasChildNodes() {
    return !!this.lastChild;
  }
  isSameNode(e) {
    return this === e;
  }
  compareDocumentPosition(e) {
    let t = 0;
    if (this !== e) {
      let i = l2(this), n = l2(e);
      if (i < n)
        t += n2, this.contains(e) && (t += BC);
      else if (n < i)
        t += i2, e.contains(this) && (t += DC);
      else if (i && n) {
        const { childNodes: s } = this.parentNode;
        s.indexOf(this) < s.indexOf(e) ? t += n2 : t += i2;
      }
      (!i || !n) && (t += OC, t += LC);
    }
    return t;
  }
  isEqualNode(e) {
    if (this === e)
      return !0;
    if (this.nodeType === e.nodeType) {
      switch (this.nodeType) {
        case Pn:
        case Fn: {
          const t = this.childNodes, i = e.childNodes;
          return t.length === i.length && t.every((n, s) => n.isEqualNode(i[s]));
        }
      }
      return this.toString() === e.toString();
    }
    return !1;
  }
  _getParent() {
    return this.parentNode;
  }
  getRootNode() {
    let e = this;
    for (; e.parentNode; )
      e = e.parentNode;
    return e.nodeType === Pn ? e.documentElement : e;
  }
};
l(qn, "Node");
var XC = /"/g, Is = class extends qn {
  constructor(e, t, i = "") {
    super(e, "#attribute", vt), this.ownerElement = null, this.name = Do(t), this[Ge] = Do(i), this[Ul] = !1;
  }
  get value() {
    return this[Ge];
  }
  set value(e) {
    const { [Ge]: t, name: i, ownerElement: n } = this;
    this[Ge] = Do(e), this[Ul] = !0, n && (Jm(n, i, t), Tu(n, i, t, this[Ge]));
  }
  cloneNode() {
    const { ownerDocument: e, name: t, [Ge]: i } = this;
    return new Is(e, t, i);
  }
  toString() {
    const { name: e, [Ge]: t } = this;
    return YC.has(e) && !t ? e : `${e}="${t.replace(XC, "&quot;")}"`;
  }
  toJSON() {
    const e = [];
    return i4(this, e), e;
  }
};
l(Is, "Attr");
var c4 = /* @__PURE__ */ l(({ ownerDocument: e, parentNode: t }) => {
  for (; t; ) {
    if (t === e)
      return !0;
    t = t.parentNode || t.host;
  }
  return !1;
}, "isConnected"), h4 = /* @__PURE__ */ l(({ parentNode: e }) => {
  if (e)
    switch (e.nodeType) {
      case Pn:
      case Fn:
        return null;
    }
  return e;
}, "parentElement"), Ko = /* @__PURE__ */ l(({ [pt]: e }) => {
  switch (e ? e.nodeType : 0) {
    case Hn:
      return e[Ut];
    case St:
    case an:
      return e;
  }
  return null;
}, "previousSibling"), bs = /* @__PURE__ */ l((e) => {
  const t = ei(e)[G];
  return t && (t.nodeType === Hn ? null : t);
}, "nextSibling"), Zm = /* @__PURE__ */ l((e) => {
  let t = bs(e);
  for (; t && t.nodeType !== Oe; )
    t = bs(t);
  return t;
}, "nextElementSibling"), d4 = /* @__PURE__ */ l((e) => {
  let t = Ko(e);
  for (; t && t.nodeType !== Oe; )
    t = Ko(t);
  return t;
}, "previousElementSibling"), Qm = /* @__PURE__ */ l((e, t) => {
  const i = e.createDocumentFragment();
  return i.append(...t), i;
}, "asFragment"), p4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && n.insertBefore(Qm(i, t), e);
}, "before"), f4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && n.insertBefore(Qm(i, t), ei(e)[G]);
}, "after"), m4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && (n.insertBefore(Qm(i, t), e), e.remove());
}, "replaceWith"), v4 = /* @__PURE__ */ l((e, t, i) => {
  const { parentNode: n, nodeType: s } = t;
  (e || i) && (Jb(e, i), t[pt] = null, ei(t)[G] = null), n && (t.parentNode = null, Bo(t, n), s === Oe && $C(t));
}, "remove"), ca = class extends qn {
  constructor(e, t, i, n) {
    super(e, t, i), this[Ge] = Do(n);
  }
  get isConnected() {
    return c4(this);
  }
  get parentElement() {
    return h4(this);
  }
  get previousSibling() {
    return Ko(this);
  }
  get nextSibling() {
    return bs(this);
  }
  get previousElementSibling() {
    return d4(this);
  }
  get nextElementSibling() {
    return Zm(this);
  }
  before(...e) {
    p4(this, e);
  }
  after(...e) {
    f4(this, e);
  }
  replaceWith(...e) {
    m4(this, e);
  }
  remove() {
    v4(this[pt], this, this[G]);
  }
  get data() {
    return this[Ge];
  }
  set data(e) {
    this[Ge] = Do(e), Bo(this, this.parentNode);
  }
  get nodeValue() {
    return this.data;
  }
  set nodeValue(e) {
    this.data = e;
  }
  get textContent() {
    return this.data;
  }
  set textContent(e) {
    this.data = e;
  }
  get length() {
    return this.data.length;
  }
  substringData(e, t) {
    return this.data.substr(e, t);
  }
  appendData(e) {
    this.data += e;
  }
  insertData(e, t) {
    const { data: i } = this;
    this.data = i.slice(0, e) + t + i.slice(e);
  }
  deleteData(e, t) {
    const { data: i } = this;
    this.data = i.slice(0, e) + i.slice(e + t);
  }
  replaceData(e, t, i) {
    const { data: n } = this;
    this.data = n.slice(0, e) + i + n.slice(e + t);
  }
  toJSON() {
    const e = [];
    return n4(this, e), e;
  }
};
l(ca, "CharacterData");
var ha = class extends ca {
  constructor(e, t = "") {
    super(e, "#comment", an, t);
  }
  cloneNode() {
    const { ownerDocument: e, [Ge]: t } = this;
    return new ha(e, t);
  }
  toString() {
    return `<!--${this[Ge]}-->`;
  }
};
l(ha, "Comment");
Wi(gr(), 1);
var ae;
(function(e) {
  e.Attribute = "attribute", e.Pseudo = "pseudo", e.PseudoElement = "pseudo-element", e.Tag = "tag", e.Universal = "universal", e.Adjacent = "adjacent", e.Child = "child", e.Descendant = "descendant", e.Parent = "parent", e.Sibling = "sibling", e.ColumnCombinator = "column-combinator";
})(ae || (ae = {}));
var lt;
(function(e) {
  e.Any = "any", e.Element = "element", e.End = "end", e.Equals = "equals", e.Exists = "exists", e.Hyphen = "hyphen", e.Not = "not", e.Start = "start";
})(lt || (lt = {}));
var u2 = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/, JC = /\\([\da-f]{1,6}\s?|(\s)|.)/gi, ZC = /* @__PURE__ */ new Map([
  [126, lt.Element],
  [94, lt.Start],
  [36, lt.End],
  [42, lt.Any],
  [33, lt.Not],
  [124, lt.Hyphen]
]), QC = /* @__PURE__ */ new Set([
  "has",
  "not",
  "matches",
  "is",
  "where",
  "host",
  "host-context"
]);
function g4(e) {
  switch (e.type) {
    case ae.Adjacent:
    case ae.Child:
    case ae.Descendant:
    case ae.Parent:
    case ae.Sibling:
    case ae.ColumnCombinator:
      return !0;
    default:
      return !1;
  }
}
l(g4, "isTraversal");
var eT = /* @__PURE__ */ new Set(["contains", "icontains"]);
function y4(e, t, i) {
  const n = parseInt(t, 16) - 65536;
  return n !== n || i ? t : n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, n & 1023 | 56320);
}
l(y4, "funescape");
function Qs(e) {
  return e.replace(JC, y4);
}
l(Qs, "unescapeCSS");
function rl(e) {
  return e === 39 || e === 34;
}
l(rl, "isQuote");
function bc(e) {
  return e === 32 || e === 9 || e === 10 || e === 12 || e === 13;
}
l(bc, "isWhitespace");
function ev(e) {
  const t = [], i = tv(t, `${e}`, 0);
  if (i < e.length)
    throw new Error(`Unmatched selector: ${e.slice(i)}`);
  return t;
}
l(ev, "parse");
function tv(e, t, i) {
  let n = [];
  function s(_) {
    const C = t.slice(i + _).match(u2);
    if (!C)
      throw new Error(`Expected name, found ${t.slice(i)}`);
    const [E] = C;
    return i += _ + E.length, Qs(E);
  }
  l(s, "getName");
  function r(_) {
    for (i += _; i < t.length && bc(t.charCodeAt(i)); )
      i++;
  }
  l(r, "stripWhitespace");
  function a() {
    i += 1;
    const _ = i;
    let C = 1;
    for (; C > 0 && i < t.length; i++)
      t.charCodeAt(i) === 40 && !u(i) ? C++ : t.charCodeAt(i) === 41 && !u(i) && C--;
    if (C)
      throw new Error("Parenthesis not matched");
    return Qs(t.slice(_, i - 1));
  }
  l(a, "readValueWithParenthesis");
  function u(_) {
    let C = 0;
    for (; t.charCodeAt(--_) === 92; )
      C++;
    return (C & 1) === 1;
  }
  l(u, "isEscaped");
  function c() {
    if (n.length > 0 && g4(n[n.length - 1]))
      throw new Error("Did not expect successive traversals.");
  }
  l(c, "ensureNotTraversal");
  function h(_) {
    if (n.length > 0 && n[n.length - 1].type === ae.Descendant) {
      n[n.length - 1].type = _;
      return;
    }
    c(), n.push({ type: _ });
  }
  l(h, "addTraversal");
  function p(_, C) {
    n.push({
      type: ae.Attribute,
      name: _,
      action: C,
      value: s(1),
      namespace: null,
      ignoreCase: "quirks"
    });
  }
  l(p, "addSpecialAttribute");
  function f() {
    if (n.length && n[n.length - 1].type === ae.Descendant && n.pop(), n.length === 0)
      throw new Error("Empty sub-selector");
    e.push(n);
  }
  if (l(f, "finalizeSubselector"), r(0), t.length === i)
    return i;
  e:
    for (; i < t.length; ) {
      const _ = t.charCodeAt(i);
      switch (_) {
        case 32:
        case 9:
        case 10:
        case 12:
        case 13: {
          (n.length === 0 || n[0].type !== ae.Descendant) && (c(), n.push({ type: ae.Descendant })), r(1);
          break;
        }
        case 62: {
          h(ae.Child), r(1);
          break;
        }
        case 60: {
          h(ae.Parent), r(1);
          break;
        }
        case 126: {
          h(ae.Sibling), r(1);
          break;
        }
        case 43: {
          h(ae.Adjacent), r(1);
          break;
        }
        case 46: {
          p("class", lt.Element);
          break;
        }
        case 35: {
          p("id", lt.Equals);
          break;
        }
        case 91: {
          r(1);
          let C, E = null;
          t.charCodeAt(i) === 124 ? C = s(1) : t.startsWith("*|", i) ? (E = "*", C = s(2)) : (C = s(0), t.charCodeAt(i) === 124 && t.charCodeAt(i + 1) !== 61 && (E = C, C = s(1))), r(0);
          let P = lt.Exists;
          const A = ZC.get(t.charCodeAt(i));
          if (A) {
            if (P = A, t.charCodeAt(i + 1) !== 61)
              throw new Error("Expected `=`");
            r(2);
          } else
            t.charCodeAt(i) === 61 && (P = lt.Equals, r(1));
          let F = "", M = null;
          if (P !== "exists") {
            if (rl(t.charCodeAt(i))) {
              const D = t.charCodeAt(i);
              let v = i + 1;
              for (; v < t.length && (t.charCodeAt(v) !== D || u(v)); )
                v += 1;
              if (t.charCodeAt(v) !== D)
                throw new Error("Attribute value didn't end");
              F = Qs(t.slice(i + 1, v)), i = v + 1;
            } else {
              const D = i;
              for (; i < t.length && (!bc(t.charCodeAt(i)) && t.charCodeAt(i) !== 93 || u(i)); )
                i += 1;
              F = Qs(t.slice(D, i));
            }
            r(0);
            const z = t.charCodeAt(i) | 32;
            z === 115 ? (M = !1, r(1)) : z === 105 && (M = !0, r(1));
          }
          if (t.charCodeAt(i) !== 93)
            throw new Error("Attribute selector didn't terminate");
          i += 1;
          const j = {
            type: ae.Attribute,
            name: C,
            action: P,
            value: F,
            namespace: E,
            ignoreCase: M
          };
          n.push(j);
          break;
        }
        case 58: {
          if (t.charCodeAt(i + 1) === 58) {
            n.push({
              type: ae.PseudoElement,
              name: s(2).toLowerCase(),
              data: t.charCodeAt(i) === 40 ? a() : null
            });
            continue;
          }
          const C = s(1).toLowerCase();
          let E = null;
          if (t.charCodeAt(i) === 40)
            if (QC.has(C)) {
              if (rl(t.charCodeAt(i + 1)))
                throw new Error(`Pseudo-selector ${C} cannot be quoted`);
              if (E = [], i = tv(E, t, i + 1), t.charCodeAt(i) !== 41)
                throw new Error(`Missing closing parenthesis in :${C} (${t})`);
              i += 1;
            } else {
              if (E = a(), eT.has(C)) {
                const P = E.charCodeAt(0);
                P === E.charCodeAt(E.length - 1) && rl(P) && (E = E.slice(1, -1));
              }
              E = Qs(E);
            }
          n.push({ type: ae.Pseudo, name: C, data: E });
          break;
        }
        case 44: {
          f(), n = [], r(1);
          break;
        }
        default: {
          if (t.startsWith("/*", i)) {
            const P = t.indexOf("*/", i + 2);
            if (P < 0)
              throw new Error("Comment was not terminated");
            i = P + 2, n.length === 0 && r(0);
            break;
          }
          let C = null, E;
          if (_ === 42)
            i += 1, E = "*";
          else if (_ === 124) {
            if (E = "", t.charCodeAt(i + 1) === 124) {
              h(ae.ColumnCombinator), r(2);
              break;
            }
          } else if (u2.test(t.slice(i)))
            E = s(0);
          else
            break e;
          t.charCodeAt(i) === 124 && t.charCodeAt(i + 1) !== 124 && (C = E, t.charCodeAt(i + 1) === 42 ? (E = "*", i += 2) : E = s(1)), n.push(E === "*" ? { type: ae.Universal, namespace: C } : { type: ae.Tag, name: E, namespace: C });
        }
      }
    }
  return f(), i;
}
l(tv, "parseSelector");
var Dn = Wi(gr(), 1), _4 = /* @__PURE__ */ new Map([
  [ae.Universal, 50],
  [ae.Tag, 30],
  [ae.Attribute, 1],
  [ae.Pseudo, 0]
]);
function Eu(e) {
  return !_4.has(e.type);
}
l(Eu, "isTraversal");
var tT = /* @__PURE__ */ new Map([
  [lt.Exists, 10],
  [lt.Equals, 8],
  [lt.Not, 7],
  [lt.Start, 6],
  [lt.End, 6],
  [lt.Any, 5]
]);
function b4(e) {
  const t = e.map(iv);
  for (let i = 1; i < e.length; i++) {
    const n = t[i];
    if (!(n < 0))
      for (let s = i - 1; s >= 0 && n < t[s]; s--) {
        const r = e[s + 1];
        e[s + 1] = e[s], e[s] = r, t[s + 1] = t[s], t[s] = n;
      }
  }
}
l(b4, "sortByProcedure");
function iv(e) {
  var t, i;
  let n = (t = _4.get(e.type)) !== null && t !== void 0 ? t : -1;
  return e.type === ae.Attribute ? (n = (i = tT.get(e.action)) !== null && i !== void 0 ? i : 4, e.action === lt.Equals && e.name === "id" && (n = 9), e.ignoreCase && (n >>= 1)) : e.type === ae.Pseudo && (e.data ? e.name === "has" || e.name === "contains" ? n = 0 : Array.isArray(e.data) ? (n = Math.min(...e.data.map((s) => Math.min(...s.map(iv)))), n < 0 && (n = 0)) : n = 2 : n = 3), n;
}
l(iv, "getProcedure");
var Na = Wi(gr(), 1), iT = /[-[\]{}()*+?.,\\^$|#\s]/g;
function wc(e) {
  return e.replace(iT, "\\$&");
}
l(wc, "escapeRegex");
var nT = /* @__PURE__ */ new Set([
  "accept",
  "accept-charset",
  "align",
  "alink",
  "axis",
  "bgcolor",
  "charset",
  "checked",
  "clear",
  "codetype",
  "color",
  "compact",
  "declare",
  "defer",
  "dir",
  "direction",
  "disabled",
  "enctype",
  "face",
  "frame",
  "hreflang",
  "http-equiv",
  "lang",
  "language",
  "link",
  "media",
  "method",
  "multiple",
  "nohref",
  "noresize",
  "noshade",
  "nowrap",
  "readonly",
  "rel",
  "rev",
  "rules",
  "scope",
  "scrolling",
  "selected",
  "shape",
  "target",
  "text",
  "type",
  "valign",
  "valuetype",
  "vlink"
]);
function _n(e, t) {
  return typeof e.ignoreCase == "boolean" ? e.ignoreCase : e.ignoreCase === "quirks" ? !!t.quirksMode : !t.xmlMode && nT.has(e.name);
}
l(_n, "shouldIgnoreCase");
var sT = {
  equals(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    return _n(t, i) ? (r = r.toLowerCase(), (a) => {
      const u = n.getAttributeValue(a, s);
      return u != null && u.length === r.length && u.toLowerCase() === r && e(a);
    }) : (a) => n.getAttributeValue(a, s) === r && e(a);
  },
  hyphen(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = r.length;
    return _n(t, i) ? (r = r.toLowerCase(), /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && (h.length === a || h.charAt(a) === "-") && h.substr(0, a).toLowerCase() === r && e(c);
    }, "hyphenIC")) : /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && (h.length === a || h.charAt(a) === "-") && h.substr(0, a) === r && e(c);
    }, "hyphen");
  },
  element(e, t, i) {
    const { adapter: n } = i, { name: s, value: r } = t;
    if (/\s/.test(r))
      return Na.default.falseFunc;
    const a = new RegExp(`(?:^|\\s)${wc(r)}(?:$|\\s)`, _n(t, i) ? "i" : "");
    return /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && h.length >= r.length && a.test(h) && e(c);
    }, "element");
  },
  exists(e, { name: t }, { adapter: i }) {
    return (n) => i.hasAttrib(n, t) && e(n);
  },
  start(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = r.length;
    return a === 0 ? Na.default.falseFunc : _n(t, i) ? (r = r.toLowerCase(), (u) => {
      const c = n.getAttributeValue(u, s);
      return c != null && c.length >= a && c.substr(0, a).toLowerCase() === r && e(u);
    }) : (u) => {
      var c;
      return !!(!((c = n.getAttributeValue(u, s)) === null || c === void 0) && c.startsWith(r)) && e(u);
    };
  },
  end(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = -r.length;
    return a === 0 ? Na.default.falseFunc : _n(t, i) ? (r = r.toLowerCase(), (u) => {
      var c;
      return ((c = n.getAttributeValue(u, s)) === null || c === void 0 ? void 0 : c.substr(a).toLowerCase()) === r && e(u);
    }) : (u) => {
      var c;
      return !!(!((c = n.getAttributeValue(u, s)) === null || c === void 0) && c.endsWith(r)) && e(u);
    };
  },
  any(e, t, i) {
    const { adapter: n } = i, { name: s, value: r } = t;
    if (r === "")
      return Na.default.falseFunc;
    if (_n(t, i)) {
      const a = new RegExp(wc(r), "i");
      return /* @__PURE__ */ l(function(c) {
        const h = n.getAttributeValue(c, s);
        return h != null && h.length >= r.length && a.test(h) && e(c);
      }, "anyIC");
    }
    return (a) => {
      var u;
      return !!(!((u = n.getAttributeValue(a, s)) === null || u === void 0) && u.includes(r)) && e(a);
    };
  },
  not(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    return r === "" ? (a) => !!n.getAttributeValue(a, s) && e(a) : _n(t, i) ? (r = r.toLowerCase(), (a) => {
      const u = n.getAttributeValue(a, s);
      return (u == null || u.length !== r.length || u.toLowerCase() !== r) && e(a);
    }) : (a) => n.getAttributeValue(a, s) !== r && e(a);
  }
}, rT = /* @__PURE__ */ new Set([9, 10, 12, 13, 32]), c2 = "0".charCodeAt(0), oT = "9".charCodeAt(0);
function w4(e) {
  if (e = e.trim().toLowerCase(), e === "even")
    return [2, 0];
  if (e === "odd")
    return [2, 1];
  let t = 0, i = 0, n = r(), s = a();
  if (t < e.length && e.charAt(t) === "n" && (t++, i = n * (s ?? 1), u(), t < e.length ? (n = r(), u(), s = a()) : n = s = 0), s === null || t < e.length)
    throw new Error(`n-th rule couldn't be parsed ('${e}')`);
  return [i, n * s];
  function r() {
    return e.charAt(t) === "-" ? (t++, -1) : (e.charAt(t) === "+" && t++, 1);
  }
  function a() {
    const c = t;
    let h = 0;
    for (; t < e.length && e.charCodeAt(t) >= c2 && e.charCodeAt(t) <= oT; )
      h = h * 10 + (e.charCodeAt(t) - c2), t++;
    return t === c ? null : h;
  }
  function u() {
    for (; t < e.length && rT.has(e.charCodeAt(t)); )
      t++;
  }
}
l(w4, "parse");
var h2 = Wi(gr(), 1);
function S4(e) {
  const t = e[0], i = e[1] - 1;
  if (i < 0 && t <= 0)
    return h2.default.falseFunc;
  if (t === -1)
    return (r) => r <= i;
  if (t === 0)
    return (r) => r === i;
  if (t === 1)
    return i < 0 ? h2.default.trueFunc : (r) => r >= i;
  const n = Math.abs(t), s = (i % n + n) % n;
  return t > 1 ? (r) => r >= i && r % n === s : (r) => r <= i && r % n === s;
}
l(S4, "compile");
function oo(e) {
  return S4(w4(e));
}
l(oo, "nthCheck");
var zt = Wi(gr(), 1);
function ao(e, t) {
  return (i) => {
    const n = t.getParent(i);
    return n != null && t.isTag(n) && e(i);
  };
}
l(ao, "getChildFunc");
var Sc = {
  contains(e, t, { adapter: i }) {
    return /* @__PURE__ */ l(function(s) {
      return e(s) && i.getText(s).includes(t);
    }, "contains");
  },
  icontains(e, t, { adapter: i }) {
    const n = t.toLowerCase();
    return /* @__PURE__ */ l(function(r) {
      return e(r) && i.getText(r).toLowerCase().includes(n);
    }, "icontains");
  },
  "nth-child"(e, t, { adapter: i, equals: n }) {
    const s = oo(t);
    return s === zt.default.falseFunc ? zt.default.falseFunc : s === zt.default.trueFunc ? ao(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = 0; h < u.length && !n(a, u[h]); h++)
        i.isTag(u[h]) && c++;
      return s(c) && e(a);
    }, "nthChild");
  },
  "nth-last-child"(e, t, { adapter: i, equals: n }) {
    const s = oo(t);
    return s === zt.default.falseFunc ? zt.default.falseFunc : s === zt.default.trueFunc ? ao(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = u.length - 1; h >= 0 && !n(a, u[h]); h--)
        i.isTag(u[h]) && c++;
      return s(c) && e(a);
    }, "nthLastChild");
  },
  "nth-of-type"(e, t, { adapter: i, equals: n }) {
    const s = oo(t);
    return s === zt.default.falseFunc ? zt.default.falseFunc : s === zt.default.trueFunc ? ao(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = 0; h < u.length; h++) {
        const p = u[h];
        if (n(a, p))
          break;
        i.isTag(p) && i.getName(p) === i.getName(a) && c++;
      }
      return s(c) && e(a);
    }, "nthOfType");
  },
  "nth-last-of-type"(e, t, { adapter: i, equals: n }) {
    const s = oo(t);
    return s === zt.default.falseFunc ? zt.default.falseFunc : s === zt.default.trueFunc ? ao(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = u.length - 1; h >= 0; h--) {
        const p = u[h];
        if (n(a, p))
          break;
        i.isTag(p) && i.getName(p) === i.getName(a) && c++;
      }
      return s(c) && e(a);
    }, "nthLastOfType");
  },
  root(e, t, { adapter: i }) {
    return (n) => {
      const s = i.getParent(n);
      return (s == null || !i.isTag(s)) && e(n);
    };
  },
  scope(e, t, i, n) {
    const { equals: s } = i;
    return !n || n.length === 0 ? Sc.root(e, t, i) : n.length === 1 ? (r) => s(n[0], r) && e(r) : (r) => n.includes(r) && e(r);
  },
  hover: ol("isHovered"),
  visited: ol("isVisited"),
  active: ol("isActive")
};
function ol(e) {
  return /* @__PURE__ */ l(function(i, n, { adapter: s }) {
    const r = s[e];
    return typeof r != "function" ? zt.default.falseFunc : /* @__PURE__ */ l(function(u) {
      return r(u) && i(u);
    }, "active");
  }, "dynamicPseudo");
}
l(ol, "dynamicStatePseudo");
var d2 = {
  empty(e, { adapter: t }) {
    return !t.getChildren(e).some((i) => t.isTag(i) || t.getText(i) !== "");
  },
  "first-child"(e, { adapter: t, equals: i }) {
    if (t.prevElementSibling)
      return t.prevElementSibling(e) == null;
    const n = t.getSiblings(e).find((s) => t.isTag(s));
    return n != null && i(e, n);
  },
  "last-child"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e);
    for (let s = n.length - 1; s >= 0; s--) {
      if (i(e, n[s]))
        return !0;
      if (t.isTag(n[s]))
        break;
    }
    return !1;
  },
  "first-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e), s = t.getName(e);
    for (let r = 0; r < n.length; r++) {
      const a = n[r];
      if (i(e, a))
        return !0;
      if (t.isTag(a) && t.getName(a) === s)
        break;
    }
    return !1;
  },
  "last-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e), s = t.getName(e);
    for (let r = n.length - 1; r >= 0; r--) {
      const a = n[r];
      if (i(e, a))
        return !0;
      if (t.isTag(a) && t.getName(a) === s)
        break;
    }
    return !1;
  },
  "only-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getName(e);
    return t.getSiblings(e).every((s) => i(e, s) || !t.isTag(s) || t.getName(s) !== n);
  },
  "only-child"(e, { adapter: t, equals: i }) {
    return t.getSiblings(e).every((n) => i(e, n) || !t.isTag(n));
  }
};
function Cc(e, t, i, n) {
  if (i === null) {
    if (e.length > n)
      throw new Error(`Pseudo-class :${t} requires an argument`);
  } else if (e.length === n)
    throw new Error(`Pseudo-class :${t} doesn't have any arguments`);
}
l(Cc, "verifyPseudoArgs");
var aT = {
  "any-link": ":is(a, area, link)[href]",
  link: ":any-link:not(:visited)",
  disabled: `:is(
        :is(button, input, select, textarea, optgroup, option)[disabled],
        optgroup[disabled] > option,
        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)
    )`,
  enabled: ":not(:disabled)",
  checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)",
  required: ":is(input, select, textarea)[required]",
  optional: ":is(input, select, textarea):not([required])",
  selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)",
  checkbox: "[type=checkbox]",
  file: "[type=file]",
  password: "[type=password]",
  radio: "[type=radio]",
  reset: "[type=reset]",
  image: "[type=image]",
  submit: "[type=submit]",
  parent: ":not(:empty)",
  header: ":is(h1, h2, h3, h4, h5, h6)",
  button: ":is(button, input[type=button])",
  input: ":is(input, textarea, select, button)",
  text: "input:is(:not([type!='']), [type=text])"
}, yi = Wi(gr(), 1), C4 = {};
function nv(e, t) {
  return e === yi.default.falseFunc ? yi.default.falseFunc : (i) => t.isTag(i) && e(i);
}
l(nv, "ensureIsTag");
function sv(e, t) {
  const i = t.getSiblings(e);
  if (i.length <= 1)
    return [];
  const n = i.indexOf(e);
  return n < 0 || n === i.length - 1 ? [] : i.slice(n + 1).filter(t.isTag);
}
l(sv, "getNextSiblings");
function zl(e) {
  return {
    xmlMode: !!e.xmlMode,
    lowerCaseAttributeNames: !!e.lowerCaseAttributeNames,
    lowerCaseTags: !!e.lowerCaseTags,
    quirksMode: !!e.quirksMode,
    cacheResults: !!e.cacheResults,
    pseudos: e.pseudos,
    adapter: e.adapter,
    equals: e.equals
  };
}
l(zl, "copyOptions");
var U1 = /* @__PURE__ */ l((e, t, i, n, s) => {
  const r = s(t, zl(i), n);
  return r === yi.default.trueFunc ? e : r === yi.default.falseFunc ? yi.default.falseFunc : (a) => r(a) && e(a);
}, "is"), j1 = {
  is: U1,
  matches: U1,
  where: U1,
  not(e, t, i, n, s) {
    const r = s(t, zl(i), n);
    return r === yi.default.falseFunc ? e : r === yi.default.trueFunc ? yi.default.falseFunc : (a) => !r(a) && e(a);
  },
  has(e, t, i, n, s) {
    const { adapter: r } = i, a = zl(i);
    a.relativeSelector = !0;
    const u = t.some((p) => p.some(Eu)) ? [C4] : void 0, c = s(t, a, u);
    if (c === yi.default.falseFunc)
      return yi.default.falseFunc;
    const h = nv(c, r);
    if (u && c !== yi.default.trueFunc) {
      const { shouldTestNextSiblings: p = !1 } = c;
      return (f) => {
        if (!e(f))
          return !1;
        u[0] = f;
        const _ = r.getChildren(f), C = p ? [..._, ...sv(f, r)] : _;
        return r.existsOne(h, C);
      };
    }
    return (p) => e(p) && r.existsOne(h, r.getChildren(p));
  }
};
function T4(e, t, i, n, s) {
  var r;
  const { name: a, data: u } = t;
  if (Array.isArray(u)) {
    if (!(a in j1))
      throw new Error(`Unknown pseudo-class :${a}(${u})`);
    return j1[a](e, u, i, n, s);
  }
  const c = (r = i.pseudos) === null || r === void 0 ? void 0 : r[a], h = typeof c == "string" ? c : aT[a];
  if (typeof h == "string") {
    if (u != null)
      throw new Error(`Pseudo ${a} doesn't have any arguments`);
    const p = ev(h);
    return j1.is(e, p, i, n, s);
  }
  if (typeof c == "function")
    return Cc(c, a, u, 1), (p) => c(p, u) && e(p);
  if (a in Sc)
    return Sc[a](e, u, i, n);
  if (a in d2) {
    const p = d2[a];
    return Cc(p, a, u, 2), (f) => p(f, i, u) && e(f);
  }
  throw new Error(`Unknown pseudo-class :${a}`);
}
l(T4, "compilePseudoSelector");
function al(e, t) {
  const i = t.getParent(e);
  return i && t.isTag(i) ? i : null;
}
l(al, "getElementParent");
function x4(e, t, i, n, s) {
  const { adapter: r, equals: a } = i;
  switch (t.type) {
    case ae.PseudoElement:
      throw new Error("Pseudo-elements are not supported by css-select");
    case ae.ColumnCombinator:
      throw new Error("Column combinators are not yet supported by css-select");
    case ae.Attribute: {
      if (t.namespace != null)
        throw new Error("Namespaced attributes are not yet supported by css-select");
      return (!i.xmlMode || i.lowerCaseAttributeNames) && (t.name = t.name.toLowerCase()), sT[t.action](e, t, i);
    }
    case ae.Pseudo:
      return T4(e, t, i, n, s);
    case ae.Tag: {
      if (t.namespace != null)
        throw new Error("Namespaced tag names are not yet supported by css-select");
      let { name: u } = t;
      return (!i.xmlMode || i.lowerCaseTags) && (u = u.toLowerCase()), /* @__PURE__ */ l(function(h) {
        return r.getName(h) === u && e(h);
      }, "tag");
    }
    case ae.Descendant: {
      if (i.cacheResults === !1 || typeof WeakSet > "u")
        return /* @__PURE__ */ l(function(h) {
          let p = h;
          for (; p = al(p, r); )
            if (e(p))
              return !0;
          return !1;
        }, "descendant");
      const u = /* @__PURE__ */ new WeakSet();
      return /* @__PURE__ */ l(function(h) {
        let p = h;
        for (; p = al(p, r); )
          if (!u.has(p)) {
            if (r.isTag(p) && e(p))
              return !0;
            u.add(p);
          }
        return !1;
      }, "cachedDescendant");
    }
    case "_flexibleDescendant":
      return /* @__PURE__ */ l(function(c) {
        let h = c;
        do
          if (e(h))
            return !0;
        while (h = al(h, r));
        return !1;
      }, "flexibleDescendant");
    case ae.Parent:
      return /* @__PURE__ */ l(function(c) {
        return r.getChildren(c).some((h) => r.isTag(h) && e(h));
      }, "parent");
    case ae.Child:
      return /* @__PURE__ */ l(function(c) {
        const h = r.getParent(c);
        return h != null && r.isTag(h) && e(h);
      }, "child");
    case ae.Sibling:
      return /* @__PURE__ */ l(function(c) {
        const h = r.getSiblings(c);
        for (let p = 0; p < h.length; p++) {
          const f = h[p];
          if (a(c, f))
            break;
          if (r.isTag(f) && e(f))
            return !0;
        }
        return !1;
      }, "sibling");
    case ae.Adjacent:
      return r.prevElementSibling ? /* @__PURE__ */ l(function(c) {
        const h = r.prevElementSibling(c);
        return h != null && e(h);
      }, "adjacent") : /* @__PURE__ */ l(function(c) {
        const h = r.getSiblings(c);
        let p;
        for (let f = 0; f < h.length; f++) {
          const _ = h[f];
          if (a(c, _))
            break;
          r.isTag(_) && (p = _);
        }
        return !!p && e(p);
      }, "adjacent");
    case ae.Universal: {
      if (t.namespace != null && t.namespace !== "*")
        throw new Error("Namespaced universal selectors are not yet supported by css-select");
      return e;
    }
  }
}
l(x4, "compileGeneralSelector");
function rv(e, t, i) {
  const n = ov(e, t, i);
  return nv(n, t.adapter);
}
l(rv, "compile");
function ov(e, t, i) {
  const n = typeof e == "string" ? ev(e) : e;
  return lv(n, t, i);
}
l(ov, "compileUnsafe");
function av(e) {
  return e.type === ae.Pseudo && (e.name === "scope" || Array.isArray(e.data) && e.data.some((t) => t.some(av)));
}
l(av, "includesScopePseudo");
var lT = { type: ae.Descendant }, uT = {
  type: "_flexibleDescendant"
}, cT = {
  type: ae.Pseudo,
  name: "scope",
  data: null
};
function E4(e, { adapter: t }, i) {
  const n = !!i?.every((s) => {
    const r = t.isTag(s) && t.getParent(s);
    return s === C4 || r && t.isTag(r);
  });
  for (const s of e) {
    if (!(s.length > 0 && Eu(s[0]) && s[0].type !== ae.Descendant))
      if (n && !s.some(av))
        s.unshift(lT);
      else
        continue;
    s.unshift(cT);
  }
}
l(E4, "absolutize");
function lv(e, t, i) {
  var n;
  e.forEach(b4), i = (n = t.context) !== null && n !== void 0 ? n : i;
  const s = Array.isArray(i), r = i && (Array.isArray(i) ? i : [i]);
  if (t.relativeSelector !== !1)
    E4(e, t, r);
  else if (e.some((c) => c.length > 0 && Eu(c[0])))
    throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled");
  let a = !1;
  const u = e.map((c) => {
    if (c.length >= 2) {
      const [h, p] = c;
      h.type !== ae.Pseudo || h.name !== "scope" || (s && p.type === ae.Descendant ? c[1] = uT : (p.type === ae.Adjacent || p.type === ae.Sibling) && (a = !0));
    }
    return k4(c, t, r);
  }).reduce(A4, Dn.default.falseFunc);
  return u.shouldTestNextSiblings = a, u;
}
l(lv, "compileToken");
function k4(e, t, i) {
  var n;
  return e.reduce((s, r) => s === Dn.default.falseFunc ? Dn.default.falseFunc : x4(s, r, t, i, lv), (n = t.rootFunc) !== null && n !== void 0 ? n : Dn.default.trueFunc);
}
l(k4, "compileRules");
function A4(e, t) {
  return t === Dn.default.falseFunc || e === Dn.default.trueFunc ? e : e === Dn.default.falseFunc || t === Dn.default.trueFunc ? t : /* @__PURE__ */ l(function(n) {
    return e(n) || t(n);
  }, "combine");
}
l(A4, "reduceRules");
var I4 = /* @__PURE__ */ l((e, t) => e === t, "defaultEquals"), hT = {
  adapter: gu,
  equals: I4
};
function ku(e) {
  var t, i, n, s;
  const r = e ?? hT;
  return (t = r.adapter) !== null && t !== void 0 || (r.adapter = gu), (i = r.equals) !== null && i !== void 0 || (r.equals = (s = (n = r.adapter) === null || n === void 0 ? void 0 : n.equals) !== null && s !== void 0 ? s : I4), r;
}
l(ku, "convertOptionFormats");
function P4(e) {
  return /* @__PURE__ */ l(function(i, n, s) {
    const r = ku(n);
    return e(i, r, s);
  }, "addAdapter");
}
l(P4, "wrapCompile");
var dT = P4(rv);
function pT(e) {
  return /* @__PURE__ */ l(function(i, n, s) {
    const r = ku(s);
    typeof i != "function" && (i = ov(i, r, n));
    const a = M4(n, r.adapter, i.shouldTestNextSiblings);
    return e(i, a, r);
  }, "select");
}
l(pT, "getSelectorFunc");
function M4(e, t, i = !1) {
  return i && (e = N4(e, t)), Array.isArray(e) ? t.removeSubsets(e) : t.getChildren(e);
}
l(M4, "prepareContext");
function N4(e, t) {
  const i = Array.isArray(e) ? e.slice(0) : [e], n = i.length;
  for (let s = 0; s < n; s++) {
    const r = sv(i[s], t);
    i.push(...r);
  }
  return i;
}
l(N4, "appendNextSiblings");
function R4(e, t, i) {
  const n = ku(i);
  return (typeof t == "function" ? t : rv(t, n))(e);
}
l(R4, "is");
var { isArray: fT } = Array, Au = /* @__PURE__ */ l(({ nodeType: e }) => e === Oe, "isTag"), L4 = /* @__PURE__ */ l((e, t) => t.some((i) => Au(i) && (e(i) || L4(e, Sr(i)))), "existsOne"), mT = /* @__PURE__ */ l((e, t) => t === "class" ? e.classList.value : e.getAttribute(t), "getAttributeValue"), Sr = /* @__PURE__ */ l(({ childNodes: e }) => e, "getChildren"), vT = /* @__PURE__ */ l((e) => {
  const { localName: t } = e;
  return ua(e) ? t.toLowerCase() : t;
}, "getName"), gT = /* @__PURE__ */ l(({ parentNode: e }) => e, "getParent"), yT = /* @__PURE__ */ l((e) => {
  const { parentNode: t } = e;
  return t ? Sr(t) : e;
}, "getSiblings"), Tc = /* @__PURE__ */ l((e) => fT(e) ? e.map(Tc).join("") : Au(e) ? Tc(Sr(e)) : e.nodeType === St ? e.data : "", "getText"), _T = /* @__PURE__ */ l((e, t) => e.hasAttribute(t), "hasAttrib"), bT = /* @__PURE__ */ l((e) => {
  let { length: t } = e;
  for (; t--; ) {
    const i = e[t];
    if (t && -1 < e.lastIndexOf(i, t - 1)) {
      e.splice(t, 1);
      continue;
    }
    for (let { parentNode: n } = i; n; n = n.parentNode)
      if (e.includes(n)) {
        e.splice(t, 1);
        break;
      }
  }
  return e;
}, "removeSubsets"), D4 = /* @__PURE__ */ l((e, t) => {
  const i = [];
  for (const n of t)
    Au(n) && (e(n) && i.push(n), i.push(...D4(e, Sr(n))));
  return i;
}, "findAll"), B4 = /* @__PURE__ */ l((e, t) => {
  for (let i of t)
    if (e(i) || (i = B4(e, Sr(i))))
      return i;
  return null;
}, "findOne"), O4 = {
  isTag: Au,
  existsOne: L4,
  getAttributeValue: mT,
  getChildren: Sr,
  getName: vT,
  getParent: gT,
  getSiblings: yT,
  getText: Tc,
  hasAttrib: _T,
  removeSubsets: bT,
  findAll: D4,
  findOne: B4
}, xc = /* @__PURE__ */ l((e, t) => dT(t, {
  context: t.includes(":scope") ? e : void 0,
  xmlMode: !ua(e),
  adapter: O4
}), "prepareMatch"), wT = /* @__PURE__ */ l((e, t) => R4(e, t, {
  strict: !0,
  context: t.includes(":scope") ? e : void 0,
  xmlMode: !ua(e),
  adapter: O4
}), "matches"), { replace: ST } = "", CT = /[<>&\xA0]/g, TT = {
  "\xA0": "&nbsp;",
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;"
}, xT = /* @__PURE__ */ l((e) => TT[e], "pe"), ET = /* @__PURE__ */ l((e) => ST.call(e, CT, xT), "escape"), Ps = class extends ca {
  constructor(e, t = "") {
    super(e, "#text", St, t);
  }
  get wholeText() {
    const e = [];
    let { previousSibling: t, nextSibling: i } = this;
    for (; t && t.nodeType === St; ) {
      e.unshift(t[Ge]);
      t = t.previousSibling;
    }
    for (e.push(this[Ge]); i && i.nodeType === St; ) {
      e.push(i[Ge]);
      i = i.nextSibling;
    }
    return e.join("");
  }
  cloneNode() {
    const { ownerDocument: e, [Ge]: t } = this;
    return new Ps(e, t);
  }
  toString() {
    return ET(this[Ge]);
  }
};
l(Ps, "Text");
var kT = /* @__PURE__ */ l((e) => e instanceof qn, "isNode"), H1 = /* @__PURE__ */ l((e, t, i) => {
  const { ownerDocument: n } = e;
  for (const s of i)
    e.insertBefore(kT(s) ? s : new Ps(n, s), t);
}, "insert"), uv = class extends qn {
  constructor(e, t, i) {
    super(e, t, i), this[bt] = null, this[G] = this[re] = {
      [G]: null,
      [pt]: this,
      [Ut]: this,
      nodeType: Hn,
      ownerDocument: this.ownerDocument,
      parentNode: null
    };
  }
  get childNodes() {
    const e = new bi();
    let { firstChild: t } = this;
    for (; t; )
      e.push(t), t = bs(t);
    return e;
  }
  get children() {
    const e = new bi();
    let { firstElementChild: t } = this;
    for (; t; )
      e.push(t), t = Zm(t);
    return e;
  }
  get firstChild() {
    let { [G]: e, [re]: t } = this;
    for (; e.nodeType === vt; )
      e = e[G];
    return e === t ? null : e;
  }
  get firstElementChild() {
    let { firstChild: e } = this;
    for (; e; ) {
      if (e.nodeType === Oe)
        return e;
      e = bs(e);
    }
    return null;
  }
  get lastChild() {
    const e = this[re][pt];
    switch (e.nodeType) {
      case Hn:
        return e[Ut];
      case vt:
        return null;
    }
    return e === this ? null : e;
  }
  get lastElementChild() {
    let { lastChild: e } = this;
    for (; e; ) {
      if (e.nodeType === Oe)
        return e;
      e = Ko(e);
    }
    return null;
  }
  get childElementCount() {
    return this.children.length;
  }
  prepend(...e) {
    H1(this, this.firstChild, e);
  }
  append(...e) {
    H1(this, this[re], e);
  }
  replaceChildren(...e) {
    let { [G]: t, [re]: i } = this;
    for (; t !== i && t.nodeType === vt; )
      t = t[G];
    for (; t !== i; ) {
      const n = ei(t)[G];
      t.remove(), t = n;
    }
    e.length && H1(this, i, e);
  }
  getElementsByClassName(e) {
    const t = new bi();
    let { [G]: i, [re]: n } = this;
    for (; i !== n; )
      i.nodeType === Oe && i.hasAttribute("class") && i.classList.has(e) && t.push(i), i = i[G];
    return t;
  }
  getElementsByTagName(e) {
    const t = new bi();
    let { [G]: i, [re]: n } = this;
    for (; i !== n; )
      i.nodeType === Oe && (i.localName === e || gc(i) === e) && t.push(i), i = i[G];
    return t;
  }
  querySelector(e) {
    const t = xc(this, e);
    let { [G]: i, [re]: n } = this;
    for (; i !== n; ) {
      if (i.nodeType === Oe && t(i))
        return i;
      i = i[G];
    }
    return null;
  }
  querySelectorAll(e) {
    const t = xc(this, e), i = new bi();
    let { [G]: n, [re]: s } = this;
    for (; n !== s; )
      n.nodeType === Oe && t(n) && i.push(n), n = n[G];
    return i;
  }
  appendChild(e) {
    return this.insertBefore(e, this[re]);
  }
  contains(e) {
    let t = e;
    for (; t && t !== this; )
      t = t.parentNode;
    return t === this;
  }
  insertBefore(e, t = null) {
    if (e === t)
      return e;
    if (e === this)
      throw new Error("unable to append a node to itself");
    const i = t || this[re];
    switch (e.nodeType) {
      case Oe:
        e.remove(), e.parentNode = this, Xb(i[pt], e, i), Bo(e, null), yc(e);
        break;
      case Fn: {
        let { [bt]: n, firstChild: s, lastChild: r } = e;
        if (s) {
          WC(i[pt], s, r, i), wi(e, e[re]), n && n.replaceChildren();
          do
            s.parentNode = this, Bo(s, null), s.nodeType === Oe && yc(s);
          while (s !== r && (s = bs(s)));
        }
        break;
      }
      case St:
      case an:
        e.remove();
      default:
        e.parentNode = this, Su(i[pt], e, i), Bo(e, null);
        break;
    }
    return e;
  }
  normalize() {
    let { [G]: e, [re]: t } = this;
    for (; e !== t; ) {
      const { [G]: i, [pt]: n, nodeType: s } = e;
      s === St && (e[Ge] ? n && n.nodeType === St && (n.textContent += e.textContent, e.remove()) : e.remove()), e = i;
    }
  }
  removeChild(e) {
    if (e.parentNode !== this)
      throw new Error("node is not a child");
    return e.remove(), e;
  }
  replaceChild(e, t) {
    const i = ei(t)[G];
    return t.remove(), this.insertBefore(e, i), t;
  }
};
l(uv, "ParentNode");
var Iu = class extends uv {
  getElementById(e) {
    let { [G]: t, [re]: i } = this;
    for (; t !== i; ) {
      if (t.nodeType === Oe && t.id === e)
        return t;
      t = t[G];
    }
    return null;
  }
  cloneNode(e) {
    const { ownerDocument: t, constructor: i } = this, n = new i(t);
    if (e) {
      const { [re]: s } = n;
      for (const r of this.childNodes)
        n.insertBefore(r.cloneNode(e), s);
    }
    return n;
  }
  toString() {
    const { childNodes: e, localName: t } = this;
    return `<${t}>${e.join("")}</${t}>`;
  }
  toJSON() {
    const e = [];
    return zC(this, e), e;
  }
};
l(Iu, "NonElementParentNode");
var Pu = class extends Iu {
  constructor(e) {
    super(e, "#document-fragment", Fn);
  }
};
l(Pu, "DocumentFragment");
var mr = class extends qn {
  constructor(e, t, i = "", n = "") {
    super(e, "#document-type", fr), this.name = t, this.publicId = i, this.systemId = n;
  }
  cloneNode() {
    const { ownerDocument: e, name: t, publicId: i, systemId: n } = this;
    return new mr(e, t, i, n);
  }
  toString() {
    const { name: e, publicId: t, systemId: i } = this, n = 0 < t.length, s = [e];
    return n && s.push("PUBLIC", `"${t}"`), i.length && (n || s.push("SYSTEM"), s.push(`"${i}"`)), `<!DOCTYPE ${s.join(" ")}>`;
  }
  toJSON() {
    const e = [];
    return s4(this, e), e;
  }
};
l(mr, "DocumentType");
var F4 = /* @__PURE__ */ l((e) => e.childNodes.join(""), "getInnerHtml"), V4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i } = e, { constructor: n } = i, s = new n();
  s[vi] = i[vi];
  const { childNodes: r } = e4(s, ua(e), t);
  e.replaceChildren(...r);
}, "setInnerHtml"), ll = /* @__PURE__ */ l((e) => e.replace(/(([A-Z0-9])([A-Z0-9][a-z]))|(([a-z])([A-Z]))/g, "$2$5-$3$6").toLowerCase(), "default"), ul = /* @__PURE__ */ new WeakMap(), W1 = /* @__PURE__ */ l((e) => `data-${ll(e)}`, "key"), AT = /* @__PURE__ */ l((e) => e.slice(5).replace(/-([a-z])/g, (t, i) => i.toUpperCase()), "prop"), IT = {
  get(e, t) {
    if (t in e)
      return ul.get(e).getAttribute(W1(t));
  },
  set(e, t, i) {
    return e[t] = i, ul.get(e).setAttribute(W1(t), i), !0;
  },
  deleteProperty(e, t) {
    return t in e && ul.get(e).removeAttribute(W1(t)), delete e[t];
  }
}, cv = class {
  constructor(e) {
    for (const { name: t, value: i } of e.attributes)
      /^data-/.test(t) && (this[AT(t)] = i);
    return ul.set(this, e), new Proxy(this, IT);
  }
};
l(cv, "DOMStringMap");
Gt(cv.prototype, null);
var { add: PT } = Set.prototype, p2 = /* @__PURE__ */ l((e, t) => {
  for (const i of t)
    i && PT.call(e, i);
}, "addTokens"), Br = /* @__PURE__ */ l(({ [eb]: e, value: t }) => {
  const i = e.getAttributeNode("class");
  i ? i.value = t : _c(e, new Is(e.ownerDocument, "class", t));
}, "update"), U4 = class extends Set {
  constructor(e) {
    super(), this[eb] = e;
    const t = e.getAttributeNode("class");
    t && p2(this, t.value.split(/\s+/));
  }
  get length() {
    return this.size;
  }
  get value() {
    return [...this].join(" ");
  }
  add(...e) {
    p2(this, e), Br(this);
  }
  contains(e) {
    return this.has(e);
  }
  remove(...e) {
    for (const t of e)
      this.delete(t);
    Br(this);
  }
  toggle(e, t) {
    if (this.has(e)) {
      if (t)
        return !0;
      this.delete(e), Br(this);
    } else if (t || arguments.length === 1)
      return super.add(e), Br(this), !0;
    return !1;
  }
  replace(e, t) {
    return this.has(e) ? (this.delete(e), super.add(t), Br(this), !0) : !1;
  }
  supports() {
    return !0;
  }
};
l(U4, "DOMTokenList");
var Yl = /* @__PURE__ */ new WeakMap(), Ec = /* @__PURE__ */ l((e) => [...e.keys()].filter((t) => t !== bt), "getKeys"), kc = /* @__PURE__ */ l((e) => {
  const t = Yl.get(e).getAttributeNode("style");
  if ((!t || t[Ul] || e.get(bt) !== t) && (e.clear(), t)) {
    e.set(bt, t);
    for (const i of t[Ge].split(/\s*;\s*/)) {
      let [n, ...s] = i.split(":");
      if (s.length > 0) {
        n = n.trim();
        const r = s.join(":").trim();
        n && r && e.set(n, r);
      }
    }
  }
  return t;
}, "updateKeys"), Ra = {
  get(e, t) {
    return t in MT ? e[t] : (kc(e), t === "length" ? Ec(e).length : /^\d+$/.test(t) ? Ec(e)[t] : e.get(ll(t)));
  },
  set(e, t, i) {
    if (t === "cssText")
      e[t] = i;
    else {
      let n = kc(e);
      if (i == null ? e.delete(ll(t)) : e.set(ll(t), i), !n) {
        const s = Yl.get(e);
        n = s.ownerDocument.createAttribute("style"), s.setAttributeNode(n), e.set(bt, n);
      }
      n[Ul] = !1, n[Ge] = e.toString();
    }
    return !0;
  }
}, hv = class extends Map {
  constructor(e) {
    return super(), Yl.set(this, e), new Proxy(this, Ra);
  }
  get cssText() {
    return this.toString();
  }
  set cssText(e) {
    Yl.get(this).setAttribute("style", e);
  }
  getPropertyValue(e) {
    const t = this[bt];
    return Ra.get(t, e);
  }
  setProperty(e, t) {
    const i = this[bt];
    Ra.set(i, e, t);
  }
  removeProperty(e) {
    const t = this[bt];
    Ra.set(t, e, null);
  }
  [Symbol.iterator]() {
    const e = Ec(this[bt]), { length: t } = e;
    let i = 0;
    return {
      next() {
        const n = i === t;
        return { done: n, value: n ? null : e[i++] };
      }
    };
  }
  get [bt]() {
    return this;
  }
  toString() {
    const e = this[bt];
    kc(e);
    const t = [];
    return e.forEach(j4, t), t.join(";");
  }
};
l(hv, "CSSStyleDeclaration");
var { prototype: MT } = hv;
function j4(e, t) {
  t !== bt && this.push(`${t}:${e}`);
}
l(j4, "push");
var f2 = 3, m2 = 2, v2 = 1, g2 = 0, Wn = class {
  static get BUBBLING_PHASE() {
    return f2;
  }
  static get AT_TARGET() {
    return m2;
  }
  static get CAPTURING_PHASE() {
    return v2;
  }
  static get NONE() {
    return g2;
  }
  constructor(e, t = {}) {
    this.type = e, this.bubbles = !!t.bubbles, this.cancelBubble = !1, this._stopImmediatePropagationFlag = !1, this.cancelable = !!t.cancelable, this.eventPhase = this.NONE, this.timeStamp = Date.now(), this.defaultPrevented = !1, this.originalTarget = null, this.returnValue = null, this.srcElement = null, this.target = null, this._path = [];
  }
  get BUBBLING_PHASE() {
    return f2;
  }
  get AT_TARGET() {
    return m2;
  }
  get CAPTURING_PHASE() {
    return v2;
  }
  get NONE() {
    return g2;
  }
  preventDefault() {
    this.defaultPrevented = !0;
  }
  composedPath() {
    return this._path;
  }
  stopPropagation() {
    this.cancelBubble = !0;
  }
  stopImmediatePropagation() {
    this.stopPropagation(), this._stopImmediatePropagationFlag = !0;
  }
};
l(Wn, "GlobalEvent");
var dv = class extends Array {
  constructor(e) {
    super(), this.ownerElement = e;
  }
  getNamedItem(e) {
    return this.ownerElement.getAttributeNode(e);
  }
  setNamedItem(e) {
    this.ownerElement.setAttributeNode(e), this.unshift(e);
  }
  removeNamedItem(e) {
    const t = this.getNamedItem(e);
    this.ownerElement.removeAttribute(e), this.splice(this.indexOf(t), 1);
  }
  item(e) {
    return e < this.length ? this[e] : null;
  }
  getNamedItemNS(e, t) {
    return this.getNamedItem(t);
  }
  setNamedItemNS(e, t) {
    return this.setNamedItem(t);
  }
  removeNamedItemNS(e, t) {
    return this.removeNamedItem(t);
  }
};
l(dv, "NamedNodeMap");
var Mu = class extends Iu {
  constructor(e) {
    super(e.ownerDocument, "#shadow-root", Fn), this.host = e;
  }
  get innerHTML() {
    return F4(this);
  }
  set innerHTML(e) {
    V4(this, e);
  }
};
l(Mu, "ShadowRoot");
var NT = {
  get(e, t) {
    return t in e ? e[t] : e.find(({ name: i }) => i === t);
  }
}, y2 = /* @__PURE__ */ l((e, t, i) => {
  if ("ownerSVGElement" in t) {
    const n = e.createElementNS(Gl, i);
    return n.ownerSVGElement = t.ownerSVGElement, n;
  }
  return e.createElement(i);
}, "create"), RT = /* @__PURE__ */ l(({ localName: e, ownerDocument: t }) => t[br].voidElements.test(e), "isVoid"), Cr = class extends uv {
  constructor(e, t) {
    super(e, t, Oe), this[Zs] = null, this[O1] = null, this[F1] = null;
  }
  get isConnected() {
    return c4(this);
  }
  get parentElement() {
    return h4(this);
  }
  get previousSibling() {
    return Ko(this);
  }
  get nextSibling() {
    return bs(this);
  }
  get previousElementSibling() {
    return d4(this);
  }
  get nextElementSibling() {
    return Zm(this);
  }
  before(...e) {
    p4(this, e);
  }
  after(...e) {
    f4(this, e);
  }
  replaceWith(...e) {
    m4(this, e);
  }
  remove() {
    v4(this[pt], this, this[re][G]);
  }
  get id() {
    return X.get(this, "id");
  }
  set id(e) {
    X.set(this, "id", e);
  }
  get className() {
    return this.classList.value;
  }
  set className(e) {
    const { classList: t } = this;
    t.clear(), t.add(...e.split(/\s+/));
  }
  get nodeName() {
    return gc(this);
  }
  get tagName() {
    return gc(this);
  }
  get classList() {
    return this[Zs] || (this[Zs] = new U4(this));
  }
  get dataset() {
    return this[O1] || (this[O1] = new cv(this));
  }
  get nonce() {
    return X.get(this, "nonce");
  }
  set nonce(e) {
    X.set(this, "nonce", e);
  }
  get style() {
    return this[F1] || (this[F1] = new hv(this));
  }
  get tabIndex() {
    return Ln.get(this, "tabindex") || -1;
  }
  set tabIndex(e) {
    Ln.set(this, "tabindex", e);
  }
  get innerText() {
    const e = [];
    let { [G]: t, [re]: i } = this;
    for (; t !== i; )
      t.nodeType === St ? e.push(t.textContent.replace(/\s+/g, " ")) : e.length && t[G] != i && IC.has(t.tagName) && e.push(`
`), t = t[G];
    return e.join("");
  }
  get textContent() {
    const e = [];
    let { [G]: t, [re]: i } = this;
    for (; t !== i; )
      t.nodeType === St && e.push(t.textContent), t = t[G];
    return e.join("");
  }
  set textContent(e) {
    this.replaceChildren(), e && this.appendChild(new Ps(this.ownerDocument, e));
  }
  get innerHTML() {
    return F4(this);
  }
  set innerHTML(e) {
    V4(this, e);
  }
  get outerHTML() {
    return this.toString();
  }
  set outerHTML(e) {
    const t = this.ownerDocument.createElement("");
    t.innerHTML = e, this.replaceWith(...t.childNodes);
  }
  get attributes() {
    const e = new dv(this);
    let t = this[G];
    for (; t.nodeType === vt; )
      e.push(t), t = t[G];
    return new Proxy(e, NT);
  }
  focus() {
    this.dispatchEvent(new Wn("focus"));
  }
  getAttribute(e) {
    if (e === "class")
      return this.className;
    const t = this.getAttributeNode(e);
    return t && t.value;
  }
  getAttributeNode(e) {
    let t = this[G];
    for (; t.nodeType === vt; ) {
      if (t.name === e)
        return t;
      t = t[G];
    }
    return null;
  }
  getAttributeNames() {
    const e = new bi();
    let t = this[G];
    for (; t.nodeType === vt; )
      e.push(t.name), t = t[G];
    return e;
  }
  hasAttribute(e) {
    return !!this.getAttributeNode(e);
  }
  hasAttributes() {
    return this[G].nodeType === vt;
  }
  removeAttribute(e) {
    e === "class" && this[Zs] && this[Zs].clear();
    let t = this[G];
    for (; t.nodeType === vt; ) {
      if (t.name === e) {
        a2(this, t);
        return;
      }
      t = t[G];
    }
  }
  removeAttributeNode(e) {
    let t = this[G];
    for (; t.nodeType === vt; ) {
      if (t === e) {
        a2(this, t);
        return;
      }
      t = t[G];
    }
  }
  setAttribute(e, t) {
    if (e === "class")
      this.className = t;
    else {
      const i = this.getAttributeNode(e);
      i ? i.value = t : _c(this, new Is(this.ownerDocument, e, t));
    }
  }
  setAttributeNode(e) {
    const { name: t } = e, i = this.getAttributeNode(t);
    if (i !== e) {
      i && this.removeAttributeNode(i);
      const { ownerElement: n } = e;
      n && n.removeAttributeNode(e), _c(this, e);
    }
    return i;
  }
  toggleAttribute(e, t) {
    return this.hasAttribute(e) ? t ? !0 : (this.removeAttribute(e), !1) : t || arguments.length === 1 ? (this.setAttribute(e, ""), !0) : !1;
  }
  get shadowRoot() {
    if (Rn.has(this)) {
      const { mode: e, shadowRoot: t } = Rn.get(this);
      if (e === "open")
        return t;
    }
    return null;
  }
  attachShadow(e) {
    if (Rn.has(this))
      throw new Error("operation not supported");
    const t = new Mu(this);
    return t.append(...this.childNodes), Rn.set(this, {
      mode: e.mode,
      shadowRoot: t
    }), t;
  }
  matches(e) {
    return wT(this, e);
  }
  closest(e) {
    let t = this;
    const i = xc(t, e);
    for (; t && !i(t); )
      t = t.parentElement;
    return t;
  }
  insertAdjacentElement(e, t) {
    const { parentElement: i } = this;
    switch (e) {
      case "beforebegin":
        if (i) {
          i.insertBefore(t, this);
          break;
        }
        return null;
      case "afterbegin":
        this.insertBefore(t, this.firstChild);
        break;
      case "beforeend":
        this.insertBefore(t, null);
        break;
      case "afterend":
        if (i) {
          i.insertBefore(t, this.nextSibling);
          break;
        }
        return null;
    }
    return t;
  }
  insertAdjacentHTML(e, t) {
    const i = this.ownerDocument.createElement("template");
    i.innerHTML = t, this.insertAdjacentElement(e, i.content);
  }
  insertAdjacentText(e, t) {
    const i = this.ownerDocument.createTextNode(t);
    this.insertAdjacentElement(e, i);
  }
  cloneNode(e = !1) {
    const { ownerDocument: t, localName: i } = this, n = /* @__PURE__ */ l((h) => {
      h.parentNode = r, wi(a, h), a = h;
    }, "addNext"), s = y2(t, this, i);
    let r = s, a = s, { [G]: u, [re]: c } = this;
    for (; u !== c && (e || u.nodeType === vt); ) {
      switch (u.nodeType) {
        case Hn:
          wi(a, r[re]), a = r[re], r = r.parentNode;
          break;
        case Oe: {
          const h = y2(t, u, u.localName);
          n(h), r = h;
          break;
        }
        case vt:
        case St:
        case an:
          n(u.cloneNode(e));
          break;
      }
      u = u[G];
    }
    return wi(a, s[re]), s;
  }
  toString() {
    const e = [], { [re]: t } = this;
    let i = { [G]: this }, n = !1;
    do
      switch (i = i[G], i.nodeType) {
        case vt: {
          const s = " " + i;
          switch (s) {
            case " id":
            case " class":
            case " style":
              break;
            default:
              e.push(s);
          }
          break;
        }
        case Hn: {
          const s = i[Ut];
          n ? ("ownerSVGElement" in s ? e.push(" />") : RT(s) ? e.push(ua(s) ? ">" : " />") : e.push(`></${s.localName}>`), n = !1) : e.push(`</${s.localName}>`);
          break;
        }
        case Oe:
          n && e.push(">"), i.toString !== this.toString ? (e.push(i.toString()), i = i[re], n = !1) : (e.push(`<${i.localName}`), n = !0);
          break;
        case St:
        case an:
          e.push((n ? ">" : "") + i), n = !1;
          break;
      }
    while (i !== t);
    return e.join("");
  }
  toJSON() {
    const e = [];
    return r4(this, e), e;
  }
  getAttributeNS(e, t) {
    return this.getAttribute(t);
  }
  getElementsByTagNameNS(e, t) {
    return this.getElementsByTagName(t);
  }
  hasAttributeNS(e, t) {
    return this.hasAttribute(t);
  }
  removeAttributeNS(e, t) {
    this.removeAttribute(t);
  }
  setAttributeNS(e, t, i) {
    this.setAttribute(t, i);
  }
  setAttributeNodeNS(e) {
    return this.setAttributeNode(e);
  }
};
l(Cr, "Element");
var $1 = /* @__PURE__ */ new WeakMap(), LT = {
  get(e, t) {
    return e[t];
  },
  set(e, t, i) {
    return e[t] = i, !0;
  }
}, Nu = class extends Cr {
  constructor(e, t, i = null) {
    super(e, t), this.ownerSVGElement = i;
  }
  get className() {
    return $1.has(this) || $1.set(this, new Proxy({ baseVal: "", animVal: "" }, LT)), $1.get(this);
  }
  set className(e) {
    const { classList: t } = this;
    t.clear(), t.add(...e.split(/\s+/));
  }
  getAttribute(e) {
    return e === "class" ? [...this.classList].join(" ") : super.getAttribute(e);
  }
  setAttribute(e, t) {
    if (e === "class")
      this.className = t;
    else if (e === "style") {
      const { className: i } = this;
      i.baseVal = i.animVal = t;
    }
    super.setAttribute(e, t);
  }
};
l(Nu, "SVGElement");
var ui = /* @__PURE__ */ l(() => {
  throw new TypeError("Illegal constructor");
}, "illegalConstructor");
function Ru() {
  ui();
}
l(Ru, "Attr");
Gt(Ru, Is);
Ru.prototype = Is.prototype;
function Lu() {
  ui();
}
l(Lu, "CharacterData");
Gt(Lu, ca);
Lu.prototype = ca.prototype;
function Du() {
  ui();
}
l(Du, "Comment");
Gt(Du, ha);
Du.prototype = ha.prototype;
function Bu() {
  ui();
}
l(Bu, "DocumentFragment");
Gt(Bu, Pu);
Bu.prototype = Pu.prototype;
function Ou() {
  ui();
}
l(Ou, "DocumentType");
Gt(Ou, mr);
Ou.prototype = mr.prototype;
function Fu() {
  ui();
}
l(Fu, "Element");
Gt(Fu, Cr);
Fu.prototype = Cr.prototype;
function Vu() {
  ui();
}
l(Vu, "Node");
Gt(Vu, qn);
Vu.prototype = qn.prototype;
function Uu() {
  ui();
}
l(Uu, "ShadowRoot");
Gt(Uu, Mu);
Uu.prototype = Mu.prototype;
function ju() {
  ui();
}
l(ju, "Text");
Gt(ju, Ps);
ju.prototype = Ps.prototype;
function Hu() {
  ui();
}
l(Hu, "SVGElement");
Gt(Hu, Nu);
Hu.prototype = Nu.prototype;
var DT = {
  Attr: Ru,
  CharacterData: Lu,
  Comment: Du,
  DocumentFragment: Bu,
  DocumentType: Ou,
  Element: Fu,
  Node: Vu,
  ShadowRoot: Uu,
  Text: ju,
  SVGElement: Hu
}, Or = /* @__PURE__ */ new WeakMap(), k = {
  get(e, t) {
    return Or.has(e) && Or.get(e)[t] || null;
  },
  set(e, t, i) {
    Or.has(e) || Or.set(e, {});
    const n = Or.get(e), s = t.slice(2);
    n[t] && e.removeEventListener(s, n[t], !1), (n[t] = i) && e.addEventListener(s, i, !1);
  }
}, q = class extends Cr {
  static get observedAttributes() {
    return [];
  }
  constructor(e = null, t = "") {
    super(e, t);
    const i = !e;
    let n;
    if (i) {
      const { constructor: s } = this;
      if (!ql.has(s))
        throw new Error("unable to initialize this Custom Element");
      ({ ownerDocument: e, localName: t, options: n } = ql.get(s));
    }
    if (e[Ro]) {
      const { element: s, values: r } = e[Ro];
      e[Ro] = null;
      for (const [a, u] of r)
        s[a] = u;
      return s;
    }
    i && (this.ownerDocument = this[re].ownerDocument = e, this.localName = t, ks.set(this, { connected: !1 }), n.is && this.setAttribute("is", n.is));
  }
  blur() {
    this.dispatchEvent(new Wn("blur"));
  }
  click() {
    this.dispatchEvent(new Wn("click"));
  }
  get accessKeyLabel() {
    const { accessKey: e } = this;
    return e && `Alt+Shift+${e}`;
  }
  get isContentEditable() {
    return this.hasAttribute("contenteditable");
  }
  get contentEditable() {
    return He.get(this, "contenteditable");
  }
  set contentEditable(e) {
    He.set(this, "contenteditable", e);
  }
  get draggable() {
    return He.get(this, "draggable");
  }
  set draggable(e) {
    He.set(this, "draggable", e);
  }
  get hidden() {
    return He.get(this, "hidden");
  }
  set hidden(e) {
    He.set(this, "hidden", e);
  }
  get spellcheck() {
    return He.get(this, "spellcheck");
  }
  set spellcheck(e) {
    He.set(this, "spellcheck", e);
  }
  get accessKey() {
    return X.get(this, "accesskey");
  }
  set accessKey(e) {
    X.set(this, "accesskey", e);
  }
  get dir() {
    return X.get(this, "dir");
  }
  set dir(e) {
    X.set(this, "dir", e);
  }
  get lang() {
    return X.get(this, "lang");
  }
  set lang(e) {
    X.set(this, "lang", e);
  }
  get title() {
    return X.get(this, "title");
  }
  set title(e) {
    X.set(this, "title", e);
  }
  get onabort() {
    return k.get(this, "onabort");
  }
  set onabort(e) {
    k.set(this, "onabort", e);
  }
  get onblur() {
    return k.get(this, "onblur");
  }
  set onblur(e) {
    k.set(this, "onblur", e);
  }
  get oncancel() {
    return k.get(this, "oncancel");
  }
  set oncancel(e) {
    k.set(this, "oncancel", e);
  }
  get oncanplay() {
    return k.get(this, "oncanplay");
  }
  set oncanplay(e) {
    k.set(this, "oncanplay", e);
  }
  get oncanplaythrough() {
    return k.get(this, "oncanplaythrough");
  }
  set oncanplaythrough(e) {
    k.set(this, "oncanplaythrough", e);
  }
  get onchange() {
    return k.get(this, "onchange");
  }
  set onchange(e) {
    k.set(this, "onchange", e);
  }
  get onclick() {
    return k.get(this, "onclick");
  }
  set onclick(e) {
    k.set(this, "onclick", e);
  }
  get onclose() {
    return k.get(this, "onclose");
  }
  set onclose(e) {
    k.set(this, "onclose", e);
  }
  get oncontextmenu() {
    return k.get(this, "oncontextmenu");
  }
  set oncontextmenu(e) {
    k.set(this, "oncontextmenu", e);
  }
  get oncuechange() {
    return k.get(this, "oncuechange");
  }
  set oncuechange(e) {
    k.set(this, "oncuechange", e);
  }
  get ondblclick() {
    return k.get(this, "ondblclick");
  }
  set ondblclick(e) {
    k.set(this, "ondblclick", e);
  }
  get ondrag() {
    return k.get(this, "ondrag");
  }
  set ondrag(e) {
    k.set(this, "ondrag", e);
  }
  get ondragend() {
    return k.get(this, "ondragend");
  }
  set ondragend(e) {
    k.set(this, "ondragend", e);
  }
  get ondragenter() {
    return k.get(this, "ondragenter");
  }
  set ondragenter(e) {
    k.set(this, "ondragenter", e);
  }
  get ondragleave() {
    return k.get(this, "ondragleave");
  }
  set ondragleave(e) {
    k.set(this, "ondragleave", e);
  }
  get ondragover() {
    return k.get(this, "ondragover");
  }
  set ondragover(e) {
    k.set(this, "ondragover", e);
  }
  get ondragstart() {
    return k.get(this, "ondragstart");
  }
  set ondragstart(e) {
    k.set(this, "ondragstart", e);
  }
  get ondrop() {
    return k.get(this, "ondrop");
  }
  set ondrop(e) {
    k.set(this, "ondrop", e);
  }
  get ondurationchange() {
    return k.get(this, "ondurationchange");
  }
  set ondurationchange(e) {
    k.set(this, "ondurationchange", e);
  }
  get onemptied() {
    return k.get(this, "onemptied");
  }
  set onemptied(e) {
    k.set(this, "onemptied", e);
  }
  get onended() {
    return k.get(this, "onended");
  }
  set onended(e) {
    k.set(this, "onended", e);
  }
  get onerror() {
    return k.get(this, "onerror");
  }
  set onerror(e) {
    k.set(this, "onerror", e);
  }
  get onfocus() {
    return k.get(this, "onfocus");
  }
  set onfocus(e) {
    k.set(this, "onfocus", e);
  }
  get oninput() {
    return k.get(this, "oninput");
  }
  set oninput(e) {
    k.set(this, "oninput", e);
  }
  get oninvalid() {
    return k.get(this, "oninvalid");
  }
  set oninvalid(e) {
    k.set(this, "oninvalid", e);
  }
  get onkeydown() {
    return k.get(this, "onkeydown");
  }
  set onkeydown(e) {
    k.set(this, "onkeydown", e);
  }
  get onkeypress() {
    return k.get(this, "onkeypress");
  }
  set onkeypress(e) {
    k.set(this, "onkeypress", e);
  }
  get onkeyup() {
    return k.get(this, "onkeyup");
  }
  set onkeyup(e) {
    k.set(this, "onkeyup", e);
  }
  get onload() {
    return k.get(this, "onload");
  }
  set onload(e) {
    k.set(this, "onload", e);
  }
  get onloadeddata() {
    return k.get(this, "onloadeddata");
  }
  set onloadeddata(e) {
    k.set(this, "onloadeddata", e);
  }
  get onloadedmetadata() {
    return k.get(this, "onloadedmetadata");
  }
  set onloadedmetadata(e) {
    k.set(this, "onloadedmetadata", e);
  }
  get onloadstart() {
    return k.get(this, "onloadstart");
  }
  set onloadstart(e) {
    k.set(this, "onloadstart", e);
  }
  get onmousedown() {
    return k.get(this, "onmousedown");
  }
  set onmousedown(e) {
    k.set(this, "onmousedown", e);
  }
  get onmouseenter() {
    return k.get(this, "onmouseenter");
  }
  set onmouseenter(e) {
    k.set(this, "onmouseenter", e);
  }
  get onmouseleave() {
    return k.get(this, "onmouseleave");
  }
  set onmouseleave(e) {
    k.set(this, "onmouseleave", e);
  }
  get onmousemove() {
    return k.get(this, "onmousemove");
  }
  set onmousemove(e) {
    k.set(this, "onmousemove", e);
  }
  get onmouseout() {
    return k.get(this, "onmouseout");
  }
  set onmouseout(e) {
    k.set(this, "onmouseout", e);
  }
  get onmouseover() {
    return k.get(this, "onmouseover");
  }
  set onmouseover(e) {
    k.set(this, "onmouseover", e);
  }
  get onmouseup() {
    return k.get(this, "onmouseup");
  }
  set onmouseup(e) {
    k.set(this, "onmouseup", e);
  }
  get onmousewheel() {
    return k.get(this, "onmousewheel");
  }
  set onmousewheel(e) {
    k.set(this, "onmousewheel", e);
  }
  get onpause() {
    return k.get(this, "onpause");
  }
  set onpause(e) {
    k.set(this, "onpause", e);
  }
  get onplay() {
    return k.get(this, "onplay");
  }
  set onplay(e) {
    k.set(this, "onplay", e);
  }
  get onplaying() {
    return k.get(this, "onplaying");
  }
  set onplaying(e) {
    k.set(this, "onplaying", e);
  }
  get onprogress() {
    return k.get(this, "onprogress");
  }
  set onprogress(e) {
    k.set(this, "onprogress", e);
  }
  get onratechange() {
    return k.get(this, "onratechange");
  }
  set onratechange(e) {
    k.set(this, "onratechange", e);
  }
  get onreset() {
    return k.get(this, "onreset");
  }
  set onreset(e) {
    k.set(this, "onreset", e);
  }
  get onresize() {
    return k.get(this, "onresize");
  }
  set onresize(e) {
    k.set(this, "onresize", e);
  }
  get onscroll() {
    return k.get(this, "onscroll");
  }
  set onscroll(e) {
    k.set(this, "onscroll", e);
  }
  get onseeked() {
    return k.get(this, "onseeked");
  }
  set onseeked(e) {
    k.set(this, "onseeked", e);
  }
  get onseeking() {
    return k.get(this, "onseeking");
  }
  set onseeking(e) {
    k.set(this, "onseeking", e);
  }
  get onselect() {
    return k.get(this, "onselect");
  }
  set onselect(e) {
    k.set(this, "onselect", e);
  }
  get onshow() {
    return k.get(this, "onshow");
  }
  set onshow(e) {
    k.set(this, "onshow", e);
  }
  get onstalled() {
    return k.get(this, "onstalled");
  }
  set onstalled(e) {
    k.set(this, "onstalled", e);
  }
  get onsubmit() {
    return k.get(this, "onsubmit");
  }
  set onsubmit(e) {
    k.set(this, "onsubmit", e);
  }
  get onsuspend() {
    return k.get(this, "onsuspend");
  }
  set onsuspend(e) {
    k.set(this, "onsuspend", e);
  }
  get ontimeupdate() {
    return k.get(this, "ontimeupdate");
  }
  set ontimeupdate(e) {
    k.set(this, "ontimeupdate", e);
  }
  get ontoggle() {
    return k.get(this, "ontoggle");
  }
  set ontoggle(e) {
    k.set(this, "ontoggle", e);
  }
  get onvolumechange() {
    return k.get(this, "onvolumechange");
  }
  set onvolumechange(e) {
    k.set(this, "onvolumechange", e);
  }
  get onwaiting() {
    return k.get(this, "onwaiting");
  }
  set onwaiting(e) {
    k.set(this, "onwaiting", e);
  }
  get onauxclick() {
    return k.get(this, "onauxclick");
  }
  set onauxclick(e) {
    k.set(this, "onauxclick", e);
  }
  get ongotpointercapture() {
    return k.get(this, "ongotpointercapture");
  }
  set ongotpointercapture(e) {
    k.set(this, "ongotpointercapture", e);
  }
  get onlostpointercapture() {
    return k.get(this, "onlostpointercapture");
  }
  set onlostpointercapture(e) {
    k.set(this, "onlostpointercapture", e);
  }
  get onpointercancel() {
    return k.get(this, "onpointercancel");
  }
  set onpointercancel(e) {
    k.set(this, "onpointercancel", e);
  }
  get onpointerdown() {
    return k.get(this, "onpointerdown");
  }
  set onpointerdown(e) {
    k.set(this, "onpointerdown", e);
  }
  get onpointerenter() {
    return k.get(this, "onpointerenter");
  }
  set onpointerenter(e) {
    k.set(this, "onpointerenter", e);
  }
  get onpointerleave() {
    return k.get(this, "onpointerleave");
  }
  set onpointerleave(e) {
    k.set(this, "onpointerleave", e);
  }
  get onpointermove() {
    return k.get(this, "onpointermove");
  }
  set onpointermove(e) {
    k.set(this, "onpointermove", e);
  }
  get onpointerout() {
    return k.get(this, "onpointerout");
  }
  set onpointerout(e) {
    k.set(this, "onpointerout", e);
  }
  get onpointerover() {
    return k.get(this, "onpointerover");
  }
  set onpointerover(e) {
    k.set(this, "onpointerover", e);
  }
  get onpointerup() {
    return k.get(this, "onpointerup");
  }
  set onpointerup(e) {
    k.set(this, "onpointerup", e);
  }
};
l(q, "HTMLElement");
var H4 = "template", pv = class extends q {
  constructor(e) {
    super(e, H4);
    const t = this.ownerDocument.createDocumentFragment();
    (this[Ma] = t)[bt] = this;
  }
  get content() {
    if (this.hasChildNodes() && !this[Ma].hasChildNodes())
      for (const e of this.childNodes)
        this[Ma].appendChild(e.cloneNode(!0));
    return this[Ma];
  }
};
l(pv, "HTMLTemplateElement");
Rt(H4, pv);
var W4 = class extends q {
  constructor(e, t = "html") {
    super(e, t);
  }
};
l(W4, "HTMLHtmlElement");
var { toString: BT } = q.prototype, da = class extends q {
  get innerHTML() {
    return this.textContent;
  }
  set innerHTML(e) {
    this.textContent = e;
  }
  toString() {
    return BT.call(this.cloneNode()).replace(/></, `>${this.textContent}<`);
  }
};
l(da, "TextElement");
var $4 = "script", fv = class extends da {
  constructor(e, t = $4) {
    super(e, t);
  }
  get type() {
    return X.get(this, "type");
  }
  set type(e) {
    X.set(this, "type", e);
  }
  get src() {
    return X.get(this, "src");
  }
  set src(e) {
    X.set(this, "src", e);
  }
  get defer() {
    return He.get(this, "defer");
  }
  set defer(e) {
    He.set(this, "defer", e);
  }
  get crossOrigin() {
    return X.get(this, "crossorigin");
  }
  set crossOrigin(e) {
    X.set(this, "crossorigin", e);
  }
  get nomodule() {
    return He.get(this, "nomodule");
  }
  set nomodule(e) {
    He.set(this, "nomodule", e);
  }
  get referrerPolicy() {
    return X.get(this, "referrerpolicy");
  }
  set referrerPolicy(e) {
    X.set(this, "referrerpolicy", e);
  }
  get nonce() {
    return X.get(this, "nonce");
  }
  set nonce(e) {
    X.set(this, "nonce", e);
  }
  get async() {
    return He.get(this, "async");
  }
  set async(e) {
    He.set(this, "async", e);
  }
};
l(fv, "HTMLScriptElement");
Rt($4, fv);
var G4 = class extends q {
  constructor(e, t = "frame") {
    super(e, t);
  }
};
l(G4, "HTMLFrameElement");
var q4 = "iframe", mv = class extends q {
  constructor(e, t = q4) {
    super(e, t);
  }
  get src() {
    return X.get(this, "src");
  }
  set src(e) {
    X.set(this, "src", e);
  }
};
l(mv, "HTMLIFrameElement");
Rt(q4, mv);
var K4 = class extends q {
  constructor(e, t = "object") {
    super(e, t);
  }
};
l(K4, "HTMLObjectElement");
var z4 = class extends q {
  constructor(e, t = "head") {
    super(e, t);
  }
};
l(z4, "HTMLHeadElement");
var Y4 = class extends q {
  constructor(e, t = "body") {
    super(e, t);
  }
};
l(Y4, "HTMLBodyElement");
var OT = Wi(n7(), 1), X4 = "style", vv = class extends da {
  constructor(e, t = X4) {
    super(e, t), this[Fs] = null;
  }
  get sheet() {
    const e = this[Fs];
    return e !== null ? e : this[Fs] = (0, OT.parse)(this.textContent);
  }
  get innerHTML() {
    return super.innerHTML || "";
  }
  set innerHTML(e) {
    super.textContent = e, this[Fs] = null;
  }
  get innerText() {
    return super.innerText || "";
  }
  set innerText(e) {
    super.textContent = e, this[Fs] = null;
  }
  get textContent() {
    return super.textContent || "";
  }
  set textContent(e) {
    super.textContent = e, this[Fs] = null;
  }
};
l(vv, "HTMLStyleElement");
Rt(X4, vv);
var J4 = class extends q {
  constructor(e, t = "time") {
    super(e, t);
  }
};
l(J4, "HTMLTimeElement");
var Z4 = class extends q {
  constructor(e, t = "fieldset") {
    super(e, t);
  }
};
l(Z4, "HTMLFieldSetElement");
var Q4 = class extends q {
  constructor(e, t = "embed") {
    super(e, t);
  }
};
l(Q4, "HTMLEmbedElement");
var e6 = class extends q {
  constructor(e, t = "hr") {
    super(e, t);
  }
};
l(e6, "HTMLHRElement");
var t6 = class extends q {
  constructor(e, t = "progress") {
    super(e, t);
  }
};
l(t6, "HTMLProgressElement");
var i6 = class extends q {
  constructor(e, t = "p") {
    super(e, t);
  }
};
l(i6, "HTMLParagraphElement");
var n6 = class extends q {
  constructor(e, t = "table") {
    super(e, t);
  }
};
l(n6, "HTMLTableElement");
var s6 = class extends q {
  constructor(e, t = "frameset") {
    super(e, t);
  }
};
l(s6, "HTMLFrameSetElement");
var r6 = class extends q {
  constructor(e, t = "li") {
    super(e, t);
  }
};
l(r6, "HTMLLIElement");
var o6 = class extends q {
  constructor(e, t = "base") {
    super(e, t);
  }
};
l(o6, "HTMLBaseElement");
var a6 = class extends q {
  constructor(e, t = "datalist") {
    super(e, t);
  }
};
l(a6, "HTMLDataListElement");
var l6 = "input", gv = class extends q {
  constructor(e, t = l6) {
    super(e, t);
  }
  get autofocus() {
    return He.get(this, "autofocus") || -1;
  }
  set autofocus(e) {
    He.set(this, "autofocus", e);
  }
  get disabled() {
    return He.get(this, "disabled");
  }
  set disabled(e) {
    He.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get placeholder() {
    return this.getAttribute("placeholder");
  }
  set placeholder(e) {
    this.setAttribute("placeholder", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
};
l(gv, "HTMLInputElement");
Rt(l6, gv);
var u6 = class extends q {
  constructor(e, t = "param") {
    super(e, t);
  }
};
l(u6, "HTMLParamElement");
var c6 = class extends q {
  constructor(e, t = "media") {
    super(e, t);
  }
};
l(c6, "HTMLMediaElement");
var h6 = class extends q {
  constructor(e, t = "audio") {
    super(e, t);
  }
};
l(h6, "HTMLAudioElement");
var d6 = "h1", yv = class extends q {
  constructor(e, t = d6) {
    super(e, t);
  }
};
l(yv, "HTMLHeadingElement");
Rt([d6, "h2", "h3", "h4", "h5", "h6"], yv);
var p6 = class extends q {
  constructor(e, t = "dir") {
    super(e, t);
  }
};
l(p6, "HTMLDirectoryElement");
var f6 = class extends q {
  constructor(e, t = "quote") {
    super(e, t);
  }
};
l(f6, "HTMLQuoteElement");
var FT = Wi(s7(), 1), { createCanvas: VT } = FT.default, m6 = "canvas", _v = class extends q {
  constructor(e, t = m6) {
    super(e, t), this[gi] = VT(300, 150);
  }
  get width() {
    return this[gi].width;
  }
  set width(e) {
    Ln.set(this, "width", e), this[gi].width = e;
  }
  get height() {
    return this[gi].height;
  }
  set height(e) {
    Ln.set(this, "height", e), this[gi].height = e;
  }
  getContext(e) {
    return this[gi].getContext(e);
  }
  toDataURL(...e) {
    return this[gi].toDataURL(...e);
  }
};
l(_v, "HTMLCanvasElement");
Rt(m6, _v);
var v6 = class extends q {
  constructor(e, t = "legend") {
    super(e, t);
  }
};
l(v6, "HTMLLegendElement");
var g6 = class extends q {
  constructor(e, t = "option") {
    super(e, t);
  }
};
l(g6, "HTMLOptionElement");
var y6 = class extends q {
  constructor(e, t = "span") {
    super(e, t);
  }
};
l(y6, "HTMLSpanElement");
var _6 = class extends q {
  constructor(e, t = "meter") {
    super(e, t);
  }
};
l(_6, "HTMLMeterElement");
var b6 = class extends q {
  constructor(e, t = "video") {
    super(e, t);
  }
};
l(b6, "HTMLVideoElement");
var w6 = class extends q {
  constructor(e, t = "td") {
    super(e, t);
  }
};
l(w6, "HTMLTableCellElement");
var S6 = "title", bv = class extends da {
  constructor(e, t = S6) {
    super(e, t);
  }
};
l(bv, "HTMLTitleElement");
Rt(S6, bv);
var C6 = class extends q {
  constructor(e, t = "output") {
    super(e, t);
  }
};
l(C6, "HTMLOutputElement");
var T6 = class extends q {
  constructor(e, t = "tr") {
    super(e, t);
  }
};
l(T6, "HTMLTableRowElement");
var x6 = class extends q {
  constructor(e, t = "data") {
    super(e, t);
  }
};
l(x6, "HTMLDataElement");
var E6 = class extends q {
  constructor(e, t = "menu") {
    super(e, t);
  }
};
l(E6, "HTMLMenuElement");
var k6 = "select", wv = class extends q {
  constructor(e, t = k6) {
    super(e, t);
  }
  get options() {
    let e = new bi(), { firstElementChild: t } = this;
    for (; t; )
      t.tagName === "OPTGROUP" ? e.push(...t.children) : e.push(t), t = t.nextElementSibling;
    return e;
  }
  get disabled() {
    return He.get(this, "disabled");
  }
  set disabled(e) {
    He.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
};
l(wv, "HTMLSelectElement");
Rt(k6, wv);
var A6 = class extends q {
  constructor(e, t = "br") {
    super(e, t);
  }
};
l(A6, "HTMLBRElement");
var I6 = "button", Sv = class extends q {
  constructor(e, t = I6) {
    super(e, t);
  }
  get disabled() {
    return He.get(this, "disabled");
  }
  set disabled(e) {
    He.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
};
l(Sv, "HTMLButtonElement");
Rt(I6, Sv);
var P6 = class extends q {
  constructor(e, t = "map") {
    super(e, t);
  }
};
l(P6, "HTMLMapElement");
var M6 = class extends q {
  constructor(e, t = "optgroup") {
    super(e, t);
  }
};
l(M6, "HTMLOptGroupElement");
var N6 = class extends q {
  constructor(e, t = "dl") {
    super(e, t);
  }
};
l(N6, "HTMLDListElement");
var R6 = "textarea", Cv = class extends da {
  constructor(e, t = R6) {
    super(e, t);
  }
  get disabled() {
    return He.get(this, "disabled");
  }
  set disabled(e) {
    He.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get placeholder() {
    return this.getAttribute("placeholder");
  }
  set placeholder(e) {
    this.setAttribute("placeholder", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
  get value() {
    return this.textContent;
  }
  set value(e) {
    this.textContent = e;
  }
};
l(Cv, "HTMLTextAreaElement");
Rt(R6, Cv);
var L6 = class extends q {
  constructor(e, t = "font") {
    super(e, t);
  }
};
l(L6, "HTMLFontElement");
var D6 = class extends q {
  constructor(e, t = "div") {
    super(e, t);
  }
};
l(D6, "HTMLDivElement");
var B6 = "link", Tv = class extends q {
  constructor(e, t = B6) {
    super(e, t);
  }
  get disabled() {
    return He.get(this, "disabled");
  }
  set disabled(e) {
    He.set(this, "disabled", e);
  }
  get href() {
    return X.get(this, "href");
  }
  set href(e) {
    X.set(this, "href", e);
  }
  get hreflang() {
    return X.get(this, "hreflang");
  }
  set hreflang(e) {
    X.set(this, "hreflang", e);
  }
  get media() {
    return X.get(this, "media");
  }
  set media(e) {
    X.set(this, "media", e);
  }
  get rel() {
    return X.get(this, "rel");
  }
  set rel(e) {
    X.set(this, "rel", e);
  }
  get type() {
    return X.get(this, "type");
  }
  set type(e) {
    X.set(this, "type", e);
  }
};
l(Tv, "HTMLLinkElement");
Rt(B6, Tv);
var O6 = class extends q {
  constructor(e, t = "slot") {
    super(e, t);
  }
};
l(O6, "HTMLSlotElement");
var F6 = class extends q {
  constructor(e, t = "form") {
    super(e, t);
  }
};
l(F6, "HTMLFormElement");
var V6 = "img", Wu = class extends q {
  constructor(e, t = V6) {
    super(e, t);
  }
  get alt() {
    return X.get(this, "alt");
  }
  set alt(e) {
    X.set(this, "alt", e);
  }
  get sizes() {
    return X.get(this, "sizes");
  }
  set sizes(e) {
    X.set(this, "sizes", e);
  }
  get src() {
    return X.get(this, "src");
  }
  set src(e) {
    X.set(this, "src", e);
  }
  get srcset() {
    return X.get(this, "srcset");
  }
  set srcset(e) {
    X.set(this, "srcset", e);
  }
  get title() {
    return X.get(this, "title");
  }
  set title(e) {
    X.set(this, "title", e);
  }
  get width() {
    return Ln.get(this, "width");
  }
  set width(e) {
    Ln.set(this, "width", e);
  }
  get height() {
    return Ln.get(this, "height");
  }
  set height(e) {
    Ln.set(this, "height", e);
  }
};
l(Wu, "HTMLImageElement");
Rt(V6, Wu);
var U6 = class extends q {
  constructor(e, t = "pre") {
    super(e, t);
  }
};
l(U6, "HTMLPreElement");
var j6 = class extends q {
  constructor(e, t = "ul") {
    super(e, t);
  }
};
l(j6, "HTMLUListElement");
var H6 = class extends q {
  constructor(e, t = "meta") {
    super(e, t);
  }
};
l(H6, "HTMLMetaElement");
var W6 = class extends q {
  constructor(e, t = "picture") {
    super(e, t);
  }
};
l(W6, "HTMLPictureElement");
var $6 = class extends q {
  constructor(e, t = "area") {
    super(e, t);
  }
};
l($6, "HTMLAreaElement");
var G6 = class extends q {
  constructor(e, t = "ol") {
    super(e, t);
  }
};
l(G6, "HTMLOListElement");
var q6 = class extends q {
  constructor(e, t = "caption") {
    super(e, t);
  }
};
l(q6, "HTMLTableCaptionElement");
var K6 = "a", xv = class extends q {
  constructor(e, t = K6) {
    super(e, t);
  }
  get href() {
    return encodeURI(X.get(this, "href"));
  }
  set href(e) {
    X.set(this, "href", decodeURI(e));
  }
  get download() {
    return encodeURI(X.get(this, "download"));
  }
  set download(e) {
    X.set(this, "download", decodeURI(e));
  }
  get target() {
    return X.get(this, "target");
  }
  set target(e) {
    X.set(this, "target", e);
  }
  get type() {
    return X.get(this, "type");
  }
  set type(e) {
    X.set(this, "type", e);
  }
};
l(xv, "HTMLAnchorElement");
Rt(K6, xv);
var z6 = class extends q {
  constructor(e, t = "label") {
    super(e, t);
  }
};
l(z6, "HTMLLabelElement");
var Y6 = class extends q {
  constructor(e, t = "unknown") {
    super(e, t);
  }
};
l(Y6, "HTMLUnknownElement");
var X6 = class extends q {
  constructor(e, t = "mod") {
    super(e, t);
  }
};
l(X6, "HTMLModElement");
var J6 = class extends q {
  constructor(e, t = "details") {
    super(e, t);
  }
};
l(J6, "HTMLDetailsElement");
var Z6 = "source", Ev = class extends q {
  constructor(e, t = Z6) {
    super(e, t);
  }
  get src() {
    return X.get(this, "src");
  }
  set src(e) {
    X.set(this, "src", e);
  }
  get srcset() {
    return X.get(this, "srcset");
  }
  set srcset(e) {
    X.set(this, "srcset", e);
  }
  get sizes() {
    return X.get(this, "sizes");
  }
  set sizes(e) {
    X.set(this, "sizes", e);
  }
  get type() {
    return X.get(this, "type");
  }
  set type(e) {
    X.set(this, "type", e);
  }
};
l(Ev, "HTMLSourceElement");
Rt(Z6, Ev);
var Q6 = class extends q {
  constructor(e, t = "track") {
    super(e, t);
  }
};
l(Q6, "HTMLTrackElement");
var ew = class extends q {
  constructor(e, t = "marquee") {
    super(e, t);
  }
};
l(ew, "HTMLMarqueeElement");
var UT = {
  HTMLElement: q,
  HTMLTemplateElement: pv,
  HTMLHtmlElement: W4,
  HTMLScriptElement: fv,
  HTMLFrameElement: G4,
  HTMLIFrameElement: mv,
  HTMLObjectElement: K4,
  HTMLHeadElement: z4,
  HTMLBodyElement: Y4,
  HTMLStyleElement: vv,
  HTMLTimeElement: J4,
  HTMLFieldSetElement: Z4,
  HTMLEmbedElement: Q4,
  HTMLHRElement: e6,
  HTMLProgressElement: t6,
  HTMLParagraphElement: i6,
  HTMLTableElement: n6,
  HTMLFrameSetElement: s6,
  HTMLLIElement: r6,
  HTMLBaseElement: o6,
  HTMLDataListElement: a6,
  HTMLInputElement: gv,
  HTMLParamElement: u6,
  HTMLMediaElement: c6,
  HTMLAudioElement: h6,
  HTMLHeadingElement: yv,
  HTMLDirectoryElement: p6,
  HTMLQuoteElement: f6,
  HTMLCanvasElement: _v,
  HTMLLegendElement: v6,
  HTMLOptionElement: g6,
  HTMLSpanElement: y6,
  HTMLMeterElement: _6,
  HTMLVideoElement: b6,
  HTMLTableCellElement: w6,
  HTMLTitleElement: bv,
  HTMLOutputElement: C6,
  HTMLTableRowElement: T6,
  HTMLDataElement: x6,
  HTMLMenuElement: E6,
  HTMLSelectElement: wv,
  HTMLBRElement: A6,
  HTMLButtonElement: Sv,
  HTMLMapElement: P6,
  HTMLOptGroupElement: M6,
  HTMLDListElement: N6,
  HTMLTextAreaElement: Cv,
  HTMLFontElement: L6,
  HTMLDivElement: D6,
  HTMLLinkElement: Tv,
  HTMLSlotElement: O6,
  HTMLFormElement: F6,
  HTMLImageElement: Wu,
  HTMLPreElement: U6,
  HTMLUListElement: j6,
  HTMLMetaElement: H6,
  HTMLPictureElement: W6,
  HTMLAreaElement: $6,
  HTMLOListElement: G6,
  HTMLTableCaptionElement: q6,
  HTMLAnchorElement: xv,
  HTMLLabelElement: z6,
  HTMLUnknownElement: Y6,
  HTMLModElement: X6,
  HTMLDetailsElement: J6,
  HTMLSourceElement: Ev,
  HTMLTrackElement: Q6,
  HTMLMarqueeElement: ew
}, La = { test: () => !0 }, jT = {
  "text/html": {
    docType: "<!DOCTYPE html>",
    ignoreCase: !0,
    voidElements: /^(?:area|base|br|col|embed|hr|img|input|keygen|link|menuitem|meta|param|source|track|wbr)$/i
  },
  "image/svg+xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: La
  },
  "text/xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: La
  },
  "application/xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: La
  },
  "application/xhtml+xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: La
  }
}, tw = typeof CustomEvent == "function" ? CustomEvent : /* @__PURE__ */ l(class extends Wn {
  constructor(t, i = {}) {
    super(t, i), this.detail = i.detail;
  }
}, "CustomEvent"), iw = class extends Wn {
  constructor(e, t = {}) {
    super(e, t), this.inputType = t.inputType, this.data = t.data, this.dataTransfer = t.dataTransfer, this.isComposing = t.isComposing || !1, this.ranges = t.ranges;
  }
};
l(iw, "InputEvent");
var HT = /* @__PURE__ */ l((e) => /* @__PURE__ */ l(class extends Wu {
  constructor(i, n) {
    switch (super(e), arguments.length) {
      case 1:
        this.height = i, this.width = i;
        break;
      case 2:
        this.height = n, this.width = i;
        break;
    }
  }
}, "Image"), "ImageClass"), _2 = /* @__PURE__ */ l(({ [Ut]: e, [re]: t }, i = null) => {
  Jb(e[pt], t[G]);
  do {
    const n = ei(e), s = n === t ? n : n[G];
    i ? i.insertBefore(e, i[re]) : e.remove(), e = s;
  } while (e !== t);
}, "deleteContents"), kv = class {
  constructor() {
    this[Ut] = null, this[re] = null, this.commonAncestorContainer = null;
  }
  insertNode(e) {
    this[re].parentNode.insertBefore(e, this[Ut]);
  }
  selectNode(e) {
    this[Ut] = e, this[re] = ei(e);
  }
  surroundContents(e) {
    e.replaceChildren(this.extractContents());
  }
  setStartBefore(e) {
    this[Ut] = e;
  }
  setStartAfter(e) {
    this[Ut] = e.nextSibling;
  }
  setEndBefore(e) {
    this[re] = ei(e.previousSibling);
  }
  setEndAfter(e) {
    this[re] = ei(e);
  }
  cloneContents() {
    let { [Ut]: e, [re]: t } = this;
    const i = e.ownerDocument.createDocumentFragment();
    for (; e !== t; )
      i.insertBefore(e.cloneNode(!0), i[re]), e = ei(e), e !== t && (e = e[G]);
    return i;
  }
  deleteContents() {
    _2(this);
  }
  extractContents() {
    const e = this[Ut].ownerDocument.createDocumentFragment();
    return _2(this, e), e;
  }
  createContextualFragment(e) {
    const t = this.commonAncestorContainer.createElement("template");
    return t.innerHTML = e, this.selectNode(t.content), t.content;
  }
  cloneRange() {
    const e = new kv();
    return e[Ut] = this[Ut], e[re] = this[re], e;
  }
};
l(kv, "Range");
var WT = /* @__PURE__ */ l(({ nodeType: e }, t) => {
  switch (e) {
    case Oe:
      return t & MC;
    case St:
      return t & NC;
    case an:
      return t & RC;
  }
  return 0;
}, "isOK"), nw = class {
  constructor(e, t = PC) {
    this.root = e, this.currentNode = e, this.whatToShow = t;
    let { [G]: i, [re]: n } = e;
    if (e.nodeType === Pn) {
      const { documentElement: r } = e;
      i = r, n = r[re];
    }
    const s = [];
    for (; i !== n; )
      WT(i, t) && s.push(i), i = i[G];
    this[bt] = { i: 0, nodes: s };
  }
  nextNode() {
    const e = this[bt];
    return this.currentNode = e.i < e.nodes.length ? e.nodes[e.i++] : null, this.currentNode;
  }
};
l(nw, "TreeWalker");
var b2 = /* @__PURE__ */ l((e, t, i) => {
  let { [G]: n, [re]: s } = t;
  return e.call({ ownerDocument: t, [G]: n, [re]: s }, i);
}, "query"), sw = FC({}, DT, UT, {
  CustomEvent: tw,
  Event: Wn,
  EventTarget: xu,
  InputEvent: iw,
  NamedNodeMap: dv,
  NodeList: bi
}), Da = /* @__PURE__ */ new WeakMap(), $n = class extends Iu {
  constructor(e) {
    super(null, "#document", Pn), this[vi] = { active: !1, registry: null }, this[Mn] = { active: !1, class: null }, this[br] = jT[e], this[Yn] = null, this[fc] = null, this[il] = null, this[gi] = null, this[Ro] = null;
  }
  get defaultView() {
    return Da.has(this) || Da.set(this, new Proxy(globalThis, {
      set: (e, t, i) => {
        switch (t) {
          case "addEventListener":
          case "removeEventListener":
          case "dispatchEvent":
            this[Dr][t] = i;
            break;
          default:
            e[t] = i;
            break;
        }
        return !0;
      },
      get: (e, t) => {
        switch (t) {
          case "addEventListener":
          case "removeEventListener":
          case "dispatchEvent":
            if (!this[Dr]) {
              const i = this[Dr] = new xu();
              i.dispatchEvent = i.dispatchEvent.bind(i), i.addEventListener = i.addEventListener.bind(i), i.removeEventListener = i.removeEventListener.bind(i);
            }
            return this[Dr][t];
          case "document":
            return this;
          case "navigator":
            return {
              userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36"
            };
          case "window":
            return Da.get(this);
          case "customElements":
            return this[vi].registry || (this[vi] = new Qb(this)), this[vi];
          case "performance":
            return KC.performance;
          case "DOMParser":
            return this[fc];
          case "Image":
            return this[gi] || (this[gi] = HT(this)), this[gi];
          case "MutationObserver":
            return this[Mn].class || (this[Mn] = new a4(this)), this[Mn].class;
        }
        return this[il] && this[il][t] || sw[t] || e[t];
      }
    })), Da.get(this);
  }
  get doctype() {
    const e = this[Yn];
    if (e)
      return e;
    const { firstChild: t } = this;
    return t && t.nodeType === fr ? this[Yn] = t : null;
  }
  set doctype(e) {
    if (/^([a-z:]+)(\s+system|\s+public(\s+"([^"]+)")?)?(\s+"([^"]+)")?/i.test(e)) {
      const { $1: t, $4: i, $6: n } = RegExp;
      this[Yn] = new mr(this, t, i, n), Su(this, this[Yn], this[G]);
    }
  }
  get documentElement() {
    return this.firstElementChild;
  }
  get isConnected() {
    return !0;
  }
  _getParent() {
    return this[Dr];
  }
  createAttribute(e) {
    return new Is(this, e);
  }
  createComment(e) {
    return new ha(this, e);
  }
  createDocumentFragment() {
    return new Pu(this);
  }
  createDocumentType(e, t, i) {
    return new mr(this, e, t, i);
  }
  createElement(e) {
    return new Cr(this, e);
  }
  createRange() {
    const e = new kv();
    return e.commonAncestorContainer = this, e;
  }
  createTextNode(e) {
    return new Ps(this, e);
  }
  createTreeWalker(e, t = -1) {
    return new nw(e, t);
  }
  createNodeIterator(e, t = -1) {
    return this.createTreeWalker(e, t);
  }
  createEvent(e) {
    const t = VC(e === "Event" ? new Wn("") : new tw(""));
    return t.initEvent = t.initCustomEvent = (i, n = !1, s = !1, r) => {
      UC(t, {
        type: { value: i },
        canBubble: { value: n },
        cancelable: { value: s },
        detail: { value: r }
      });
    }, t;
  }
  cloneNode(e = !1) {
    const {
      constructor: t,
      [vi]: i,
      [Yn]: n
    } = this, s = new t();
    if (s[vi] = i, e) {
      const r = s[re], { childNodes: a } = this;
      for (let { length: u } = a, c = 0; c < u; c++)
        s.insertBefore(a[c].cloneNode(!0), r);
      n && (s[Yn] = a[0]);
    }
    return s;
  }
  importNode(e) {
    const t = 1 < arguments.length && !!arguments[1], i = e.cloneNode(t), { [vi]: n } = this, { active: s } = n, r = /* @__PURE__ */ l((a) => {
      const { ownerDocument: u, nodeType: c } = a;
      a.ownerDocument = this, s && u !== this && c === Oe && n.upgrade(a);
    }, "upgrade");
    if (r(i), t)
      switch (i.nodeType) {
        case Oe:
        case Fn: {
          let { [G]: a, [re]: u } = i;
          for (; a !== u; )
            a.nodeType === Oe && r(a), a = a[G];
          break;
        }
      }
    return i;
  }
  toString() {
    return this.childNodes.join("");
  }
  querySelector(e) {
    return b2(super.querySelector, this, e);
  }
  querySelectorAll(e) {
    return b2(super.querySelectorAll, this, e);
  }
  getElementsByTagNameNS(e, t) {
    return this.getElementsByTagName(t);
  }
  createAttributeNS(e, t) {
    return this.createAttribute(t);
  }
  createElementNS(e, t, i) {
    return e === Gl ? new Nu(this, t, null) : this.createElement(t, i);
  }
};
l($n, "Document");
Gt(sw.Document = /* @__PURE__ */ l(function() {
  ui();
}, "Document"), $n).prototype = $n.prototype;
var $T = /* @__PURE__ */ l((e, t, i, n) => {
  if (!t && Kl.has(i)) {
    const a = Kl.get(i);
    return new a(e, i);
  }
  const { [vi]: { active: s, registry: r } } = e;
  if (s) {
    const a = t ? n.is : i;
    if (r.has(a)) {
      const { Class: u } = r.get(a), c = new u(e, i);
      return ks.set(c, { connected: !1 }), c;
    }
  }
  return new q(e, i);
}, "createHTMLElement"), rw = class extends $n {
  constructor() {
    super("text/html");
  }
  get all() {
    const e = new bi();
    let { [G]: t, [re]: i } = this;
    for (; t !== i; ) {
      switch (t.nodeType) {
        case Oe:
          e.push(t);
          break;
      }
      t = t[G];
    }
    return e;
  }
  get head() {
    const { documentElement: e } = this;
    let { firstElementChild: t } = e;
    return (!t || t.tagName !== "HEAD") && (t = this.createElement("head"), e.prepend(t)), t;
  }
  get body() {
    const { head: e } = this;
    let { nextElementSibling: t } = e;
    return (!t || t.tagName !== "BODY") && (t = this.createElement("body"), e.after(t)), t;
  }
  get title() {
    const { head: e } = this;
    let t = e.getElementsByTagName("title").shift();
    return t ? t.textContent : "";
  }
  set title(e) {
    const { head: t } = this;
    let i = t.getElementsByTagName("title").shift();
    i ? i.textContent = e : t.insertBefore(this.createElement("title"), t.firstChild).textContent = e;
  }
  createElement(e, t) {
    const i = !!(t && t.is), n = $T(this, i, e, t);
    return i && n.setAttribute("is", t.is), n;
  }
};
l(rw, "HTMLDocument");
var ow = class extends $n {
  constructor() {
    super("image/svg+xml");
  }
  toString() {
    return this[br].docType + super.toString();
  }
};
l(ow, "SVGDocument");
var aw = class extends $n {
  constructor() {
    super("text/xml");
  }
  toString() {
    return this[br].docType + super.toString();
  }
};
l(aw, "XMLDocument");
var Av = class {
  parseFromString(e, t, i = null) {
    let n = !1, s;
    return t === "text/html" ? (n = !0, s = new rw()) : t === "image/svg+xml" ? s = new ow() : s = new aw(), s[fc] = Av, i && (s[il] = i), e ? e4(s, n, e) : s;
  }
};
l(Av, "DOMParser");
function lw() {
  ui();
}
l(lw, "Document");
Gt(lw, $n).prototype = $n.prototype;
var ki = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Xn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ce = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, GT = function(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator], i;
  return t ? t.call(e) : (e = typeof __values == "function" ? __values(e) : e[Symbol.iterator](), i = {}, n("next"), n("throw"), n("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function n(r) {
    i[r] = e[r] && function(a) {
      return new Promise(function(u, c) {
        a = e[r](a), s(u, c, a.done, a.value);
      });
    };
  }
  function s(r, a, u, c) {
    Promise.resolve(c).then(function(h) {
      r({ value: h, done: u });
    }, a);
  }
}, yt, cl, si, cr, Ji, lo, uo, ri, uw, w2, S2, cw = class {
  constructor(e, t, i, n) {
    var s, r, a, u, c, h, p, f, _, C, E, P, A, F, M, j, z, D, v, U, Z, he, te, Je, Q, ie, ye, Ze, Te, st, Ve;
    yt.add(this), cl.set(this, void 0), si.set(this, void 0), cr.set(this, void 0), Ji.set(this, void 0), lo.set(this, void 0), uo.set(this, void 0), Xn(this, si, t, "f"), Xn(this, cr, i, "f"), Xn(this, Ji, n, "f");
    const fe = y.parseResponse(e[0].data), Et = !((s = e?.[1]) === null || s === void 0) && s.data ? y.parseResponse(e[1].data) : void 0;
    if (Xn(this, cl, [fe, Et], "f"), ((r = fe.playability_status) === null || r === void 0 ? void 0 : r.status) === "ERROR")
      throw new x("This video is unavailable", fe.playability_status);
    if (fe.microformat && !(!((a = fe.microformat) === null || a === void 0) && a.is(Gr, ia)))
      throw new x("Invalid microformat", fe.microformat);
    this.basic_info = Object.assign(Object.assign(Object.assign({}, fe.video_details), {
      embed: !((u = fe.microformat) === null || u === void 0) && u.is(Gr) ? (c = fe.microformat) === null || c === void 0 ? void 0 : c.embed : null,
      channel: !((h = fe.microformat) === null || h === void 0) && h.is(Gr) ? (p = fe.microformat) === null || p === void 0 ? void 0 : p.channel : null,
      is_unlisted: (f = fe.microformat) === null || f === void 0 ? void 0 : f.is_unlisted,
      is_family_safe: (_ = fe.microformat) === null || _ === void 0 ? void 0 : _.is_family_safe,
      has_ypc_metadata: !((C = fe.microformat) === null || C === void 0) && C.is(Gr) ? (E = fe.microformat) === null || E === void 0 ? void 0 : E.has_ypc_metadata : null
    }), { like_count: void 0, is_liked: void 0, is_disliked: void 0 }), this.streaming_data = fe.streaming_data, this.playability_status = fe.playability_status, this.annotations = fe.annotations, this.storyboards = fe.storyboards, this.endscreen = fe.endscreen, this.captions = fe.captions, this.cards = fe.cards, Xn(this, uo, fe.playback_tracking, "f");
    const qt = Et?.contents.item().as(I_), ci = qt?.results, un = qt?.secondary_results;
    if (ci && un) {
      this.primary_info = (P = ci.get({ type: "VideoPrimaryInfo" })) === null || P === void 0 ? void 0 : P.as(R_), this.secondary_info = (A = ci.get({ type: "VideoSecondaryInfo" })) === null || A === void 0 ? void 0 : A.as(L_), this.merchandise = (F = ci.get({ type: "MerchandiseShelf" })) === null || F === void 0 ? void 0 : F.as(Fy), this.related_chip_cloud = (j = (M = un.get({ type: "RelatedChipCloud" })) === null || M === void 0 ? void 0 : M.as(g_)) === null || j === void 0 ? void 0 : j.content.item().as(Gh), this.watch_next_feed = (D = (z = un.get({ type: "ItemSection" })) === null || z === void 0 ? void 0 : z.as(Hi)) === null || D === void 0 ? void 0 : D.contents, this.watch_next_feed && Array.isArray(this.watch_next_feed) && Xn(this, lo, (v = this.watch_next_feed.pop()) === null || v === void 0 ? void 0 : v.as(sn), "f"), this.player_overlays = Et?.player_overlays.item().as(Uf);
      const Lt = (Z = (U = this.primary_info) === null || U === void 0 ? void 0 : U.menu) === null || Z === void 0 ? void 0 : Z.top_level_buttons.firstOfType(qr);
      this.basic_info.like_count = (te = (he = Lt?.like_button) === null || he === void 0 ? void 0 : he.as(_t)) === null || te === void 0 ? void 0 : te.like_count, this.basic_info.is_liked = (Q = (Je = Lt?.like_button) === null || Je === void 0 ? void 0 : Je.as(_t)) === null || Q === void 0 ? void 0 : Q.is_toggled, this.basic_info.is_disliked = (ye = (ie = Lt?.dislike_button) === null || ie === void 0 ? void 0 : ie.as(_t)) === null || ye === void 0 ? void 0 : ye.is_toggled;
      const Ms = (Ze = ci.get({ target_id: "comments-entry-point" })) === null || Ze === void 0 ? void 0 : Ze.as(Hi);
      this.comments_entry_point_header = (st = (Te = Ms?.contents) === null || Te === void 0 ? void 0 : Te.get({ type: "CommentsEntryPointHeader" })) === null || st === void 0 ? void 0 : st.as(ry), this.livechat = (Ve = Et?.contents_memo.getType(ky)) === null || Ve === void 0 ? void 0 : Ve[0];
    }
  }
  selectFilter(e) {
    var t, i, n, s;
    return ki(this, void 0, void 0, function* () {
      if (!this.filters.includes(e))
        throw new x("Invalid filter", { available_filters: this.filters });
      const r = (i = (t = this.related_chip_cloud) === null || t === void 0 ? void 0 : t.chips) === null || i === void 0 ? void 0 : i.get({ text: e });
      if (r?.is_selected)
        return this;
      const a = yield (n = r?.endpoint) === null || n === void 0 ? void 0 : n.call(Ce(this, si, "f"), void 0, !0), u = (s = a?.on_response_received_endpoints) === null || s === void 0 ? void 0 : s.get({ target_id: "watch-next-feed" });
      return this.watch_next_feed = u?.contents, this;
    });
  }
  addToWatchHistory() {
    return ki(this, void 0, void 0, function* () {
      if (!Ce(this, uo, "f"))
        throw new x("Playback tracking not available");
      const e = {
        cpn: Ce(this, Ji, "f"),
        fmt: 251,
        rtn: 0,
        rt: 0
      }, t = Ce(this, uo, "f").videostats_playback_url.replace("https://s.", "https://www.");
      return yield Ce(this, si, "f").stats(t, {
        client_name: ve.CLIENTS.WEB.NAME,
        client_version: ve.CLIENTS.WEB.VERSION
      }, e);
    });
  }
  getWatchNextContinuation() {
    var e, t, i, n;
    return ki(this, void 0, void 0, function* () {
      const s = yield (e = Ce(this, lo, "f")) === null || e === void 0 ? void 0 : e.endpoint.call(Ce(this, si, "f"), void 0, !0), r = (t = s?.on_response_received_endpoints) === null || t === void 0 ? void 0 : t.get({ type: "appendContinuationItemsAction" });
      if (!r)
        throw new x("Continuation not found");
      return this.watch_next_feed = r?.contents, Xn(this, lo, (n = (i = this.watch_next_feed) === null || i === void 0 ? void 0 : i.pop()) === null || n === void 0 ? void 0 : n.as(sn), "f"), this;
    });
  }
  like() {
    var e, t, i;
    return ki(this, void 0, void 0, function* () {
      const n = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(qr), s = (i = n?.like_button) === null || i === void 0 ? void 0 : i.as(_t);
      if (!s)
        throw new x("Like button not found", { video_id: this.basic_info.id });
      if (s.is_toggled)
        throw new x("This video is already liked", { video_id: this.basic_info.id });
      return yield s.endpoint.call(Ce(this, si, "f"));
    });
  }
  dislike() {
    var e, t, i;
    return ki(this, void 0, void 0, function* () {
      const n = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(qr), s = (i = n?.dislike_button) === null || i === void 0 ? void 0 : i.as(_t);
      if (!s)
        throw new x("Dislike button not found", { video_id: this.basic_info.id });
      if (s.is_toggled)
        throw new x("This video is already disliked", { video_id: this.basic_info.id });
      return yield s.endpoint.call(Ce(this, si, "f"));
    });
  }
  removeLike() {
    var e, t, i, n;
    return ki(this, void 0, void 0, function* () {
      let s;
      const r = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(qr), a = (i = r?.like_button) === null || i === void 0 ? void 0 : i.as(_t), u = (n = r?.dislike_button) === null || n === void 0 ? void 0 : n.as(_t);
      if (a?.is_toggled ? s = a : u?.is_toggled && (s = u), !s)
        throw new x("This video is not liked/disliked", { video_id: this.basic_info.id });
      return yield s.toggled_endpoint.call(Ce(this, si, "f"));
    });
  }
  getLiveChat() {
    if (!this.livechat)
      throw new x("Live Chat is not available", { video_id: this.basic_info.id });
    return new uC(this);
  }
  get filters() {
    var e, t;
    return ((t = (e = this.related_chip_cloud) === null || e === void 0 ? void 0 : e.chips) === null || t === void 0 ? void 0 : t.map((i) => i.text.toString())) || [];
  }
  get actions() {
    return Ce(this, si, "f");
  }
  get cpn() {
    return Ce(this, Ji, "f");
  }
  get page() {
    return Ce(this, cl, "f");
  }
  get music_tracks() {
    return [];
  }
  chooseFormat(e) {
    if (!this.streaming_data)
      throw new x("Streaming data not available", { video_id: this.basic_info.id });
    const t = [
      ...this.streaming_data.formats || [],
      ...this.streaming_data.adaptive_formats || []
    ], i = e.type ? e.type.includes("audio") : !0, n = e.type ? e.type.includes("video") : !0, s = e.quality || "360p";
    let r = -1;
    const a = ["best", "bestefficiency"].includes(s), u = s !== "best";
    let c = t.filter((h) => i && !h.has_audio || n && !h.has_video || e.format !== "any" && !h.mime_type.includes(e.format || "mp4") || !a && h.quality_label !== s ? !1 : (r < h.width && (r = h.width), !0));
    if (!c.length)
      throw new x("No matching formats found", {
        options: e
      });
    if (a && n && (c = c.filter((h) => h.width === r)), i && !n) {
      const h = c.filter((p) => !p.has_video);
      h.length > 0 && (c = h);
    }
    return u ? c.sort((h, p) => h.bitrate - p.bitrate) : c.sort((h, p) => p.bitrate - h.bitrate), c[0];
  }
  toDash(e = (t) => t) {
    if (!this.streaming_data)
      throw new x("Streaming data not available", { video_id: this.basic_info.id });
    const { adaptive_formats: t } = this.streaming_data, i = t[0].approx_duration_ms / 1e3, n = new Av().parseFromString("", "text/xml"), s = n.createElement("Period");
    return n.appendChild(Ce(this, yt, "m", ri).call(this, n, "MPD", {
      xmlns: "urn:mpeg:dash:schema:mpd:2011",
      minBufferTime: "PT1.500S",
      profiles: "urn:mpeg:dash:profile:isoff-main:2011",
      type: "static",
      mediaPresentationDuration: `PT${i}S`,
      "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
      "xsi:schemaLocation": "urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd"
    }, [
      s
    ])), Ce(this, yt, "m", uw).call(this, n, s, t, e), `${n}`;
  }
  download(e = {}) {
    var t, i;
    return ki(this, void 0, void 0, function* () {
      if (((t = this.playability_status) === null || t === void 0 ? void 0 : t.status) === "UNPLAYABLE")
        throw new x("Video is unplayable", { video: this, error_type: "UNPLAYABLE" });
      if (((i = this.playability_status) === null || i === void 0 ? void 0 : i.status) === "LOGIN_REQUIRED")
        throw new x("Video is login required", { video: this, error_type: "LOGIN_REQUIRED" });
      if (!this.streaming_data)
        throw new x("Streaming data not available.", { video: this, error_type: "NO_STREAMING_DATA" });
      const n = Object.assign({ quality: "360p", type: "video+audio", format: "mp4", range: void 0 }, e), s = this.chooseFormat(n), r = s.decipher(Ce(this, cr, "f"));
      if (n.type === "video+audio" && !e.range) {
        const _ = yield Ce(this, si, "f").session.http.fetch_function(`${r}&cpn=${Ce(this, Ji, "f")}`, {
          method: "GET",
          headers: ve.STREAM_HEADERS,
          redirect: "follow"
        });
        if (!_.ok)
          throw new x("The server responded with a non 2xx status code", { video: this, error_type: "FETCH_FAILED", response: _ });
        const C = _.body;
        if (!C)
          throw new x("Could not get ReadableStream from fetch Response.", { video: this, error_type: "FETCH_FAILED", response: _ });
        return C;
      }
      const a = 1048576 * 10;
      let u = e.range ? e.range.start : 0, c = e.range ? e.range.end : a, h = !1, p;
      return new ReadableStream({
        start() {
        },
        pull: (_) => ki(this, void 0, void 0, function* () {
          if (h) {
            _.close();
            return;
          }
          return (c >= s.content_length || e.range) && (h = !0), new Promise((C, E) => ki(this, void 0, void 0, function* () {
            var P, A;
            try {
              p = new AbortController();
              const j = yield Ce(this, si, "f").session.http.fetch_function(`${r}&cpn=${Ce(this, Ji, "f")}&range=${u}-${c || ""}`, {
                method: "GET",
                headers: Object.assign({}, ve.STREAM_HEADERS),
                signal: p.signal
              }), z = j.body;
              if (!z)
                throw new x("Could not get ReadableStream from fetch Response.", { video: this, error_type: "FETCH_FAILED", response: j });
              try {
                for (var F = GT($c(z)), M; M = yield F.next(), !M.done; ) {
                  const D = M.value;
                  _.enqueue(D);
                }
              } catch (D) {
                P = { error: D };
              } finally {
                try {
                  M && !M.done && (A = F.return) && (yield A.call(F));
                } finally {
                  if (P)
                    throw P.error;
                }
              }
              u = c + 1, c += a, C();
              return;
            } catch (j) {
              E(j);
            }
          }));
        }),
        cancel(_) {
          return ki(this, void 0, void 0, function* () {
            p.abort(_);
          });
        }
      }, {
        highWaterMark: 1,
        size(_) {
          return _.byteLength;
        }
      });
    });
  }
};
l(cw, "VideoInfo");
cl = /* @__PURE__ */ new WeakMap(), si = /* @__PURE__ */ new WeakMap(), cr = /* @__PURE__ */ new WeakMap(), Ji = /* @__PURE__ */ new WeakMap(), lo = /* @__PURE__ */ new WeakMap(), uo = /* @__PURE__ */ new WeakMap(), yt = /* @__PURE__ */ new WeakSet(), ri = /* @__PURE__ */ l(function(t, i, n, s = []) {
  const r = t.createElement(i);
  for (const [a, u] of Object.entries(n))
    r.setAttribute(a, u);
  for (const a of s)
    typeof a > "u" || r.appendChild(a);
  return r;
}, "_VideoInfo_el"), uw = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = [], a = [[]];
  n.forEach((u) => {
    if (!u.index_range || !u.init_range)
      return;
    const c = u.mime_type, h = r.indexOf(c);
    h > -1 ? a[h].push(u) : (r.push(c), a.push([]), a[r.length - 1].push(u));
  });
  for (let u = 0; u < r.length; u++) {
    const c = Ce(this, yt, "m", ri).call(this, t, "AdaptationSet", {
      id: `${u}`,
      mimeType: r[u].split(";")[0],
      startWithSAP: "1",
      subsegmentAlignment: "true"
    });
    i.appendChild(c), a[u].forEach((h) => {
      h.has_video ? Ce(this, yt, "m", w2).call(this, t, c, h, s) : Ce(this, yt, "m", S2).call(this, t, c, h, s);
    });
  }
}, "_VideoInfo_generateAdaptationSet"), w2 = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = Li(n.mime_type, 'codecs="', '"');
  if (!n.index_range || !n.init_range)
    throw new x("Index and init ranges not available", { format: n });
  const a = new URL(n.decipher(Ce(this, cr, "f")));
  a.searchParams.set("cpn", Ce(this, Ji, "f")), i.appendChild(Ce(this, yt, "m", ri).call(this, t, "Representation", {
    id: n.itag,
    codecs: r,
    bandwidth: n.bitrate,
    width: n.width,
    height: n.height,
    maxPlayoutRate: "1",
    frameRate: n.fps
  }, [
    Ce(this, yt, "m", ri).call(this, t, "BaseURL", {}, [
      t.createTextNode(s(a).toString())
    ]),
    Ce(this, yt, "m", ri).call(this, t, "SegmentBase", {
      indexRange: `${n.index_range.start}-${n.index_range.end}`
    }, [
      Ce(this, yt, "m", ri).call(this, t, "Initialization", {
        range: `${n.init_range.start}-${n.init_range.end}`
      })
    ])
  ]));
}, "_VideoInfo_generateRepresentationVideo"), S2 = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = Li(n.mime_type, 'codecs="', '"');
  if (!n.index_range || !n.init_range)
    throw new x("Index and init ranges not available", { format: n });
  const a = new URL(n.decipher(Ce(this, cr, "f")));
  a.searchParams.set("cpn", Ce(this, Ji, "f")), i.appendChild(Ce(this, yt, "m", ri).call(this, t, "Representation", {
    id: n.itag,
    codecs: r,
    bandwidth: n.bitrate
  }, [
    Ce(this, yt, "m", ri).call(this, t, "AudioChannelConfiguration", {
      schemeIdUri: "urn:mpeg:dash:23003:3:audio_channel_configuration:2011",
      value: n.audio_channels || "2"
    }),
    Ce(this, yt, "m", ri).call(this, t, "BaseURL", {}, [
      t.createTextNode(s(a).toString())
    ]),
    Ce(this, yt, "m", ri).call(this, t, "SegmentBase", {
      indexRange: `${n.index_range.start}-${n.index_range.end}`
    }, [
      Ce(this, yt, "m", ri).call(this, t, "Initialization", {
        range: `${n.init_range.start}-${n.init_range.end}`
      })
    ])
  ]));
}, "_VideoInfo_generateRepresentationAudio");
var C2 = cw, Fr = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ba = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Jn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, hl, er, dl, co, hw = class {
  constructor(e, t, i) {
    var n, s, r, a, u, c, h, p;
    hl.set(this, void 0), er.set(this, void 0), dl.set(this, void 0), co.set(this, void 0), Ba(this, er, t, "f");
    const f = y.parseResponse(e[0].data), _ = !((n = e?.[1]) === null || n === void 0) && n.data ? y.parseResponse(e[1].data) : void 0;
    if (Ba(this, hl, [f, _], "f"), Ba(this, dl, i, "f"), ((s = f.playability_status) === null || s === void 0 ? void 0 : s.status) === "ERROR")
      throw new x("This video is unavailable", f.playability_status);
    if (!(!((r = f.microformat) === null || r === void 0) && r.is(ia)))
      throw new x("Invalid microformat", f.microformat);
    if (this.basic_info = Object.assign(Object.assign({}, f.video_details), {
      description: (a = f.microformat) === null || a === void 0 ? void 0 : a.description,
      is_unlisted: (u = f.microformat) === null || u === void 0 ? void 0 : u.is_unlisted,
      is_family_safe: (c = f.microformat) === null || c === void 0 ? void 0 : c.is_family_safe,
      url_canonical: (h = f.microformat) === null || h === void 0 ? void 0 : h.url_canonical,
      tags: (p = f.microformat) === null || p === void 0 ? void 0 : p.tags
    }), this.streaming_data = f.streaming_data, this.playability_status = f.playability_status, this.storyboards = f.storyboards, this.endscreen = f.endscreen, Ba(this, co, f.playback_tracking, "f"), _) {
      const E = _.contents.item().as(Ao).contents.item().as(Io).contents.item().as(Po);
      this.tabs = E.tabs.array().as(jt), this.current_video_endpoint = _.current_video_endpoint, this.player_overlays = _.player_overlays.item().as(Uf);
    }
  }
  getTab(e) {
    return Fr(this, void 0, void 0, function* () {
      if (!this.tabs)
        throw new x("Could not find any tab");
      const t = this.tabs.get({ title: e });
      if (!t)
        throw new x(`Tab "${e}" not found`, { available_tabs: this.available_tabs });
      if (t.content)
        return t.content;
      const i = yield t.endpoint.callTest(Jn(this, er, "f"), { client: "YTMUSIC", parse: !0 });
      return i.contents.item().key("type").string() === "Message" ? i.contents.item().as(ta) : i.contents.item().as(ft).contents.array();
    });
  }
  getUpNext(e = !0) {
    var t, i;
    return Fr(this, void 0, void 0, function* () {
      const n = yield this.getTab("Up next");
      if (!n || !n.content)
        throw new x("Music queue was empty, the video id is probably invalid.", n);
      const s = n.content.as(xs);
      if (!s.playlist_id && e) {
        const r = s.contents.firstOfType(bh);
        if (!r)
          throw new x("Automix item not found");
        const a = yield (t = r.playlist_video) === null || t === void 0 ? void 0 : t.endpoint.callTest(Jn(this, er, "f"), {
          videoId: this.basic_info.id,
          client: "YTMUSIC",
          parse: !0
        });
        if (!a)
          throw new x("Could not fetch automix");
        return (i = a.contents_memo.getType(xs)) === null || i === void 0 ? void 0 : i[0];
      }
      return s;
    });
  }
  getRelated() {
    return Fr(this, void 0, void 0, function* () {
      return yield this.getTab("Related");
    });
  }
  getLyrics() {
    return Fr(this, void 0, void 0, function* () {
      return (yield this.getTab("Lyrics")).firstOfType(Ll);
    });
  }
  addToWatchHistory() {
    return Fr(this, void 0, void 0, function* () {
      if (!Jn(this, co, "f"))
        throw new x("Playback tracking not available");
      const e = {
        cpn: Jn(this, dl, "f"),
        fmt: 251,
        rtn: 0,
        rt: 0
      }, t = Jn(this, co, "f").videostats_playback_url.replace("https://s.", "https://music.");
      return yield Jn(this, er, "f").stats(t, {
        client_name: ve.CLIENTS.YTMUSIC.NAME,
        client_version: ve.CLIENTS.YTMUSIC.VERSION
      }, e);
    });
  }
  get available_tabs() {
    return this.tabs ? this.tabs.map((e) => e.title) : [];
  }
  get page() {
    return Jn(this, hl, "f");
  }
};
l(hw, "TrackInfo");
hl = /* @__PURE__ */ new WeakMap(), er = /* @__PURE__ */ new WeakMap(), dl = /* @__PURE__ */ new WeakMap(), co = /* @__PURE__ */ new WeakMap();
var T2 = hw, G1 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Oa = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ai = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, ho, bn, rs, Xl = class {
  constructor(e, t, i = {}) {
    var n, s, r, a, u, c, h;
    ho.set(this, void 0), bn.set(this, void 0), rs.set(this, void 0), Oa(this, bn, t, "f"), Oa(this, ho, i.is_continuation ? e : y.parseResponse(e.data), "f");
    const p = Ai(this, ho, "f").contents.item().as(A_).tabs.get({ selected: !0 });
    if (!p)
      throw new x("Could not find target tab.");
    const f = (n = p.content) === null || n === void 0 ? void 0 : n.as(ft);
    if (!f)
      throw new x("Target tab did not have any content.");
    this.header = f.hasKey("header") ? (s = f.header) === null || s === void 0 ? void 0 : s.item().as(Gh) : null;
    const _ = f.contents.array().as(fs, Hi), C = _.firstOfType(Hi);
    this.did_you_mean = ((r = C?.contents) === null || r === void 0 ? void 0 : r.firstOfType(py)) || null, this.showing_results_for = ((a = C?.contents) === null || a === void 0 ? void 0 : a.firstOfType(x_)) || null, this.message = ((u = C?.contents) === null || u === void 0 ? void 0 : u.firstOfType(ta)) || null, i.is_continuation || i.is_filtered ? (this.results = (c = _.firstOfType(fs)) === null || c === void 0 ? void 0 : c.contents, Oa(this, rs, (h = _.firstOfType(fs)) === null || h === void 0 ? void 0 : h.continuation, "f")) : this.sections = _.filterType(fs);
  }
  getMore(e) {
    return G1(this, void 0, void 0, function* () {
      if (!e || !e.endpoint)
        throw new x("Cannot retrieve more items for this shelf because it does not have an endpoint.");
      const t = yield e.endpoint.call(Ai(this, bn, "f"), "YTMUSIC", !0);
      if (!t)
        throw new x("Endpoint did not return any data");
      return new Xl(t, Ai(this, bn, "f"), { is_continuation: !0 });
    });
  }
  getContinuation() {
    var e, t, i;
    return G1(this, void 0, void 0, function* () {
      if (!Ai(this, rs, "f"))
        throw new x("Continuation not found.");
      const s = (yield Ai(this, bn, "f").search({ ctoken: Ai(this, rs, "f"), client: "YTMUSIC" })).data.continuationContents.musicShelfContinuation;
      return this.results = y.parse(s.contents).array().as(na), Oa(this, rs, (i = (t = (e = s?.continuations) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.nextContinuationData) === null || i === void 0 ? void 0 : i.continuation, "f"), this;
    });
  }
  selectFilter(e) {
    var t, i, n, s;
    return G1(this, void 0, void 0, function* () {
      if (!(!((t = this.filters) === null || t === void 0) && t.includes(e)))
        throw new x("Invalid filter", { available_filters: this.filters });
      const r = (n = (i = this.header) === null || i === void 0 ? void 0 : i.chips) === null || n === void 0 ? void 0 : n.as(Wo).get({ text: e });
      if (r?.is_selected)
        return this;
      const a = yield (s = r?.endpoint) === null || s === void 0 ? void 0 : s.call(Ai(this, bn, "f"), "YTMUSIC", !0);
      if (!a)
        throw new x("Endpoint did not return any data");
      return new Xl(a, Ai(this, bn, "f"), { is_continuation: !0 });
    });
  }
  get has_continuation() {
    return !!Ai(this, rs, "f");
  }
  get filters() {
    var e, t;
    return ((t = (e = this.header) === null || e === void 0 ? void 0 : e.chips) === null || t === void 0 ? void 0 : t.as(Wo).map((i) => i.text)) || null;
  }
  get songs() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Songs");
  }
  get videos() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Videos");
  }
  get albums() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Albums");
  }
  get artists() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Artists");
  }
  get playlists() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Community playlists");
  }
  get page() {
    return Ai(this, ho, "f");
  }
};
l(Xl, "Search");
ho = /* @__PURE__ */ new WeakMap(), bn = /* @__PURE__ */ new WeakMap(), rs = /* @__PURE__ */ new WeakMap();
var qT = Xl, KT = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Fa = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ii = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, wn, po, os, Iv = class {
  constructor(e, t) {
    var i, n, s;
    wn.set(this, void 0), po.set(this, void 0), os.set(this, void 0), Fa(this, po, t, "f"), Fa(this, wn, y.parseResponse(e.data), "f");
    const r = Ii(this, wn, "f").contents.item().as(sa).tabs.get({ selected: !0 });
    if (!r)
      throw new x("Could not get Home tab.");
    if (r.key("content").isNull()) {
      if (!Ii(this, wn, "f").continuation_contents)
        throw new x("Continuation did not have any content.");
      Fa(this, os, Ii(this, wn, "f").continuation_contents.as(Es).continuation, "f"), this.sections = (i = Ii(this, wn, "f").continuation_contents.as(Es).contents) === null || i === void 0 ? void 0 : i.as(pr);
      return;
    }
    Fa(this, os, (n = r.content) === null || n === void 0 ? void 0 : n.as(ft).continuation, "f"), this.sections = (s = r.content) === null || s === void 0 ? void 0 : s.as(ft).contents.array().as(pr);
  }
  getContinuation() {
    return KT(this, void 0, void 0, function* () {
      if (!Ii(this, os, "f"))
        throw new x("Continuation not found.");
      const e = yield Ii(this, po, "f").browse(Ii(this, os, "f"), { is_ctoken: !0, client: "YTMUSIC" });
      return new Iv(e, Ii(this, po, "f"));
    });
  }
  get has_continuation() {
    return !!Ii(this, os, "f");
  }
  get page() {
    return Ii(this, wn, "f");
  }
};
l(Iv, "HomeFeed");
wn = /* @__PURE__ */ new WeakMap(), po = /* @__PURE__ */ new WeakMap(), os = /* @__PURE__ */ new WeakMap();
var zT = Iv, YT = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, x2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, fo, dw = class {
  constructor(e) {
    var t, i;
    fo.set(this, void 0), YT(this, fo, y.parseResponse(e.data), "f");
    const n = x2(this, fo, "f").contents.item().as(sa).tabs.get({ selected: !0 });
    if (!n)
      throw new x("Could not find target tab.");
    const s = (t = n.content) === null || t === void 0 ? void 0 : t.as(ft);
    if (!s)
      throw new x("Target tab did not have any content.");
    this.top_buttons = ((i = s.contents.array().firstOfType(gy)) === null || i === void 0 ? void 0 : i.items.array().as(lf)) || [], this.sections = s.contents.array().getAll({ type: "MusicCarouselShelf" });
  }
  get page() {
    return x2(this, fo, "f");
  }
};
l(dw, "Explore");
fo = /* @__PURE__ */ new WeakMap();
var XT = dw, Zt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Vn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, de = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, qe, en, Sn, Jl, hs, pw, tr, Yi, pl, mo, Ac, vo, fl, ml, fw, vl, JT = {
  history: "FEmusic_history",
  playlists: "FEmusic_liked_playlists",
  albums: "FEmusic_liked_albums",
  songs: "FEmusic_liked_videos",
  artists: "FEmusic_library_corpus_track_artists",
  subscriptions: "FEmusic_library_corpus_artists"
}, mw = {
  recently_added: "Recently added",
  a_z: "A to Z",
  z_a: "Z to A"
}, vw = {};
for (const [e, t] of Object.entries(mw))
  vw[t] = e;
var gw = class {
  constructor(e) {
    qe.add(this), en.set(this, void 0), Vn(this, en, e, "f");
  }
  getPlaylists(e) {
    return Zt(this, void 0, void 0, function* () {
      const t = yield de(this, qe, "m", hs).call(this, de(this, qe, "m", Sn).call(this, "playlists"), (n) => n.item_type === "playlist"), i = e?.sort_by || null;
      return i ? de(this, qe, "m", tr).call(this, t, i) : t;
    });
  }
  getAlbums(e) {
    return Zt(this, void 0, void 0, function* () {
      const t = yield de(this, qe, "m", hs).call(this, de(this, qe, "m", Sn).call(this, "albums"), (n) => n.item_type === "album"), i = e?.sort_by || null;
      return i ? de(this, qe, "m", tr).call(this, t, i) : t;
    });
  }
  getArtists(e) {
    return Zt(this, void 0, void 0, function* () {
      const t = yield de(this, qe, "m", hs).call(this, de(this, qe, "m", Sn).call(this, "artists"), (n) => n.item_type === "library_artist"), i = e?.sort_by || null;
      return i ? de(this, qe, "m", tr).call(this, t, i) : t;
    });
  }
  getSongs(e) {
    var t;
    return Zt(this, void 0, void 0, function* () {
      const i = yield de(this, qe, "m", hs).call(this, de(this, qe, "m", Sn).call(this, "songs"), (a) => a.item_type === "song" || a.item_type === "video"), n = e?.sort_by || null, s = n === "random", r = s ? (t = i.all_items.find((a) => a.item_type === "endpoint" && a.title.toString() === "Shuffle all")) === null || t === void 0 ? void 0 : t.endpoint : null;
      if (s) {
        if (!r) {
          if (i.items.length <= 1)
            return i;
          throw new x("Unable to obtain endpoint for sort_by value 'random'");
        }
        return de(this, qe, "m", pw).call(this, r);
      }
      return n ? de(this, qe, "m", tr).call(this, i, n) : i;
    });
  }
  getSubscriptions(e) {
    return Zt(this, void 0, void 0, function* () {
      const t = yield de(this, qe, "m", hs).call(this, de(this, qe, "m", Sn).call(this, "subscriptions")), i = e?.sort_by || null;
      return i ? de(this, qe, "m", tr).call(this, t, i) : t;
    });
  }
  getRecentActivity(e) {
    var t, i, n;
    return Zt(this, void 0, void 0, function* () {
      if (!!e?.all) {
        const h = yield de(this, qe, "m", Jl).call(this, de(this, qe, "m", Sn).call(this, "history")), p = (t = h.contents_memo.get("SectionList")) === null || t === void 0 ? void 0 : t[0].as(ft), f = ((i = p?.contents) === null || i === void 0 ? void 0 : i.array()) || [], _ = p?.continuation ? {
          type: "browse",
          token: p?.continuation
        } : null;
        return new Mv(f, _, h, de(this, en, "f"));
      }
      const r = yield de(this, qe, "m", Jl).call(this, de(this, qe, "m", Sn).call(this, "songs")), u = (((n = r.contents_memo.get("SectionList")) === null || n === void 0 ? void 0 : n[0].as(ft).contents.array()) || []).find((h) => {
        var p, f;
        return ((p = h.header) === null || p === void 0 ? void 0 : p.type) === "MusicCarouselShelfBasicHeader" && ((f = h.header) === null || f === void 0 ? void 0 : f.title.toString()) === "Recent activity";
      }), c = u?.contents || [];
      return new zo(c, null, null, r, de(this, en, "f"), { sort_by: null });
    });
  }
};
l(gw, "Library");
en = /* @__PURE__ */ new WeakMap(), qe = /* @__PURE__ */ new WeakSet(), Sn = /* @__PURE__ */ l(function(t) {
  return JT[t];
}, "_Library_getBrowseId"), Jl = /* @__PURE__ */ l(function(t, i = {}) {
  return Zt(this, void 0, void 0, function* () {
    const n = yield de(this, en, "f").browse(t, Object.assign(Object.assign({}, i), { client: "YTMUSIC" }));
    return y.parseResponse(n.data);
  });
}, "_Library_fetchPage"), hs = /* @__PURE__ */ l(function(t, i = null, n = {}) {
  var s, r;
  return Zt(this, void 0, void 0, function* () {
    const a = /* @__PURE__ */ l((_) => {
      var C;
      switch (_?.type) {
        case "Grid":
          return (C = _.contents) === null || C === void 0 ? void 0 : C.array();
        case "MusicShelf":
          return _.contents;
        default:
          return [];
      }
    }, "getItemsFromDataNode"), u = yield de(this, qe, "m", Jl).call(this, t, n), h = (((s = u.contents_memo.get("SectionList")) === null || s === void 0 ? void 0 : s[0].as(ft).contents.array()) || []).find((_) => {
      var C;
      return ((C = _.header) === null || C === void 0 ? void 0 : C.type) === "ItemSectionTabbedHeader";
    }), p = (r = h?.contents) === null || r === void 0 ? void 0 : r[0], f = p?.continuation ? {
      type: "browse",
      token: p?.continuation
    } : null;
    return new zo(a(p) || [], i, f, u, de(this, en, "f"));
  });
}, "_Library_fetchAndParseTabContents"), pw = /* @__PURE__ */ l(function(t) {
  var i;
  return Zt(this, void 0, void 0, function* () {
    const n = {
      playlist_id: t.payload.playlistId,
      params: t.payload.params
    }, s = yield de(this, en, "f").next(Object.assign(Object.assign({}, n), { client: "YTMUSIC" })), r = y.parseResponse(s.data), a = (i = r.contents_memo.get("PlaylistPanel")) === null || i === void 0 ? void 0 : i[0].as(xs), u = a?.contents || [], c = a?.continuation ? {
      type: "next",
      token: a?.continuation,
      payload: n
    } : null, h = /* @__PURE__ */ l((p) => p.type === "PlaylistPanelVideo", "filter");
    return new zo(u, h, c, r, de(this, en, "f"), { sort_by: "random" });
  });
}, "_Library_fetchAndParseShuffledSongs"), tr = /* @__PURE__ */ l(function(t, i) {
  var n, s, r;
  return Zt(this, void 0, void 0, function* () {
    const a = t.page, u = (s = (n = a?.contents_memo.get("DropdownItem")) === null || n === void 0 ? void 0 : n.find((h) => h.as(Ho).label === mw[i])) === null || s === void 0 ? void 0 : s.as(Ho);
    if (!(!((r = u?.endpoint) === null || r === void 0) && r.browse)) {
      if (t.items.length <= 1)
        return t;
      throw new x(`Unable to obtain browse endpoint for sort_by value '${i}'`);
    }
    if (u?.selected)
      return t;
    const c = { params: u.endpoint.browse.params };
    return de(this, qe, "m", hs).call(this, u.endpoint.browse.id, t.filter, c);
  });
}, "_Library_applySortBy");
var Pv = class {
  constructor(e, t, i) {
    Yi.set(this, void 0), pl.set(this, void 0), mo.set(this, void 0), Vn(this, Yi, e, "f"), Vn(this, pl, t, "f"), Vn(this, mo, i, "f"), this.has_continuation = !!e;
  }
  getContinuation() {
    return Zt(this, void 0, void 0, function* () {
      if (!de(this, Yi, "f"))
        throw new x("Continuation not found.");
      let e;
      const t = de(this, Yi, "f").payload || {};
      switch (de(this, Yi, "f").type) {
        case "next":
          e = de(this, mo, "f").next(Object.assign(Object.assign({}, t), { ctoken: de(this, Yi, "f").token, client: "YTMUSIC" }));
          break;
        default:
          e = de(this, mo, "f").browse(de(this, Yi, "f").token, Object.assign(Object.assign({}, t), { is_ctoken: !0, client: "YTMUSIC" }));
      }
      const i = yield e, n = y.parseResponse(i.data);
      if (!n.continuation_contents)
        throw new x("No continuation data found.");
      return this.parseContinuationContents(n, de(this, Yi, "f"));
    });
  }
  get page() {
    return de(this, pl, "f");
  }
};
l(Pv, "LibraryResultsBase");
Yi = /* @__PURE__ */ new WeakMap(), pl = /* @__PURE__ */ new WeakMap(), mo = /* @__PURE__ */ new WeakMap();
var zo = class extends Pv {
  constructor(e, t, i, n, s, r) {
    super(i, n, s), Ac.add(this), vo.set(this, void 0), fl.set(this, void 0), ml.set(this, void 0), Vn(this, vo, t, "f"), Vn(this, fl, s, "f"), Vn(this, ml, e, "f"), this.items = t ? e.filter(t) : e, this.sort_by = r?.sort_by !== void 0 ? r.sort_by : de(this, Ac, "m", fw).call(this);
  }
  parseContinuationContents(e, t) {
    var i;
    return Zt(this, void 0, void 0, function* () {
      const n = (i = e.continuation_contents) === null || i === void 0 ? void 0 : i.as(oa, uu, cu), s = n?.continuation ? Object.assign(Object.assign({}, t), { token: n?.continuation }) : null;
      return new zo(n?.contents || [], de(this, vo, "f"), s, e, de(this, fl, "f"), { sort_by: this.sort_by });
    });
  }
  get all_items() {
    return de(this, ml, "f");
  }
  get filter() {
    return de(this, vo, "f");
  }
};
l(zo, "LibraryItemList");
vo = /* @__PURE__ */ new WeakMap(), fl = /* @__PURE__ */ new WeakMap(), ml = /* @__PURE__ */ new WeakMap(), Ac = /* @__PURE__ */ new WeakSet(), fw = /* @__PURE__ */ l(function() {
  var t, i;
  const n = ((i = (t = this.page) === null || t === void 0 ? void 0 : t.contents_memo.get("DropdownItem")) === null || i === void 0 ? void 0 : i.filter((s) => s.as(Ho).selected)) || [];
  for (const s of n) {
    const r = vw[s.label];
    if (r)
      return r;
  }
  return null;
}, "_LibraryItemList_getSortBy");
var Mv = class extends Pv {
  constructor(e, t, i, n) {
    super(t, i, n), vl.set(this, void 0), Vn(this, vl, n, "f"), this.sections = e;
  }
  parseContinuationContents(e, t) {
    var i;
    return Zt(this, void 0, void 0, function* () {
      const n = (i = e.continuation_contents) === null || i === void 0 ? void 0 : i.as(Es), s = n?.continuation ? Object.assign(Object.assign({}, t), { token: n?.continuation }) : null;
      return new Mv(n?.contents || [], s, e, de(this, vl, "f"));
    });
  }
};
l(Mv, "LibrarySectionList");
vl = /* @__PURE__ */ new WeakMap();
var ZT = gw, QT = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, E2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Va = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, ir, gl, yw = class {
  constructor(e, t) {
    ir.set(this, void 0), gl.set(this, void 0), E2(this, ir, y.parseResponse(e.data), "f"), E2(this, gl, t, "f"), this.header = this.page.header.item().as(Jy, Zy, vf);
    const i = Va(this, ir, "f").contents_memo.get("MusicShelf") || [], n = Va(this, ir, "f").contents_memo.get("MusicCarouselShelf") || [];
    this.sections = [...i, ...n];
  }
  getAllSongs() {
    var e, t;
    return QT(this, void 0, void 0, function* () {
      const i = this.sections.filter((a) => a.type === "MusicShelf");
      if (!i.length)
        throw new x("Could not find any node of type MusicShelf.");
      const n = i.find((a) => a.title.toString() === "Songs");
      if (!n)
        throw new x("Could not find target shelf (Songs).");
      if (!n.endpoint)
        throw new x("Target shelf (Songs) did not have an endpoint.");
      return ((t = (e = (yield n.endpoint.call(Va(this, gl, "f"), "YTMUSIC", !0)).contents_memo.get("MusicPlaylistShelf")) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.as(Bl)) || null;
    });
  }
  get page() {
    return Va(this, ir, "f");
  }
};
l(yw, "Artist");
ir = /* @__PURE__ */ new WeakMap(), gl = /* @__PURE__ */ new WeakMap();
var ex = yw, k2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Vr = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Cn, Ic, _w = class {
  constructor(e, t) {
    var i, n;
    Cn.set(this, void 0), Ic.set(this, void 0), k2(this, Cn, y.parseResponse(e.data), "f"), k2(this, Ic, t, "f"), this.header = Vr(this, Cn, "f").header.item().as(Dl), this.url = ((i = Vr(this, Cn, "f").microformat) === null || i === void 0 ? void 0 : i.as(ia).url_canonical) || null, this.contents = (n = Vr(this, Cn, "f").contents_memo.get("MusicShelf")) === null || n === void 0 ? void 0 : n[0].as(fs).contents, this.sections = Vr(this, Cn, "f").contents_memo.get("MusicCarouselShelf") || [];
  }
  get page() {
    return Vr(this, Cn, "f");
  }
};
l(_w, "Album");
Cn = /* @__PURE__ */ new WeakMap(), Ic = /* @__PURE__ */ new WeakMap();
var tx = _w, yl = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, dn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, et = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Pc, Yt, ds, as, go, nr, bw, Nv = class {
  constructor(e, t) {
    var i, n, s, r, a, u, c, h;
    if (Pc.add(this), Yt.set(this, void 0), ds.set(this, void 0), as.set(this, void 0), go.set(this, void 0), nr.set(this, void 0), dn(this, ds, t, "f"), dn(this, Yt, y.parseResponse(e.data), "f"), dn(this, go, ((n = (i = et(this, Yt, "f").contents_memo.getType(fs)) === null || i === void 0 ? void 0 : i.find((p) => p.title.toString() === "Suggestions")) === null || n === void 0 ? void 0 : n.continuation) || null, "f"), dn(this, nr, null, "f"), et(this, Yt, "f").continuation_contents) {
      const p = (s = et(this, Yt, "f").continuation_contents) === null || s === void 0 ? void 0 : s.as(lu);
      this.items = p.contents, dn(this, as, p.continuation, "f");
    } else
      ((r = et(this, Yt, "f").header) === null || r === void 0 ? void 0 : r.item().type) === "MusicEditablePlaylistDetailHeader" ? this.header = (a = et(this, Yt, "f").header) === null || a === void 0 ? void 0 : a.item().as(Xy).header.item().as(Dl) : this.header = ((u = et(this, Yt, "f").header) === null || u === void 0 ? void 0 : u.item().as(Dl)) || null, this.items = (c = et(this, Yt, "f").contents_memo.getType(Bl)) === null || c === void 0 ? void 0 : c[0].contents, dn(this, as, ((h = et(this, Yt, "f").contents_memo.getType(Bl)) === null || h === void 0 ? void 0 : h[0].continuation) || null, "f");
  }
  get page() {
    return et(this, Yt, "f");
  }
  get has_continuation() {
    return !!et(this, as, "f");
  }
  getContinuation() {
    return yl(this, void 0, void 0, function* () {
      if (!et(this, as, "f"))
        throw new x("Continuation not found.");
      const e = yield et(this, ds, "f").browse(et(this, as, "f"), { is_ctoken: !0, client: "YTMUSIC" });
      return new Nv(e, et(this, ds, "f"));
    });
  }
  getRelated() {
    var e, t, i;
    return yl(this, void 0, void 0, function* () {
      let n = (e = et(this, Yt, "f").contents_memo.get("SectionList")) === null || e === void 0 ? void 0 : e[0].as(ft).continuation;
      for (; n; ) {
        const s = yield et(this, ds, "f").browse(n, { is_ctoken: !0, client: "YTMUSIC" }), a = (t = y.parseResponse(s.data).continuation_contents) === null || t === void 0 ? void 0 : t.as(Es), u = (i = a?.contents) === null || i === void 0 ? void 0 : i.as(pr), c = u?.filter((h) => {
          var p;
          return ((p = h.header) === null || p === void 0 ? void 0 : p.title.toString()) === "Related playlists";
        })[0];
        if (c)
          return c.contents || [];
        n = a?.continuation;
      }
      return [];
    });
  }
  getSuggestions(e = !0) {
    return yl(this, void 0, void 0, function* () {
      const n = yield e || !et(this, nr, "f") ? et(this, Pc, "m", bw).call(this, et(this, go, "f")) : Promise.resolve(null);
      return n && (dn(this, nr, n.items, "f"), dn(this, go, n.continuation, "f")), n?.items || et(this, nr, "f");
    });
  }
};
l(Nv, "Playlist");
Yt = /* @__PURE__ */ new WeakMap(), ds = /* @__PURE__ */ new WeakMap(), as = /* @__PURE__ */ new WeakMap(), go = /* @__PURE__ */ new WeakMap(), nr = /* @__PURE__ */ new WeakMap(), Pc = /* @__PURE__ */ new WeakSet(), bw = /* @__PURE__ */ l(function(t) {
  var i;
  return yl(this, void 0, void 0, function* () {
    if (t) {
      const n = yield et(this, ds, "f").browse(t, { is_ctoken: !0, client: "YTMUSIC" }), r = (i = y.parseResponse(n.data).continuation_contents) === null || i === void 0 ? void 0 : i.as(oa);
      return {
        items: r?.contents || [],
        continuation: r?.continuation || null
      };
    }
    return {
      items: [],
      continuation: null
    };
  });
}, "_Playlist_fetchSuggestions");
var ww = Nv, ix = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, A2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Zn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Tn, yo, Sw = class {
  constructor(e, t) {
    var i, n, s;
    Tn.set(this, void 0), yo.set(this, void 0), A2(this, Tn, y.parseResponse(e.data), "f"), A2(this, yo, t, "f");
    const r = Zn(this, Tn, "f").header.item();
    this.header = r.is(oc) ? (n = (i = Zn(this, Tn, "f").header.item().as(oc).element) === null || i === void 0 ? void 0 : i.model) === null || n === void 0 ? void 0 : n.item().as(rc) : Zn(this, Tn, "f").header.item().as(vf);
    const a = Zn(this, Tn, "f").contents.item().as(sa).tabs.firstOfType(jt);
    if (!a)
      throw new x("Target tab not found");
    this.sections = (s = a.content) === null || s === void 0 ? void 0 : s.as(ft).contents.array().as(Hi, pr, ta);
  }
  getPlaylist() {
    return ix(this, void 0, void 0, function* () {
      if (!this.header)
        throw new x("Header not found");
      if (!this.header.is(rc))
        throw new x("Recap playlist not available, check back later.");
      const t = yield this.header.panels[0].text_on_tap_endpoint.callTest(Zn(this, yo, "f"), { client: "YTMUSIC" });
      return new ww(t, Zn(this, yo, "f"));
    });
  }
  get page() {
    return Zn(this, Tn, "f");
  }
};
l(Sw, "Recap");
Tn = /* @__PURE__ */ new WeakMap(), yo = /* @__PURE__ */ new WeakMap();
var nx = Sw, Jt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, I2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ne = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, _l, Oo, Le, Cw, Tw, xw = class {
  constructor(e) {
    _l.add(this), Oo.set(this, void 0), Le.set(this, void 0), I2(this, Oo, e, "f"), I2(this, Le, e.actions, "f");
  }
  getInfo(e) {
    if (e instanceof Qp)
      return Ne(this, _l, "m", Tw).call(this, e);
    if (typeof e == "string")
      return Ne(this, _l, "m", Cw).call(this, e);
    throw new x("Invalid target, expected either a video id or a valid MusicTwoRowItem", e);
  }
  search(e, t = {}) {
    return Jt(this, void 0, void 0, function* () {
      Ue({ query: e });
      const i = yield Ne(this, Le, "f").search({ query: e, filters: t, client: "YTMUSIC" });
      return new qT(i, Ne(this, Le, "f"), { is_filtered: Reflect.has(t, "type") && t.type !== "all" });
    });
  }
  getHomeFeed() {
    return Jt(this, void 0, void 0, function* () {
      const e = yield Ne(this, Le, "f").browse("FEmusic_home", { client: "YTMUSIC" });
      return new zT(e, Ne(this, Le, "f"));
    });
  }
  getExplore() {
    return Jt(this, void 0, void 0, function* () {
      const e = yield Ne(this, Le, "f").browse("FEmusic_explore", { client: "YTMUSIC" });
      return new XT(e);
    });
  }
  getLibrary() {
    return new ZT(Ne(this, Le, "f"));
  }
  getArtist(e) {
    return Jt(this, void 0, void 0, function* () {
      if (Ue({ artist_id: e }), !e.startsWith("UC") && !e.startsWith("FEmusic_library_privately_owned_artist"))
        throw new x("Invalid artist id", e);
      const t = yield Ne(this, Le, "f").browse(e, { client: "YTMUSIC" });
      return new ex(t, Ne(this, Le, "f"));
    });
  }
  getAlbum(e) {
    return Jt(this, void 0, void 0, function* () {
      if (Ue({ album_id: e }), !e.startsWith("MPR") && !e.startsWith("FEmusic_library_privately_owned_release"))
        throw new x("Invalid album id", e);
      const t = yield Ne(this, Le, "f").browse(e, { client: "YTMUSIC" });
      return new tx(t, Ne(this, Le, "f"));
    });
  }
  getPlaylist(e) {
    return Jt(this, void 0, void 0, function* () {
      Ue({ playlist_id: e }), e.startsWith("VL") || (e = `VL${e}`);
      const t = yield Ne(this, Le, "f").browse(e, { client: "YTMUSIC" });
      return new ww(t, Ne(this, Le, "f"));
    });
  }
  getUpNext(e, t = !0) {
    var i, n, s;
    return Jt(this, void 0, void 0, function* () {
      Ue({ video_id: e });
      const u = (yield Ne(this, Le, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(Ao).contents.item().as(Io).contents.item().as(Po).tabs.array().as(jt).get({ title: "Up next" });
      if (!u)
        throw new x("Could not find target tab.");
      const c = (i = u.content) === null || i === void 0 ? void 0 : i.as(xf);
      if (!c || !c.content)
        throw new x("Music queue was empty, the given id is probably invalid.", c);
      const h = c.content.as(xs);
      if (!h.playlist_id && t) {
        const p = h.contents.firstOfType(bh);
        if (!p)
          throw new x("Automix item not found");
        const f = yield (n = p.playlist_video) === null || n === void 0 ? void 0 : n.endpoint.callTest(Ne(this, Le, "f"), {
          videoId: e,
          client: "YTMUSIC",
          parse: !0
        });
        if (!f)
          throw new x("Could not fetch automix");
        return (s = f.contents_memo.getType(xs)) === null || s === void 0 ? void 0 : s[0];
      }
      return h;
    });
  }
  getRelated(e) {
    return Jt(this, void 0, void 0, function* () {
      Ue({ video_id: e });
      const n = (yield Ne(this, Le, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(Ao).contents.item().as(Io).contents.item().as(Po).tabs.array().as(jt).get({ title: "Related" });
      if (!n)
        throw new x("Could not find target tab.");
      const s = yield n.endpoint.call(Ne(this, Le, "f"), "YTMUSIC", !0);
      if (!s)
        throw new x("Could not retrieve tab contents, the given id may be invalid or is not a song.");
      return s.contents.item().as(ft).contents.array().as(pr, Ll);
    });
  }
  getLyrics(e) {
    return Jt(this, void 0, void 0, function* () {
      Ue({ video_id: e });
      const n = (yield Ne(this, Le, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(Ao).contents.item().as(Io).contents.item().as(Po).tabs.array().as(jt).get({ title: "Lyrics" });
      if (!n)
        throw new x("Could not find target tab.");
      const s = yield n.endpoint.call(Ne(this, Le, "f"), "YTMUSIC", !0);
      if (!s)
        throw new x("Could not retrieve tab contents, the given id may be invalid or is not a song.");
      if (s.contents.item().key("type").string() === "Message")
        throw new x(s.contents.item().as(ta).text, e);
      return s.contents.item().as(ft).contents.array().firstOfType(Ll);
    });
  }
  getRecap() {
    return Jt(this, void 0, void 0, function* () {
      const e = yield Ne(this, Le, "f").execute("/browse", {
        browseId: "FEmusic_listening_review",
        client: "YTMUSIC_ANDROID"
      });
      return new nx(e, Ne(this, Le, "f"));
    });
  }
  getSearchSuggestions(e) {
    var t;
    return Jt(this, void 0, void 0, function* () {
      const n = (t = (yield Ne(this, Le, "f").execute("/music/get_search_suggestions", {
        parse: !0,
        input: e,
        client: "YTMUSIC"
      })).contents_memo.getType(S_)) === null || t === void 0 ? void 0 : t[0];
      return n.contents.is_array ? n?.contents.array() : Qt([]);
    });
  }
};
l(xw, "Music");
Oo = /* @__PURE__ */ new WeakMap(), Le = /* @__PURE__ */ new WeakMap(), _l = /* @__PURE__ */ new WeakSet(), Cw = /* @__PURE__ */ l(function(t) {
  return Jt(this, void 0, void 0, function* () {
    const i = Cs(16), n = Ne(this, Le, "f").execute("/player", {
      cpn: i,
      client: "YTMUSIC",
      videoId: t,
      playbackContext: {
        contentPlaybackContext: {
          signatureTimestamp: Ne(this, Oo, "f").player.sts
        }
      }
    }), s = Ne(this, Le, "f").execute("/next", {
      client: "YTMUSIC",
      videoId: t
    }), r = yield Promise.all([n, s]);
    return new T2(r, Ne(this, Le, "f"), i);
  });
}, "_Music_fetchInfoFromVideoId"), Tw = /* @__PURE__ */ l(function(t) {
  return Jt(this, void 0, void 0, function* () {
    if (!t)
      throw new x("List item cannot be undefined");
    if (!t.endpoint)
      throw new Error("This item does not have an endpoint.");
    const i = Cs(16), n = t.endpoint.callTest(Ne(this, Le, "f"), {
      cpn: i,
      client: "YTMUSIC",
      playbackContext: {
        contentPlaybackContext: {
          signatureTimestamp: Ne(this, Oo, "f").player.sts
        }
      }
    }), s = t.endpoint.callTest(Ne(this, Le, "f"), {
      client: "YTMUSIC",
      enablePersistentPlaylistPanel: !0,
      override_endpoint: "/next"
    }), r = yield Promise.all([n, s]);
    return new T2(r, Ne(this, Le, "f"), i);
  });
}, "_Music_fetchInfoFromListItem");
var sx = xw, bl = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, P2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, pn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, xn, wl, Sl, Cl, Tl, Mc = class {
  constructor(e = !1, t) {
    xn.add(this), wl.set(this, void 0), Sl.set(this, void 0), P2(this, wl, t || Mc.default_persistent_directory, "f"), P2(this, Sl, e, "f");
  }
  static get temp_directory() {
    switch (_i()) {
      case "deno":
        const e = Reflect.get(globalThis, "Deno");
        return `${e.env.get("TMPDIR") || e.env.get("TMP") || e.env.get("TEMP") || "/tmp"}/youtubei.js`;
      case "node":
        return `${Reflect.get(module, "require")("os").tmpdir()}/youtubei.js`;
      default:
        return "";
    }
  }
  static get default_persistent_directory() {
    switch (_i()) {
      case "deno":
        return `${Reflect.get(globalThis, "Deno").cwd()}/.cache/youtubei.js`;
      case "node":
        return Reflect.get(module, "require")("path").resolve(__dirname, "..", "..", ".cache", "youtubei.js");
      default:
        return "";
    }
  }
  get cache_dir() {
    return pn(this, Sl, "f") ? pn(this, wl, "f") : Mc.temp_directory;
  }
  get(e) {
    return bl(this, void 0, void 0, function* () {
      switch (yield pn(this, xn, "m", Cl).call(this), _i()) {
        case "deno": {
          const t = `${this.cache_dir}/${e}`, i = Reflect.get(globalThis, "Deno");
          try {
            if ((yield i.stat(t)).isFile)
              return (yield i.readFile(t)).buffer;
            throw new Error("An unexpected file was found in place of the cache key");
          } catch (n) {
            if (n instanceof i.errors.NotFound)
              return;
            throw n;
          }
        }
        case "node": {
          const t = Reflect.get(module, "require")("fs/promises"), i = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
          try {
            if ((yield t.stat(i)).isFile())
              return (yield t.readFile(i)).buffer;
            throw new Error("An unexpected file was found in place of the cache key");
          } catch (n) {
            if (n?.code === "ENOENT")
              return;
            throw n;
          }
        }
        case "browser": {
          const t = yield pn(this, xn, "m", Tl).call(this);
          return t ? new Promise((i, n) => {
            const s = t.transaction("kv-store", "readonly").objectStore("kv-store").get(e);
            s.onerror = n, s.onsuccess = function() {
              var r;
              const a = (r = this.result) === null || r === void 0 ? void 0 : r.v;
              i(a ? a.buffer : void 0);
            };
          }) : void 0;
        }
      }
    });
  }
  set(e, t) {
    return bl(this, void 0, void 0, function* () {
      switch (yield pn(this, xn, "m", Cl).call(this), _i()) {
        case "deno":
          {
            const i = Reflect.get(globalThis, "Deno"), n = `${this.cache_dir}/${e}`;
            yield i.writeFile(n, new Uint8Array(t));
          }
          break;
        case "node":
          {
            const i = Reflect.get(module, "require")("fs/promises"), n = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
            yield i.writeFile(n, new Uint8Array(t));
          }
          break;
        case "browser": {
          const i = yield pn(this, xn, "m", Tl).call(this);
          return i ? new Promise((n, s) => {
            const r = i.transaction("kv-store", "readwrite").objectStore("kv-store").put({ k: e, v: t });
            r.onerror = s, r.onsuccess = () => n();
          }) : void 0;
        }
      }
    });
  }
  remove(e) {
    return bl(this, void 0, void 0, function* () {
      switch (yield pn(this, xn, "m", Cl).call(this), _i()) {
        case "deno":
          {
            const t = `${this.cache_dir}/${e}`, i = Reflect.get(globalThis, "Deno");
            try {
              yield i.remove(t);
            } catch (n) {
              if (n instanceof i.errors.NotFound)
                return;
              throw n;
            }
          }
          break;
        case "node":
          {
            const t = Reflect.get(module, "require")("fs/promises"), i = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
            try {
              yield t.unlink(i);
            } catch (n) {
              if (n?.code === "ENOENT")
                return;
              throw n;
            }
          }
          break;
        case "browser": {
          const t = yield pn(this, xn, "m", Tl).call(this);
          return t ? new Promise((i, n) => {
            const s = t.transaction("kv-store", "readwrite").objectStore("kv-store").delete(e);
            s.onerror = n, s.onsuccess = () => i();
          }) : void 0;
        }
      }
    });
  }
};
l(Mc, "UniversalCache");
wl = /* @__PURE__ */ new WeakMap(), Sl = /* @__PURE__ */ new WeakMap(), xn = /* @__PURE__ */ new WeakSet(), Cl = /* @__PURE__ */ l(function() {
  return bl(this, void 0, void 0, function* () {
    const t = this.cache_dir;
    switch (_i()) {
      case "deno":
        const i = Reflect.get(globalThis, "Deno");
        try {
          if (!(yield i.stat(t)).isDirectory)
            throw new Error("An unexpected file was found in place of the cache directory");
        } catch (s) {
          if (s instanceof i.errors.NotFound)
            yield i.mkdir(t, { recursive: !0 });
          else
            throw s;
        }
        break;
      case "node":
        const n = Reflect.get(module, "require")("fs/promises");
        try {
          if (!(yield n.stat(t)).isDirectory())
            throw new Error("An unexpected file was found in place of the cache directory");
        } catch (s) {
          if (s?.code === "ENOENT")
            yield n.mkdir(t, { recursive: !0 });
          else
            throw s;
        }
        break;
    }
  });
}, "_UniversalCache_createCache"), Tl = /* @__PURE__ */ l(function() {
  const t = Reflect.get(globalThis, "indexedDB") || Reflect.get(globalThis, "webkitIndexedDB") || Reflect.get(globalThis, "mozIndexedDB") || Reflect.get(globalThis, "msIndexedDB");
  return t ? new Promise((i, n) => {
    const s = t.open("youtubei.js", 1);
    s.onsuccess = function() {
      i(this.result);
    }, s.onerror = function(r) {
      n("indexedDB request error"), console.error(r);
    }, s.onupgradeneeded = function() {
      const r = this.result.createObjectStore("kv-store", {
        keyPath: "k"
      });
      r.transaction.oncomplete = function() {
        i(this.db);
      };
    };
  }) : console.log("IndexedDB is not supported. No cache will be used.");
}, "_UniversalCache_getBrowserDB");
var Fo = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, rx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, gs = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, _o, ys, Ew, kw, Aw, Iw = class {
  constructor(e) {
    _o.add(this), ys.set(this, void 0), rx(this, ys, e, "f");
  }
  setThumbnail(e, t) {
    return Fo(this, void 0, void 0, function* () {
      if (!e || !t)
        throw new mi("One or more parameters are missing.");
      const i = Vt.encodeCustomThumbnailPayload(e, t);
      return yield gs(this, ys, "f").actions.execute("/video_manager/metadata_update", {
        protobuf: !0,
        serialized_data: i
      });
    });
  }
  upload(e, t = {}) {
    return Fo(this, void 0, void 0, function* () {
      const i = yield gs(this, _o, "m", Ew).call(this), n = yield gs(this, _o, "m", kw).call(this, i.upload_url, e);
      if (n.status !== "STATUS_SUCCESS")
        throw new x("Could not process video.");
      return yield gs(this, _o, "m", Aw).call(this, i, n, t);
    });
  }
};
l(Iw, "Studio");
ys = /* @__PURE__ */ new WeakMap(), _o = /* @__PURE__ */ new WeakSet(), Ew = /* @__PURE__ */ l(function() {
  return Fo(this, void 0, void 0, function* () {
    const t = `innertube_android:${hr()}:0:v=3,api=1,cf=3`, i = {
      frontendUploadId: t,
      deviceDisplayName: "Pixel 6 Pro",
      fileId: `goog-edited-video://generated?videoFileUri=content://media/external/video/media/${hr()}`,
      mp4MoovAtomRelocationStatus: "UNSUPPORTED",
      transcodeResult: "DISABLED",
      connectionType: "WIFI"
    }, n = yield gs(this, ys, "f").http.fetch("/upload/youtubei", {
      baseURL: _9.URLS.YT_UPLOAD,
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-goog-upload-command": "start",
        "x-goog-upload-protocol": "resumable"
      },
      body: JSON.stringify(i)
    });
    if (!n.ok)
      throw new x("Could not get initial upload data");
    return {
      frontend_upload_id: t,
      upload_id: n.headers.get("x-guploader-uploadid"),
      upload_url: n.headers.get("x-goog-upload-url"),
      scotty_resource_id: n.headers.get("x-goog-upload-header-scotty-resource-id"),
      chunk_granularity: n.headers.get("x-goog-upload-chunk-granularity")
    };
  });
}, "_Studio_getInitialUploadData"), kw = /* @__PURE__ */ l(function(t, i) {
  return Fo(this, void 0, void 0, function* () {
    const n = yield gs(this, ys, "f").http.fetch_function(t, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-goog-upload-command": "upload, finalize",
        "x-goog-upload-file-name": `file-${Date.now()}`,
        "x-goog-upload-offset": "0"
      },
      body: i
    });
    if (!n.ok)
      throw new x("Could not upload video");
    return yield n.json();
  });
}, "_Studio_uploadVideo"), Aw = /* @__PURE__ */ l(function(t, i, n) {
  return Fo(this, void 0, void 0, function* () {
    const s = {
      resourceId: {
        scottyResourceId: {
          id: i.scottyResourceId
        }
      },
      frontendUploadId: t.frontend_upload_id,
      initialMetadata: {
        title: {
          newTitle: n.title || new Date().toDateString()
        },
        description: {
          newDescription: n.description || "",
          shouldSegment: !0
        },
        privacy: {
          newPrivacy: n.privacy || "PRIVATE"
        },
        draftState: {
          isDraft: n.is_draft || !1
        }
      }
    };
    return yield gs(this, ys, "f").actions.execute("/upload/createvideo", Object.assign({ client: "ANDROID" }, s));
  });
}, "_Studio_setVideoMetadata");
var ox = Iw, ax = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, M2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, bo, Pw = class {
  constructor(e) {
    var t, i;
    bo.set(this, void 0), ax(this, bo, y.parseResponse(e.data), "f"), this.sections = (i = (t = M2(this, bo, "f").contents_memo) === null || t === void 0 ? void 0 : t.get("Element")) === null || i === void 0 ? void 0 : i.map((n) => {
      var s;
      return (s = n.as(fd).model) === null || s === void 0 ? void 0 : s.item();
    });
  }
  get page() {
    return M2(this, bo, "f");
  }
};
l(Pw, "Analytics");
bo = /* @__PURE__ */ new WeakMap();
var lx = Pw, ux = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, N2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, wo, Mw = class {
  constructor(e) {
    var t;
    wo.set(this, void 0), ux(this, wo, y.parseResponse(e.data), "f");
    const i = N2(this, wo, "f").contents.item().as(sa).tabs.get({ selected: !0 });
    if (!i)
      throw new x("Could not find target tab.");
    this.contents = (t = i.content) === null || t === void 0 ? void 0 : t.as(ft).contents.array().as(Hi);
  }
  get page() {
    return N2(this, wo, "f");
  }
};
l(Mw, "TimeWatched");
wo = /* @__PURE__ */ new WeakMap();
var cx = Mw, hx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, R2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, So, Nw = class {
  constructor(e) {
    So.set(this, void 0), hx(this, So, y.parseResponse(e.data), "f");
    const t = R2(this, So, "f").contents.array().as(Wg)[0];
    this.contents = t.contents, this.footers = t.footers;
  }
  get page() {
    return R2(this, So, "f");
  }
};
l(Nw, "AccountInfo");
So = /* @__PURE__ */ new WeakMap();
var dx = Nw, px = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, L2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ua = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Co, To, Rv = class {
  constructor(e, t) {
    var i, n, s, r, a;
    Co.set(this, void 0), To.set(this, void 0), L2(this, To, e, "f"), L2(this, Co, y.parseResponse(t.data), "f"), this.sidebar = (i = Ua(this, Co, "f").sidebar) === null || i === void 0 ? void 0 : i.as(T_);
    const u = Ua(this, Co, "f").contents.item().as(ra).tabs.array().as(jt).get({ selected: !0 });
    if (!u)
      throw new x("Target tab not found");
    const c = (n = u.content) === null || n === void 0 ? void 0 : n.as(ft).contents.array().as(Hi);
    this.introduction = (a = (r = (s = c?.shift()) === null || s === void 0 ? void 0 : s.contents) === null || r === void 0 ? void 0 : r.get({ type: "PageIntroduction" })) === null || a === void 0 ? void 0 : a.as(Qy), this.sections = c?.map((h) => {
      var p;
      return {
        title: ((p = h.header) === null || p === void 0 ? void 0 : p.title.toString()) || null,
        contents: h.contents
      };
    });
  }
  selectSidebarItem(e) {
    return px(this, void 0, void 0, function* () {
      if (!this.sidebar)
        throw new x("Sidebar not available");
      const t = this.sidebar.items.get({ title: e });
      if (!t)
        throw new x(`Item "${e}" not found`, { available_items: this.sidebar_items });
      const i = yield t.endpoint.callTest(Ua(this, To, "f"), { parse: !1 });
      return new Rv(Ua(this, To, "f"), i);
    });
  }
  getSettingOption(e) {
    var t;
    if (!this.sections)
      throw new x("Sections not available");
    for (const i of this.sections)
      if (!!i.contents)
        for (const n of i.contents) {
          const s = n.as(Ya).options;
          if (s) {
            for (const r of s)
              if (r.is(S0) && ((t = r.title) === null || t === void 0 ? void 0 : t.toString()) === e)
                return r;
          }
        }
    throw new x(`Option "${e}" not found`, { available_options: this.setting_options });
  }
  get setting_options() {
    if (!this.sections)
      throw new x("Sections not available");
    let e = [];
    for (const t of this.sections)
      if (!!t.contents)
        for (const i of t.contents)
          i.as(Ya).options && (e = e.concat(i.as(Ya).options));
    return e.map((t) => {
      var i;
      return (i = t.title) === null || i === void 0 ? void 0 : i.toString();
    }).filter((t) => t);
  }
  get sidebar_items() {
    if (!this.sidebar)
      throw new x("Sidebar not available");
    return this.sidebar.items.map((e) => e.title.toString());
  }
};
l(Rv, "Settings");
Co = /* @__PURE__ */ new WeakMap(), To = /* @__PURE__ */ new WeakMap();
var fx = Rv, ja = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, mx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Qn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Pi, Rw = class {
  constructor(e) {
    Pi.set(this, void 0), mx(this, Pi, e, "f"), this.channel = {
      editName: (t) => Qn(this, Pi, "f").channel("channel/edit_name", { new_name: t }),
      editDescription: (t) => Qn(this, Pi, "f").channel("channel/edit_description", { new_description: t }),
      getBasicAnalytics: () => this.getAnalytics()
    };
  }
  getInfo() {
    return ja(this, void 0, void 0, function* () {
      const e = yield Qn(this, Pi, "f").execute("/account/accounts_list", { client: "ANDROID" });
      return new dx(e);
    });
  }
  getTimeWatched() {
    return ja(this, void 0, void 0, function* () {
      const e = yield Qn(this, Pi, "f").execute("/browse", {
        browseId: "SPtime_watched",
        client: "ANDROID"
      });
      return new cx(e);
    });
  }
  getSettings() {
    return ja(this, void 0, void 0, function* () {
      const e = yield Qn(this, Pi, "f").execute("/browse", {
        browseId: "SPaccount_overview"
      });
      return new fx(Qn(this, Pi, "f"), e);
    });
  }
  getAnalytics() {
    var e;
    return ja(this, void 0, void 0, function* () {
      const t = yield this.getInfo(), i = Vt.encodeChannelAnalyticsParams((e = t.footers) === null || e === void 0 ? void 0 : e.endpoint.payload.browseId), n = yield Qn(this, Pi, "f").browse("FEanalytics_screen", { params: i, client: "ANDROID" });
      return new lx(n);
    });
  }
};
l(Rw, "AccountManager");
Pi = /* @__PURE__ */ new WeakMap();
var vx = Rw, es = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, gx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, qi = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, oi, Lw = class {
  constructor(e) {
    oi.set(this, void 0), gx(this, oi, e, "f");
  }
  create(e, t) {
    return es(this, void 0, void 0, function* () {
      Ue({ title: e, video_ids: t });
      const i = yield qi(this, oi, "f").execute("/playlist/create", { title: e, ids: t, parse: !1 });
      return {
        success: i.success,
        status_code: i.status_code,
        playlist_id: i.data.playlistId,
        data: i.data
      };
    });
  }
  delete(e) {
    return es(this, void 0, void 0, function* () {
      Ue({ playlist_id: e });
      const t = yield qi(this, oi, "f").execute("playlist/delete", { playlistId: e });
      return {
        playlist_id: e,
        success: t.success,
        status_code: t.status_code,
        data: t.data
      };
    });
  }
  addVideos(e, t) {
    return es(this, void 0, void 0, function* () {
      Ue({ playlist_id: e, video_ids: t });
      const i = yield qi(this, oi, "f").execute("/browse/edit_playlist", {
        playlistId: e,
        actions: t.map((n) => ({
          action: "ACTION_ADD_VIDEO",
          addedVideoId: n
        })),
        parse: !1
      });
      return {
        playlist_id: e,
        action_result: i.data.actions
      };
    });
  }
  removeVideos(e, t) {
    return es(this, void 0, void 0, function* () {
      Ue({ playlist_id: e, video_ids: t });
      const i = yield qi(this, oi, "f").execute("/browse", { browseId: `VL${e}`, parse: !0 }), n = new Vl(qi(this, oi, "f"), i, !0);
      if (!n.info.is_editable)
        throw new x("This playlist cannot be edited.", e);
      const s = {
        playlistId: e,
        actions: []
      }, r = /* @__PURE__ */ l((u) => es(this, void 0, void 0, function* () {
        if (u.videos.filter((h) => t.includes(h.key("id").string())).forEach((h) => s.actions.push({
          action: "ACTION_REMOVE_VIDEO",
          setVideoId: h.key("set_video_id").string()
        })), s.actions.length < t.length) {
          const h = yield u.getContinuation();
          return r(h);
        }
      }), "getSetVideoIds");
      if (yield r(n), !s.actions.length)
        throw new x("Given video ids were not found in this playlist.", t);
      const a = yield qi(this, oi, "f").execute("/browse/edit_playlist", Object.assign(Object.assign({}, s), { parse: !1 }));
      return {
        playlist_id: e,
        action_result: a.data.actions
      };
    });
  }
  moveVideo(e, t, i) {
    return es(this, void 0, void 0, function* () {
      Ue({ playlist_id: e, moved_video_id: t, predecessor_video_id: i });
      const n = yield qi(this, oi, "f").execute("/browse", { browseId: `VL${e}`, parse: !0 }), s = new Vl(qi(this, oi, "f"), n, !0);
      if (!s.info.is_editable)
        throw new x("This playlist cannot be edited.", e);
      const r = {
        playlistId: e,
        actions: []
      };
      let a, u;
      const c = /* @__PURE__ */ l((p) => es(this, void 0, void 0, function* () {
        const f = p.videos.find((C) => t === C.key("id").string()), _ = p.videos.find((C) => i === C.key("id").string());
        if (a = a || f?.key("set_video_id").string(), u = u || _?.key("set_video_id").string(), !a || !u) {
          const C = yield p.getContinuation();
          return c(C);
        }
      }), "getSetVideoIds");
      yield c(s), r.actions.push({
        action: "ACTION_MOVE_VIDEO_AFTER",
        setVideoId: a,
        movedSetVideoIdPredecessor: u
      });
      const h = yield qi(this, oi, "f").execute("/browse/edit_playlist", Object.assign(Object.assign({}, r), { parse: !1 }));
      return {
        playlist_id: e,
        action_result: h.data.actions
      };
    });
  }
};
l(Lw, "PlaylistManager");
oi = /* @__PURE__ */ new WeakMap();
var yx = Lw, fn = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, _x = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, mn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, fi, Dw = class {
  constructor(e) {
    fi.set(this, void 0), _x(this, fi, e, "f");
  }
  like(e) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ video_id: e }), yield mn(this, fi, "f").engage("like/like", { video_id: e });
    });
  }
  dislike(e) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ video_id: e }), yield mn(this, fi, "f").engage("like/dislike", { video_id: e });
    });
  }
  removeLike(e) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ video_id: e }), yield mn(this, fi, "f").engage("like/removelike", { video_id: e });
    });
  }
  subscribe(e) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ channel_id: e }), yield mn(this, fi, "f").engage("subscription/subscribe", { channel_id: e });
    });
  }
  unsubscribe(e) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ channel_id: e }), yield mn(this, fi, "f").engage("subscription/unsubscribe", { channel_id: e });
    });
  }
  comment(e, t) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ video_id: e, text: t }), yield mn(this, fi, "f").engage("comment/create_comment", { video_id: e, text: t });
    });
  }
  translate(e, t, i = {}) {
    return fn(this, void 0, void 0, function* () {
      Ue({ text: e, target_language: t });
      const n = yield yield mn(this, fi, "f").engage("comment/perform_comment_action", {
        video_id: i.video_id,
        comment_id: i.comment_id,
        target_language: t,
        comment_action: "translate",
        text: e
      }), s = n.data.frameworkUpdates.entityBatchUpdate.mutations[0].payload.commentEntityPayload;
      return {
        success: n.success,
        status_code: n.status_code,
        translated_content: s.translatedContent.content,
        data: n.data
      };
    });
  }
  setNotificationPreferences(e, t) {
    return fn(this, void 0, void 0, function* () {
      return Ue({ channel_id: e, type: t }), yield mn(this, fi, "f").notifications("modify_channel_preference", { channel_id: e, pref: t || "NONE" });
    });
  }
};
l(Dw, "InteractionManager");
fi = /* @__PURE__ */ new WeakMap();
var bx = Dw, wx = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, q1 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Sx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, sr, Bw = class extends Un {
  constructor(e, t, i = !1) {
    super(e, t, i), sr.set(this, void 0);
  }
  get filter_chips() {
    var e, t;
    if (q1(this, sr, "f"))
      return q1(this, sr, "f") || [];
    if (((e = this.memo.getType(sc)) === null || e === void 0 ? void 0 : e.length) > 1)
      throw new x("There are too many feed filter chipbars, you'll need to find the correct one yourself in this.page");
    if (((t = this.memo.getType(sc)) === null || t === void 0 ? void 0 : t.length) === 0)
      throw new x("There are no feed filter chipbars");
    return Sx(this, sr, this.memo.getType(Wo), "f"), q1(this, sr, "f") || [];
  }
  get filters() {
    return this.filter_chips.map((e) => e.text.toString()) || [];
  }
  getFilteredFeed(e) {
    var t;
    return wx(this, void 0, void 0, function* () {
      let i;
      if (typeof e == "string") {
        if (!this.filters.includes(e))
          throw new x("Filter not found", {
            available_filters: this.filters
          });
        i = this.filter_chips.find((s) => s.text.toString() === e);
      } else if (e.type === "ChipCloudChip")
        i = e;
      else
        throw new x("Invalid filter");
      if (!i)
        throw new x("Filter not found");
      if (i.is_selected)
        return this;
      const n = yield (t = i.endpoint) === null || t === void 0 ? void 0 : t.call(this.actions, void 0, !0);
      return new Un(this.actions, n, !0);
    });
  }
};
l(Bw, "FilterableFeed");
sr = /* @__PURE__ */ new WeakMap();
var Cx = Bw, mt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (f) {
        a(f);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (f) {
        a(f);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Lv = class {
  constructor(e) {
    this.session = e, this.account = new vx(this.session.actions), this.playlist = new yx(this.session.actions), this.interact = new bx(this.session.actions), this.music = new sx(this.session), this.studio = new ox(this.session), this.actions = this.session.actions;
  }
  static create(e = {}) {
    return mt(this, void 0, void 0, function* () {
      return new Lv(yield Ol.create(e));
    });
  }
  getInfo(e, t) {
    return mt(this, void 0, void 0, function* () {
      const i = Cs(16), n = yield this.actions.getVideoInfo(e, i, t), s = this.actions.next({ video_id: e }), r = yield Promise.all([n, s]);
      return new C2(r, this.actions, this.session.player, i);
    });
  }
  getBasicInfo(e, t) {
    return mt(this, void 0, void 0, function* () {
      const i = Cs(16), n = yield this.actions.getVideoInfo(e, i, t);
      return new C2([n], this.actions, this.session.player, i);
    });
  }
  search(e, t = {}) {
    return mt(this, void 0, void 0, function* () {
      Ue({ query: e });
      const i = yield this.actions.search({ query: e, filters: t });
      return new eC(this.actions, i.data);
    });
  }
  getSearchSuggestions(e) {
    return mt(this, void 0, void 0, function* () {
      Ue({ query: e });
      const t = new URL(`${ve.URLS.YT_SUGGESTIONS}search`);
      t.searchParams.set("q", e), t.searchParams.set("hl", this.session.context.client.hl), t.searchParams.set("gl", this.session.context.client.gl), t.searchParams.set("ds", "yt"), t.searchParams.set("client", "youtube"), t.searchParams.set("xssi", "t"), t.searchParams.set("oe", "UTF");
      const n = yield (yield this.session.http.fetch(t)).text();
      return JSON.parse(n.replace(")]}'", ""))[1].map((a) => a[0]);
    });
  }
  getComments(e, t) {
    return mt(this, void 0, void 0, function* () {
      Ue({ video_id: e });
      const i = Vt.encodeCommentsSectionParams(e, {
        sort_by: t || "TOP_COMMENTS"
      }), n = yield this.actions.next({ ctoken: i });
      return new oC(this.actions, n.data);
    });
  }
  getHomeFeed() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEwhat_to_watch");
      return new Cx(this.actions, e.data);
    });
  }
  getLibrary() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FElibrary");
      return new rC(e.data, this.actions);
    });
  }
  getHistory() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEhistory");
      return new z_(this.actions, e.data);
    });
  }
  getTrending() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEtrending");
      return new q_(this.actions, e.data);
    });
  }
  getSubscriptionsFeed() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEsubscriptions");
      return new Un(this.actions, e.data);
    });
  }
  getChannel(e) {
    return mt(this, void 0, void 0, function* () {
      Ue({ id: e });
      const t = yield this.actions.browse(e);
      return new iC(this.actions, t.data);
    });
  }
  getNotifications() {
    return mt(this, void 0, void 0, function* () {
      const e = yield this.actions.notifications("get_notification_menu");
      return new lC(this.actions, e);
    });
  }
  getUnseenNotificationsCount() {
    return mt(this, void 0, void 0, function* () {
      return (yield this.actions.notifications("get_unseen_count")).data.unseenCount;
    });
  }
  getPlaylist(e) {
    return mt(this, void 0, void 0, function* () {
      Ue({ id: e });
      const t = yield this.actions.browse(`VL${e.replace(/VL/g, "")}`);
      return new Vl(this.actions, t.data);
    });
  }
  getStreamingData(e, t = {}) {
    return mt(this, void 0, void 0, function* () {
      return (yield this.getBasicInfo(e)).chooseFormat(t);
    });
  }
  download(e, t) {
    return mt(this, void 0, void 0, function* () {
      return (yield this.getBasicInfo(e, t?.client)).download(t);
    });
  }
  call(e, t) {
    return e.callTest(this.actions, t);
  }
};
l(Lv, "Innertube");
var Tx = Lv;
function D2(e, t) {
  return e.includes(t) ? e.filter((i) => i != t) : [...e, t];
}
function xx(e) {
  const t = Math.floor(e / 3600);
  e -= t * 3600;
  const i = Math.floor(e / 60);
  return e -= i * 60, (t ? t + ":" : "") + i + ":" + e.toString().padStart(2, "0");
}
const pa = await Tx.create({
  cookie: document.cookie,
  fetch: (...e) => fetch(...e)
});
async function Ex() {
  const e = await pa.getLibrary();
  return (await Promise.all(e.playlists.contents.map(Px))).filter((i) => i.title != "Favorites");
}
async function kx(e) {
  await pa.playlist.addVideos("WL", [e]);
}
async function Ax(e) {
  await pa.playlist.removeVideos("WL", [e]);
}
async function Ix(e, t = {}) {
  const i = e.flatMap((s) => s.videos).map((s) => s.id);
  return await Promise.all(
    i.map((s) => t[s] ?? pa.getInfo(s).then(Nx))
  );
}
async function Px(e) {
  const t = await pa.getPlaylist(e.id);
  return {
    author: Ow(e.author),
    id: e.id,
    title: e.title.text,
    videos: t.items.map(Mx).reverse()
  };
}
function Mx(e) {
  return {
    author: Ow(e.author),
    duration: e.duration.text,
    id: e.id,
    thumbnail: Fw(e.thumbnails),
    title: e.title.text
  };
}
function Ow(e) {
  return {
    id: e.id,
    name: e.name,
    url: e.url
  };
}
function Nx(e) {
  return {
    id: e.basic_info.id,
    title: e.basic_info.title,
    duration: xx(e.basic_info.duration),
    thumbnail: Fw(e.basic_info.thumbnail),
    author: e.basic_info.channel,
    published: new Date(e.primary_info.published.text)
  };
}
function Fw(e) {
  const t = e[1], i = t.width / t.height;
  return 1.7777777 - i > 0.1 ? e[0] : t;
}
const js = [];
function Rx(e, t = ce) {
  let i;
  const n = /* @__PURE__ */ new Set();
  function s(u) {
    if (Nt(e, u) && (e = u, i)) {
      const c = !js.length;
      for (const h of n)
        h[1](), js.push(h, e);
      if (c) {
        for (let h = 0; h < js.length; h += 2)
          js[h][0](js[h + 1]);
        js.length = 0;
      }
    }
  }
  function r(u) {
    s(u(e));
  }
  function a(u, c = ce) {
    const h = [u, c];
    return n.add(h), n.size === 1 && (i = t(s) || ce), u(e), () => {
      n.delete(h), n.size === 0 && (i(), i = null);
    };
  }
  return { set: s, update: r, subscribe: a };
}
let Vw = "svelteStore";
const Lx = (e) => {
  if (typeof window === void 0 || !localStorage)
    return;
  const t = localStorage.getItem(e);
  return t === void 0 ? "" : JSON.parse(t);
}, Dx = (e, t) => {
  typeof window === void 0 || !localStorage || localStorage.setItem(e, JSON.stringify(t));
}, Bx = (e, t) => (t.subscribe((i) => {
  Dx(e, i);
}), t), Ox = (e) => {
  Vw = e;
}, $u = (e, t, i = !0) => {
  const n = `${Vw}-${e}`;
  let s = t;
  return i && (s = Lx(n) || t), Bx(n, Rx(s));
};
Ox("sub2lists");
const Zl = $u("hiddenIDs", []), B2 = $u("reversedIDs", []), Yo = $u("defaultTab", "playlists"), O2 = $u("cachedVideos", {});
function Fx(e) {
  ln(e, "svelte-wei49c", "div.svelte-wei49c{display:grid;grid-template-columns:1fr;grid-template-rows:auto 1fr;height:100%}");
}
const Vx = (e) => ({ selected: e & 1 }), F2 = (e) => ({ selected: e[0] }), Ux = (e) => ({ selected: e & 1 }), V2 = (e) => ({
  select: e[1],
  selected: e[0]
});
function jx(e) {
  let t, i, n;
  const s = e[4].tabs, r = y5(s, e, e[3], V2), a = e[4].contents, u = y5(a, e, e[3], F2);
  return {
    c() {
      t = le("div"), r && r.c(), i = wt(), u && u.c(), O(t, "class", "svelte-wei49c");
    },
    m(c, h) {
      Ie(c, t, h), r && r.m(t, null), Y(t, i), u && u.m(t, null), n = !0;
    },
    p(c, [h]) {
      r && r.p && (!n || h & 9) && b5(
        r,
        s,
        c,
        c[3],
        n ? _5(s, c[3], h, Ux) : w5(c[3]),
        V2
      ), u && u.p && (!n || h & 9) && b5(
        u,
        a,
        c,
        c[3],
        n ? _5(a, c[3], h, Vx) : w5(c[3]),
        F2
      );
    },
    i(c) {
      n || (Ee(r, c), Ee(u, c), n = !0);
    },
    o(c) {
      Re(r, c), Re(u, c), n = !1;
    },
    d(c) {
      c && ke(t), r && r.d(c), u && u.d(c);
    }
  };
}
function Hx(e, t, i) {
  let { $$slots: n = {}, $$scope: s } = t, { initial: r = void 0 } = t, { selected: a = r } = t;
  const u = o3();
  function c(h) {
    return function() {
      const p = a;
      i(0, a = h), u("change", { old: p, new: h });
    };
  }
  return e.$$set = (h) => {
    "initial" in h && i(2, r = h.initial), "selected" in h && i(0, a = h.selected), "$$scope" in h && i(3, s = h.$$scope);
  }, [a, c, r, s, n];
}
class Wx extends Wt {
  constructor(t) {
    super(), Ht(this, t, Hx, jx, Nt, { initial: 2, selected: 0 }, Fx);
  }
  get initial() {
    return this.$$.ctx[2];
  }
  set initial(t) {
    this.$$set({ initial: t }), at();
  }
  get selected() {
    return this.$$.ctx[0];
  }
  set selected(t) {
    this.$$set({ selected: t }), at();
  }
}
function $x(e) {
  let t, i = '<path fill="currentColor" d="m13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return {
    c() {
      t = On("svg"), Ui(t, s);
    },
    m(r, a) {
      Ie(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Gn(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: ce,
    o: ce,
    d(r) {
      r && ke(t);
    }
  };
}
function Gx(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ct(ct({}, t), Vi(n)));
  }, t = Vi(t), [t];
}
class qx extends Wt {
  constructor(t) {
    super(), Ht(this, t, Gx, $x, Nt, {});
  }
}
function Kx(e) {
  let t, i = '<circle cx="4" cy="7" r="1" fill="currentColor"/><circle cx="4" cy="12" r="1" fill="currentColor"/><circle cx="4" cy="17" r="1" fill="currentColor"/><rect width="14" height="2" x="7" y="11" fill="currentColor" rx=".94" ry=".94"/><rect width="14" height="2" x="7" y="16" fill="currentColor" rx=".94" ry=".94"/><rect width="14" height="2" x="7" y="6" fill="currentColor" rx=".94" ry=".94"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return {
    c() {
      t = On("svg"), Ui(t, s);
    },
    m(r, a) {
      Ie(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Gn(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: ce,
    o: ce,
    d(r) {
      r && ke(t);
    }
  };
}
function zx(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ct(ct({}, t), Vi(n)));
  }, t = Vi(t), [t];
}
class Yx extends Wt {
  constructor(t) {
    super(), Ht(this, t, zx, Kx, Nt, {});
  }
}
function Xx(e) {
  ln(e, "svelte-1gqpzo3", "svg.svelte-1gqpzo3{pointer-events:none;display:block;width:100%;height:100%;fill:var(--yt-spec-brand-icon-inactive)}");
}
function Jx(e) {
  let t, i, n;
  return {
    c() {
      t = On("svg"), i = On("g"), n = On("path"), O(n, "d", "M22,7H2v1h20V7z M13,12H2v-1h11V12z M13,16H2v-1h11V16z M15,19v-8l7,4L15,19z"), O(n, "class", "style-scope yt-icon"), O(i, "class", "style-scope yt-icon"), O(t, "viewBox", "0 0 24 24"), O(t, "preserveAspectRatio", "xMidYMid meet"), O(t, "focusable", "false"), O(t, "class", "style-scope yt-icon svelte-1gqpzo3"), O(t, "width", e[0]), O(t, "height", e[1]);
    },
    m(s, r) {
      Ie(s, t, r), Y(t, i), Y(i, n);
    },
    p(s, [r]) {
      r & 1 && O(t, "width", s[0]), r & 2 && O(t, "height", s[1]);
    },
    i: ce,
    o: ce,
    d(s) {
      s && ke(t);
    }
  };
}
function Zx(e, t, i) {
  let { width: n = "1.2em" } = t, { height: s = "1.2em" } = t;
  return e.$$set = (r) => {
    "width" in r && i(0, n = r.width), "height" in r && i(1, s = r.height);
  }, [n, s];
}
class Dv extends Wt {
  constructor(t) {
    super(), Ht(this, t, Zx, Jx, Nt, { width: 0, height: 1 }, Xx);
  }
  get width() {
    return this.$$.ctx[0];
  }
  set width(t) {
    this.$$set({ width: t }), at();
  }
  get height() {
    return this.$$.ctx[1];
  }
  set height(t) {
    this.$$set({ height: t }), at();
  }
}
function Qx(e) {
  ln(e, "svelte-9m0dhs", '.sub2lists-video.svelte-9m0dhs.svelte-9m0dhs{position:relative}.sub2lists-video.svelte-9m0dhs>a.svelte-9m0dhs{display:flex;flex-direction:column;gap:0.7rem}#title.svelte-9m0dhs.svelte-9m0dhs{font-family:"Roboto", "Arial", sans-serif;font-size:1.4em;font-weight:500;overflow:hidden;display:block;-webkit-line-clamp:2;display:box;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;white-space:normal}#watchlater.svelte-9m0dhs.svelte-9m0dhs{opacity:0;transition:opacity ease-in-out 0.15s;background:rgba(10, 10, 10, 0.85);height:30px;padding:2px;border-radius:3px;position:absolute;top:0.5rem;right:0.5rem;border:0;fill:lightgray;cursor:pointer;font-weight:bold;color:white}.sub2lists-video.svelte-9m0dhs:hover #watchlater.svelte-9m0dhs{opacity:1}.sub2lists-video.svelte-9m0dhs #watchlater[data-added="true"] svg.svelte-9m0dhs{display:none}.sub2lists-video.svelte-9m0dhs #watchlater span.svelte-9m0dhs{display:none}.sub2lists-video.svelte-9m0dhs #watchlater[data-added="true"] span.svelte-9m0dhs{display:initial}#watchlater.svelte-9m0dhs span.svelte-9m0dhs{margin:0 3px}#thumbnail.svelte-9m0dhs.svelte-9m0dhs{position:relative}#thumbnail.svelte-9m0dhs img.svelte-9m0dhs{width:100%}#duration.svelte-9m0dhs.svelte-9m0dhs{color:white;position:absolute;right:0.5rem;bottom:0.5rem;background-color:rgba(10, 10, 10, 0.85);padding:3px 5px;border-radius:3px;font-weight:bold}a.svelte-9m0dhs.svelte-9m0dhs{text-decoration:none;color:var(--yt-spec-text-primary)}svg.svelte-9m0dhs.svelte-9m0dhs{pointer-events:none;width:100%;height:100%}');
}
function U2(e) {
  let t, i = e[7](e[4]) + "", n;
  return {
    c() {
      t = le("span"), n = Xe(i), O(t, "class", "svelte-9m0dhs");
    },
    m(s, r) {
      Ie(s, t, r), Y(t, n);
    },
    p(s, r) {
      r & 16 && i !== (i = s[7](s[4]) + "") && _s(n, i);
    },
    d(s) {
      s && ke(t);
    }
  };
}
function eE(e) {
  let t, i, n, s, r, a, u, c, h, p, f, _, C, E, P, A = e[0].name + "", F, M, j, z, D, v = e[4] && U2(e);
  return {
    c() {
      t = le("div"), i = le("a"), n = le("div"), s = le("button"), s.innerHTML = `<span class="svelte-9m0dhs">Added!</span> 
				<svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope yt-icon svelte-9m0dhs"><g class="style-scope yt-icon"><path d="M14.97,16.95L10,13.87V7h2v5.76l4.03,2.49L14.97,16.95z M12,3c-4.96,0-9,4.04-9,9s4.04,9,9,9s9-4.04,9-9S16.96,3,12,3 M12,2c5.52,0,10,4.48,10,10s-4.48,10-10,10S2,17.52,2,12S6.48,2,12,2L12,2z" class="style-scope yt-icon"></path></g></svg>`, r = wt(), a = le("img"), c = wt(), h = le("span"), p = Xe(e[2]), f = wt(), _ = le("span"), C = Xe(e[1]), E = wt(), P = le("a"), F = Xe(A), j = wt(), v && v.c(), O(s, "id", "watchlater"), O(s, "title", "Add to watch later"), O(s, "class", "svelte-9m0dhs"), g5(a.src, u = e[3].url) || O(a, "src", u), O(a, "alt", e[1]), O(a, "class", "svelte-9m0dhs"), O(h, "id", "duration"), O(h, "class", "svelte-9m0dhs"), O(n, "id", "thumbnail"), O(n, "class", "svelte-9m0dhs"), O(_, "id", "title"), O(_, "title", e[1]), O(_, "class", "svelte-9m0dhs"), O(P, "id", "author"), O(P, "href", M = e[0].url), O(P, "class", "svelte-9m0dhs"), O(i, "href", e[5]), O(i, "class", "svelte-9m0dhs"), O(t, "class", "sub2lists-video svelte-9m0dhs");
    },
    m(U, Z) {
      Ie(U, t, Z), Y(t, i), Y(i, n), Y(n, s), Y(n, r), Y(n, a), Y(n, c), Y(n, h), Y(h, p), Y(i, f), Y(i, _), Y(_, C), Y(i, E), Y(i, P), Y(P, F), Y(i, j), v && v.m(i, null), z || (D = ti(s, "click", Nc(e[6])), z = !0);
    },
    p(U, [Z]) {
      Z & 8 && !g5(a.src, u = U[3].url) && O(a, "src", u), Z & 2 && O(a, "alt", U[1]), Z & 4 && _s(p, U[2]), Z & 2 && _s(C, U[1]), Z & 2 && O(_, "title", U[1]), Z & 1 && A !== (A = U[0].name + "") && _s(F, A), Z & 1 && M !== (M = U[0].url) && O(P, "href", M), U[4] ? v ? v.p(U, Z) : (v = U2(U), v.c(), v.m(i, null)) : v && (v.d(1), v = null), Z & 32 && O(i, "href", U[5]);
    },
    i: ce,
    o: ce,
    d(U) {
      U && ke(t), v && v.d(), z = !1, D();
    }
  };
}
function tE(e, t, i) {
  let n, { author: s } = t, { title: r } = t, { id: a } = t, { duration: u } = t, { thumbnail: c } = t, { published: h = void 0 } = t;
  async function p() {
    this.dataset.added ? (await Ax(a), delete this.dataset.added) : (await kx(a), this.dataset.added = "true");
  }
  const f = new Intl.DateTimeFormat([], { dateStyle: "medium" });
  function _(C) {
    return f.format(C);
  }
  return e.$$set = (C) => {
    "author" in C && i(0, s = C.author), "title" in C && i(1, r = C.title), "id" in C && i(8, a = C.id), "duration" in C && i(2, u = C.duration), "thumbnail" in C && i(3, c = C.thumbnail), "published" in C && i(4, h = C.published);
  }, e.$$.update = () => {
    e.$$.dirty & 256 && i(5, n = `https://www.youtube.com/watch?v=${a}`);
  }, [
    s,
    r,
    u,
    c,
    h,
    n,
    p,
    _,
    a
  ];
}
class Uw extends Wt {
  constructor(t) {
    super(), Ht(
      this,
      t,
      tE,
      eE,
      Nt,
      {
        author: 0,
        title: 1,
        id: 8,
        duration: 2,
        thumbnail: 3,
        published: 4
      },
      Qx
    );
  }
  get author() {
    return this.$$.ctx[0];
  }
  set author(t) {
    this.$$set({ author: t }), at();
  }
  get title() {
    return this.$$.ctx[1];
  }
  set title(t) {
    this.$$set({ title: t }), at();
  }
  get id() {
    return this.$$.ctx[8];
  }
  set id(t) {
    this.$$set({ id: t }), at();
  }
  get duration() {
    return this.$$.ctx[2];
  }
  set duration(t) {
    this.$$set({ duration: t }), at();
  }
  get thumbnail() {
    return this.$$.ctx[3];
  }
  set thumbnail(t) {
    this.$$set({ thumbnail: t }), at();
  }
  get published() {
    return this.$$.ctx[4];
  }
  set published(t) {
    this.$$set({ published: t }), at();
  }
}
function iE(e) {
  let t, i = '<path fill="currentColor" d="M6.09 19h12l-1.3 1.29a1 1 0 0 0 1.42 1.42l3-3a1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0a1 1 0 0 0 0 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19Zm-.3-9.29a1 1 0 1 0 1.42-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5h-12l1.3-1.29a1 1 0 0 0 0-1.42a1 1 0 0 0-1.42 0l-3 3a1 1 0 0 0 0 1.42Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return {
    c() {
      t = On("svg"), Ui(t, s);
    },
    m(r, a) {
      Ie(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Gn(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: ce,
    o: ce,
    d(r) {
      r && ke(t);
    }
  };
}
function nE(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ct(ct({}, t), Vi(n)));
  }, t = Vi(t), [t];
}
class sE extends Wt {
  constructor(t) {
    super(), Ht(this, t, nE, iE, Nt, {});
  }
}
function rE(e) {
  let t, i = '<path fill="currentColor" d="M21.87 11.5c-.64-1.11-4.16-6.68-10.14-6.5c-5.53.14-8.73 5-9.6 6.5a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25c5.53-.14 8.74-5 9.6-6.5a1 1 0 0 0 0-1ZM12.22 17c-4.31.1-7.12-3.59-8-5c1-1.61 3.61-4.9 7.61-5c4.29-.11 7.11 3.59 8 5c-1.03 1.61-3.61 4.9-7.61 5Z"/><path fill="currentColor" d="M12 8.5a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 12 8.5Zm0 5a1.5 1.5 0 1 1 1.5-1.5a1.5 1.5 0 0 1-1.5 1.5Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return {
    c() {
      t = On("svg"), Ui(t, s);
    },
    m(r, a) {
      Ie(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Gn(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: ce,
    o: ce,
    d(r) {
      r && ke(t);
    }
  };
}
function oE(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ct(ct({}, t), Vi(n)));
  }, t = Vi(t), [t];
}
class jw extends Wt {
  constructor(t) {
    super(), Ht(this, t, oE, rE, Nt, {});
  }
}
function aE(e) {
  let t, i = '<path fill="currentColor" d="M4.71 3.29a1 1 0 0 0-1.42 1.42l5.63 5.63a3.5 3.5 0 0 0 4.74 4.74l5.63 5.63a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42ZM12 13.5a1.5 1.5 0 0 1-1.5-1.5s0-.05 0-.07l1.56 1.56Z"/><path fill="currentColor" d="M12.22 17c-4.3.1-7.12-3.59-8-5a13.7 13.7 0 0 1 2.24-2.72L5 7.87a15.89 15.89 0 0 0-2.87 3.63a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25a9.48 9.48 0 0 0 3.23-.67l-1.58-1.58a7.74 7.74 0 0 1-1.7.25Zm9.65-5.5c-.64-1.11-4.17-6.68-10.14-6.5a9.48 9.48 0 0 0-3.23.67l1.58 1.58a7.74 7.74 0 0 1 1.7-.25c4.29-.11 7.11 3.59 8 5a13.7 13.7 0 0 1-2.29 2.72L19 16.13a15.89 15.89 0 0 0 2.91-3.63a1 1 0 0 0-.04-1Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return {
    c() {
      t = On("svg"), Ui(t, s);
    },
    m(r, a) {
      Ie(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Gn(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: ce,
    o: ce,
    d(r) {
      r && ke(t);
    }
  };
}
function lE(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ct(ct({}, t), Vi(n)));
  }, t = Vi(t), [t];
}
class uE extends Wt {
  constructor(t) {
    super(), Ht(this, t, lE, aE, Nt, {});
  }
}
function cE(e) {
  ln(e, "svelte-k9k2i4", "a.svelte-k9k2i4.svelte-k9k2i4{text-decoration:none;color:var(--yt-spec-text-primary)}#title.svelte-k9k2i4.svelte-k9k2i4{display:flex;align-items:center;gap:1rem;font-size:2em;font-weight:500;margin-bottom:0.5rem}button.svelte-k9k2i4.svelte-k9k2i4{all:initial;cursor:pointer;font-size:2rem;display:flex;color:inherit}.right.svelte-k9k2i4.svelte-k9k2i4{margin-left:auto}#hide.svelte-k9k2i4.svelte-k9k2i4{opacity:0.3;transition:opacity ease-in-out 0.15s}#hide.svelte-k9k2i4.svelte-k9k2i4:hover{opacity:1}#videos.svelte-k9k2i4.svelte-k9k2i4{display:grid;gap:1rem;overflow-x:auto;scrollbar-width:thin;grid-auto-columns:250px;grid-auto-flow:column;padding:0.5rem}#videos.svelte-k9k2i4 p.svelte-k9k2i4{font-size:2rem;margin:3rem;grid-column:span 2}");
}
function j2(e, t, i) {
  const n = e.slice();
  return n[13] = t[i], n;
}
function hE(e) {
  let t, i, n, s, r;
  return i = new jw({}), {
    c() {
      t = le("button"), Pt(i.$$.fragment), O(t, "class", "right svelte-k9k2i4"), O(t, "id", "hide"), O(t, "title", "Hide playlist");
    },
    m(a, u) {
      Ie(a, t, u), Ct(i, t, null), n = !0, s || (r = ti(t, "click", e[6]), s = !0);
    },
    p: ce,
    i(a) {
      n || (Ee(i.$$.fragment, a), n = !0);
    },
    o(a) {
      Re(i.$$.fragment, a), n = !1;
    },
    d(a) {
      a && ke(t), Tt(i), s = !1, r();
    }
  };
}
function dE(e) {
  let t, i, n, s, r;
  return i = new uE({}), {
    c() {
      t = le("button"), Pt(i.$$.fragment), O(t, "class", "right svelte-k9k2i4"), O(t, "title", "Show playlist");
    },
    m(a, u) {
      Ie(a, t, u), Ct(i, t, null), n = !0, s || (r = ti(t, "click", e[6]), s = !0);
    },
    p: ce,
    i(a) {
      n || (Ee(i.$$.fragment, a), n = !0);
    },
    o(a) {
      Re(i.$$.fragment, a), n = !1;
    },
    d(a) {
      a && ke(t), Tt(i), s = !1, r();
    }
  };
}
function H2(e) {
  let t;
  return {
    c() {
      t = le("p"), t.textContent = "This playlist contains no videos.", O(t, "class", "svelte-k9k2i4");
    },
    m(i, n) {
      Ie(i, t, n);
    },
    p: ce,
    d(i) {
      i && ke(t);
    }
  };
}
function W2(e) {
  let t, i;
  const n = [e[13]];
  let s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ct(s, n[r]);
  return t = new Uw({ props: s }), {
    c() {
      Pt(t.$$.fragment);
    },
    m(r, a) {
      Ct(t, r, a), i = !0;
    },
    p(r, a) {
      const u = a & 4 ? Gn(n, [Rc(r[13])]) : {};
      t.$set(u);
    },
    i(r) {
      i || (Ee(t.$$.fragment, r), i = !0);
    },
    o(r) {
      Re(t.$$.fragment, r), i = !1;
    },
    d(r) {
      Tt(t, r);
    }
  };
}
function pE(e) {
  let t, i, n, s, r, a, u, c = e[0].name + "", h, p, f, _, C, E, P, A, F, M, j, z, D;
  C = new sE({});
  const v = [dE, hE], U = [];
  function Z(ie, ye) {
    return ie[3] ? 0 : 1;
  }
  P = Z(e), A = U[P] = v[P](e);
  let he = e[2], te = [];
  for (let ie = 0; ie < he.length; ie += 1)
    te[ie] = W2(j2(e, he, ie));
  const Je = (ie) => Re(te[ie], 1, 1, () => {
    te[ie] = null;
  });
  let Q = null;
  return he.length || (Q = H2()), {
    c() {
      t = le("div"), i = le("p"), n = le("a"), s = Xe(e[1]), r = Xe(" - "), a = le("a"), u = Xe("by "), h = Xe(c), f = wt(), _ = le("button"), Pt(C.$$.fragment), E = wt(), A.c(), F = wt(), M = le("div");
      for (let ie = 0; ie < te.length; ie += 1)
        te[ie].c();
      Q && Q.c(), O(n, "href", e[4]), O(n, "class", "svelte-k9k2i4"), O(a, "href", p = e[0].url), O(a, "class", "svelte-k9k2i4"), O(_, "title", "Reverse playlist order"), O(_, "class", "svelte-k9k2i4"), O(i, "id", "title"), O(i, "class", "svelte-k9k2i4"), O(M, "id", "videos"), O(M, "class", "svelte-k9k2i4");
    },
    m(ie, ye) {
      Ie(ie, t, ye), Y(t, i), Y(i, n), Y(n, s), Y(i, r), Y(i, a), Y(a, u), Y(a, h), Y(i, f), Y(i, _), Ct(C, _, null), Y(i, E), U[P].m(i, null), Y(t, F), Y(t, M);
      for (let Ze = 0; Ze < te.length; Ze += 1)
        te[Ze].m(M, null);
      Q && Q.m(M, null), j = !0, z || (D = ti(_, "click", e[5]), z = !0);
    },
    p(ie, [ye]) {
      (!j || ye & 2) && _s(s, ie[1]), (!j || ye & 16) && O(n, "href", ie[4]), (!j || ye & 1) && c !== (c = ie[0].name + "") && _s(h, c), (!j || ye & 1 && p !== (p = ie[0].url)) && O(a, "href", p);
      let Ze = P;
      if (P = Z(ie), P === Ze ? U[P].p(ie, ye) : (ws(), Re(U[Ze], 1, 1, () => {
        U[Ze] = null;
      }), Ss(), A = U[P], A ? A.p(ie, ye) : (A = U[P] = v[P](ie), A.c()), Ee(A, 1), A.m(i, null)), ye & 4) {
        he = ie[2];
        let Te;
        for (Te = 0; Te < he.length; Te += 1) {
          const st = j2(ie, he, Te);
          te[Te] ? (te[Te].p(st, ye), Ee(te[Te], 1)) : (te[Te] = W2(st), te[Te].c(), Ee(te[Te], 1), te[Te].m(M, null));
        }
        for (ws(), Te = he.length; Te < te.length; Te += 1)
          Je(Te);
        Ss(), !he.length && Q ? Q.p(ie, ye) : he.length ? Q && (Q.d(1), Q = null) : (Q = H2(), Q.c(), Q.m(M, null));
      }
    },
    i(ie) {
      if (!j) {
        Ee(C.$$.fragment, ie), Ee(A);
        for (let ye = 0; ye < he.length; ye += 1)
          Ee(te[ye]);
        j = !0;
      }
    },
    o(ie) {
      Re(C.$$.fragment, ie), Re(A), te = te.filter(Boolean);
      for (let ye = 0; ye < te.length; ye += 1)
        Re(te[ye]);
      j = !1;
    },
    d(ie) {
      ie && ke(t), Tt(C), U[P].d(), n3(te, ie), Q && Q.d(), z = !1, D();
    }
  };
}
function fE(e, t, i) {
  let n, s, r, a, u, c;
  Bn(e, Zl, (A) => i(10, u = A)), Bn(e, B2, (A) => i(11, c = A));
  let { author: h } = t, { title: p } = t, { id: f } = t, { videos: _ = [] } = t;
  function C(...A) {
    return s ? _.slice().reverse() : _;
  }
  function E() {
    Vo(B2, c = D2(c, f), c);
  }
  function P() {
    Vo(Zl, u = D2(u, f), u);
  }
  return e.$$set = (A) => {
    "author" in A && i(0, h = A.author), "title" in A && i(1, p = A.title), "id" in A && i(7, f = A.id), "videos" in A && i(8, _ = A.videos);
  }, e.$$.update = () => {
    e.$$.dirty & 128 && i(4, n = `https://www.youtube.com/playlist?list=${f}`), e.$$.dirty & 2176 && i(9, s = c.includes(f)), e.$$.dirty & 1152 && i(3, r = u.includes(f)), e.$$.dirty & 768 && i(2, a = C(_, s));
  }, [
    h,
    p,
    a,
    r,
    n,
    E,
    P,
    f,
    _,
    s,
    u,
    c
  ];
}
class mE extends Wt {
  constructor(t) {
    super(), Ht(this, t, fE, pE, Nt, { author: 0, title: 1, id: 7, videos: 8 }, cE);
  }
  get author() {
    return this.$$.ctx[0];
  }
  set author(t) {
    this.$$set({ author: t }), at();
  }
  get title() {
    return this.$$.ctx[1];
  }
  set title(t) {
    this.$$set({ title: t }), at();
  }
  get id() {
    return this.$$.ctx[7];
  }
  set id(t) {
    this.$$set({ id: t }), at();
  }
  get videos() {
    return this.$$.ctx[8];
  }
  set videos(t) {
    this.$$set({ videos: t }), at();
  }
}
function vE(e) {
  ln(e, "svelte-uxedze", "#playlists.svelte-uxedze{display:flex;flex-direction:column;gap:3rem;overflow-y:auto;height:100%;padding:2rem 1rem}#default-tab.svelte-uxedze{align-self:flex-end;cursor:pointer;margin-bottom:-2rem}p.svelte-uxedze{color:var(--yt-spec-text-primary);font-size:2em;font-weight:500;margin-bottom:0.5rem;display:flex;gap:1rem}button.svelte-uxedze{background:transparent;border:1px solid var(--yt-spec-text-primary);padding:0.5rem 1rem;font-size:1.5rem;display:flex;gap:0.5rem;align-items:center;color:inherit;transition:background-color ease-in-out 0.15s;cursor:pointer}button.svelte-uxedze:hover{background-color:var(--yt-spec-brand-background-solid)}");
}
function $2(e, t, i) {
  const n = e.slice();
  return n[8] = t[i], n;
}
function G2(e) {
  return { c: ce, m: ce, d: ce };
}
function q2(e, t) {
  let i, n, s;
  const r = [t[8]];
  let a = {};
  for (let u = 0; u < r.length; u += 1)
    a = ct(a, r[u]);
  return n = new mE({ props: a }), {
    key: e,
    first: null,
    c() {
      i = Ql(), Pt(n.$$.fragment), this.first = i;
    },
    m(u, c) {
      Ie(u, i, c), Ct(n, u, c), s = !0;
    },
    p(u, c) {
      t = u;
      const h = c & 4 ? Gn(r, [Rc(t[8])]) : {};
      n.$set(h);
    },
    i(u) {
      s || (Ee(n.$$.fragment, u), s = !0);
    },
    o(u) {
      Re(n.$$.fragment, u), s = !1;
    },
    d(u) {
      u && ke(i), Tt(n, u);
    }
  };
}
function K2(e) {
  let t, i, n, s, r, a, u, c, h, p;
  return a = new jw({}), {
    c() {
      t = le("p"), i = Xe("Plus "), n = Xe(e[1]), s = Xe(` hidden playlist(s)
			`), r = le("button"), Pt(a.$$.fragment), u = Xe(`
				Show`), O(r, "class", "svelte-uxedze"), O(t, "class", "svelte-uxedze");
    },
    m(f, _) {
      Ie(f, t, _), Y(t, i), Y(t, n), Y(t, s), Y(t, r), Ct(a, r, null), Y(r, u), c = !0, h || (p = ti(r, "click", e[4]), h = !0);
    },
    p(f, _) {
      (!c || _ & 2) && _s(n, f[1]);
    },
    i(f) {
      c || (Ee(a.$$.fragment, f), c = !0);
    },
    o(f) {
      Re(a.$$.fragment, f), c = !1;
    },
    d(f) {
      f && ke(t), Tt(a), h = !1, p();
    }
  };
}
function gE(e) {
  let t, i, n, s, r, a, u = [], c = /* @__PURE__ */ new Map(), h, p, f, _, C = e[2];
  const E = (F) => F[8].id;
  for (let F = 0; F < C.length; F += 1) {
    let M = $2(e, C, F), j = E(M);
    c.set(j, u[F] = q2(j, M));
  }
  let P = null;
  C.length || (P = G2());
  let A = e[1] > 0 && !e[0] && K2(e);
  return {
    c() {
      t = le("div"), i = le("label"), n = Xe(`Make this the default tab
		`), s = le("input"), a = wt();
      for (let F = 0; F < u.length; F += 1)
        u[F].c();
      P && P.c(), h = wt(), A && A.c(), O(s, "type", "checkbox"), s.disabled = !0, s.checked = r = e[3] == "playlists", O(i, "id", "default-tab"), O(i, "class", "svelte-uxedze"), O(t, "id", "playlists"), O(t, "class", "svelte-uxedze");
    },
    m(F, M) {
      Ie(F, t, M), Y(t, i), Y(i, n), Y(i, s), Y(t, a);
      for (let j = 0; j < u.length; j += 1)
        u[j].m(t, null);
      P && P.m(t, null), Y(t, h), A && A.m(t, null), p = !0, f || (_ = ti(i, "click", e[7]), f = !0);
    },
    p(F, [M]) {
      (!p || M & 8 && r !== (r = F[3] == "playlists")) && (s.checked = r), M & 4 && (C = F[2], ws(), u = n9(u, M, E, 1, F, C, c, t, i9, q2, h, $2), Ss(), C.length ? P && (P.d(1), P = null) : P || (P = G2(), P.c(), P.m(t, h))), F[1] > 0 && !F[0] ? A ? (A.p(F, M), M & 3 && Ee(A, 1)) : (A = K2(F), A.c(), Ee(A, 1), A.m(t, null)) : A && (ws(), Re(A, 1, 1, () => {
        A = null;
      }), Ss());
    },
    i(F) {
      if (!p) {
        for (let M = 0; M < C.length; M += 1)
          Ee(u[M]);
        Ee(A), p = !0;
      }
    },
    o(F) {
      for (let M = 0; M < u.length; M += 1)
        Re(u[M]);
      Re(A), p = !1;
    },
    d(F) {
      F && ke(t);
      for (let M = 0; M < u.length; M += 1)
        u[M].d();
      P && P.d(), A && A.d(), f = !1, _();
    }
  };
}
function yE(e, t, i) {
  let n, s, r, a;
  Bn(e, Zl, (f) => i(6, r = f)), Bn(e, Yo, (f) => i(3, a = f));
  let { playlists: u = [] } = t, c = !1;
  function h() {
    i(0, c = !c);
  }
  const p = () => Vo(Yo, a = "playlist", a);
  return e.$$set = (f) => {
    "playlists" in f && i(5, u = f.playlists);
  }, e.$$.update = () => {
    e.$$.dirty & 97 && i(2, n = u.filter((f) => c || !r.includes(f.id))), e.$$.dirty & 64 && i(1, s = r.length);
  }, [
    c,
    s,
    n,
    a,
    h,
    u,
    r,
    p
  ];
}
class _E extends Wt {
  constructor(t) {
    super(), Ht(this, t, yE, gE, Nt, { playlists: 5 }, vE);
  }
  get playlists() {
    return this.$$.ctx[5];
  }
  set playlists(t) {
    this.$$set({ playlists: t }), at();
  }
}
function bE(e) {
  ln(e, "svelte-1kkr9jp", "#feed.svelte-1kkr9jp{overflow-y:auto;padding:2rem 1rem;display:flex;flex-direction:column;gap:1rem}#default-tab.svelte-1kkr9jp{align-self:flex-end;cursor:pointer}.message.svelte-1kkr9jp{text-align:center;margin-top:5rem;font-size:3rem;line-height:1.5}#videos.svelte-1kkr9jp{display:grid;gap:3rem 1rem;grid-template-columns:repeat(auto-fill, minmax(200px, 1fr))}");
}
function z2(e, t, i) {
  const n = e.slice();
  return n[10] = t[i], n;
}
function wE(e) {
  let t, i;
  return {
    c() {
      t = wt(), i = le("p"), i.textContent = "Error!", O(i, "class", "message svelte-1kkr9jp");
    },
    m(n, s) {
      Ie(n, t, s), Ie(n, i, s);
    },
    p: ce,
    i: ce,
    o: ce,
    d(n) {
      n && ke(t), n && ke(i);
    }
  };
}
function SE(e) {
  let t, i = [], n = /* @__PURE__ */ new Map(), s, r = e[9];
  const a = (u) => u[10].id;
  for (let u = 0; u < r.length; u += 1) {
    let c = z2(e, r, u), h = a(c);
    n.set(h, i[u] = Y2(h, c));
  }
  return {
    c() {
      t = le("div");
      for (let u = 0; u < i.length; u += 1)
        i[u].c();
      O(t, "id", "videos"), O(t, "class", "svelte-1kkr9jp");
    },
    m(u, c) {
      Ie(u, t, c);
      for (let h = 0; h < i.length; h += 1)
        i[h].m(t, null);
      s = !0;
    },
    p(u, c) {
      c & 2 && (r = u[9], ws(), i = n9(i, c, a, 1, u, r, n, t, i9, Y2, null, z2), Ss());
    },
    i(u) {
      if (!s) {
        for (let c = 0; c < r.length; c += 1)
          Ee(i[c]);
        s = !0;
      }
    },
    o(u) {
      for (let c = 0; c < i.length; c += 1)
        Re(i[c]);
      s = !1;
    },
    d(u) {
      u && ke(t);
      for (let c = 0; c < i.length; c += 1)
        i[c].d();
    }
  };
}
function Y2(e, t) {
  let i, n, s;
  const r = [t[10]];
  let a = {};
  for (let u = 0; u < r.length; u += 1)
    a = ct(a, r[u]);
  return n = new Uw({ props: a }), {
    key: e,
    first: null,
    c() {
      i = Ql(), Pt(n.$$.fragment), this.first = i;
    },
    m(u, c) {
      Ie(u, i, c), Ct(n, u, c), s = !0;
    },
    p(u, c) {
      t = u;
      const h = c & 2 ? Gn(r, [Rc(t[10])]) : {};
      n.$set(h);
    },
    i(u) {
      s || (Ee(n.$$.fragment, u), s = !0);
    },
    o(u) {
      Re(n.$$.fragment, u), s = !1;
    },
    d(u) {
      u && ke(i), Tt(n, u);
    }
  };
}
function CE(e) {
  let t, i, n = e[0] == 0 && X2();
  return {
    c() {
      t = le("p"), i = Xe(`Loading...\r
			`), n && n.c(), O(t, "class", "message svelte-1kkr9jp");
    },
    m(s, r) {
      Ie(s, t, r), Y(t, i), n && n.m(t, null);
    },
    p(s, r) {
      s[0] == 0 ? n || (n = X2(), n.c(), n.m(t, null)) : n && (n.d(1), n = null);
    },
    i: ce,
    o: ce,
    d(s) {
      s && ke(t), n && n.d();
    }
  };
}
function X2(e) {
  let t, i;
  return {
    c() {
      t = le("br"), i = Xe("First time caching might take a minute");
    },
    m(n, s) {
      Ie(n, t, s), Ie(n, i, s);
    },
    d(n) {
      n && ke(t), n && ke(i);
    }
  };
}
function TE(e) {
  let t, i, n, s, r, a, u, c, h, p, f = {
    ctx: e,
    current: null,
    token: null,
    hasCatch: !0,
    pending: CE,
    then: SE,
    catch: wE,
    value: 9,
    error: 13,
    blocks: [, , ,]
  };
  return El(u = e[1], f), {
    c() {
      t = le("div"), i = le("label"), n = Xe(`Make this the default tab\r
		`), s = le("input"), a = wt(), f.block.c(), O(s, "type", "checkbox"), s.disabled = !0, s.checked = r = e[2] == "feed", O(i, "id", "default-tab"), O(i, "class", "svelte-1kkr9jp"), O(t, "id", "feed"), O(t, "class", "svelte-1kkr9jp");
    },
    m(_, C) {
      Ie(_, t, C), Y(t, i), Y(i, n), Y(i, s), Y(t, a), f.block.m(t, f.anchor = null), f.mount = () => t, f.anchor = null, c = !0, h || (p = ti(i, "click", e[7]), h = !0);
    },
    p(_, [C]) {
      e = _, (!c || C & 4 && r !== (r = e[2] == "feed")) && (s.checked = r), f.ctx = e, C & 2 && u !== (u = e[1]) && El(u, f) || t9(f, e, C);
    },
    i(_) {
      c || (Ee(f.block), c = !0);
    },
    o(_) {
      for (let C = 0; C < 3; C += 1) {
        const E = f.blocks[C];
        Re(E);
      }
      c = !1;
    },
    d(_) {
      _ && ke(t), f.block.d(), f.token = null, f = null, h = !1, p();
    }
  };
}
function xE(e, t, i) {
  let n, s, r, a, u, c;
  Bn(e, O2, (_) => i(5, a = _)), Bn(e, Zl, (_) => i(6, u = _)), Bn(e, Yo, (_) => i(2, c = _));
  let { playlists: h = [] } = t;
  async function p(_) {
    const C = await Ix(_, a);
    for (const E of C)
      Vo(O2, a[E.id] = E, a), E.published = new Date(E.published);
    return C.sort((E, P) => P.published.getTime() - E.published.getTime());
  }
  const f = () => Vo(Yo, c = "feed", c);
  return e.$$set = (_) => {
    "playlists" in _ && i(3, h = _.playlists);
  }, e.$$.update = () => {
    e.$$.dirty & 72 && i(4, n = h.filter((_) => !u.includes(_.id))), e.$$.dirty & 16 && i(1, s = p(n)), e.$$.dirty & 32 && i(0, r = Object.keys(a).length);
  }, [
    r,
    s,
    c,
    h,
    n,
    a,
    u,
    f
  ];
}
class EE extends Wt {
  constructor(t) {
    super(), Ht(this, t, xE, TE, Nt, { playlists: 3 }, bE);
  }
  get playlists() {
    return this.$$.ctx[3];
  }
  set playlists(t) {
    this.$$set({ playlists: t }), at();
  }
}
function kE(e) {
  ln(e, "svelte-cpt3kc", "#sub2lists-popup *::-webkit-scrollbar{width:9px;height:9px}#sub2lists-popup *::-webkit-scrollbar-track{background:transparent}#sub2lists-popup *::-webkit-scrollbar-thumb{background-color:rgba(155, 155, 155, 0.5);border:transparent}dialog *{scrollbar-width:thin;box-sizing:border-box}dialog.svelte-cpt3kc.svelte-cpt3kc{position:fixed;background:var(--yt-spec-general-background-a);color:var(--yt-spec-text-primary);border-color:var(--yt-spec-text-primary);width:90%;height:90%;font-size:1.2rem;padding:0;overflow:hidden}dialog.svelte-cpt3kc.svelte-cpt3kc::backdrop{background-color:rgba(0, 0, 0, 0.25)}menu.svelte-cpt3kc.svelte-cpt3kc{display:flex;border-bottom:1px solid var(--yt-spec-text-primary);font-size:2rem}.tab.svelte-cpt3kc.svelte-cpt3kc{background-color:transparent;border:none;border-right:1px solid var(--yt-spec-text-primary);padding:1rem 1.5rem;color:inherit;font-size:2rem;cursor:pointer;display:flex;align-items:center;gap:0.5rem}.tab-close.svelte-cpt3kc.svelte-cpt3kc{border:none;border-left:1px solid var(--yt-spec-text-primary);margin-left:auto;padding:0.5rem;display:grid;place-items:center}.selected.svelte-cpt3kc.svelte-cpt3kc,menu.svelte-cpt3kc button.svelte-cpt3kc:hover{background-color:var(--yt-spec-badge-chip-background)}.message.svelte-cpt3kc.svelte-cpt3kc{text-align:center;margin-top:5rem;font-size:3rem}");
}
function AE(e) {
  let t, i, n, s, r, a, u, c, h, p, f, _, C, E;
  return n = new Dv({}), u = new Yx({}), f = new qx({ props: { height: "3rem", width: "3rem" } }), {
    c() {
      t = le("menu"), i = le("button"), Pt(n.$$.fragment), s = Xe(`
				Feed`), r = wt(), a = le("button"), Pt(u.$$.fragment), c = Xe(`
				Playlists`), h = wt(), p = le("button"), Pt(f.$$.fragment), O(i, "class", "tab svelte-cpt3kc"), i.autofocus = !0, wa(i, "selected", e[4] == "feed"), O(a, "class", "tab svelte-cpt3kc"), wa(a, "selected", e[4] == "playlists"), O(p, "class", "tab tab-close svelte-cpt3kc"), O(t, "slot", "tabs"), O(t, "class", "svelte-cpt3kc");
    },
    m(P, A) {
      Ie(P, t, A), Y(t, i), Ct(n, i, null), Y(i, s), Y(t, r), Y(t, a), Ct(u, a, null), Y(a, c), Y(t, h), Y(t, p), Ct(f, p, null), _ = !0, i.focus(), C || (E = [
        ti(i, "click", function() {
          K1(e[11]("feed")) && e[11]("feed").apply(this, arguments);
        }),
        ti(a, "click", function() {
          K1(e[11]("playlists")) && e[11]("playlists").apply(this, arguments);
        }),
        ti(p, "click", e[0])
      ], C = !0);
    },
    p(P, A) {
      e = P, (!_ || A & 16) && wa(i, "selected", e[4] == "feed"), (!_ || A & 16) && wa(a, "selected", e[4] == "playlists");
    },
    i(P) {
      _ || (Ee(n.$$.fragment, P), Ee(u.$$.fragment, P), Ee(f.$$.fragment, P), _ = !0);
    },
    o(P) {
      Re(n.$$.fragment, P), Re(u.$$.fragment, P), Re(f.$$.fragment, P), _ = !1;
    },
    d(P) {
      P && ke(t), Tt(n), Tt(u), Tt(f), C = !1, vr(E);
    }
  };
}
function IE(e) {
  let t, i;
  return {
    c() {
      t = wt(), i = le("p"), i.textContent = "Error!", O(i, "class", "message svelte-cpt3kc");
    },
    m(n, s) {
      Ie(n, t, s), Ie(n, i, s);
    },
    p: ce,
    i: ce,
    o: ce,
    d(n) {
      n && ke(t), n && ke(i);
    }
  };
}
function PE(e) {
  let t, i, n, s;
  const r = [RE, NE, ME], a = [];
  function u(c, h) {
    return c[4] == "feed" ? 0 : c[4] == "playlists" ? 1 : 2;
  }
  return t = u(e), i = a[t] = r[t](e), {
    c() {
      i.c(), n = Ql();
    },
    m(c, h) {
      a[t].m(c, h), Ie(c, n, h), s = !0;
    },
    p(c, h) {
      let p = t;
      t = u(c), t === p ? a[t].p(c, h) : (ws(), Re(a[p], 1, 1, () => {
        a[p] = null;
      }), Ss(), i = a[t], i ? i.p(c, h) : (i = a[t] = r[t](c), i.c()), Ee(i, 1), i.m(n.parentNode, n));
    },
    i(c) {
      s || (Ee(i), s = !0);
    },
    o(c) {
      Re(i), s = !1;
    },
    d(c) {
      a[t].d(c), c && ke(n);
    }
  };
}
function ME(e) {
  return {
    c: ce,
    m: ce,
    p: ce,
    i: ce,
    o: ce,
    d: ce
  };
}
function NE(e) {
  let t, i;
  return t = new _E({
    props: { playlists: e[9] }
  }), {
    c() {
      Pt(t.$$.fragment);
    },
    m(n, s) {
      Ct(t, n, s), i = !0;
    },
    p(n, s) {
      const r = {};
      s & 4 && (r.playlists = n[9]), t.$set(r);
    },
    i(n) {
      i || (Ee(t.$$.fragment, n), i = !0);
    },
    o(n) {
      Re(t.$$.fragment, n), i = !1;
    },
    d(n) {
      Tt(t, n);
    }
  };
}
function RE(e) {
  let t, i;
  return t = new EE({
    props: { playlists: e[9] }
  }), {
    c() {
      Pt(t.$$.fragment);
    },
    m(n, s) {
      Ct(t, n, s), i = !0;
    },
    p(n, s) {
      const r = {};
      s & 4 && (r.playlists = n[9]), t.$set(r);
    },
    i(n) {
      i || (Ee(t.$$.fragment, n), i = !0);
    },
    o(n) {
      Re(t.$$.fragment, n), i = !1;
    },
    d(n) {
      Tt(t, n);
    }
  };
}
function LE(e) {
  let t;
  return {
    c() {
      t = le("p"), t.textContent = "Loading...", O(t, "class", "message svelte-cpt3kc");
    },
    m(i, n) {
      Ie(i, t, n);
    },
    p: ce,
    i: ce,
    o: ce,
    d(i) {
      i && ke(t);
    }
  };
}
function DE(e) {
  let t, i, n, s = {
    ctx: e,
    current: null,
    token: null,
    hasCatch: !0,
    pending: LE,
    then: PE,
    catch: IE,
    value: 9,
    error: 10,
    blocks: [, , ,]
  };
  return El(i = e[2], s), {
    c() {
      t = Ql(), s.block.c();
    },
    m(r, a) {
      Ie(r, t, a), s.block.m(r, s.anchor = a), s.mount = () => t.parentNode, s.anchor = t, n = !0;
    },
    p(r, a) {
      e = r, s.ctx = e, a & 4 && i !== (i = e[2]) && El(i, s) || t9(s, e, a);
    },
    i(r) {
      n || (Ee(s.block), n = !0);
    },
    o(r) {
      for (let a = 0; a < 3; a += 1) {
        const u = s.blocks[a];
        Re(u);
      }
      n = !1;
    },
    d(r) {
      r && ke(t), s.block.d(r), s.token = null, s = null;
    }
  };
}
function BE(e) {
  let t, i, n, s, r, a;
  function u(h) {
    e[6](h);
  }
  let c = {
    initial: e[3],
    $$slots: {
      contents: [
        DE,
        ({ selected: h }) => ({ 4: h }),
        ({ selected: h }) => h ? 16 : 0
      ],
      tabs: [
        AE,
        ({ select: h, selected: p }) => ({ 11: h, 4: p }),
        ({ select: h, selected: p }) => (h ? 2048 : 0) | (p ? 16 : 0)
      ]
    },
    $$scope: { ctx: e }
  };
  return e[4] !== void 0 && (c.selected = e[4]), i = new Wx({ props: c }), xl.push(() => h3(i, "selected", u)), {
    c() {
      t = le("dialog"), Pt(i.$$.fragment), O(t, "id", "sub2lists-popup"), O(t, "class", "svelte-cpt3kc");
    },
    m(h, p) {
      Ie(h, t, p), Ct(i, t, null), e[7](t), s = !0, r || (a = ti(t, "close", e[0]), r = !0);
    },
    p(h, [p]) {
      const f = {};
      p & 8 && (f.initial = h[3]), p & 6164 && (f.$$scope = { dirty: p, ctx: h }), !n && p & 16 && (n = !0, f.selected = h[4], u3(() => n = !1)), i.$set(f);
    },
    i(h) {
      s || (Ee(i.$$.fragment, h), s = !0);
    },
    o(h) {
      Re(i.$$.fragment, h), s = !1;
    },
    d(h) {
      h && ke(t), Tt(i), e[7](null), r = !1, a();
    }
  };
}
function OE(e, t, i) {
  let n;
  Bn(e, Yo, (_) => i(3, n = _));
  const s = () => {
    c.showModal(), i(4, u = n), i(2, h = a()), document.body.style.overflow = "hidden";
  }, r = () => {
    c.close(), document.body.style.removeProperty("overflow");
  };
  async function a() {
    return Ex();
  }
  let u, c, h = new Promise(() => {
  });
  function p(_) {
    u = _, i(4, u);
  }
  function f(_) {
    xl[_ ? "unshift" : "push"](() => {
      c = _, i(1, c);
    });
  }
  return [
    r,
    c,
    h,
    n,
    u,
    s,
    p,
    f
  ];
}
class zE extends Wt {
  constructor(t) {
    super(), Ht(this, t, OE, BE, Nt, { show: 5, hide: 0 }, kE);
  }
  get show() {
    return this.$$.ctx[5];
  }
  get hide() {
    return this.$$.ctx[0];
  }
}
function FE(e) {
  ln(e, "svelte-179qxd2", "a.svelte-179qxd2{text-decoration:none;color:var(--yt-spec-text-primary)}#wrapper.svelte-179qxd2{padding:0 24px;min-width:0;height:var(--paper-item-min-height, 48px);display:flex;align-items:center;color:var(--yt-spec-brand-icon-inactive)}#icon.svelte-179qxd2{width:24px;height:24px;margin-right:24px}");
}
function VE(e) {
  let t, i, n, s, r, a, u, c, h;
  return r = new Dv({}), {
    c() {
      t = le("div"), i = le("a"), n = le("div"), s = le("div"), Pt(r.$$.fragment), a = Xe(`
			Playlists`), O(s, "id", "icon"), O(s, "class", "svelte-179qxd2"), O(n, "id", "wrapper"), O(n, "class", "svelte-179qxd2"), O(i, "href", "/feed/playlists"), O(i, "class", "yt-simple-endpoint style-scope ytd-guide-entry-renderer svelte-179qxd2"), O(i, "id", "endpoint"), O(t, "id", "sub2lists-menuitem"), O(t, "class", "title ytd-guide-entry-renderer");
    },
    m(p, f) {
      Ie(p, t, f), Y(t, i), Y(i, n), Y(n, s), Ct(r, s, null), Y(n, a), u = !0, c || (h = ti(i, "click", Nc(e[0])), c = !0);
    },
    p: ce,
    i(p) {
      u || (Ee(r.$$.fragment, p), u = !0);
    },
    o(p) {
      Re(r.$$.fragment, p), u = !1;
    },
    d(p) {
      p && ke(t), Tt(r), c = !1, h();
    }
  };
}
function UE(e) {
  function t(i) {
    e9.call(this, e, i);
  }
  return [t];
}
class YE extends Wt {
  constructor(t) {
    super(), Ht(this, t, UE, VE, Nt, {}, FE);
  }
}
function jE(e) {
  ln(e, "svelte-6pkl07", ".ytd-mini-guide-renderer.svelte-6pkl07{background-color:var(--yt-spec-brand-background-solid)}.ytd-mini-guide-renderer.svelte-6pkl07:hover{background-color:var(--yt-spec-badge-chip-background);outline:none}#wrapper.svelte-6pkl07{width:24px;height:24px;margin-bottom:6px}");
}
function HE(e) {
  let t, i, n, s, r, a, u, c;
  return s = new Dv({}), {
    c() {
      t = le("div"), i = le("a"), n = le("div"), Pt(s.$$.fragment), r = Xe(`
		Playlists`), O(n, "id", "wrapper"), O(n, "class", "svelte-6pkl07"), O(i, "id", "endpoint"), O(i, "class", "yt-simple-endpoint style-scope ytd-mini-guide-entry-renderer"), O(t, "id", "sub2lists-menuitem-mini"), O(t, "class", "style-scope ytd-mini-guide-renderer svelte-6pkl07");
    },
    m(h, p) {
      Ie(h, t, p), Y(t, i), Y(i, n), Ct(s, n, null), Y(i, r), a = !0, u || (c = ti(i, "click", Nc(e[0])), u = !0);
    },
    p: ce,
    i(h) {
      a || (Ee(s.$$.fragment, h), a = !0);
    },
    o(h) {
      Re(s.$$.fragment, h), a = !1;
    },
    d(h) {
      h && ke(t), Tt(s), u = !1, c();
    }
  };
}
function WE(e) {
  function t(i) {
    e9.call(this, e, i);
  }
  return [t];
}
class XE extends Wt {
  constructor(t) {
    super(), Ht(this, t, WE, HE, Nt, {}, jE);
  }
}
export {
  YE as MenuItem,
  XE as MenuItemMini,
  zE as Modal
};
