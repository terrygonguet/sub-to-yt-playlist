function Se() {
}
function ht(e, t) {
  for (const i in t)
    e[i] = t[i];
  return e;
}
function Uw(e) {
  return e && typeof e == "object" && typeof e.then == "function";
}
function U2(e) {
  return e();
}
function a5() {
  return /* @__PURE__ */ Object.create(null);
}
function pr(e) {
  e.forEach(U2);
}
function j2(e) {
  return typeof e == "function";
}
function Ot(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
let ga;
function l5(e, t) {
  return ga || (ga = document.createElement("a")), ga.href = t, e === ga.href;
}
function jw(e) {
  return Object.keys(e).length === 0;
}
function Hw(e, ...t) {
  if (e == null)
    return Se;
  const i = e.subscribe(...t);
  return i.unsubscribe ? () => i.unsubscribe() : i;
}
function V1(e, t, i) {
  e.$$.on_destroy.push(Hw(t, i));
}
function u5(e, t, i, n) {
  if (e) {
    const s = H2(e, t, i, n);
    return e[0](s);
  }
}
function H2(e, t, i, n) {
  return e[1] && n ? ht(i.ctx.slice(), e[1](n(t))) : i.ctx;
}
function c5(e, t, i, n) {
  if (e[2] && n) {
    const s = e[2](n(i));
    if (t.dirty === void 0)
      return s;
    if (typeof s == "object") {
      const r = [], a = Math.max(t.dirty.length, s.length);
      for (let u = 0; u < a; u += 1)
        r[u] = t.dirty[u] | s[u];
      return r;
    }
    return t.dirty | s;
  }
  return t.dirty;
}
function h5(e, t, i, n, s, r) {
  if (s) {
    const a = H2(t, i, n, r);
    e.p(a, s);
  }
}
function d5(e) {
  if (e.ctx.length > 32) {
    const t = [], i = e.ctx.length / 32;
    for (let n = 0; n < i; n++)
      t[n] = -1;
    return t;
  }
  return -1;
}
function Fi(e) {
  const t = {};
  for (const i in e)
    i[0] !== "$" && (t[i] = e[i]);
  return t;
}
function p5(e, t, i) {
  return e.set(i), t;
}
function me(e, t) {
  e.appendChild(t);
}
function ws(e, t, i) {
  const n = Ww(e);
  if (!n.getElementById(t)) {
    const s = Ee("style");
    s.id = t, s.textContent = i, $w(n, s);
  }
}
function Ww(e) {
  if (!e)
    return document;
  const t = e.getRootNode ? e.getRootNode() : e.ownerDocument;
  return t && t.host ? t : e.ownerDocument;
}
function $w(e, t) {
  return me(e.head || e, t), t.sheet;
}
function qe(e, t, i) {
  e.insertBefore(t, i || null);
}
function We(e) {
  e.parentNode.removeChild(e);
}
function Gw(e, t) {
  for (let i = 0; i < e.length; i += 1)
    e[i] && e[i].d(t);
}
function Ee(e) {
  return document.createElement(e);
}
function zo(e) {
  return document.createElementNS("http://www.w3.org/2000/svg", e);
}
function Dt(e) {
  return document.createTextNode(e);
}
function yi() {
  return Dt(" ");
}
function W2() {
  return Dt("");
}
function Vi(e, t, i, n) {
  return e.addEventListener(t, i, n), () => e.removeEventListener(t, i, n);
}
function xc(e) {
  return function(t) {
    return t.preventDefault(), e.call(this, t);
  };
}
function q(e, t, i) {
  i == null ? e.removeAttribute(t) : e.getAttribute(t) !== i && e.setAttribute(t, i);
}
function Ui(e, t) {
  for (const i in t)
    q(e, i, t[i]);
}
function qw(e) {
  return Array.from(e.childNodes);
}
function ir(e, t) {
  t = "" + t, e.wholeText !== t && (e.data = t);
}
function er(e, t, i) {
  e.classList[i ? "add" : "remove"](t);
}
function zw(e, t, { bubbles: i = !1, cancelable: n = !1 } = {}) {
  const s = document.createEvent("CustomEvent");
  return s.initCustomEvent(e, i, n, t), s;
}
let Bo;
function tn(e) {
  Bo = e;
}
function $2() {
  if (!Bo)
    throw new Error("Function called outside component initialization");
  return Bo;
}
function Kw() {
  const e = $2();
  return (t, i, { cancelable: n = !1 } = {}) => {
    const s = e.$$.callbacks[t];
    if (s) {
      const r = zw(t, i, { cancelable: n });
      return s.slice().forEach((a) => {
        a.call(e, r);
      }), !r.defaultPrevented;
    }
    return !0;
  };
}
function G2(e, t) {
  const i = e.$$.callbacks[t.type];
  i && i.slice().forEach((n) => n.call(this, t));
}
const Or = [], U1 = [], Fa = [], f5 = [], Yw = Promise.resolve();
let j1 = !1;
function Xw() {
  j1 || (j1 = !0, Yw.then(xt));
}
function H1(e) {
  Fa.push(e);
}
const Qu = /* @__PURE__ */ new Set();
let ya = 0;
function xt() {
  const e = Bo;
  do {
    for (; ya < Or.length; ) {
      const t = Or[ya];
      ya++, tn(t), Jw(t.$$);
    }
    for (tn(null), Or.length = 0, ya = 0; U1.length; )
      U1.pop()();
    for (let t = 0; t < Fa.length; t += 1) {
      const i = Fa[t];
      Qu.has(i) || (Qu.add(i), i());
    }
    Fa.length = 0;
  } while (Or.length);
  for (; f5.length; )
    f5.pop()();
  j1 = !1, Qu.clear(), tn(e);
}
function Jw(e) {
  if (e.fragment !== null) {
    e.update(), pr(e.before_update);
    const t = e.dirty;
    e.dirty = [-1], e.fragment && e.fragment.p(e.ctx, t), e.after_update.forEach(H1);
  }
}
const Va = /* @__PURE__ */ new Set();
let us;
function Oo() {
  us = {
    r: 0,
    c: [],
    p: us
  };
}
function Fo() {
  us.r || pr(us.c), us = us.p;
}
function Ve(e, t) {
  e && e.i && (Va.delete(e), e.i(t));
}
function Ke(e, t, i, n) {
  if (e && e.o) {
    if (Va.has(e))
      return;
    Va.add(e), us.c.push(() => {
      Va.delete(e), n && (i && e.d(1), n());
    }), e.o(t);
  } else
    n && n();
}
function m5(e, t) {
  const i = t.token = {};
  function n(s, r, a, u) {
    if (t.token !== i)
      return;
    t.resolved = u;
    let c = t.ctx;
    a !== void 0 && (c = c.slice(), c[a] = u);
    const h = s && (t.current = s)(c);
    let p = !1;
    t.block && (t.blocks ? t.blocks.forEach((m, b) => {
      b !== r && m && (Oo(), Ke(m, 1, 1, () => {
        t.blocks[b] === m && (t.blocks[b] = null);
      }), Fo());
    }) : t.block.d(1), h.c(), Ve(h, 1), h.m(t.mount(), t.anchor), p = !0), t.block = h, t.blocks && (t.blocks[r] = h), p && xt();
  }
  if (Uw(e)) {
    const s = $2();
    if (e.then((r) => {
      tn(s), n(t.then, 1, t.value, r), tn(null);
    }, (r) => {
      if (tn(s), n(t.catch, 2, t.error, r), tn(null), !t.hasCatch)
        throw r;
    }), t.current !== t.pending)
      return n(t.pending, 0), !0;
  } else {
    if (t.current !== t.then)
      return n(t.then, 1, t.value, e), !0;
    t.resolved = e;
  }
}
function Zw(e, t, i) {
  const n = t.slice(), { resolved: s } = e;
  e.current === e.then && (n[e.value] = s), e.current === e.catch && (n[e.error] = s), e.block.p(n, i);
}
function Qw(e, t) {
  Ke(e, 1, 1, () => {
    t.delete(e.key);
  });
}
function e3(e, t, i, n, s, r, a, u, c, h, p, m) {
  let b = e.length, C = r.length, k = b;
  const D = {};
  for (; k--; )
    D[e[k].key] = k;
  const I = [], $ = /* @__PURE__ */ new Map(), O = /* @__PURE__ */ new Map();
  for (k = C; k--; ) {
    const v = m(s, r, k), H = i(v);
    let ce = a.get(H);
    ce ? n && ce.p(v, t) : (ce = h(H, v), ce.c()), $.set(H, I[k] = ce), H in D && O.set(H, Math.abs(k - D[H]));
  }
  const F = /* @__PURE__ */ new Set(), K = /* @__PURE__ */ new Set();
  function M(v) {
    Ve(v, 1), v.m(u, p), a.set(v.key, v), p = v.first, C--;
  }
  for (; b && C; ) {
    const v = I[C - 1], H = e[b - 1], ce = v.key, ae = H.key;
    v === H ? (p = v.first, b--, C--) : $.has(ae) ? !a.has(ce) || F.has(ce) ? M(v) : K.has(ae) ? b-- : O.get(ce) > O.get(ae) ? (K.add(ce), M(v)) : (F.add(ae), b--) : (c(H, a), b--);
  }
  for (; b--; ) {
    const v = e[b];
    $.has(v.key) || c(v, a);
  }
  for (; C; )
    M(I[C - 1]);
  return I;
}
function Ss(e, t) {
  const i = {}, n = {}, s = { $$scope: 1 };
  let r = e.length;
  for (; r--; ) {
    const a = e[r], u = t[r];
    if (u) {
      for (const c in a)
        c in u || (n[c] = 1);
      for (const c in u)
        s[c] || (i[c] = u[c], s[c] = 1);
      e[r] = u;
    } else
      for (const c in a)
        s[c] = 1;
  }
  for (const a in n)
    a in i || (i[a] = void 0);
  return i;
}
function q2(e) {
  return typeof e == "object" && e !== null ? e : {};
}
function bi(e) {
  e && e.c();
}
function si(e, t, i, n) {
  const { fragment: s, on_mount: r, on_destroy: a, after_update: u } = e.$$;
  s && s.m(t, i), n || H1(() => {
    const c = r.map(U2).filter(j2);
    a ? a.push(...c) : pr(c), e.$$.on_mount = [];
  }), u.forEach(H1);
}
function ri(e, t) {
  const i = e.$$;
  i.fragment !== null && (pr(i.on_destroy), i.fragment && i.fragment.d(t), i.on_destroy = i.fragment = null, i.ctx = []);
}
function t3(e, t) {
  e.$$.dirty[0] === -1 && (Or.push(e), Xw(), e.$$.dirty.fill(0)), e.$$.dirty[t / 31 | 0] |= 1 << t % 31;
}
function Yt(e, t, i, n, s, r, a, u = [-1]) {
  const c = Bo;
  tn(e);
  const h = e.$$ = {
    fragment: null,
    ctx: null,
    props: r,
    update: Se,
    not_equal: s,
    bound: a5(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(t.context || (c ? c.$$.context : [])),
    callbacks: a5(),
    dirty: u,
    skip_bound: !1,
    root: t.target || c.$$.root
  };
  a && a(h.root);
  let p = !1;
  if (h.ctx = i ? i(e, t.props || {}, (m, b, ...C) => {
    const k = C.length ? C[0] : b;
    return h.ctx && s(h.ctx[m], h.ctx[m] = k) && (!h.skip_bound && h.bound[m] && h.bound[m](k), p && t3(e, m)), b;
  }) : [], h.update(), p = !0, pr(h.before_update), h.fragment = n ? n(h.ctx) : !1, t.target) {
    if (t.hydrate) {
      const m = qw(t.target);
      h.fragment && h.fragment.l(m), m.forEach(We);
    } else
      h.fragment && h.fragment.c();
    t.intro && Ve(e.$$.fragment), si(e, t.target, t.anchor, t.customElement), xt();
  }
  tn(c);
}
class Xt {
  $destroy() {
    ri(this, 1), this.$destroy = Se;
  }
  $on(t, i) {
    const n = this.$$.callbacks[t] || (this.$$.callbacks[t] = []);
    return n.push(i), () => {
      const s = n.indexOf(i);
      s !== -1 && n.splice(s, 1);
    };
  }
  $set(t) {
    this.$$set && !jw(t) && (this.$$.skip_bound = !0, this.$$set(t), this.$$.skip_bound = !1);
  }
}
var i3 = Object.create, Ko = Object.defineProperty, n3 = Object.defineProperties, s3 = Object.getOwnPropertyDescriptor, r3 = Object.getOwnPropertyDescriptors, z2 = Object.getOwnPropertyNames, v5 = Object.getOwnPropertySymbols, o3 = Object.getPrototypeOf, K2 = Object.prototype.hasOwnProperty, a3 = Object.prototype.propertyIsEnumerable, g5 = (e, t, i) => t in e ? Ko(e, t, { enumerable: !0, configurable: !0, writable: !0, value: i }) : e[t] = i, So = (e, t) => {
  for (var i in t || (t = {}))
    K2.call(t, i) && g5(e, i, t[i]);
  if (v5)
    for (var i of v5(t))
      a3.call(t, i) && g5(e, i, t[i]);
  return e;
}, y5 = (e, t) => n3(e, r3(t)), l = (e, t) => Ko(e, "name", { value: t, configurable: !0 }), Y2 = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, {
  get: (t, i) => (typeof require < "u" ? require : t)[i]
}) : e)(function(e) {
  if (typeof require < "u")
    return require.apply(this, arguments);
  throw new Error('Dynamic require of "' + e + '" is not supported');
}), X = (e, t) => function() {
  return t || (0, e[z2(e)[0]])((t = { exports: {} }).exports, t), t.exports;
}, Yo = (e, t) => {
  for (var i in t)
    Ko(e, i, { get: t[i], enumerable: !0 });
}, l3 = (e, t, i, n) => {
  if (t && typeof t == "object" || typeof t == "function")
    for (let s of z2(t))
      !K2.call(e, s) && s !== i && Ko(e, s, { get: () => t[s], enumerable: !(n = s3(t, s)) || n.enumerable });
  return e;
}, Wi = (e, t, i) => (i = e != null ? i3(o3(e)) : {}, l3(t || !e || !e.__esModule ? Ko(i, "default", { value: e, enumerable: !0 }) : i, e)), u3 = X({
  "node_modules/jintr/dist/src/nodes/ArrayExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return i.elements.map((s) => n.visitNode(s));
      }
    };
    l(t, "ArrayExpression"), e.default = t;
  }
}), c3 = X({
  "node_modules/jintr/dist/src/nodes/AssignmentExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator, r = n.visitNode(i.right);
        switch (s) {
          case "=":
            if (i.left.computed) {
              const a = n.visitNode(i.left.object), u = n.visitNode(i.left.property);
              return a[u] = r;
            }
            return n.scope.set(i.left.name, r), n.scope.get(i.left.name);
          case "+=":
            return n.scope.set(i.left.name, n.scope.get(i.left.name) + r), n.scope.get(i.left.name);
          case "-=":
            return n.scope.set(i.left.name, n.scope.get(i.left.name) - r), n.scope.get(i.left.name);
          default:
            console.warn("Operator not implemented:", s);
        }
      }
    };
    l(t, "AssignmentExpression"), e.default = t;
  }
}), h3 = X({
  "node_modules/jintr/dist/src/nodes/BinaryExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator, r = n.visitNode(i.left), a = n.visitNode(i.right);
        switch (s) {
          case "+":
            return r + a;
          case "-":
            return r - a;
          case "/":
            return r / a;
          case "%":
            return r % a;
          case "*":
            return r * a;
          case "==":
            return r == a;
          case "===":
            return r === a;
          case "!==":
            return r !== a;
          case "!=":
            return r != a;
          case ">":
            return r > a;
          case "<":
            return r < a;
          case "<<":
            return r << a;
          case ">>":
            return r >> a;
          case ">>>":
            return r >>> a;
          case ">=":
            return r >= a;
          case "<=":
            return r <= a;
          case "|":
            return r | a;
          case "&":
            return r & a;
          case "^":
            return r ^ a;
          case "in":
            return r in a;
          case "instanceof":
            return r instanceof a;
          default:
            console.warn("Unsupported binary operator: ", s);
        }
      }
    };
    l(t, "BinaryExpression"), e.default = t;
  }
}), d3 = X({
  "node_modules/jintr/dist/src/nodes/BlockStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (const s of i.body) {
          const r = n.visitNode(s);
          if (s.type === "ReturnStatement" || r === "break" || r === "continue" || (s.type === "WhileStatement" || s.type === "IfStatement" || s.type === "ForStatement" || s.type === "TryStatement") && !!r)
            return r;
        }
      }
    };
    l(t, "BlockStatement"), e.default = t;
  }
}), p3 = X({
  "node_modules/jintr/dist/src/nodes/BreakStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return "break";
      }
    };
    l(t, "BreakStatement"), e.default = t;
  }
}), f3 = X({
  "node_modules/jintr/dist/src/nodes/CallExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        var s, r;
        const a = (s = i.callee.object) === null || s === void 0 ? void 0 : s.name, u = i.callee.name || ((r = i.callee.property) === null || r === void 0 ? void 0 : r.name);
        if (n.listeners[a]) {
          const h = n.listeners[a](i, n);
          if (h !== "proceed")
            return h;
        }
        if (n.listeners[u]) {
          const h = n.listeners[u](i, n);
          if (h !== "proceed")
            return h;
        }
        switch (u) {
          case "print": {
            const h = i.arguments.map((p) => n.visitNode(p));
            console.log(...h);
            return;
          }
          case "push": {
            const h = i.arguments.map((m) => n.visitNode(m)), p = n.visitNode(i.callee.object);
            for (const m of h)
              p.push(m);
            return;
          }
          case "join": {
            const h = i.arguments.map((m) => n.visitNode(m));
            return n.visitNode(i.callee.object).join((h == null ? void 0 : h[0]) || "");
          }
          case "splice": {
            const h = i.arguments.map((m) => n.visitNode(m));
            return n.visitNode(i.callee.object).splice(...h);
          }
          case "reverse":
            return i.arguments.map((p) => n.visitNode(p)), n.visitNode(i.callee.object).reverse();
          case "unshift": {
            const h = i.arguments.map((m) => n.visitNode(m));
            return n.visitNode(i.callee.object).unshift(...h);
          }
          case "split": {
            const h = i.arguments.map((m) => n.visitNode(m));
            return n.visitNode(i.callee.object).split(...h);
          }
          case "indexOf": {
            const h = i.arguments.map((m) => n.visitNode(m));
            return n.visitNode(i.callee.object).indexOf(...h);
          }
          case "pop":
            return i.arguments.map((p) => n.visitNode(p)), n.visitNode(i.callee.object).pop();
          case "forEach": {
            const h = i.arguments.map((b) => n.visitNode(b)), p = n.visitNode(i.callee.object);
            h.length > 1 && n.scope.set("_this", h.slice(-1)[0]);
            let m = 0;
            for (const b of p)
              h[0]([b, m++, p]);
            return;
          }
        }
        const c = n.visitNode(i.callee);
        if (typeof c != "function")
          throw i.callee.object ? new Error(`${n.visitNode(i.callee.object)}.${n.visitNode(i.callee.property)}(...) is not a function`) : new Error(`${c} is not a function`);
        {
          const h = i.arguments.map((p) => n.visitNode(p));
          return c.toString().includes("[native code]") ? n.visitNode(i.callee.object)[i.callee.property.name]() : c(h);
        }
      }
    };
    l(t, "CallExpression"), e.default = t;
  }
}), m3 = X({
  "node_modules/jintr/dist/src/nodes/ConditionalExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const { test: s, consequent: r, alternate: a } = i;
        return s.operator, n.visitNode(s) ? n.visitNode(r) : n.visitNode(a);
      }
    };
    l(t, "ConditionalExpression"), e.default = t;
  }
}), v3 = X({
  "node_modules/jintr/dist/src/nodes/ContinueStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return "continue";
      }
    };
    l(t, "ContinueStatement"), e.default = t;
  }
}), g3 = X({
  "node_modules/jintr/dist/src/nodes/ExpressionStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.visitNode(i.expression);
      }
    };
    l(t, "ExpressionStatement"), e.default = t;
  }
}), y3 = X({
  "node_modules/jintr/dist/src/nodes/ForStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        i.init && n.visitNode(i.init);
        const s = /* @__PURE__ */ l(() => i.test ? n.visitNode(i.test) : !0, "test");
        for (; s(); ) {
          const a = n.visitNode(i.body);
          if (a !== "continue") {
            if (a === "break")
              break;
            if (i.update && n.visitNode(i.update), a && i.body.type !== "ExpressionStatement")
              return a;
          }
        }
      }
    };
    l(t, "ForStatement"), e.default = t;
  }
}), _3 = X({
  "node_modules/jintr/dist/src/nodes/FunctionDeclaration.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = /* @__PURE__ */ l((h, p) => Object.defineProperty(p, "name", { value: h }), "nameFunction"), { params: r, body: a } = i, u = n.visitNode(i.id), c = s(u, (h) => {
          for (let p = 0; p < r.length; p++)
            n.visitNode(r[p]), n.scope.set(r[p].name, h[p]);
          return n.visitNode(a);
        });
        n.scope.set(u, c);
      }
    };
    l(t, "FunctionDeclaration"), e.default = t;
  }
}), b3 = X({
  "node_modules/jintr/dist/src/nodes/FunctionExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = /* @__PURE__ */ l((c, h) => Object.defineProperty(h, "name", { value: c }), "nameFunction"), { params: r, body: a } = i;
        return s("anonymous function", (c) => {
          for (let h = 0; h < r.length; h++)
            n.visitNode(r[h]), n.scope.set(r[h].name, c[h]);
          return n.visitNode(a);
        });
      }
    };
    l(t, "FunctionExpression"), e.default = t;
  }
}), w3 = X({
  "node_modules/jintr/dist/src/nodes/Identifier.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        if (n.listeners[i.name]) {
          const s = n.listeners[i.name](i, n);
          if (s !== "proceed")
            return s;
        }
        return n.scope.has(i.name) ? n.scope.get(i.name) : i.name;
      }
    };
    l(t, "Identifier"), e.default = t;
  }
}), S3 = X({
  "node_modules/jintr/dist/src/nodes/IfStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        if (n.visitNode(i.test))
          return n.visitNode(i.consequent);
        if (i.alternate)
          return n.visitNode(i.alternate);
      }
    };
    l(t, "IfStatement"), e.default = t;
  }
}), C3 = X({
  "node_modules/jintr/dist/src/nodes/Literal.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return i.value;
      }
    };
    l(t, "Literal"), e.default = t;
  }
}), T3 = X({
  "node_modules/jintr/dist/src/nodes/LogicalExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (s) {
          case "&&": {
            const r = n.visitNode(i.left);
            return r === !0 ? n.visitNode(i.right) : r;
          }
          case "||":
            return n.visitNode(i.left) || n.visitNode(i.right);
          default:
            throw Error(`Unsupported logical operator: ${s}`);
        }
      }
    };
    l(t, "LogicalExpression"), e.default = t;
  }
}), x3 = X({
  "node_modules/jintr/dist/src/nodes/MemberExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const { object: s, property: r, computed: a } = i, u = n.visitNode(s), c = a ? n.visitNode(r) : r.name;
        if (c === "length")
          return u.length;
        if (n.listeners[c]) {
          const h = n.listeners[c](i, n);
          if (h !== "proceed")
            return h;
        }
        return u == null ? void 0 : u[c];
      }
    };
    l(t, "MemberExpression"), e.default = t;
  }
}), E3 = X({
  "node_modules/jintr/dist/src/nodes/NewExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = n.visitNode(i.callee), r = i.arguments.map((a) => n.visitNode(a));
        return new s(r);
      }
    };
    l(t, "NewExpression"), e.default = t;
  }
}), A3 = X({
  "node_modules/jintr/dist/src/nodes/ObjectExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = {};
        for (const r of i.properties) {
          const a = n.visitNode(r.key), u = n.visitNode(r.value);
          s[a] = u;
        }
        return s;
      }
    };
    l(t, "ObjectExpression"), e.default = t;
  }
}), k3 = X({
  "node_modules/jintr/dist/src/nodes/ReturnStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.visitNode(i.argument);
      }
    };
    l(t, "ReturnStatement"), e.default = t;
  }
}), I3 = X({
  "node_modules/jintr/dist/src/nodes/SequenceExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        let s;
        for (const r of i.expressions)
          s = n.visitNode(r);
        return s;
      }
    };
    l(t, "SequenceExpression"), e.default = t;
  }
}), P3 = X({
  "node_modules/jintr/dist/src/nodes/SwitchCase.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (const s of i.consequent) {
          const r = n.visitNode(s);
          if (s.type === "ContinueStatement")
            return r;
          if (s.type === "BreakStatement")
            return r;
        }
      }
    };
    l(t, "SwitchCase"), e.default = t;
  }
}), M3 = X({
  "node_modules/jintr/dist/src/nodes/SwitchStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = n.visitNode(i.discriminant);
        let r = !1, a = -1, u = 0;
        for (; ; ) {
          const c = i.cases[u];
          if (r) {
            const h = n.visitNode(c);
            if (h === "break")
              break;
            if (h === "continue")
              return h;
            if (++u, u >= i.cases.length) {
              u = 0;
              break;
            } else
              continue;
          }
          if (r = c && s === n.visitNode(c.test), r === void 0 && u > i.cases.length)
            break;
          if (c && !r && !c.test) {
            a = u, u += 1;
            continue;
          }
          if (!c && !r && a !== -1) {
            r = !0, u = a;
            continue;
          }
          r || ++u;
        }
      }
    };
    l(t, "SwitchStatement"), e.default = t;
  }
}), N3 = X({
  "node_modules/jintr/dist/src/nodes/ThisExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        return n.scope.get("_this");
      }
    };
    l(t, "ThisExpression"), e.default = t;
  }
}), R3 = X({
  "node_modules/jintr/dist/src/nodes/ThrowStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        throw n.visitNode(i.argument);
      }
    };
    l(t, "ThrowStatement"), e.default = t;
  }
}), L3 = X({
  "node_modules/jintr/dist/src/nodes/TryStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        try {
          return n.visitNode(i.block);
        } catch (s) {
          return n.scope.set(i.handler.param.name, s), n.visitNode(i.handler.body);
        } finally {
          n.visitNode(i.finalizer);
        }
      }
    };
    l(t, "TryStatement"), e.default = t;
  }
}), D3 = X({
  "node_modules/jintr/dist/src/nodes/UnaryExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (s) {
          case "-":
            return -n.visitNode(i.argument);
          case "void": {
            n.visitNode(i.argument);
            return;
          }
          case "typeof":
            return typeof n.visitNode(i.argument);
          default:
            console.warn("Unsupported unary operator: ", s);
        }
      }
    };
    l(t, "UnaryExpression"), e.default = t;
  }
}), B3 = X({
  "node_modules/jintr/dist/src/nodes/UpdateExpression.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        const s = i.operator;
        switch (n.visitNode(i.argument), s) {
          case "++": {
            if (i.argument.object) {
              const a = n.visitNode(i.argument.object);
              return a[n.visitNode(i.argument.property)]++;
            }
            let r = n.visitNode(i.argument);
            return n.scope.set(i.argument.name, r + 1), i.prefix ? ++r : r;
          }
          case "--": {
            if (i.argument.object) {
              const a = n.visitNode(i.argument.object);
              return a[n.visitNode(i.argument.property)]--;
            }
            let r = n.visitNode(i.argument);
            return n.scope.set(i.argument.name, r - 1), i.prefix ? --r : r;
          }
          default:
            console.warn("Unsupported operator: ", s);
        }
      }
    };
    l(t, "UpdateExpression"), e.default = t;
  }
}), O3 = X({
  "node_modules/jintr/dist/src/nodes/VariableDeclaration.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        i.declarations.forEach((s) => {
          const { id: r, init: a } = s, u = r.name, c = a ? n.visitNode(a) : void 0;
          n.scope.set(u, c);
        });
      }
    };
    l(t, "VariableDeclaration"), e.default = t;
  }
}), F3 = X({
  "node_modules/jintr/dist/src/nodes/WhileStatement.js"(e) {
    Object.defineProperty(e, "__esModule", { value: !0 });
    var t = class {
      static visit(i, n) {
        for (; n.visitNode(i.test); ) {
          const s = n.visitNode(i.body);
          if (s === "break")
            break;
          if (s !== "continue" && s)
            return s;
        }
      }
    };
    l(t, "WhileStatement"), e.default = t;
  }
}), V3 = X({
  "node_modules/jintr/dist/src/map.js"(e) {
    var t = e && e.__importDefault || function(De) {
      return De && De.__esModule ? De : { default: De };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(u3()), n = t(c3()), s = t(h3()), r = t(d3()), a = t(p3()), u = t(f3()), c = t(m3()), h = t(v3()), p = t(g3()), m = t(y3()), b = t(_3()), C = t(b3()), k = t(w3()), D = t(S3()), I = t(C3()), $ = t(T3()), O = t(x3()), F = t(E3()), K = t(A3()), M = t(k3()), v = t(I3()), H = t(P3()), ce = t(M3()), ae = t(N3()), Q = t(R3()), Xe = t(L3()), J = t(D3()), ee = t(B3()), ve = t(O3()), Je = t(F3()), Ce = {
      ArrayExpression: i.default,
      AssignmentExpression: n.default,
      BinaryExpression: s.default,
      BlockStatement: r.default,
      BreakStatement: a.default,
      CallExpression: u.default,
      ConditionalExpression: c.default,
      ContinueStatement: h.default,
      ExpressionStatement: p.default,
      ForStatement: m.default,
      FunctionDeclaration: b.default,
      FunctionExpression: C.default,
      Identifier: k.default,
      IfStatement: D.default,
      Literal: I.default,
      LogicalExpression: $.default,
      MemberExpression: O.default,
      NewExpression: F.default,
      ObjectExpression: K.default,
      ReturnStatement: M.default,
      SequenceExpression: v.default,
      SwitchCase: H.default,
      SwitchStatement: ce.default,
      ThisExpression: ae.default,
      ThrowStatement: Q.default,
      TryStatement: Xe.default,
      UnaryExpression: J.default,
      UpdateExpression: ee.default,
      VariableDeclaration: ve.default,
      WhileStatement: Je.default
    };
    function nt(De) {
      const he = Ce[De];
      if (!he) {
        const wt = new Error(`Module not found: ${De}`);
        throw wt.code = "MODULE_NOT_FOUND", wt;
      }
      return he;
    }
    l(nt, "getNode"), e.default = nt;
  }
}), U3 = X({
  "node_modules/jintr/dist/src/visitor.js"(e) {
    var t = e && e.__importDefault || function(s) {
      return s && s.__esModule ? s : { default: s };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(V3()), n = class {
      constructor(s) {
        this.scope = /* @__PURE__ */ new Map(), this.listeners = {}, this.ast = s;
      }
      run() {
        let s;
        for (const r of this.ast)
          s = this.visitNode(r);
        return s;
      }
      visitNode(s) {
        if (!s)
          return null;
        try {
          return (0, i.default)(s.type).visit(s, this);
        } catch (r) {
          if (r.code === "MODULE_NOT_FOUND")
            console.warn("Node not implemented:", s);
          else
            throw r;
        }
      }
      on(s, r) {
        this.listeners[s] = r;
      }
    };
    l(n, "Visitor"), e.default = n;
  }
}), j3 = X({
  "node_modules/acorn/dist/acorn.js"(e, t) {
    (function(i, n) {
      typeof e == "object" && typeof t < "u" ? n(e) : typeof define == "function" && define.amd ? define(["exports"], n) : (i = typeof globalThis < "u" ? globalThis : i || self, n(i.acorn = {}));
    })(e, function(i) {
      var n = [509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 574, 3, 9, 9, 370, 1, 154, 10, 50, 3, 123, 2, 54, 14, 32, 10, 3, 1, 11, 3, 46, 10, 8, 0, 46, 9, 7, 2, 37, 13, 2, 9, 6, 1, 45, 0, 13, 2, 49, 13, 9, 3, 2, 11, 83, 11, 7, 0, 161, 11, 6, 9, 7, 3, 56, 1, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 193, 17, 10, 9, 5, 0, 82, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 84, 14, 5, 9, 243, 14, 166, 9, 71, 5, 2, 1, 3, 3, 2, 0, 2, 1, 13, 9, 120, 6, 3, 6, 4, 0, 29, 9, 41, 6, 2, 3, 9, 0, 10, 10, 47, 15, 406, 7, 2, 7, 17, 9, 57, 21, 2, 13, 123, 5, 4, 0, 2, 1, 2, 6, 2, 0, 9, 9, 49, 4, 2, 1, 2, 4, 9, 9, 330, 3, 19306, 9, 87, 9, 39, 4, 60, 6, 26, 9, 1014, 0, 2, 54, 8, 3, 82, 0, 12, 1, 19628, 1, 4706, 45, 3, 22, 543, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 262, 6, 10, 9, 357, 0, 62, 13, 1495, 6, 110, 6, 6, 9, 4759, 9, 787719, 239], s = [0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 14, 29, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 13, 10, 2, 14, 2, 6, 2, 1, 2, 10, 2, 14, 2, 6, 2, 1, 68, 310, 10, 21, 11, 7, 25, 5, 2, 41, 2, 8, 70, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 28, 43, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 14, 35, 349, 41, 7, 1, 79, 28, 11, 0, 9, 21, 43, 17, 47, 20, 28, 22, 13, 52, 58, 1, 3, 0, 14, 44, 33, 24, 27, 35, 30, 0, 3, 0, 9, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 85, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 159, 52, 19, 3, 21, 2, 31, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 14, 0, 72, 26, 38, 6, 186, 43, 117, 63, 32, 7, 3, 0, 3, 7, 2, 1, 2, 23, 16, 0, 2, 0, 95, 7, 3, 38, 17, 0, 2, 0, 29, 0, 11, 39, 8, 0, 22, 0, 12, 45, 20, 0, 19, 72, 264, 8, 2, 36, 18, 0, 50, 29, 113, 6, 2, 1, 2, 37, 22, 0, 26, 5, 2, 1, 2, 31, 15, 0, 328, 18, 190, 0, 80, 921, 103, 110, 18, 195, 2637, 96, 16, 1070, 4050, 582, 8634, 568, 8, 30, 18, 78, 18, 29, 19, 47, 17, 3, 32, 20, 6, 18, 689, 63, 129, 74, 6, 0, 67, 12, 65, 1, 2, 0, 29, 6135, 9, 1237, 43, 8, 8936, 3, 2, 6, 2, 1, 2, 290, 46, 2, 18, 3, 9, 395, 2309, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 1845, 30, 482, 44, 11, 6, 17, 0, 322, 29, 19, 43, 1269, 6, 2, 3, 2, 1, 2, 14, 2, 196, 60, 67, 8, 0, 1205, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42719, 33, 4152, 8, 221, 3, 5761, 15, 7472, 3104, 541, 1507, 4938], r = "\u200C\u200D\xB7\u0300-\u036F\u0387\u0483-\u0487\u0591-\u05BD\u05BF\u05C1\u05C2\u05C4\u05C5\u05C7\u0610-\u061A\u064B-\u0669\u0670\u06D6-\u06DC\u06DF-\u06E4\u06E7\u06E8\u06EA-\u06ED\u06F0-\u06F9\u0711\u0730-\u074A\u07A6-\u07B0\u07C0-\u07C9\u07EB-\u07F3\u07FD\u0816-\u0819\u081B-\u0823\u0825-\u0827\u0829-\u082D\u0859-\u085B\u0898-\u089F\u08CA-\u08E1\u08E3-\u0903\u093A-\u093C\u093E-\u094F\u0951-\u0957\u0962\u0963\u0966-\u096F\u0981-\u0983\u09BC\u09BE-\u09C4\u09C7\u09C8\u09CB-\u09CD\u09D7\u09E2\u09E3\u09E6-\u09EF\u09FE\u0A01-\u0A03\u0A3C\u0A3E-\u0A42\u0A47\u0A48\u0A4B-\u0A4D\u0A51\u0A66-\u0A71\u0A75\u0A81-\u0A83\u0ABC\u0ABE-\u0AC5\u0AC7-\u0AC9\u0ACB-\u0ACD\u0AE2\u0AE3\u0AE6-\u0AEF\u0AFA-\u0AFF\u0B01-\u0B03\u0B3C\u0B3E-\u0B44\u0B47\u0B48\u0B4B-\u0B4D\u0B55-\u0B57\u0B62\u0B63\u0B66-\u0B6F\u0B82\u0BBE-\u0BC2\u0BC6-\u0BC8\u0BCA-\u0BCD\u0BD7\u0BE6-\u0BEF\u0C00-\u0C04\u0C3C\u0C3E-\u0C44\u0C46-\u0C48\u0C4A-\u0C4D\u0C55\u0C56\u0C62\u0C63\u0C66-\u0C6F\u0C81-\u0C83\u0CBC\u0CBE-\u0CC4\u0CC6-\u0CC8\u0CCA-\u0CCD\u0CD5\u0CD6\u0CE2\u0CE3\u0CE6-\u0CEF\u0D00-\u0D03\u0D3B\u0D3C\u0D3E-\u0D44\u0D46-\u0D48\u0D4A-\u0D4D\u0D57\u0D62\u0D63\u0D66-\u0D6F\u0D81-\u0D83\u0DCA\u0DCF-\u0DD4\u0DD6\u0DD8-\u0DDF\u0DE6-\u0DEF\u0DF2\u0DF3\u0E31\u0E34-\u0E3A\u0E47-\u0E4E\u0E50-\u0E59\u0EB1\u0EB4-\u0EBC\u0EC8-\u0ECD\u0ED0-\u0ED9\u0F18\u0F19\u0F20-\u0F29\u0F35\u0F37\u0F39\u0F3E\u0F3F\u0F71-\u0F84\u0F86\u0F87\u0F8D-\u0F97\u0F99-\u0FBC\u0FC6\u102B-\u103E\u1040-\u1049\u1056-\u1059\u105E-\u1060\u1062-\u1064\u1067-\u106D\u1071-\u1074\u1082-\u108D\u108F-\u109D\u135D-\u135F\u1369-\u1371\u1712-\u1715\u1732-\u1734\u1752\u1753\u1772\u1773\u17B4-\u17D3\u17DD\u17E0-\u17E9\u180B-\u180D\u180F-\u1819\u18A9\u1920-\u192B\u1930-\u193B\u1946-\u194F\u19D0-\u19DA\u1A17-\u1A1B\u1A55-\u1A5E\u1A60-\u1A7C\u1A7F-\u1A89\u1A90-\u1A99\u1AB0-\u1ABD\u1ABF-\u1ACE\u1B00-\u1B04\u1B34-\u1B44\u1B50-\u1B59\u1B6B-\u1B73\u1B80-\u1B82\u1BA1-\u1BAD\u1BB0-\u1BB9\u1BE6-\u1BF3\u1C24-\u1C37\u1C40-\u1C49\u1C50-\u1C59\u1CD0-\u1CD2\u1CD4-\u1CE8\u1CED\u1CF4\u1CF7-\u1CF9\u1DC0-\u1DFF\u203F\u2040\u2054\u20D0-\u20DC\u20E1\u20E5-\u20F0\u2CEF-\u2CF1\u2D7F\u2DE0-\u2DFF\u302A-\u302F\u3099\u309A\uA620-\uA629\uA66F\uA674-\uA67D\uA69E\uA69F\uA6F0\uA6F1\uA802\uA806\uA80B\uA823-\uA827\uA82C\uA880\uA881\uA8B4-\uA8C5\uA8D0-\uA8D9\uA8E0-\uA8F1\uA8FF-\uA909\uA926-\uA92D\uA947-\uA953\uA980-\uA983\uA9B3-\uA9C0\uA9D0-\uA9D9\uA9E5\uA9F0-\uA9F9\uAA29-\uAA36\uAA43\uAA4C\uAA4D\uAA50-\uAA59\uAA7B-\uAA7D\uAAB0\uAAB2-\uAAB4\uAAB7\uAAB8\uAABE\uAABF\uAAC1\uAAEB-\uAAEF\uAAF5\uAAF6\uABE3-\uABEA\uABEC\uABED\uABF0-\uABF9\uFB1E\uFE00-\uFE0F\uFE20-\uFE2F\uFE33\uFE34\uFE4D-\uFE4F\uFF10-\uFF19\uFF3F", a = "\xAA\xB5\xBA\xC0-\xD6\xD8-\xF6\xF8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377\u037A-\u037D\u037F\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5\u03F7-\u0481\u048A-\u052F\u0531-\u0556\u0559\u0560-\u0588\u05D0-\u05EA\u05EF-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u0860-\u086A\u0870-\u0887\u0889-\u088E\u08A0-\u08C9\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u09FC\u0A05-\u0A0A\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0AF9\u0B05-\u0B0C\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C39\u0C3D\u0C58-\u0C5A\u0C5D\u0C60\u0C61\u0C80\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3\u0CB5-\u0CB9\u0CBD\u0CDD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D04-\u0D0C\u0D0E-\u0D10\u0D12-\u0D3A\u0D3D\u0D4E\u0D54-\u0D56\u0D5F-\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81\u0E82\u0E84\u0E86-\u0E8A\u0E8C-\u0EA3\u0EA5\u0EA7-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F5\u13F8-\u13FD\u1401-\u166C\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u16EE-\u16F8\u1700-\u1711\u171F-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7\u17DC\u1820-\u1878\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191E\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19B0-\u19C9\u1A00-\u1A16\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4C\u1B83-\u1BA0\u1BAE\u1BAF\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1C80-\u1C88\u1C90-\u1CBA\u1CBD-\u1CBF\u1CE9-\u1CEC\u1CEE-\u1CF3\u1CF5\u1CF6\u1CFA\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2118-\u211D\u2124\u2126\u2128\u212A-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2160-\u2188\u2C00-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE\u2DD0-\u2DD6\u2DD8-\u2DDE\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303C\u3041-\u3096\u309B-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312F\u3131-\u318E\u31A0-\u31BF\u31F0-\u31FF\u3400-\u4DBF\u4E00-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B\uA640-\uA66E\uA67F-\uA69D\uA6A0-\uA6EF\uA717-\uA71F\uA722-\uA788\uA78B-\uA7CA\uA7D0\uA7D1\uA7D3\uA7D5-\uA7D9\uA7F2-\uA801\uA803-\uA805\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB\uA8FD\uA8FE\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uA9E0-\uA9E4\uA9E6-\uA9EF\uA9FA-\uA9FE\uAA00-\uAA28\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA7E-\uAAAF\uAAB1\uAAB5\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E\uAB30-\uAB5A\uAB5C-\uAB69\uAB70-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF\uFFD2-\uFFD7\uFFDA-\uFFDC", u = {
        3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
        5: "class enum extends super const export import",
        6: "enum",
        strict: "implements interface let package private protected public static yield",
        strictBind: "eval arguments"
      }, c = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this", h = {
        5: c,
        "5module": c + " export import",
        6: c + " const class extends export import super"
      }, p = /^in(stanceof)?$/, m = new RegExp("[" + a + "]"), b = new RegExp("[" + a + r + "]");
      function C(o, d) {
        for (var f = 65536, g = 0; g < d.length; g += 2) {
          if (f += d[g], f > o)
            return !1;
          if (f += d[g + 1], f >= o)
            return !0;
        }
      }
      l(C, "isInAstralSet");
      function k(o, d) {
        return o < 65 ? o === 36 : o < 91 ? !0 : o < 97 ? o === 95 : o < 123 ? !0 : o <= 65535 ? o >= 170 && m.test(String.fromCharCode(o)) : d === !1 ? !1 : C(o, s);
      }
      l(k, "isIdentifierStart");
      function D(o, d) {
        return o < 48 ? o === 36 : o < 58 ? !0 : o < 65 ? !1 : o < 91 ? !0 : o < 97 ? o === 95 : o < 123 ? !0 : o <= 65535 ? o >= 170 && b.test(String.fromCharCode(o)) : d === !1 ? !1 : C(o, s) || C(o, n);
      }
      l(D, "isIdentifierChar");
      var I = /* @__PURE__ */ l(function(d, f) {
        f === void 0 && (f = {}), this.label = d, this.keyword = f.keyword, this.beforeExpr = !!f.beforeExpr, this.startsExpr = !!f.startsExpr, this.isLoop = !!f.isLoop, this.isAssign = !!f.isAssign, this.prefix = !!f.prefix, this.postfix = !!f.postfix, this.binop = f.binop || null, this.updateContext = null;
      }, "TokenType");
      function $(o, d) {
        return new I(o, { beforeExpr: !0, binop: d });
      }
      l($, "binop");
      var O = { beforeExpr: !0 }, F = { startsExpr: !0 }, K = {};
      function M(o, d) {
        return d === void 0 && (d = {}), d.keyword = o, K[o] = new I(o, d);
      }
      l(M, "kw");
      var v = {
        num: new I("num", F),
        regexp: new I("regexp", F),
        string: new I("string", F),
        name: new I("name", F),
        privateId: new I("privateId", F),
        eof: new I("eof"),
        bracketL: new I("[", { beforeExpr: !0, startsExpr: !0 }),
        bracketR: new I("]"),
        braceL: new I("{", { beforeExpr: !0, startsExpr: !0 }),
        braceR: new I("}"),
        parenL: new I("(", { beforeExpr: !0, startsExpr: !0 }),
        parenR: new I(")"),
        comma: new I(",", O),
        semi: new I(";", O),
        colon: new I(":", O),
        dot: new I("."),
        question: new I("?", O),
        questionDot: new I("?."),
        arrow: new I("=>", O),
        template: new I("template"),
        invalidTemplate: new I("invalidTemplate"),
        ellipsis: new I("...", O),
        backQuote: new I("`", F),
        dollarBraceL: new I("${", { beforeExpr: !0, startsExpr: !0 }),
        eq: new I("=", { beforeExpr: !0, isAssign: !0 }),
        assign: new I("_=", { beforeExpr: !0, isAssign: !0 }),
        incDec: new I("++/--", { prefix: !0, postfix: !0, startsExpr: !0 }),
        prefix: new I("!/~", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        logicalOR: $("||", 1),
        logicalAND: $("&&", 2),
        bitwiseOR: $("|", 3),
        bitwiseXOR: $("^", 4),
        bitwiseAND: $("&", 5),
        equality: $("==/!=/===/!==", 6),
        relational: $("</>/<=/>=", 7),
        bitShift: $("<</>>/>>>", 8),
        plusMin: new I("+/-", { beforeExpr: !0, binop: 9, prefix: !0, startsExpr: !0 }),
        modulo: $("%", 10),
        star: $("*", 10),
        slash: $("/", 10),
        starstar: new I("**", { beforeExpr: !0 }),
        coalesce: $("??", 1),
        _break: M("break"),
        _case: M("case", O),
        _catch: M("catch"),
        _continue: M("continue"),
        _debugger: M("debugger"),
        _default: M("default", O),
        _do: M("do", { isLoop: !0, beforeExpr: !0 }),
        _else: M("else", O),
        _finally: M("finally"),
        _for: M("for", { isLoop: !0 }),
        _function: M("function", F),
        _if: M("if"),
        _return: M("return", O),
        _switch: M("switch"),
        _throw: M("throw", O),
        _try: M("try"),
        _var: M("var"),
        _const: M("const"),
        _while: M("while", { isLoop: !0 }),
        _with: M("with"),
        _new: M("new", { beforeExpr: !0, startsExpr: !0 }),
        _this: M("this", F),
        _super: M("super", F),
        _class: M("class", F),
        _extends: M("extends", O),
        _export: M("export"),
        _import: M("import", F),
        _null: M("null", F),
        _true: M("true", F),
        _false: M("false", F),
        _in: M("in", { beforeExpr: !0, binop: 7 }),
        _instanceof: M("instanceof", { beforeExpr: !0, binop: 7 }),
        _typeof: M("typeof", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _void: M("void", { beforeExpr: !0, prefix: !0, startsExpr: !0 }),
        _delete: M("delete", { beforeExpr: !0, prefix: !0, startsExpr: !0 })
      }, H = /\r\n?|\n|\u2028|\u2029/, ce = new RegExp(H.source, "g");
      function ae(o) {
        return o === 10 || o === 13 || o === 8232 || o === 8233;
      }
      l(ae, "isNewLine");
      function Q(o, d, f) {
        f === void 0 && (f = o.length);
        for (var g = d; g < f; g++) {
          var S = o.charCodeAt(g);
          if (ae(S))
            return g < f - 1 && S === 13 && o.charCodeAt(g + 1) === 10 ? g + 2 : g + 1;
        }
        return -1;
      }
      l(Q, "nextLineBreak");
      var Xe = /[\u1680\u2000-\u200a\u202f\u205f\u3000\ufeff]/, J = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g, ee = Object.prototype, ve = ee.hasOwnProperty, Je = ee.toString, Ce = Object.hasOwn || function(o, d) {
        return ve.call(o, d);
      }, nt = Array.isArray || function(o) {
        return Je.call(o) === "[object Array]";
      };
      function De(o) {
        return new RegExp("^(?:" + o.replace(/ /g, "|") + ")$");
      }
      l(De, "wordsRegexp");
      function he(o) {
        return o <= 65535 ? String.fromCharCode(o) : (o -= 65536, String.fromCharCode((o >> 10) + 55296, (o & 1023) + 56320));
      }
      l(he, "codePointToString");
      var wt = /(?:[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF])/, Ut = /* @__PURE__ */ l(function(d, f) {
        this.line = d, this.column = f;
      }, "Position");
      Ut.prototype.offset = /* @__PURE__ */ l(function(d) {
        return new Ut(this.line, this.column + d);
      }, "offset");
      var ai = /* @__PURE__ */ l(function(d, f, g) {
        this.start = f, this.end = g, d.sourceFile !== null && (this.source = d.sourceFile);
      }, "SourceLocation");
      function ln(o, d) {
        for (var f = 1, g = 0; ; ) {
          var S = Q(o, g, d);
          if (S < 0)
            return new Ut(f, d - g);
          ++f, g = S;
        }
      }
      l(ln, "getLineInfo");
      var kt = {
        ecmaVersion: null,
        sourceType: "script",
        onInsertedSemicolon: null,
        onTrailingComma: null,
        allowReserved: null,
        allowReturnOutsideFunction: !1,
        allowImportExportEverywhere: !1,
        allowAwaitOutsideFunction: null,
        allowSuperOutsideMethod: null,
        allowHashBang: !1,
        locations: !1,
        onToken: null,
        onComment: null,
        ranges: !1,
        program: null,
        sourceFile: null,
        directSourceFile: null,
        preserveParens: !1
      }, Es = !1;
      function Av(o) {
        var d = {};
        for (var f in kt)
          d[f] = o && Ce(o, f) ? o[f] : kt[f];
        if (d.ecmaVersion === "latest" ? d.ecmaVersion = 1e8 : d.ecmaVersion == null ? (!Es && typeof console == "object" && console.warn && (Es = !0, console.warn(`Since Acorn 8.0.0, options.ecmaVersion is required.
Defaulting to 2020, but this will stop working in the future.`)), d.ecmaVersion = 11) : d.ecmaVersion >= 2015 && (d.ecmaVersion -= 2009), d.allowReserved == null && (d.allowReserved = d.ecmaVersion < 5), o.allowHashBang == null && (d.allowHashBang = d.ecmaVersion >= 14), nt(d.onToken)) {
          var g = d.onToken;
          d.onToken = function(S) {
            return g.push(S);
          };
        }
        return nt(d.onComment) && (d.onComment = kv(d, d.onComment)), d;
      }
      l(Av, "getOptions");
      function kv(o, d) {
        return function(f, g, S, T, A, B) {
          var V = {
            type: f ? "Block" : "Line",
            value: g,
            start: S,
            end: T
          };
          o.locations && (V.loc = new ai(this, A, B)), o.ranges && (V.range = [S, T]), d.push(V);
        };
      }
      l(kv, "pushComment");
      var wr = 1, As = 2, Ou = 4, Iv = 8, Pv = 16, Mv = 32, Fu = 64, Nv = 128, Sr = 256, Vu = wr | As | Sr;
      function ha(o, d) {
        return As | (o ? Ou : 0) | (d ? Iv : 0);
      }
      l(ha, "functionFlags");
      var da = 0, Uu = 1, $i = 2, Rv = 3, Lv = 4, Dv = 5, Ye = /* @__PURE__ */ l(function(d, f, g) {
        this.options = d = Av(d), this.sourceFile = d.sourceFile, this.keywords = De(h[d.ecmaVersion >= 6 ? 6 : d.sourceType === "module" ? "5module" : 5]);
        var S = "";
        d.allowReserved !== !0 && (S = u[d.ecmaVersion >= 6 ? 6 : d.ecmaVersion === 5 ? 5 : 3], d.sourceType === "module" && (S += " await")), this.reservedWords = De(S);
        var T = (S ? S + " " : "") + u.strict;
        this.reservedWordsStrict = De(T), this.reservedWordsStrictBind = De(T + " " + u.strictBind), this.input = String(f), this.containsEsc = !1, g ? (this.pos = g, this.lineStart = this.input.lastIndexOf(`
`, g - 1) + 1, this.curLine = this.input.slice(0, this.lineStart).split(H).length) : (this.pos = this.lineStart = 0, this.curLine = 1), this.type = v.eof, this.value = null, this.start = this.end = this.pos, this.startLoc = this.endLoc = this.curPosition(), this.lastTokEndLoc = this.lastTokStartLoc = null, this.lastTokStart = this.lastTokEnd = this.pos, this.context = this.initialContext(), this.exprAllowed = !0, this.inModule = d.sourceType === "module", this.strict = this.inModule || this.strictDirective(this.pos), this.potentialArrowAt = -1, this.potentialArrowInForAwait = !1, this.yieldPos = this.awaitPos = this.awaitIdentPos = 0, this.labels = [], this.undefinedExports = /* @__PURE__ */ Object.create(null), this.pos === 0 && d.allowHashBang && this.input.slice(0, 2) === "#!" && this.skipLineComment(2), this.scopeStack = [], this.enterScope(wr), this.regexpState = null, this.privateNameStack = [];
      }, "Parser"), wi = { inFunction: { configurable: !0 }, inGenerator: { configurable: !0 }, inAsync: { configurable: !0 }, canAwait: { configurable: !0 }, allowSuper: { configurable: !0 }, allowDirectSuper: { configurable: !0 }, treatFunctionsAsVar: { configurable: !0 }, allowNewDotTarget: { configurable: !0 }, inClassStaticBlock: { configurable: !0 } };
      Ye.prototype.parse = /* @__PURE__ */ l(function() {
        var d = this.options.program || this.startNode();
        return this.nextToken(), this.parseTopLevel(d);
      }, "parse"), wi.inFunction.get = function() {
        return (this.currentVarScope().flags & As) > 0;
      }, wi.inGenerator.get = function() {
        return (this.currentVarScope().flags & Iv) > 0 && !this.currentVarScope().inClassFieldInit;
      }, wi.inAsync.get = function() {
        return (this.currentVarScope().flags & Ou) > 0 && !this.currentVarScope().inClassFieldInit;
      }, wi.canAwait.get = function() {
        for (var o = this.scopeStack.length - 1; o >= 0; o--) {
          var d = this.scopeStack[o];
          if (d.inClassFieldInit || d.flags & Sr)
            return !1;
          if (d.flags & As)
            return (d.flags & Ou) > 0;
        }
        return this.inModule && this.options.ecmaVersion >= 13 || this.options.allowAwaitOutsideFunction;
      }, wi.allowSuper.get = function() {
        var o = this.currentThisScope(), d = o.flags, f = o.inClassFieldInit;
        return (d & Fu) > 0 || f || this.options.allowSuperOutsideMethod;
      }, wi.allowDirectSuper.get = function() {
        return (this.currentThisScope().flags & Nv) > 0;
      }, wi.treatFunctionsAsVar.get = function() {
        return this.treatFunctionsAsVarInScope(this.currentScope());
      }, wi.allowNewDotTarget.get = function() {
        var o = this.currentThisScope(), d = o.flags, f = o.inClassFieldInit;
        return (d & (As | Sr)) > 0 || f;
      }, wi.inClassStaticBlock.get = function() {
        return (this.currentVarScope().flags & Sr) > 0;
      }, Ye.extend = /* @__PURE__ */ l(function() {
        for (var d = [], f = arguments.length; f--; )
          d[f] = arguments[f];
        for (var g = this, S = 0; S < d.length; S++)
          g = d[S](g);
        return g;
      }, "extend"), Ye.parse = /* @__PURE__ */ l(function(d, f) {
        return new this(f, d).parse();
      }, "parse"), Ye.parseExpressionAt = /* @__PURE__ */ l(function(d, f, g) {
        var S = new this(g, d, f);
        return S.nextToken(), S.parseExpression();
      }, "parseExpressionAt"), Ye.tokenizer = /* @__PURE__ */ l(function(d, f) {
        return new this(f, d);
      }, "tokenizer"), Object.defineProperties(Ye.prototype, wi);
      var St = Ye.prototype, Pw = /^(?:'((?:\\.|[^'\\])*?)'|"((?:\\.|[^"\\])*?)")/;
      St.strictDirective = function(o) {
        if (this.options.ecmaVersion < 5)
          return !1;
        for (; ; ) {
          J.lastIndex = o, o += J.exec(this.input)[0].length;
          var d = Pw.exec(this.input.slice(o));
          if (!d)
            return !1;
          if ((d[1] || d[2]) === "use strict") {
            J.lastIndex = o + d[0].length;
            var f = J.exec(this.input), g = f.index + f[0].length, S = this.input.charAt(g);
            return S === ";" || S === "}" || H.test(f[0]) && !(/[(`.[+\-/*%<>=,?^&]/.test(S) || S === "!" && this.input.charAt(g + 1) === "=");
          }
          o += d[0].length, J.lastIndex = o, o += J.exec(this.input)[0].length, this.input[o] === ";" && o++;
        }
      }, St.eat = function(o) {
        return this.type === o ? (this.next(), !0) : !1;
      }, St.isContextual = function(o) {
        return this.type === v.name && this.value === o && !this.containsEsc;
      }, St.eatContextual = function(o) {
        return this.isContextual(o) ? (this.next(), !0) : !1;
      }, St.expectContextual = function(o) {
        this.eatContextual(o) || this.unexpected();
      }, St.canInsertSemicolon = function() {
        return this.type === v.eof || this.type === v.braceR || H.test(this.input.slice(this.lastTokEnd, this.start));
      }, St.insertSemicolon = function() {
        if (this.canInsertSemicolon())
          return this.options.onInsertedSemicolon && this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc), !0;
      }, St.semicolon = function() {
        !this.eat(v.semi) && !this.insertSemicolon() && this.unexpected();
      }, St.afterTrailingComma = function(o, d) {
        if (this.type === o)
          return this.options.onTrailingComma && this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc), d || this.next(), !0;
      }, St.expect = function(o) {
        this.eat(o) || this.unexpected();
      }, St.unexpected = function(o) {
        this.raise(o != null ? o : this.start, "Unexpected token");
      };
      var pa = /* @__PURE__ */ l(function() {
        this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = this.doubleProto = -1;
      }, "DestructuringErrors");
      St.checkPatternErrors = function(o, d) {
        if (!!o) {
          o.trailingComma > -1 && this.raiseRecoverable(o.trailingComma, "Comma is not permitted after the rest element");
          var f = d ? o.parenthesizedAssign : o.parenthesizedBind;
          f > -1 && this.raiseRecoverable(f, d ? "Assigning to rvalue" : "Parenthesized pattern");
        }
      }, St.checkExpressionErrors = function(o, d) {
        if (!o)
          return !1;
        var f = o.shorthandAssign, g = o.doubleProto;
        if (!d)
          return f >= 0 || g >= 0;
        f >= 0 && this.raise(f, "Shorthand property assignments are valid only in destructuring patterns"), g >= 0 && this.raiseRecoverable(g, "Redefinition of __proto__ property");
      }, St.checkYieldAwaitInDefaultParams = function() {
        this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos) && this.raise(this.yieldPos, "Yield expression cannot be a default value"), this.awaitPos && this.raise(this.awaitPos, "Await expression cannot be a default value");
      }, St.isSimpleAssignTarget = function(o) {
        return o.type === "ParenthesizedExpression" ? this.isSimpleAssignTarget(o.expression) : o.type === "Identifier" || o.type === "MemberExpression";
      };
      var te = Ye.prototype;
      te.parseTopLevel = function(o) {
        var d = /* @__PURE__ */ Object.create(null);
        for (o.body || (o.body = []); this.type !== v.eof; ) {
          var f = this.parseStatement(null, !0, d);
          o.body.push(f);
        }
        if (this.inModule)
          for (var g = 0, S = Object.keys(this.undefinedExports); g < S.length; g += 1) {
            var T = S[g];
            this.raiseRecoverable(this.undefinedExports[T].start, "Export '" + T + "' is not defined");
          }
        return this.adaptDirectivePrologue(o.body), this.next(), o.sourceType = this.options.sourceType, this.finishNode(o, "Program");
      };
      var ju = { kind: "loop" }, Mw = { kind: "switch" };
      te.isLet = function(o) {
        if (this.options.ecmaVersion < 6 || !this.isContextual("let"))
          return !1;
        J.lastIndex = this.pos;
        var d = J.exec(this.input), f = this.pos + d[0].length, g = this.input.charCodeAt(f);
        if (g === 91 || g === 92 || g > 55295 && g < 56320)
          return !0;
        if (o)
          return !1;
        if (g === 123)
          return !0;
        if (k(g, !0)) {
          for (var S = f + 1; D(g = this.input.charCodeAt(S), !0); )
            ++S;
          if (g === 92 || g > 55295 && g < 56320)
            return !0;
          var T = this.input.slice(f, S);
          if (!p.test(T))
            return !0;
        }
        return !1;
      }, te.isAsyncFunction = function() {
        if (this.options.ecmaVersion < 8 || !this.isContextual("async"))
          return !1;
        J.lastIndex = this.pos;
        var o = J.exec(this.input), d = this.pos + o[0].length, f;
        return !H.test(this.input.slice(this.pos, d)) && this.input.slice(d, d + 8) === "function" && (d + 8 === this.input.length || !(D(f = this.input.charCodeAt(d + 8)) || f > 55295 && f < 56320));
      }, te.parseStatement = function(o, d, f) {
        var g = this.type, S = this.startNode(), T;
        switch (this.isLet(o) && (g = v._var, T = "let"), g) {
          case v._break:
          case v._continue:
            return this.parseBreakContinueStatement(S, g.keyword);
          case v._debugger:
            return this.parseDebuggerStatement(S);
          case v._do:
            return this.parseDoStatement(S);
          case v._for:
            return this.parseForStatement(S);
          case v._function:
            return o && (this.strict || o !== "if" && o !== "label") && this.options.ecmaVersion >= 6 && this.unexpected(), this.parseFunctionStatement(S, !1, !o);
          case v._class:
            return o && this.unexpected(), this.parseClass(S, !0);
          case v._if:
            return this.parseIfStatement(S);
          case v._return:
            return this.parseReturnStatement(S);
          case v._switch:
            return this.parseSwitchStatement(S);
          case v._throw:
            return this.parseThrowStatement(S);
          case v._try:
            return this.parseTryStatement(S);
          case v._const:
          case v._var:
            return T = T || this.value, o && T !== "var" && this.unexpected(), this.parseVarStatement(S, T);
          case v._while:
            return this.parseWhileStatement(S);
          case v._with:
            return this.parseWithStatement(S);
          case v.braceL:
            return this.parseBlock(!0, S);
          case v.semi:
            return this.parseEmptyStatement(S);
          case v._export:
          case v._import:
            if (this.options.ecmaVersion > 10 && g === v._import) {
              J.lastIndex = this.pos;
              var A = J.exec(this.input), B = this.pos + A[0].length, V = this.input.charCodeAt(B);
              if (V === 40 || V === 46)
                return this.parseExpressionStatement(S, this.parseExpression());
            }
            return this.options.allowImportExportEverywhere || (d || this.raise(this.start, "'import' and 'export' may only appear at the top level"), this.inModule || this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'")), g === v._import ? this.parseImport(S) : this.parseExport(S, f);
          default:
            if (this.isAsyncFunction())
              return o && this.unexpected(), this.next(), this.parseFunctionStatement(S, !0, !o);
            var ue = this.value, ge = this.parseExpression();
            return g === v.name && ge.type === "Identifier" && this.eat(v.colon) ? this.parseLabeledStatement(S, ue, ge, o) : this.parseExpressionStatement(S, ge);
        }
      }, te.parseBreakContinueStatement = function(o, d) {
        var f = d === "break";
        this.next(), this.eat(v.semi) || this.insertSemicolon() ? o.label = null : this.type !== v.name ? this.unexpected() : (o.label = this.parseIdent(), this.semicolon());
        for (var g = 0; g < this.labels.length; ++g) {
          var S = this.labels[g];
          if ((o.label == null || S.name === o.label.name) && (S.kind != null && (f || S.kind === "loop") || o.label && f))
            break;
        }
        return g === this.labels.length && this.raise(o.start, "Unsyntactic " + d), this.finishNode(o, f ? "BreakStatement" : "ContinueStatement");
      }, te.parseDebuggerStatement = function(o) {
        return this.next(), this.semicolon(), this.finishNode(o, "DebuggerStatement");
      }, te.parseDoStatement = function(o) {
        return this.next(), this.labels.push(ju), o.body = this.parseStatement("do"), this.labels.pop(), this.expect(v._while), o.test = this.parseParenExpression(), this.options.ecmaVersion >= 6 ? this.eat(v.semi) : this.semicolon(), this.finishNode(o, "DoWhileStatement");
      }, te.parseForStatement = function(o) {
        this.next();
        var d = this.options.ecmaVersion >= 9 && this.canAwait && this.eatContextual("await") ? this.lastTokStart : -1;
        if (this.labels.push(ju), this.enterScope(0), this.expect(v.parenL), this.type === v.semi)
          return d > -1 && this.unexpected(d), this.parseFor(o, null);
        var f = this.isLet();
        if (this.type === v._var || this.type === v._const || f) {
          var g = this.startNode(), S = f ? "let" : this.value;
          return this.next(), this.parseVar(g, !0, S), this.finishNode(g, "VariableDeclaration"), (this.type === v._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) && g.declarations.length === 1 ? (this.options.ecmaVersion >= 9 && (this.type === v._in ? d > -1 && this.unexpected(d) : o.await = d > -1), this.parseForIn(o, g)) : (d > -1 && this.unexpected(d), this.parseFor(o, g));
        }
        var T = this.isContextual("let"), A = !1, B = new pa(), V = this.parseExpression(d > -1 ? "await" : !0, B);
        return this.type === v._in || (A = this.options.ecmaVersion >= 6 && this.isContextual("of")) ? (this.options.ecmaVersion >= 9 && (this.type === v._in ? d > -1 && this.unexpected(d) : o.await = d > -1), T && A && this.raise(V.start, "The left-hand side of a for-of loop may not start with 'let'."), this.toAssignable(V, !1, B), this.checkLValPattern(V), this.parseForIn(o, V)) : (this.checkExpressionErrors(B, !0), d > -1 && this.unexpected(d), this.parseFor(o, V));
      }, te.parseFunctionStatement = function(o, d, f) {
        return this.next(), this.parseFunction(o, Cr | (f ? 0 : Hu), !1, d);
      }, te.parseIfStatement = function(o) {
        return this.next(), o.test = this.parseParenExpression(), o.consequent = this.parseStatement("if"), o.alternate = this.eat(v._else) ? this.parseStatement("if") : null, this.finishNode(o, "IfStatement");
      }, te.parseReturnStatement = function(o) {
        return !this.inFunction && !this.options.allowReturnOutsideFunction && this.raise(this.start, "'return' outside of function"), this.next(), this.eat(v.semi) || this.insertSemicolon() ? o.argument = null : (o.argument = this.parseExpression(), this.semicolon()), this.finishNode(o, "ReturnStatement");
      }, te.parseSwitchStatement = function(o) {
        this.next(), o.discriminant = this.parseParenExpression(), o.cases = [], this.expect(v.braceL), this.labels.push(Mw), this.enterScope(0);
        for (var d, f = !1; this.type !== v.braceR; )
          if (this.type === v._case || this.type === v._default) {
            var g = this.type === v._case;
            d && this.finishNode(d, "SwitchCase"), o.cases.push(d = this.startNode()), d.consequent = [], this.next(), g ? d.test = this.parseExpression() : (f && this.raiseRecoverable(this.lastTokStart, "Multiple default clauses"), f = !0, d.test = null), this.expect(v.colon);
          } else
            d || this.unexpected(), d.consequent.push(this.parseStatement(null));
        return this.exitScope(), d && this.finishNode(d, "SwitchCase"), this.next(), this.labels.pop(), this.finishNode(o, "SwitchStatement");
      }, te.parseThrowStatement = function(o) {
        return this.next(), H.test(this.input.slice(this.lastTokEnd, this.start)) && this.raise(this.lastTokEnd, "Illegal newline after throw"), o.argument = this.parseExpression(), this.semicolon(), this.finishNode(o, "ThrowStatement");
      };
      var Nw = [];
      te.parseTryStatement = function(o) {
        if (this.next(), o.block = this.parseBlock(), o.handler = null, this.type === v._catch) {
          var d = this.startNode();
          if (this.next(), this.eat(v.parenL)) {
            d.param = this.parseBindingAtom();
            var f = d.param.type === "Identifier";
            this.enterScope(f ? Mv : 0), this.checkLValPattern(d.param, f ? Lv : $i), this.expect(v.parenR);
          } else
            this.options.ecmaVersion < 10 && this.unexpected(), d.param = null, this.enterScope(0);
          d.body = this.parseBlock(!1), this.exitScope(), o.handler = this.finishNode(d, "CatchClause");
        }
        return o.finalizer = this.eat(v._finally) ? this.parseBlock() : null, !o.handler && !o.finalizer && this.raise(o.start, "Missing catch or finally clause"), this.finishNode(o, "TryStatement");
      }, te.parseVarStatement = function(o, d) {
        return this.next(), this.parseVar(o, !1, d), this.semicolon(), this.finishNode(o, "VariableDeclaration");
      }, te.parseWhileStatement = function(o) {
        return this.next(), o.test = this.parseParenExpression(), this.labels.push(ju), o.body = this.parseStatement("while"), this.labels.pop(), this.finishNode(o, "WhileStatement");
      }, te.parseWithStatement = function(o) {
        return this.strict && this.raise(this.start, "'with' in strict mode"), this.next(), o.object = this.parseParenExpression(), o.body = this.parseStatement("with"), this.finishNode(o, "WithStatement");
      }, te.parseEmptyStatement = function(o) {
        return this.next(), this.finishNode(o, "EmptyStatement");
      }, te.parseLabeledStatement = function(o, d, f, g) {
        for (var S = 0, T = this.labels; S < T.length; S += 1) {
          var A = T[S];
          A.name === d && this.raise(f.start, "Label '" + d + "' is already declared");
        }
        for (var B = this.type.isLoop ? "loop" : this.type === v._switch ? "switch" : null, V = this.labels.length - 1; V >= 0; V--) {
          var ue = this.labels[V];
          if (ue.statementStart === o.start)
            ue.statementStart = this.start, ue.kind = B;
          else
            break;
        }
        return this.labels.push({ name: d, kind: B, statementStart: this.start }), o.body = this.parseStatement(g ? g.indexOf("label") === -1 ? g + "label" : g : "label"), this.labels.pop(), o.label = f, this.finishNode(o, "LabeledStatement");
      }, te.parseExpressionStatement = function(o, d) {
        return o.expression = d, this.semicolon(), this.finishNode(o, "ExpressionStatement");
      }, te.parseBlock = function(o, d, f) {
        for (o === void 0 && (o = !0), d === void 0 && (d = this.startNode()), d.body = [], this.expect(v.braceL), o && this.enterScope(0); this.type !== v.braceR; ) {
          var g = this.parseStatement(null);
          d.body.push(g);
        }
        return f && (this.strict = !1), this.next(), o && this.exitScope(), this.finishNode(d, "BlockStatement");
      }, te.parseFor = function(o, d) {
        return o.init = d, this.expect(v.semi), o.test = this.type === v.semi ? null : this.parseExpression(), this.expect(v.semi), o.update = this.type === v.parenR ? null : this.parseExpression(), this.expect(v.parenR), o.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(o, "ForStatement");
      }, te.parseForIn = function(o, d) {
        var f = this.type === v._in;
        return this.next(), d.type === "VariableDeclaration" && d.declarations[0].init != null && (!f || this.options.ecmaVersion < 8 || this.strict || d.kind !== "var" || d.declarations[0].id.type !== "Identifier") && this.raise(d.start, (f ? "for-in" : "for-of") + " loop variable declaration may not have an initializer"), o.left = d, o.right = f ? this.parseExpression() : this.parseMaybeAssign(), this.expect(v.parenR), o.body = this.parseStatement("for"), this.exitScope(), this.labels.pop(), this.finishNode(o, f ? "ForInStatement" : "ForOfStatement");
      }, te.parseVar = function(o, d, f) {
        for (o.declarations = [], o.kind = f; ; ) {
          var g = this.startNode();
          if (this.parseVarId(g, f), this.eat(v.eq) ? g.init = this.parseMaybeAssign(d) : f === "const" && !(this.type === v._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) ? this.unexpected() : g.id.type !== "Identifier" && !(d && (this.type === v._in || this.isContextual("of"))) ? this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value") : g.init = null, o.declarations.push(this.finishNode(g, "VariableDeclarator")), !this.eat(v.comma))
            break;
        }
        return o;
      }, te.parseVarId = function(o, d) {
        o.id = this.parseBindingAtom(), this.checkLValPattern(o.id, d === "var" ? Uu : $i, !1);
      };
      var Cr = 1, Hu = 2, Bv = 4;
      te.parseFunction = function(o, d, f, g, S) {
        this.initFunction(o), (this.options.ecmaVersion >= 9 || this.options.ecmaVersion >= 6 && !g) && (this.type === v.star && d & Hu && this.unexpected(), o.generator = this.eat(v.star)), this.options.ecmaVersion >= 8 && (o.async = !!g), d & Cr && (o.id = d & Bv && this.type !== v.name ? null : this.parseIdent(), o.id && !(d & Hu) && this.checkLValSimple(o.id, this.strict || o.generator || o.async ? this.treatFunctionsAsVar ? Uu : $i : Rv));
        var T = this.yieldPos, A = this.awaitPos, B = this.awaitIdentPos;
        return this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(ha(o.async, o.generator)), d & Cr || (o.id = this.type === v.name ? this.parseIdent() : null), this.parseFunctionParams(o), this.parseFunctionBody(o, f, !1, S), this.yieldPos = T, this.awaitPos = A, this.awaitIdentPos = B, this.finishNode(o, d & Cr ? "FunctionDeclaration" : "FunctionExpression");
      }, te.parseFunctionParams = function(o) {
        this.expect(v.parenL), o.params = this.parseBindingList(v.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams();
      }, te.parseClass = function(o, d) {
        this.next();
        var f = this.strict;
        this.strict = !0, this.parseClassId(o, d), this.parseClassSuper(o);
        var g = this.enterClassBody(), S = this.startNode(), T = !1;
        for (S.body = [], this.expect(v.braceL); this.type !== v.braceR; ) {
          var A = this.parseClassElement(o.superClass !== null);
          A && (S.body.push(A), A.type === "MethodDefinition" && A.kind === "constructor" ? (T && this.raise(A.start, "Duplicate constructor in the same class"), T = !0) : A.key && A.key.type === "PrivateIdentifier" && Ov(g, A) && this.raiseRecoverable(A.key.start, "Identifier '#" + A.key.name + "' has already been declared"));
        }
        return this.strict = f, this.next(), o.body = this.finishNode(S, "ClassBody"), this.exitClassBody(), this.finishNode(o, d ? "ClassDeclaration" : "ClassExpression");
      }, te.parseClassElement = function(o) {
        if (this.eat(v.semi))
          return null;
        var d = this.options.ecmaVersion, f = this.startNode(), g = "", S = !1, T = !1, A = "method", B = !1;
        if (this.eatContextual("static")) {
          if (d >= 13 && this.eat(v.braceL))
            return this.parseClassStaticBlock(f), f;
          this.isClassElementNameStart() || this.type === v.star ? B = !0 : g = "static";
        }
        if (f.static = B, !g && d >= 8 && this.eatContextual("async") && ((this.isClassElementNameStart() || this.type === v.star) && !this.canInsertSemicolon() ? T = !0 : g = "async"), !g && (d >= 9 || !T) && this.eat(v.star) && (S = !0), !g && !T && !S) {
          var V = this.value;
          (this.eatContextual("get") || this.eatContextual("set")) && (this.isClassElementNameStart() ? A = V : g = V);
        }
        if (g ? (f.computed = !1, f.key = this.startNodeAt(this.lastTokStart, this.lastTokStartLoc), f.key.name = g, this.finishNode(f.key, "Identifier")) : this.parseClassElementName(f), d < 13 || this.type === v.parenL || A !== "method" || S || T) {
          var ue = !f.static && Tr(f, "constructor"), ge = ue && o;
          ue && A !== "method" && this.raise(f.key.start, "Constructor can't have get/set modifier"), f.kind = ue ? "constructor" : A, this.parseClassMethod(f, S, T, ge);
        } else
          this.parseClassField(f);
        return f;
      }, te.isClassElementNameStart = function() {
        return this.type === v.name || this.type === v.privateId || this.type === v.num || this.type === v.string || this.type === v.bracketL || this.type.keyword;
      }, te.parseClassElementName = function(o) {
        this.type === v.privateId ? (this.value === "constructor" && this.raise(this.start, "Classes can't have an element named '#constructor'"), o.computed = !1, o.key = this.parsePrivateIdent()) : this.parsePropertyName(o);
      }, te.parseClassMethod = function(o, d, f, g) {
        var S = o.key;
        o.kind === "constructor" ? (d && this.raise(S.start, "Constructor can't be a generator"), f && this.raise(S.start, "Constructor can't be an async method")) : o.static && Tr(o, "prototype") && this.raise(S.start, "Classes may not have a static property named prototype");
        var T = o.value = this.parseMethod(d, f, g);
        return o.kind === "get" && T.params.length !== 0 && this.raiseRecoverable(T.start, "getter should have no params"), o.kind === "set" && T.params.length !== 1 && this.raiseRecoverable(T.start, "setter should have exactly one param"), o.kind === "set" && T.params[0].type === "RestElement" && this.raiseRecoverable(T.params[0].start, "Setter cannot use rest params"), this.finishNode(o, "MethodDefinition");
      }, te.parseClassField = function(o) {
        if (Tr(o, "constructor") ? this.raise(o.key.start, "Classes can't have a field named 'constructor'") : o.static && Tr(o, "prototype") && this.raise(o.key.start, "Classes can't have a static field named 'prototype'"), this.eat(v.eq)) {
          var d = this.currentThisScope(), f = d.inClassFieldInit;
          d.inClassFieldInit = !0, o.value = this.parseMaybeAssign(), d.inClassFieldInit = f;
        } else
          o.value = null;
        return this.semicolon(), this.finishNode(o, "PropertyDefinition");
      }, te.parseClassStaticBlock = function(o) {
        o.body = [];
        var d = this.labels;
        for (this.labels = [], this.enterScope(Sr | Fu); this.type !== v.braceR; ) {
          var f = this.parseStatement(null);
          o.body.push(f);
        }
        return this.next(), this.exitScope(), this.labels = d, this.finishNode(o, "StaticBlock");
      }, te.parseClassId = function(o, d) {
        this.type === v.name ? (o.id = this.parseIdent(), d && this.checkLValSimple(o.id, $i, !1)) : (d === !0 && this.unexpected(), o.id = null);
      }, te.parseClassSuper = function(o) {
        o.superClass = this.eat(v._extends) ? this.parseExprSubscripts(!1) : null;
      }, te.enterClassBody = function() {
        var o = { declared: /* @__PURE__ */ Object.create(null), used: [] };
        return this.privateNameStack.push(o), o.declared;
      }, te.exitClassBody = function() {
        for (var o = this.privateNameStack.pop(), d = o.declared, f = o.used, g = this.privateNameStack.length, S = g === 0 ? null : this.privateNameStack[g - 1], T = 0; T < f.length; ++T) {
          var A = f[T];
          Ce(d, A.name) || (S ? S.used.push(A) : this.raiseRecoverable(A.start, "Private field '#" + A.name + "' must be declared in an enclosing class"));
        }
      };
      function Ov(o, d) {
        var f = d.key.name, g = o[f], S = "true";
        return d.type === "MethodDefinition" && (d.kind === "get" || d.kind === "set") && (S = (d.static ? "s" : "i") + d.kind), g === "iget" && S === "iset" || g === "iset" && S === "iget" || g === "sget" && S === "sset" || g === "sset" && S === "sget" ? (o[f] = "true", !1) : g ? !0 : (o[f] = S, !1);
      }
      l(Ov, "isPrivateNameConflicted");
      function Tr(o, d) {
        var f = o.computed, g = o.key;
        return !f && (g.type === "Identifier" && g.name === d || g.type === "Literal" && g.value === d);
      }
      l(Tr, "checkKeyName"), te.parseExport = function(o, d) {
        if (this.next(), this.eat(v.star))
          return this.options.ecmaVersion >= 11 && (this.eatContextual("as") ? (o.exported = this.parseModuleExportName(), this.checkExport(d, o.exported, this.lastTokStart)) : o.exported = null), this.expectContextual("from"), this.type !== v.string && this.unexpected(), o.source = this.parseExprAtom(), this.semicolon(), this.finishNode(o, "ExportAllDeclaration");
        if (this.eat(v._default)) {
          this.checkExport(d, "default", this.lastTokStart);
          var f;
          if (this.type === v._function || (f = this.isAsyncFunction())) {
            var g = this.startNode();
            this.next(), f && this.next(), o.declaration = this.parseFunction(g, Cr | Bv, !1, f);
          } else if (this.type === v._class) {
            var S = this.startNode();
            o.declaration = this.parseClass(S, "nullableID");
          } else
            o.declaration = this.parseMaybeAssign(), this.semicolon();
          return this.finishNode(o, "ExportDefaultDeclaration");
        }
        if (this.shouldParseExportStatement())
          o.declaration = this.parseStatement(null), o.declaration.type === "VariableDeclaration" ? this.checkVariableExport(d, o.declaration.declarations) : this.checkExport(d, o.declaration.id, o.declaration.id.start), o.specifiers = [], o.source = null;
        else {
          if (o.declaration = null, o.specifiers = this.parseExportSpecifiers(d), this.eatContextual("from"))
            this.type !== v.string && this.unexpected(), o.source = this.parseExprAtom();
          else {
            for (var T = 0, A = o.specifiers; T < A.length; T += 1) {
              var B = A[T];
              this.checkUnreserved(B.local), this.checkLocalExport(B.local), B.local.type === "Literal" && this.raise(B.local.start, "A string literal cannot be used as an exported binding without `from`.");
            }
            o.source = null;
          }
          this.semicolon();
        }
        return this.finishNode(o, "ExportNamedDeclaration");
      }, te.checkExport = function(o, d, f) {
        !o || (typeof d != "string" && (d = d.type === "Identifier" ? d.name : d.value), Ce(o, d) && this.raiseRecoverable(f, "Duplicate export '" + d + "'"), o[d] = !0);
      }, te.checkPatternExport = function(o, d) {
        var f = d.type;
        if (f === "Identifier")
          this.checkExport(o, d, d.start);
        else if (f === "ObjectPattern")
          for (var g = 0, S = d.properties; g < S.length; g += 1) {
            var T = S[g];
            this.checkPatternExport(o, T);
          }
        else if (f === "ArrayPattern")
          for (var A = 0, B = d.elements; A < B.length; A += 1) {
            var V = B[A];
            V && this.checkPatternExport(o, V);
          }
        else
          f === "Property" ? this.checkPatternExport(o, d.value) : f === "AssignmentPattern" ? this.checkPatternExport(o, d.left) : f === "RestElement" ? this.checkPatternExport(o, d.argument) : f === "ParenthesizedExpression" && this.checkPatternExport(o, d.expression);
      }, te.checkVariableExport = function(o, d) {
        if (!!o)
          for (var f = 0, g = d; f < g.length; f += 1) {
            var S = g[f];
            this.checkPatternExport(o, S.id);
          }
      }, te.shouldParseExportStatement = function() {
        return this.type.keyword === "var" || this.type.keyword === "const" || this.type.keyword === "class" || this.type.keyword === "function" || this.isLet() || this.isAsyncFunction();
      }, te.parseExportSpecifiers = function(o) {
        var d = [], f = !0;
        for (this.expect(v.braceL); !this.eat(v.braceR); ) {
          if (f)
            f = !1;
          else if (this.expect(v.comma), this.afterTrailingComma(v.braceR))
            break;
          var g = this.startNode();
          g.local = this.parseModuleExportName(), g.exported = this.eatContextual("as") ? this.parseModuleExportName() : g.local, this.checkExport(o, g.exported, g.exported.start), d.push(this.finishNode(g, "ExportSpecifier"));
        }
        return d;
      }, te.parseImport = function(o) {
        return this.next(), this.type === v.string ? (o.specifiers = Nw, o.source = this.parseExprAtom()) : (o.specifiers = this.parseImportSpecifiers(), this.expectContextual("from"), o.source = this.type === v.string ? this.parseExprAtom() : this.unexpected()), this.semicolon(), this.finishNode(o, "ImportDeclaration");
      }, te.parseImportSpecifiers = function() {
        var o = [], d = !0;
        if (this.type === v.name) {
          var f = this.startNode();
          if (f.local = this.parseIdent(), this.checkLValSimple(f.local, $i), o.push(this.finishNode(f, "ImportDefaultSpecifier")), !this.eat(v.comma))
            return o;
        }
        if (this.type === v.star) {
          var g = this.startNode();
          return this.next(), this.expectContextual("as"), g.local = this.parseIdent(), this.checkLValSimple(g.local, $i), o.push(this.finishNode(g, "ImportNamespaceSpecifier")), o;
        }
        for (this.expect(v.braceL); !this.eat(v.braceR); ) {
          if (d)
            d = !1;
          else if (this.expect(v.comma), this.afterTrailingComma(v.braceR))
            break;
          var S = this.startNode();
          S.imported = this.parseModuleExportName(), this.eatContextual("as") ? S.local = this.parseIdent() : (this.checkUnreserved(S.imported), S.local = S.imported), this.checkLValSimple(S.local, $i), o.push(this.finishNode(S, "ImportSpecifier"));
        }
        return o;
      }, te.parseModuleExportName = function() {
        if (this.options.ecmaVersion >= 13 && this.type === v.string) {
          var o = this.parseLiteral(this.value);
          return wt.test(o.value) && this.raise(o.start, "An export name cannot include a lone surrogate."), o;
        }
        return this.parseIdent(!0);
      }, te.adaptDirectivePrologue = function(o) {
        for (var d = 0; d < o.length && this.isDirectiveCandidate(o[d]); ++d)
          o[d].directive = o[d].expression.raw.slice(1, -1);
      }, te.isDirectiveCandidate = function(o) {
        return this.options.ecmaVersion >= 5 && o.type === "ExpressionStatement" && o.expression.type === "Literal" && typeof o.expression.value == "string" && (this.input[o.start] === '"' || this.input[o.start] === "'");
      };
      var li = Ye.prototype;
      li.toAssignable = function(o, d, f) {
        if (this.options.ecmaVersion >= 6 && o)
          switch (o.type) {
            case "Identifier":
              this.inAsync && o.name === "await" && this.raise(o.start, "Cannot use 'await' as identifier inside an async function");
              break;
            case "ObjectPattern":
            case "ArrayPattern":
            case "AssignmentPattern":
            case "RestElement":
              break;
            case "ObjectExpression":
              o.type = "ObjectPattern", f && this.checkPatternErrors(f, !0);
              for (var g = 0, S = o.properties; g < S.length; g += 1) {
                var T = S[g];
                this.toAssignable(T, d), T.type === "RestElement" && (T.argument.type === "ArrayPattern" || T.argument.type === "ObjectPattern") && this.raise(T.argument.start, "Unexpected token");
              }
              break;
            case "Property":
              o.kind !== "init" && this.raise(o.key.start, "Object pattern can't contain getter or setter"), this.toAssignable(o.value, d);
              break;
            case "ArrayExpression":
              o.type = "ArrayPattern", f && this.checkPatternErrors(f, !0), this.toAssignableList(o.elements, d);
              break;
            case "SpreadElement":
              o.type = "RestElement", this.toAssignable(o.argument, d), o.argument.type === "AssignmentPattern" && this.raise(o.argument.start, "Rest elements cannot have a default value");
              break;
            case "AssignmentExpression":
              o.operator !== "=" && this.raise(o.left.end, "Only '=' operator can be used for specifying default value."), o.type = "AssignmentPattern", delete o.operator, this.toAssignable(o.left, d);
              break;
            case "ParenthesizedExpression":
              this.toAssignable(o.expression, d, f);
              break;
            case "ChainExpression":
              this.raiseRecoverable(o.start, "Optional chaining cannot appear in left-hand side");
              break;
            case "MemberExpression":
              if (!d)
                break;
            default:
              this.raise(o.start, "Assigning to rvalue");
          }
        else
          f && this.checkPatternErrors(f, !0);
        return o;
      }, li.toAssignableList = function(o, d) {
        for (var f = o.length, g = 0; g < f; g++) {
          var S = o[g];
          S && this.toAssignable(S, d);
        }
        if (f) {
          var T = o[f - 1];
          this.options.ecmaVersion === 6 && d && T && T.type === "RestElement" && T.argument.type !== "Identifier" && this.unexpected(T.argument.start);
        }
        return o;
      }, li.parseSpread = function(o) {
        var d = this.startNode();
        return this.next(), d.argument = this.parseMaybeAssign(!1, o), this.finishNode(d, "SpreadElement");
      }, li.parseRestBinding = function() {
        var o = this.startNode();
        return this.next(), this.options.ecmaVersion === 6 && this.type !== v.name && this.unexpected(), o.argument = this.parseBindingAtom(), this.finishNode(o, "RestElement");
      }, li.parseBindingAtom = function() {
        if (this.options.ecmaVersion >= 6)
          switch (this.type) {
            case v.bracketL:
              var o = this.startNode();
              return this.next(), o.elements = this.parseBindingList(v.bracketR, !0, !0), this.finishNode(o, "ArrayPattern");
            case v.braceL:
              return this.parseObj(!0);
          }
        return this.parseIdent();
      }, li.parseBindingList = function(o, d, f) {
        for (var g = [], S = !0; !this.eat(o); )
          if (S ? S = !1 : this.expect(v.comma), d && this.type === v.comma)
            g.push(null);
          else {
            if (f && this.afterTrailingComma(o))
              break;
            if (this.type === v.ellipsis) {
              var T = this.parseRestBinding();
              this.parseBindingListItem(T), g.push(T), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element"), this.expect(o);
              break;
            } else {
              var A = this.parseMaybeDefault(this.start, this.startLoc);
              this.parseBindingListItem(A), g.push(A);
            }
          }
        return g;
      }, li.parseBindingListItem = function(o) {
        return o;
      }, li.parseMaybeDefault = function(o, d, f) {
        if (f = f || this.parseBindingAtom(), this.options.ecmaVersion < 6 || !this.eat(v.eq))
          return f;
        var g = this.startNodeAt(o, d);
        return g.left = f, g.right = this.parseMaybeAssign(), this.finishNode(g, "AssignmentPattern");
      }, li.checkLValSimple = function(o, d, f) {
        d === void 0 && (d = da);
        var g = d !== da;
        switch (o.type) {
          case "Identifier":
            this.strict && this.reservedWordsStrictBind.test(o.name) && this.raiseRecoverable(o.start, (g ? "Binding " : "Assigning to ") + o.name + " in strict mode"), g && (d === $i && o.name === "let" && this.raiseRecoverable(o.start, "let is disallowed as a lexically bound name"), f && (Ce(f, o.name) && this.raiseRecoverable(o.start, "Argument name clash"), f[o.name] = !0), d !== Dv && this.declareName(o.name, d, o.start));
            break;
          case "ChainExpression":
            this.raiseRecoverable(o.start, "Optional chaining cannot appear in left-hand side");
            break;
          case "MemberExpression":
            g && this.raiseRecoverable(o.start, "Binding member expression");
            break;
          case "ParenthesizedExpression":
            return g && this.raiseRecoverable(o.start, "Binding parenthesized expression"), this.checkLValSimple(o.expression, d, f);
          default:
            this.raise(o.start, (g ? "Binding" : "Assigning to") + " rvalue");
        }
      }, li.checkLValPattern = function(o, d, f) {
        switch (d === void 0 && (d = da), o.type) {
          case "ObjectPattern":
            for (var g = 0, S = o.properties; g < S.length; g += 1) {
              var T = S[g];
              this.checkLValInnerPattern(T, d, f);
            }
            break;
          case "ArrayPattern":
            for (var A = 0, B = o.elements; A < B.length; A += 1) {
              var V = B[A];
              V && this.checkLValInnerPattern(V, d, f);
            }
            break;
          default:
            this.checkLValSimple(o, d, f);
        }
      }, li.checkLValInnerPattern = function(o, d, f) {
        switch (d === void 0 && (d = da), o.type) {
          case "Property":
            this.checkLValInnerPattern(o.value, d, f);
            break;
          case "AssignmentPattern":
            this.checkLValPattern(o.left, d, f);
            break;
          case "RestElement":
            this.checkLValPattern(o.argument, d, f);
            break;
          default:
            this.checkLValPattern(o, d, f);
        }
      };
      var Zt = /* @__PURE__ */ l(function(d, f, g, S, T) {
        this.token = d, this.isExpr = !!f, this.preserveSpace = !!g, this.override = S, this.generator = !!T;
      }, "TokContext"), Ue = {
        b_stat: new Zt("{", !1),
        b_expr: new Zt("{", !0),
        b_tmpl: new Zt("${", !1),
        p_stat: new Zt("(", !1),
        p_expr: new Zt("(", !0),
        q_tmpl: new Zt("`", !0, !0, function(o) {
          return o.tryReadTemplateToken();
        }),
        f_stat: new Zt("function", !1),
        f_expr: new Zt("function", !0),
        f_expr_gen: new Zt("function", !0, !1, null, !0),
        f_gen: new Zt("function", !1, !1, null, !0)
      }, ks = Ye.prototype;
      ks.initialContext = function() {
        return [Ue.b_stat];
      }, ks.curContext = function() {
        return this.context[this.context.length - 1];
      }, ks.braceIsBlock = function(o) {
        var d = this.curContext();
        return d === Ue.f_expr || d === Ue.f_stat ? !0 : o === v.colon && (d === Ue.b_stat || d === Ue.b_expr) ? !d.isExpr : o === v._return || o === v.name && this.exprAllowed ? H.test(this.input.slice(this.lastTokEnd, this.start)) : o === v._else || o === v.semi || o === v.eof || o === v.parenR || o === v.arrow ? !0 : o === v.braceL ? d === Ue.b_stat : o === v._var || o === v._const || o === v.name ? !1 : !this.exprAllowed;
      }, ks.inGeneratorContext = function() {
        for (var o = this.context.length - 1; o >= 1; o--) {
          var d = this.context[o];
          if (d.token === "function")
            return d.generator;
        }
        return !1;
      }, ks.updateContext = function(o) {
        var d, f = this.type;
        f.keyword && o === v.dot ? this.exprAllowed = !1 : (d = f.updateContext) ? d.call(this, o) : this.exprAllowed = f.beforeExpr;
      }, ks.overrideContext = function(o) {
        this.curContext() !== o && (this.context[this.context.length - 1] = o);
      }, v.parenR.updateContext = v.braceR.updateContext = function() {
        if (this.context.length === 1) {
          this.exprAllowed = !0;
          return;
        }
        var o = this.context.pop();
        o === Ue.b_stat && this.curContext().token === "function" && (o = this.context.pop()), this.exprAllowed = !o.isExpr;
      }, v.braceL.updateContext = function(o) {
        this.context.push(this.braceIsBlock(o) ? Ue.b_stat : Ue.b_expr), this.exprAllowed = !0;
      }, v.dollarBraceL.updateContext = function() {
        this.context.push(Ue.b_tmpl), this.exprAllowed = !0;
      }, v.parenL.updateContext = function(o) {
        var d = o === v._if || o === v._for || o === v._with || o === v._while;
        this.context.push(d ? Ue.p_stat : Ue.p_expr), this.exprAllowed = !0;
      }, v.incDec.updateContext = function() {
      }, v._function.updateContext = v._class.updateContext = function(o) {
        o.beforeExpr && o !== v._else && !(o === v.semi && this.curContext() !== Ue.p_stat) && !(o === v._return && H.test(this.input.slice(this.lastTokEnd, this.start))) && !((o === v.colon || o === v.braceL) && this.curContext() === Ue.b_stat) ? this.context.push(Ue.f_expr) : this.context.push(Ue.f_stat), this.exprAllowed = !1;
      }, v.backQuote.updateContext = function() {
        this.curContext() === Ue.q_tmpl ? this.context.pop() : this.context.push(Ue.q_tmpl), this.exprAllowed = !1;
      }, v.star.updateContext = function(o) {
        if (o === v._function) {
          var d = this.context.length - 1;
          this.context[d] === Ue.f_expr ? this.context[d] = Ue.f_expr_gen : this.context[d] = Ue.f_gen;
        }
        this.exprAllowed = !0;
      }, v.name.updateContext = function(o) {
        var d = !1;
        this.options.ecmaVersion >= 6 && o !== v.dot && (this.value === "of" && !this.exprAllowed || this.value === "yield" && this.inGeneratorContext()) && (d = !0), this.exprAllowed = d;
      };
      var de = Ye.prototype;
      de.checkPropClash = function(o, d, f) {
        if (!(this.options.ecmaVersion >= 9 && o.type === "SpreadElement") && !(this.options.ecmaVersion >= 6 && (o.computed || o.method || o.shorthand))) {
          var g = o.key, S;
          switch (g.type) {
            case "Identifier":
              S = g.name;
              break;
            case "Literal":
              S = String(g.value);
              break;
            default:
              return;
          }
          var T = o.kind;
          if (this.options.ecmaVersion >= 6) {
            S === "__proto__" && T === "init" && (d.proto && (f ? f.doubleProto < 0 && (f.doubleProto = g.start) : this.raiseRecoverable(g.start, "Redefinition of __proto__ property")), d.proto = !0);
            return;
          }
          S = "$" + S;
          var A = d[S];
          if (A) {
            var B;
            T === "init" ? B = this.strict && A.init || A.get || A.set : B = A.init || A[T], B && this.raiseRecoverable(g.start, "Redefinition of property");
          } else
            A = d[S] = {
              init: !1,
              get: !1,
              set: !1
            };
          A[T] = !0;
        }
      }, de.parseExpression = function(o, d) {
        var f = this.start, g = this.startLoc, S = this.parseMaybeAssign(o, d);
        if (this.type === v.comma) {
          var T = this.startNodeAt(f, g);
          for (T.expressions = [S]; this.eat(v.comma); )
            T.expressions.push(this.parseMaybeAssign(o, d));
          return this.finishNode(T, "SequenceExpression");
        }
        return S;
      }, de.parseMaybeAssign = function(o, d, f) {
        if (this.isContextual("yield")) {
          if (this.inGenerator)
            return this.parseYield(o);
          this.exprAllowed = !1;
        }
        var g = !1, S = -1, T = -1, A = -1;
        d ? (S = d.parenthesizedAssign, T = d.trailingComma, A = d.doubleProto, d.parenthesizedAssign = d.trailingComma = -1) : (d = new pa(), g = !0);
        var B = this.start, V = this.startLoc;
        (this.type === v.parenL || this.type === v.name) && (this.potentialArrowAt = this.start, this.potentialArrowInForAwait = o === "await");
        var ue = this.parseMaybeConditional(o, d);
        if (f && (ue = f.call(this, ue, B, V)), this.type.isAssign) {
          var ge = this.startNodeAt(B, V);
          return ge.operator = this.value, this.type === v.eq && (ue = this.toAssignable(ue, !1, d)), g || (d.parenthesizedAssign = d.trailingComma = d.doubleProto = -1), d.shorthandAssign >= ue.start && (d.shorthandAssign = -1), this.type === v.eq ? this.checkLValPattern(ue) : this.checkLValSimple(ue), ge.left = ue, this.next(), ge.right = this.parseMaybeAssign(o), A > -1 && (d.doubleProto = A), this.finishNode(ge, "AssignmentExpression");
        } else
          g && this.checkExpressionErrors(d, !0);
        return S > -1 && (d.parenthesizedAssign = S), T > -1 && (d.trailingComma = T), ue;
      }, de.parseMaybeConditional = function(o, d) {
        var f = this.start, g = this.startLoc, S = this.parseExprOps(o, d);
        if (this.checkExpressionErrors(d))
          return S;
        if (this.eat(v.question)) {
          var T = this.startNodeAt(f, g);
          return T.test = S, T.consequent = this.parseMaybeAssign(), this.expect(v.colon), T.alternate = this.parseMaybeAssign(o), this.finishNode(T, "ConditionalExpression");
        }
        return S;
      }, de.parseExprOps = function(o, d) {
        var f = this.start, g = this.startLoc, S = this.parseMaybeUnary(d, !1, !1, o);
        return this.checkExpressionErrors(d) || S.start === f && S.type === "ArrowFunctionExpression" ? S : this.parseExprOp(S, f, g, -1, o);
      }, de.parseExprOp = function(o, d, f, g, S) {
        var T = this.type.binop;
        if (T != null && (!S || this.type !== v._in) && T > g) {
          var A = this.type === v.logicalOR || this.type === v.logicalAND, B = this.type === v.coalesce;
          B && (T = v.logicalAND.binop);
          var V = this.value;
          this.next();
          var ue = this.start, ge = this.startLoc, mt = this.parseExprOp(this.parseMaybeUnary(null, !1, !1, S), ue, ge, T, S), Wn = this.buildBinary(d, f, o, mt, V, A || B);
          return (A && this.type === v.coalesce || B && (this.type === v.logicalOR || this.type === v.logicalAND)) && this.raiseRecoverable(this.start, "Logical expressions and coalesce expressions cannot be mixed. Wrap either by parentheses"), this.parseExprOp(Wn, d, f, g, S);
        }
        return o;
      }, de.buildBinary = function(o, d, f, g, S, T) {
        g.type === "PrivateIdentifier" && this.raise(g.start, "Private identifier can only be left side of binary expression");
        var A = this.startNodeAt(o, d);
        return A.left = f, A.operator = S, A.right = g, this.finishNode(A, T ? "LogicalExpression" : "BinaryExpression");
      }, de.parseMaybeUnary = function(o, d, f, g) {
        var S = this.start, T = this.startLoc, A;
        if (this.isContextual("await") && this.canAwait)
          A = this.parseAwait(g), d = !0;
        else if (this.type.prefix) {
          var B = this.startNode(), V = this.type === v.incDec;
          B.operator = this.value, B.prefix = !0, this.next(), B.argument = this.parseMaybeUnary(null, !0, V, g), this.checkExpressionErrors(o, !0), V ? this.checkLValSimple(B.argument) : this.strict && B.operator === "delete" && B.argument.type === "Identifier" ? this.raiseRecoverable(B.start, "Deleting local variable in strict mode") : B.operator === "delete" && Wu(B.argument) ? this.raiseRecoverable(B.start, "Private fields can not be deleted") : d = !0, A = this.finishNode(B, V ? "UpdateExpression" : "UnaryExpression");
        } else if (!d && this.type === v.privateId)
          (g || this.privateNameStack.length === 0) && this.unexpected(), A = this.parsePrivateIdent(), this.type !== v._in && this.unexpected();
        else {
          if (A = this.parseExprSubscripts(o, g), this.checkExpressionErrors(o))
            return A;
          for (; this.type.postfix && !this.canInsertSemicolon(); ) {
            var ue = this.startNodeAt(S, T);
            ue.operator = this.value, ue.prefix = !1, ue.argument = A, this.checkLValSimple(A), this.next(), A = this.finishNode(ue, "UpdateExpression");
          }
        }
        if (!f && this.eat(v.starstar))
          if (d)
            this.unexpected(this.lastTokStart);
          else
            return this.buildBinary(S, T, A, this.parseMaybeUnary(null, !1, !1, g), "**", !1);
        else
          return A;
      };
      function Wu(o) {
        return o.type === "MemberExpression" && o.property.type === "PrivateIdentifier" || o.type === "ChainExpression" && Wu(o.expression);
      }
      l(Wu, "isPrivateFieldAccess"), de.parseExprSubscripts = function(o, d) {
        var f = this.start, g = this.startLoc, S = this.parseExprAtom(o, d);
        if (S.type === "ArrowFunctionExpression" && this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")")
          return S;
        var T = this.parseSubscripts(S, f, g, !1, d);
        return o && T.type === "MemberExpression" && (o.parenthesizedAssign >= T.start && (o.parenthesizedAssign = -1), o.parenthesizedBind >= T.start && (o.parenthesizedBind = -1), o.trailingComma >= T.start && (o.trailingComma = -1)), T;
      }, de.parseSubscripts = function(o, d, f, g, S) {
        for (var T = this.options.ecmaVersion >= 8 && o.type === "Identifier" && o.name === "async" && this.lastTokEnd === o.end && !this.canInsertSemicolon() && o.end - o.start === 5 && this.potentialArrowAt === o.start, A = !1; ; ) {
          var B = this.parseSubscript(o, d, f, g, T, A, S);
          if (B.optional && (A = !0), B === o || B.type === "ArrowFunctionExpression") {
            if (A) {
              var V = this.startNodeAt(d, f);
              V.expression = B, B = this.finishNode(V, "ChainExpression");
            }
            return B;
          }
          o = B;
        }
      }, de.parseSubscript = function(o, d, f, g, S, T, A) {
        var B = this.options.ecmaVersion >= 11, V = B && this.eat(v.questionDot);
        g && V && this.raise(this.lastTokStart, "Optional chaining cannot appear in the callee of new expressions");
        var ue = this.eat(v.bracketL);
        if (ue || V && this.type !== v.parenL && this.type !== v.backQuote || this.eat(v.dot)) {
          var ge = this.startNodeAt(d, f);
          ge.object = o, ue ? (ge.property = this.parseExpression(), this.expect(v.bracketR)) : this.type === v.privateId && o.type !== "Super" ? ge.property = this.parsePrivateIdent() : ge.property = this.parseIdent(this.options.allowReserved !== "never"), ge.computed = !!ue, B && (ge.optional = V), o = this.finishNode(ge, "MemberExpression");
        } else if (!g && this.eat(v.parenL)) {
          var mt = new pa(), Wn = this.yieldPos, kr = this.awaitPos, Is = this.awaitIdentPos;
          this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0;
          var va = this.parseExprList(v.parenR, this.options.ecmaVersion >= 8, !1, mt);
          if (S && !V && !this.canInsertSemicolon() && this.eat(v.arrow))
            return this.checkPatternErrors(mt, !1), this.checkYieldAwaitInDefaultParams(), this.awaitIdentPos > 0 && this.raise(this.awaitIdentPos, "Cannot use 'await' as identifier inside an async function"), this.yieldPos = Wn, this.awaitPos = kr, this.awaitIdentPos = Is, this.parseArrowExpression(this.startNodeAt(d, f), va, !0, A);
          this.checkExpressionErrors(mt, !0), this.yieldPos = Wn || this.yieldPos, this.awaitPos = kr || this.awaitPos, this.awaitIdentPos = Is || this.awaitIdentPos;
          var Ps = this.startNodeAt(d, f);
          Ps.callee = o, Ps.arguments = va, B && (Ps.optional = V), o = this.finishNode(Ps, "CallExpression");
        } else if (this.type === v.backQuote) {
          (V || T) && this.raise(this.start, "Optional chaining cannot appear in the tag of tagged template expressions");
          var Ms = this.startNodeAt(d, f);
          Ms.tag = o, Ms.quasi = this.parseTemplate({ isTagged: !0 }), o = this.finishNode(Ms, "TaggedTemplateExpression");
        }
        return o;
      }, de.parseExprAtom = function(o, d) {
        this.type === v.slash && this.readRegexp();
        var f, g = this.potentialArrowAt === this.start;
        switch (this.type) {
          case v._super:
            return this.allowSuper || this.raise(this.start, "'super' keyword outside a method"), f = this.startNode(), this.next(), this.type === v.parenL && !this.allowDirectSuper && this.raise(f.start, "super() call outside constructor of a subclass"), this.type !== v.dot && this.type !== v.bracketL && this.type !== v.parenL && this.unexpected(), this.finishNode(f, "Super");
          case v._this:
            return f = this.startNode(), this.next(), this.finishNode(f, "ThisExpression");
          case v.name:
            var S = this.start, T = this.startLoc, A = this.containsEsc, B = this.parseIdent(!1);
            if (this.options.ecmaVersion >= 8 && !A && B.name === "async" && !this.canInsertSemicolon() && this.eat(v._function))
              return this.overrideContext(Ue.f_expr), this.parseFunction(this.startNodeAt(S, T), 0, !1, !0, d);
            if (g && !this.canInsertSemicolon()) {
              if (this.eat(v.arrow))
                return this.parseArrowExpression(this.startNodeAt(S, T), [B], !1, d);
              if (this.options.ecmaVersion >= 8 && B.name === "async" && this.type === v.name && !A && (!this.potentialArrowInForAwait || this.value !== "of" || this.containsEsc))
                return B = this.parseIdent(!1), (this.canInsertSemicolon() || !this.eat(v.arrow)) && this.unexpected(), this.parseArrowExpression(this.startNodeAt(S, T), [B], !0, d);
            }
            return B;
          case v.regexp:
            var V = this.value;
            return f = this.parseLiteral(V.value), f.regex = { pattern: V.pattern, flags: V.flags }, f;
          case v.num:
          case v.string:
            return this.parseLiteral(this.value);
          case v._null:
          case v._true:
          case v._false:
            return f = this.startNode(), f.value = this.type === v._null ? null : this.type === v._true, f.raw = this.type.keyword, this.next(), this.finishNode(f, "Literal");
          case v.parenL:
            var ue = this.start, ge = this.parseParenAndDistinguishExpression(g, d);
            return o && (o.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(ge) && (o.parenthesizedAssign = ue), o.parenthesizedBind < 0 && (o.parenthesizedBind = ue)), ge;
          case v.bracketL:
            return f = this.startNode(), this.next(), f.elements = this.parseExprList(v.bracketR, !0, !0, o), this.finishNode(f, "ArrayExpression");
          case v.braceL:
            return this.overrideContext(Ue.b_expr), this.parseObj(!1, o);
          case v._function:
            return f = this.startNode(), this.next(), this.parseFunction(f, 0);
          case v._class:
            return this.parseClass(this.startNode(), !1);
          case v._new:
            return this.parseNew();
          case v.backQuote:
            return this.parseTemplate();
          case v._import:
            return this.options.ecmaVersion >= 11 ? this.parseExprImport() : this.unexpected();
          default:
            this.unexpected();
        }
      }, de.parseExprImport = function() {
        var o = this.startNode();
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword import");
        var d = this.parseIdent(!0);
        switch (this.type) {
          case v.parenL:
            return this.parseDynamicImport(o);
          case v.dot:
            return o.meta = d, this.parseImportMeta(o);
          default:
            this.unexpected();
        }
      }, de.parseDynamicImport = function(o) {
        if (this.next(), o.source = this.parseMaybeAssign(), !this.eat(v.parenR)) {
          var d = this.start;
          this.eat(v.comma) && this.eat(v.parenR) ? this.raiseRecoverable(d, "Trailing comma is not allowed in import()") : this.unexpected(d);
        }
        return this.finishNode(o, "ImportExpression");
      }, de.parseImportMeta = function(o) {
        this.next();
        var d = this.containsEsc;
        return o.property = this.parseIdent(!0), o.property.name !== "meta" && this.raiseRecoverable(o.property.start, "The only valid meta property for import is 'import.meta'"), d && this.raiseRecoverable(o.start, "'import.meta' must not contain escaped characters"), this.options.sourceType !== "module" && !this.options.allowImportExportEverywhere && this.raiseRecoverable(o.start, "Cannot use 'import.meta' outside a module"), this.finishNode(o, "MetaProperty");
      }, de.parseLiteral = function(o) {
        var d = this.startNode();
        return d.value = o, d.raw = this.input.slice(this.start, this.end), d.raw.charCodeAt(d.raw.length - 1) === 110 && (d.bigint = d.raw.slice(0, -1).replace(/_/g, "")), this.next(), this.finishNode(d, "Literal");
      }, de.parseParenExpression = function() {
        this.expect(v.parenL);
        var o = this.parseExpression();
        return this.expect(v.parenR), o;
      }, de.parseParenAndDistinguishExpression = function(o, d) {
        var f = this.start, g = this.startLoc, S, T = this.options.ecmaVersion >= 8;
        if (this.options.ecmaVersion >= 6) {
          this.next();
          var A = this.start, B = this.startLoc, V = [], ue = !0, ge = !1, mt = new pa(), Wn = this.yieldPos, kr = this.awaitPos, Is;
          for (this.yieldPos = 0, this.awaitPos = 0; this.type !== v.parenR; )
            if (ue ? ue = !1 : this.expect(v.comma), T && this.afterTrailingComma(v.parenR, !0)) {
              ge = !0;
              break;
            } else if (this.type === v.ellipsis) {
              Is = this.start, V.push(this.parseParenItem(this.parseRestBinding())), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element");
              break;
            } else
              V.push(this.parseMaybeAssign(!1, mt, this.parseParenItem));
          var va = this.lastTokEnd, Ps = this.lastTokEndLoc;
          if (this.expect(v.parenR), o && !this.canInsertSemicolon() && this.eat(v.arrow))
            return this.checkPatternErrors(mt, !1), this.checkYieldAwaitInDefaultParams(), this.yieldPos = Wn, this.awaitPos = kr, this.parseParenArrowList(f, g, V, d);
          (!V.length || ge) && this.unexpected(this.lastTokStart), Is && this.unexpected(Is), this.checkExpressionErrors(mt, !0), this.yieldPos = Wn || this.yieldPos, this.awaitPos = kr || this.awaitPos, V.length > 1 ? (S = this.startNodeAt(A, B), S.expressions = V, this.finishNodeAt(S, "SequenceExpression", va, Ps)) : S = V[0];
        } else
          S = this.parseParenExpression();
        if (this.options.preserveParens) {
          var Ms = this.startNodeAt(f, g);
          return Ms.expression = S, this.finishNode(Ms, "ParenthesizedExpression");
        } else
          return S;
      }, de.parseParenItem = function(o) {
        return o;
      }, de.parseParenArrowList = function(o, d, f, g) {
        return this.parseArrowExpression(this.startNodeAt(o, d), f, !1, g);
      };
      var Rw = [];
      de.parseNew = function() {
        this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword new");
        var o = this.startNode(), d = this.parseIdent(!0);
        if (this.options.ecmaVersion >= 6 && this.eat(v.dot)) {
          o.meta = d;
          var f = this.containsEsc;
          return o.property = this.parseIdent(!0), o.property.name !== "target" && this.raiseRecoverable(o.property.start, "The only valid meta property for new is 'new.target'"), f && this.raiseRecoverable(o.start, "'new.target' must not contain escaped characters"), this.allowNewDotTarget || this.raiseRecoverable(o.start, "'new.target' can only be used in functions and class static block"), this.finishNode(o, "MetaProperty");
        }
        var g = this.start, S = this.startLoc, T = this.type === v._import;
        return o.callee = this.parseSubscripts(this.parseExprAtom(), g, S, !0, !1), T && o.callee.type === "ImportExpression" && this.raise(g, "Cannot use new with import()"), this.eat(v.parenL) ? o.arguments = this.parseExprList(v.parenR, this.options.ecmaVersion >= 8, !1) : o.arguments = Rw, this.finishNode(o, "NewExpression");
      }, de.parseTemplateElement = function(o) {
        var d = o.isTagged, f = this.startNode();
        return this.type === v.invalidTemplate ? (d || this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal"), f.value = {
          raw: this.value,
          cooked: null
        }) : f.value = {
          raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, `
`),
          cooked: this.value
        }, this.next(), f.tail = this.type === v.backQuote, this.finishNode(f, "TemplateElement");
      }, de.parseTemplate = function(o) {
        o === void 0 && (o = {});
        var d = o.isTagged;
        d === void 0 && (d = !1);
        var f = this.startNode();
        this.next(), f.expressions = [];
        var g = this.parseTemplateElement({ isTagged: d });
        for (f.quasis = [g]; !g.tail; )
          this.type === v.eof && this.raise(this.pos, "Unterminated template literal"), this.expect(v.dollarBraceL), f.expressions.push(this.parseExpression()), this.expect(v.braceR), f.quasis.push(g = this.parseTemplateElement({ isTagged: d }));
        return this.next(), this.finishNode(f, "TemplateLiteral");
      }, de.isAsyncProp = function(o) {
        return !o.computed && o.key.type === "Identifier" && o.key.name === "async" && (this.type === v.name || this.type === v.num || this.type === v.string || this.type === v.bracketL || this.type.keyword || this.options.ecmaVersion >= 9 && this.type === v.star) && !H.test(this.input.slice(this.lastTokEnd, this.start));
      }, de.parseObj = function(o, d) {
        var f = this.startNode(), g = !0, S = {};
        for (f.properties = [], this.next(); !this.eat(v.braceR); ) {
          if (g)
            g = !1;
          else if (this.expect(v.comma), this.options.ecmaVersion >= 5 && this.afterTrailingComma(v.braceR))
            break;
          var T = this.parseProperty(o, d);
          o || this.checkPropClash(T, S, d), f.properties.push(T);
        }
        return this.finishNode(f, o ? "ObjectPattern" : "ObjectExpression");
      }, de.parseProperty = function(o, d) {
        var f = this.startNode(), g, S, T, A;
        if (this.options.ecmaVersion >= 9 && this.eat(v.ellipsis))
          return o ? (f.argument = this.parseIdent(!1), this.type === v.comma && this.raise(this.start, "Comma is not permitted after the rest element"), this.finishNode(f, "RestElement")) : (f.argument = this.parseMaybeAssign(!1, d), this.type === v.comma && d && d.trailingComma < 0 && (d.trailingComma = this.start), this.finishNode(f, "SpreadElement"));
        this.options.ecmaVersion >= 6 && (f.method = !1, f.shorthand = !1, (o || d) && (T = this.start, A = this.startLoc), o || (g = this.eat(v.star)));
        var B = this.containsEsc;
        return this.parsePropertyName(f), !o && !B && this.options.ecmaVersion >= 8 && !g && this.isAsyncProp(f) ? (S = !0, g = this.options.ecmaVersion >= 9 && this.eat(v.star), this.parsePropertyName(f, d)) : S = !1, this.parsePropertyValue(f, o, g, S, T, A, d, B), this.finishNode(f, "Property");
      }, de.parsePropertyValue = function(o, d, f, g, S, T, A, B) {
        if ((f || g) && this.type === v.colon && this.unexpected(), this.eat(v.colon))
          o.value = d ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(!1, A), o.kind = "init";
        else if (this.options.ecmaVersion >= 6 && this.type === v.parenL)
          d && this.unexpected(), o.kind = "init", o.method = !0, o.value = this.parseMethod(f, g);
        else if (!d && !B && this.options.ecmaVersion >= 5 && !o.computed && o.key.type === "Identifier" && (o.key.name === "get" || o.key.name === "set") && this.type !== v.comma && this.type !== v.braceR && this.type !== v.eq) {
          (f || g) && this.unexpected(), o.kind = o.key.name, this.parsePropertyName(o), o.value = this.parseMethod(!1);
          var V = o.kind === "get" ? 0 : 1;
          if (o.value.params.length !== V) {
            var ue = o.value.start;
            o.kind === "get" ? this.raiseRecoverable(ue, "getter should have no params") : this.raiseRecoverable(ue, "setter should have exactly one param");
          } else
            o.kind === "set" && o.value.params[0].type === "RestElement" && this.raiseRecoverable(o.value.params[0].start, "Setter cannot use rest params");
        } else
          this.options.ecmaVersion >= 6 && !o.computed && o.key.type === "Identifier" ? ((f || g) && this.unexpected(), this.checkUnreserved(o.key), o.key.name === "await" && !this.awaitIdentPos && (this.awaitIdentPos = S), o.kind = "init", d ? o.value = this.parseMaybeDefault(S, T, this.copyNode(o.key)) : this.type === v.eq && A ? (A.shorthandAssign < 0 && (A.shorthandAssign = this.start), o.value = this.parseMaybeDefault(S, T, this.copyNode(o.key))) : o.value = this.copyNode(o.key), o.shorthand = !0) : this.unexpected();
      }, de.parsePropertyName = function(o) {
        if (this.options.ecmaVersion >= 6) {
          if (this.eat(v.bracketL))
            return o.computed = !0, o.key = this.parseMaybeAssign(), this.expect(v.bracketR), o.key;
          o.computed = !1;
        }
        return o.key = this.type === v.num || this.type === v.string ? this.parseExprAtom() : this.parseIdent(this.options.allowReserved !== "never");
      }, de.initFunction = function(o) {
        o.id = null, this.options.ecmaVersion >= 6 && (o.generator = o.expression = !1), this.options.ecmaVersion >= 8 && (o.async = !1);
      }, de.parseMethod = function(o, d, f) {
        var g = this.startNode(), S = this.yieldPos, T = this.awaitPos, A = this.awaitIdentPos;
        return this.initFunction(g), this.options.ecmaVersion >= 6 && (g.generator = o), this.options.ecmaVersion >= 8 && (g.async = !!d), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, this.enterScope(ha(d, g.generator) | Fu | (f ? Nv : 0)), this.expect(v.parenL), g.params = this.parseBindingList(v.parenR, !1, this.options.ecmaVersion >= 8), this.checkYieldAwaitInDefaultParams(), this.parseFunctionBody(g, !1, !0, !1), this.yieldPos = S, this.awaitPos = T, this.awaitIdentPos = A, this.finishNode(g, "FunctionExpression");
      }, de.parseArrowExpression = function(o, d, f, g) {
        var S = this.yieldPos, T = this.awaitPos, A = this.awaitIdentPos;
        return this.enterScope(ha(f, !1) | Pv), this.initFunction(o), this.options.ecmaVersion >= 8 && (o.async = !!f), this.yieldPos = 0, this.awaitPos = 0, this.awaitIdentPos = 0, o.params = this.toAssignableList(d, !0), this.parseFunctionBody(o, !0, !1, g), this.yieldPos = S, this.awaitPos = T, this.awaitIdentPos = A, this.finishNode(o, "ArrowFunctionExpression");
      }, de.parseFunctionBody = function(o, d, f, g) {
        var S = d && this.type !== v.braceL, T = this.strict, A = !1;
        if (S)
          o.body = this.parseMaybeAssign(g), o.expression = !0, this.checkParams(o, !1);
        else {
          var B = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(o.params);
          (!T || B) && (A = this.strictDirective(this.end), A && B && this.raiseRecoverable(o.start, "Illegal 'use strict' directive in function with non-simple parameter list"));
          var V = this.labels;
          this.labels = [], A && (this.strict = !0), this.checkParams(o, !T && !A && !d && !f && this.isSimpleParamList(o.params)), this.strict && o.id && this.checkLValSimple(o.id, Dv), o.body = this.parseBlock(!1, void 0, A && !T), o.expression = !1, this.adaptDirectivePrologue(o.body.body), this.labels = V;
        }
        this.exitScope();
      }, de.isSimpleParamList = function(o) {
        for (var d = 0, f = o; d < f.length; d += 1) {
          var g = f[d];
          if (g.type !== "Identifier")
            return !1;
        }
        return !0;
      }, de.checkParams = function(o, d) {
        for (var f = /* @__PURE__ */ Object.create(null), g = 0, S = o.params; g < S.length; g += 1) {
          var T = S[g];
          this.checkLValInnerPattern(T, Uu, d ? null : f);
        }
      }, de.parseExprList = function(o, d, f, g) {
        for (var S = [], T = !0; !this.eat(o); ) {
          if (T)
            T = !1;
          else if (this.expect(v.comma), d && this.afterTrailingComma(o))
            break;
          var A = void 0;
          f && this.type === v.comma ? A = null : this.type === v.ellipsis ? (A = this.parseSpread(g), g && this.type === v.comma && g.trailingComma < 0 && (g.trailingComma = this.start)) : A = this.parseMaybeAssign(!1, g), S.push(A);
        }
        return S;
      }, de.checkUnreserved = function(o) {
        var d = o.start, f = o.end, g = o.name;
        if (this.inGenerator && g === "yield" && this.raiseRecoverable(d, "Cannot use 'yield' as identifier inside a generator"), this.inAsync && g === "await" && this.raiseRecoverable(d, "Cannot use 'await' as identifier inside an async function"), this.currentThisScope().inClassFieldInit && g === "arguments" && this.raiseRecoverable(d, "Cannot use 'arguments' in class field initializer"), this.inClassStaticBlock && (g === "arguments" || g === "await") && this.raise(d, "Cannot use " + g + " in class static initialization block"), this.keywords.test(g) && this.raise(d, "Unexpected keyword '" + g + "'"), !(this.options.ecmaVersion < 6 && this.input.slice(d, f).indexOf("\\") !== -1)) {
          var S = this.strict ? this.reservedWordsStrict : this.reservedWords;
          S.test(g) && (!this.inAsync && g === "await" && this.raiseRecoverable(d, "Cannot use keyword 'await' outside an async function"), this.raiseRecoverable(d, "The keyword '" + g + "' is reserved"));
        }
      }, de.parseIdent = function(o, d) {
        var f = this.startNode();
        return this.type === v.name ? f.name = this.value : this.type.keyword ? (f.name = this.type.keyword, (f.name === "class" || f.name === "function") && (this.lastTokEnd !== this.lastTokStart + 1 || this.input.charCodeAt(this.lastTokStart) !== 46) && this.context.pop()) : this.unexpected(), this.next(!!o), this.finishNode(f, "Identifier"), o || (this.checkUnreserved(f), f.name === "await" && !this.awaitIdentPos && (this.awaitIdentPos = f.start)), f;
      }, de.parsePrivateIdent = function() {
        var o = this.startNode();
        return this.type === v.privateId ? o.name = this.value : this.unexpected(), this.next(), this.finishNode(o, "PrivateIdentifier"), this.privateNameStack.length === 0 ? this.raise(o.start, "Private field '#" + o.name + "' must be declared in an enclosing class") : this.privateNameStack[this.privateNameStack.length - 1].used.push(o), o;
      }, de.parseYield = function(o) {
        this.yieldPos || (this.yieldPos = this.start);
        var d = this.startNode();
        return this.next(), this.type === v.semi || this.canInsertSemicolon() || this.type !== v.star && !this.type.startsExpr ? (d.delegate = !1, d.argument = null) : (d.delegate = this.eat(v.star), d.argument = this.parseMaybeAssign(o)), this.finishNode(d, "YieldExpression");
      }, de.parseAwait = function(o) {
        this.awaitPos || (this.awaitPos = this.start);
        var d = this.startNode();
        return this.next(), d.argument = this.parseMaybeUnary(null, !0, !1, o), this.finishNode(d, "AwaitExpression");
      };
      var fa = Ye.prototype;
      fa.raise = function(o, d) {
        var f = ln(this.input, o);
        d += " (" + f.line + ":" + f.column + ")";
        var g = new SyntaxError(d);
        throw g.pos = o, g.loc = f, g.raisedAt = this.pos, g;
      }, fa.raiseRecoverable = fa.raise, fa.curPosition = function() {
        if (this.options.locations)
          return new Ut(this.curLine, this.pos - this.lineStart);
      };
      var un = Ye.prototype, Lw = /* @__PURE__ */ l(function(d) {
        this.flags = d, this.var = [], this.lexical = [], this.functions = [], this.inClassFieldInit = !1;
      }, "Scope");
      un.enterScope = function(o) {
        this.scopeStack.push(new Lw(o));
      }, un.exitScope = function() {
        this.scopeStack.pop();
      }, un.treatFunctionsAsVarInScope = function(o) {
        return o.flags & As || !this.inModule && o.flags & wr;
      }, un.declareName = function(o, d, f) {
        var g = !1;
        if (d === $i) {
          var S = this.currentScope();
          g = S.lexical.indexOf(o) > -1 || S.functions.indexOf(o) > -1 || S.var.indexOf(o) > -1, S.lexical.push(o), this.inModule && S.flags & wr && delete this.undefinedExports[o];
        } else if (d === Lv) {
          var T = this.currentScope();
          T.lexical.push(o);
        } else if (d === Rv) {
          var A = this.currentScope();
          this.treatFunctionsAsVar ? g = A.lexical.indexOf(o) > -1 : g = A.lexical.indexOf(o) > -1 || A.var.indexOf(o) > -1, A.functions.push(o);
        } else
          for (var B = this.scopeStack.length - 1; B >= 0; --B) {
            var V = this.scopeStack[B];
            if (V.lexical.indexOf(o) > -1 && !(V.flags & Mv && V.lexical[0] === o) || !this.treatFunctionsAsVarInScope(V) && V.functions.indexOf(o) > -1) {
              g = !0;
              break;
            }
            if (V.var.push(o), this.inModule && V.flags & wr && delete this.undefinedExports[o], V.flags & Vu)
              break;
          }
        g && this.raiseRecoverable(f, "Identifier '" + o + "' has already been declared");
      }, un.checkLocalExport = function(o) {
        this.scopeStack[0].lexical.indexOf(o.name) === -1 && this.scopeStack[0].var.indexOf(o.name) === -1 && (this.undefinedExports[o.name] = o);
      }, un.currentScope = function() {
        return this.scopeStack[this.scopeStack.length - 1];
      }, un.currentVarScope = function() {
        for (var o = this.scopeStack.length - 1; ; o--) {
          var d = this.scopeStack[o];
          if (d.flags & Vu)
            return d;
        }
      }, un.currentThisScope = function() {
        for (var o = this.scopeStack.length - 1; ; o--) {
          var d = this.scopeStack[o];
          if (d.flags & Vu && !(d.flags & Pv))
            return d;
        }
      };
      var xr = /* @__PURE__ */ l(function(d, f, g) {
        this.type = "", this.start = f, this.end = 0, d.options.locations && (this.loc = new ai(d, g)), d.options.directSourceFile && (this.sourceFile = d.options.directSourceFile), d.options.ranges && (this.range = [f, 0]);
      }, "Node"), Er = Ye.prototype;
      Er.startNode = function() {
        return new xr(this, this.start, this.startLoc);
      }, Er.startNodeAt = function(o, d) {
        return new xr(this, o, d);
      };
      function $u(o, d, f, g) {
        return o.type = d, o.end = f, this.options.locations && (o.loc.end = g), this.options.ranges && (o.range[1] = f), o;
      }
      l($u, "finishNodeAt"), Er.finishNode = function(o, d) {
        return $u.call(this, o, d, this.lastTokEnd, this.lastTokEndLoc);
      }, Er.finishNodeAt = function(o, d, f, g) {
        return $u.call(this, o, d, f, g);
      }, Er.copyNode = function(o) {
        var d = new xr(this, o.start, this.startLoc);
        for (var f in o)
          d[f] = o[f];
        return d;
      };
      var Fv = "ASCII ASCII_Hex_Digit AHex Alphabetic Alpha Any Assigned Bidi_Control Bidi_C Bidi_Mirrored Bidi_M Case_Ignorable CI Cased Changes_When_Casefolded CWCF Changes_When_Casemapped CWCM Changes_When_Lowercased CWL Changes_When_NFKC_Casefolded CWKCF Changes_When_Titlecased CWT Changes_When_Uppercased CWU Dash Default_Ignorable_Code_Point DI Deprecated Dep Diacritic Dia Emoji Emoji_Component Emoji_Modifier Emoji_Modifier_Base Emoji_Presentation Extender Ext Grapheme_Base Gr_Base Grapheme_Extend Gr_Ext Hex_Digit Hex IDS_Binary_Operator IDSB IDS_Trinary_Operator IDST ID_Continue IDC ID_Start IDS Ideographic Ideo Join_Control Join_C Logical_Order_Exception LOE Lowercase Lower Math Noncharacter_Code_Point NChar Pattern_Syntax Pat_Syn Pattern_White_Space Pat_WS Quotation_Mark QMark Radical Regional_Indicator RI Sentence_Terminal STerm Soft_Dotted SD Terminal_Punctuation Term Unified_Ideograph UIdeo Uppercase Upper Variation_Selector VS White_Space space XID_Continue XIDC XID_Start XIDS", Vv = Fv + " Extended_Pictographic", Uv = Vv, jv = Uv + " EBase EComp EMod EPres ExtPict", Dw = jv, Bw = {
        9: Fv,
        10: Vv,
        11: Uv,
        12: jv,
        13: Dw
      }, Hv = "Cased_Letter LC Close_Punctuation Pe Connector_Punctuation Pc Control Cc cntrl Currency_Symbol Sc Dash_Punctuation Pd Decimal_Number Nd digit Enclosing_Mark Me Final_Punctuation Pf Format Cf Initial_Punctuation Pi Letter L Letter_Number Nl Line_Separator Zl Lowercase_Letter Ll Mark M Combining_Mark Math_Symbol Sm Modifier_Letter Lm Modifier_Symbol Sk Nonspacing_Mark Mn Number N Open_Punctuation Ps Other C Other_Letter Lo Other_Number No Other_Punctuation Po Other_Symbol So Paragraph_Separator Zp Private_Use Co Punctuation P punct Separator Z Space_Separator Zs Spacing_Mark Mc Surrogate Cs Symbol S Titlecase_Letter Lt Unassigned Cn Uppercase_Letter Lu", Wv = "Adlam Adlm Ahom Anatolian_Hieroglyphs Hluw Arabic Arab Armenian Armn Avestan Avst Balinese Bali Bamum Bamu Bassa_Vah Bass Batak Batk Bengali Beng Bhaiksuki Bhks Bopomofo Bopo Brahmi Brah Braille Brai Buginese Bugi Buhid Buhd Canadian_Aboriginal Cans Carian Cari Caucasian_Albanian Aghb Chakma Cakm Cham Cham Cherokee Cher Common Zyyy Coptic Copt Qaac Cuneiform Xsux Cypriot Cprt Cyrillic Cyrl Deseret Dsrt Devanagari Deva Duployan Dupl Egyptian_Hieroglyphs Egyp Elbasan Elba Ethiopic Ethi Georgian Geor Glagolitic Glag Gothic Goth Grantha Gran Greek Grek Gujarati Gujr Gurmukhi Guru Han Hani Hangul Hang Hanunoo Hano Hatran Hatr Hebrew Hebr Hiragana Hira Imperial_Aramaic Armi Inherited Zinh Qaai Inscriptional_Pahlavi Phli Inscriptional_Parthian Prti Javanese Java Kaithi Kthi Kannada Knda Katakana Kana Kayah_Li Kali Kharoshthi Khar Khmer Khmr Khojki Khoj Khudawadi Sind Lao Laoo Latin Latn Lepcha Lepc Limbu Limb Linear_A Lina Linear_B Linb Lisu Lisu Lycian Lyci Lydian Lydi Mahajani Mahj Malayalam Mlym Mandaic Mand Manichaean Mani Marchen Marc Masaram_Gondi Gonm Meetei_Mayek Mtei Mende_Kikakui Mend Meroitic_Cursive Merc Meroitic_Hieroglyphs Mero Miao Plrd Modi Mongolian Mong Mro Mroo Multani Mult Myanmar Mymr Nabataean Nbat New_Tai_Lue Talu Newa Newa Nko Nkoo Nushu Nshu Ogham Ogam Ol_Chiki Olck Old_Hungarian Hung Old_Italic Ital Old_North_Arabian Narb Old_Permic Perm Old_Persian Xpeo Old_South_Arabian Sarb Old_Turkic Orkh Oriya Orya Osage Osge Osmanya Osma Pahawh_Hmong Hmng Palmyrene Palm Pau_Cin_Hau Pauc Phags_Pa Phag Phoenician Phnx Psalter_Pahlavi Phlp Rejang Rjng Runic Runr Samaritan Samr Saurashtra Saur Sharada Shrd Shavian Shaw Siddham Sidd SignWriting Sgnw Sinhala Sinh Sora_Sompeng Sora Soyombo Soyo Sundanese Sund Syloti_Nagri Sylo Syriac Syrc Tagalog Tglg Tagbanwa Tagb Tai_Le Tale Tai_Tham Lana Tai_Viet Tavt Takri Takr Tamil Taml Tangut Tang Telugu Telu Thaana Thaa Thai Thai Tibetan Tibt Tifinagh Tfng Tirhuta Tirh Ugaritic Ugar Vai Vaii Warang_Citi Wara Yi Yiii Zanabazar_Square Zanb", $v = Wv + " Dogra Dogr Gunjala_Gondi Gong Hanifi_Rohingya Rohg Makasar Maka Medefaidrin Medf Old_Sogdian Sogo Sogdian Sogd", Gv = $v + " Elymaic Elym Nandinagari Nand Nyiakeng_Puachue_Hmong Hmnp Wancho Wcho", qv = Gv + " Chorasmian Chrs Diak Dives_Akuru Khitan_Small_Script Kits Yezi Yezidi", Ow = qv + " Cypro_Minoan Cpmn Old_Uyghur Ougr Tangsa Tnsa Toto Vithkuqi Vith", Fw = {
        9: Wv,
        10: $v,
        11: Gv,
        12: qv,
        13: Ow
      }, zv = {};
      function Kv(o) {
        var d = zv[o] = {
          binary: De(Bw[o] + " " + Hv),
          nonBinary: {
            General_Category: De(Hv),
            Script: De(Fw[o])
          }
        };
        d.nonBinary.Script_Extensions = d.nonBinary.Script, d.nonBinary.gc = d.nonBinary.General_Category, d.nonBinary.sc = d.nonBinary.Script, d.nonBinary.scx = d.nonBinary.Script_Extensions;
      }
      l(Kv, "buildUnicodeData");
      for (var Gu = 0, Yv = [9, 10, 11, 12, 13]; Gu < Yv.length; Gu += 1) {
        var Vw = Yv[Gu];
        Kv(Vw);
      }
      var Z = Ye.prototype, Gi = /* @__PURE__ */ l(function(d) {
        this.parser = d, this.validFlags = "gim" + (d.options.ecmaVersion >= 6 ? "uy" : "") + (d.options.ecmaVersion >= 9 ? "s" : "") + (d.options.ecmaVersion >= 13 ? "d" : ""), this.unicodeProperties = zv[d.options.ecmaVersion >= 13 ? 13 : d.options.ecmaVersion], this.source = "", this.flags = "", this.start = 0, this.switchU = !1, this.switchN = !1, this.pos = 0, this.lastIntValue = 0, this.lastStringValue = "", this.lastAssertionIsQuantifiable = !1, this.numCapturingParens = 0, this.maxBackReference = 0, this.groupNames = [], this.backReferenceNames = [];
      }, "RegExpValidationState");
      Gi.prototype.reset = /* @__PURE__ */ l(function(d, f, g) {
        var S = g.indexOf("u") !== -1;
        this.start = d | 0, this.source = f + "", this.flags = g, this.switchU = S && this.parser.options.ecmaVersion >= 6, this.switchN = S && this.parser.options.ecmaVersion >= 9;
      }, "reset"), Gi.prototype.raise = /* @__PURE__ */ l(function(d) {
        this.parser.raiseRecoverable(this.start, "Invalid regular expression: /" + this.source + "/: " + d);
      }, "raise"), Gi.prototype.at = /* @__PURE__ */ l(function(d, f) {
        f === void 0 && (f = !1);
        var g = this.source, S = g.length;
        if (d >= S)
          return -1;
        var T = g.charCodeAt(d);
        if (!(f || this.switchU) || T <= 55295 || T >= 57344 || d + 1 >= S)
          return T;
        var A = g.charCodeAt(d + 1);
        return A >= 56320 && A <= 57343 ? (T << 10) + A - 56613888 : T;
      }, "at"), Gi.prototype.nextIndex = /* @__PURE__ */ l(function(d, f) {
        f === void 0 && (f = !1);
        var g = this.source, S = g.length;
        if (d >= S)
          return S;
        var T = g.charCodeAt(d), A;
        return !(f || this.switchU) || T <= 55295 || T >= 57344 || d + 1 >= S || (A = g.charCodeAt(d + 1)) < 56320 || A > 57343 ? d + 1 : d + 2;
      }, "nextIndex"), Gi.prototype.current = /* @__PURE__ */ l(function(d) {
        return d === void 0 && (d = !1), this.at(this.pos, d);
      }, "current"), Gi.prototype.lookahead = /* @__PURE__ */ l(function(d) {
        return d === void 0 && (d = !1), this.at(this.nextIndex(this.pos, d), d);
      }, "lookahead"), Gi.prototype.advance = /* @__PURE__ */ l(function(d) {
        d === void 0 && (d = !1), this.pos = this.nextIndex(this.pos, d);
      }, "advance"), Gi.prototype.eat = /* @__PURE__ */ l(function(d, f) {
        return f === void 0 && (f = !1), this.current(f) === d ? (this.advance(f), !0) : !1;
      }, "eat"), Z.validateRegExpFlags = function(o) {
        for (var d = o.validFlags, f = o.flags, g = 0; g < f.length; g++) {
          var S = f.charAt(g);
          d.indexOf(S) === -1 && this.raise(o.start, "Invalid regular expression flag"), f.indexOf(S, g + 1) > -1 && this.raise(o.start, "Duplicate regular expression flag");
        }
      }, Z.validateRegExpPattern = function(o) {
        this.regexp_pattern(o), !o.switchN && this.options.ecmaVersion >= 9 && o.groupNames.length > 0 && (o.switchN = !0, this.regexp_pattern(o));
      }, Z.regexp_pattern = function(o) {
        o.pos = 0, o.lastIntValue = 0, o.lastStringValue = "", o.lastAssertionIsQuantifiable = !1, o.numCapturingParens = 0, o.maxBackReference = 0, o.groupNames.length = 0, o.backReferenceNames.length = 0, this.regexp_disjunction(o), o.pos !== o.source.length && (o.eat(41) && o.raise("Unmatched ')'"), (o.eat(93) || o.eat(125)) && o.raise("Lone quantifier brackets")), o.maxBackReference > o.numCapturingParens && o.raise("Invalid escape");
        for (var d = 0, f = o.backReferenceNames; d < f.length; d += 1) {
          var g = f[d];
          o.groupNames.indexOf(g) === -1 && o.raise("Invalid named capture referenced");
        }
      }, Z.regexp_disjunction = function(o) {
        for (this.regexp_alternative(o); o.eat(124); )
          this.regexp_alternative(o);
        this.regexp_eatQuantifier(o, !0) && o.raise("Nothing to repeat"), o.eat(123) && o.raise("Lone quantifier brackets");
      }, Z.regexp_alternative = function(o) {
        for (; o.pos < o.source.length && this.regexp_eatTerm(o); )
          ;
      }, Z.regexp_eatTerm = function(o) {
        return this.regexp_eatAssertion(o) ? (o.lastAssertionIsQuantifiable && this.regexp_eatQuantifier(o) && o.switchU && o.raise("Invalid quantifier"), !0) : (o.switchU ? this.regexp_eatAtom(o) : this.regexp_eatExtendedAtom(o)) ? (this.regexp_eatQuantifier(o), !0) : !1;
      }, Z.regexp_eatAssertion = function(o) {
        var d = o.pos;
        if (o.lastAssertionIsQuantifiable = !1, o.eat(94) || o.eat(36))
          return !0;
        if (o.eat(92)) {
          if (o.eat(66) || o.eat(98))
            return !0;
          o.pos = d;
        }
        if (o.eat(40) && o.eat(63)) {
          var f = !1;
          if (this.options.ecmaVersion >= 9 && (f = o.eat(60)), o.eat(61) || o.eat(33))
            return this.regexp_disjunction(o), o.eat(41) || o.raise("Unterminated group"), o.lastAssertionIsQuantifiable = !f, !0;
        }
        return o.pos = d, !1;
      }, Z.regexp_eatQuantifier = function(o, d) {
        return d === void 0 && (d = !1), this.regexp_eatQuantifierPrefix(o, d) ? (o.eat(63), !0) : !1;
      }, Z.regexp_eatQuantifierPrefix = function(o, d) {
        return o.eat(42) || o.eat(43) || o.eat(63) || this.regexp_eatBracedQuantifier(o, d);
      }, Z.regexp_eatBracedQuantifier = function(o, d) {
        var f = o.pos;
        if (o.eat(123)) {
          var g = 0, S = -1;
          if (this.regexp_eatDecimalDigits(o) && (g = o.lastIntValue, o.eat(44) && this.regexp_eatDecimalDigits(o) && (S = o.lastIntValue), o.eat(125)))
            return S !== -1 && S < g && !d && o.raise("numbers out of order in {} quantifier"), !0;
          o.switchU && !d && o.raise("Incomplete quantifier"), o.pos = f;
        }
        return !1;
      }, Z.regexp_eatAtom = function(o) {
        return this.regexp_eatPatternCharacters(o) || o.eat(46) || this.regexp_eatReverseSolidusAtomEscape(o) || this.regexp_eatCharacterClass(o) || this.regexp_eatUncapturingGroup(o) || this.regexp_eatCapturingGroup(o);
      }, Z.regexp_eatReverseSolidusAtomEscape = function(o) {
        var d = o.pos;
        if (o.eat(92)) {
          if (this.regexp_eatAtomEscape(o))
            return !0;
          o.pos = d;
        }
        return !1;
      }, Z.regexp_eatUncapturingGroup = function(o) {
        var d = o.pos;
        if (o.eat(40)) {
          if (o.eat(63) && o.eat(58)) {
            if (this.regexp_disjunction(o), o.eat(41))
              return !0;
            o.raise("Unterminated group");
          }
          o.pos = d;
        }
        return !1;
      }, Z.regexp_eatCapturingGroup = function(o) {
        if (o.eat(40)) {
          if (this.options.ecmaVersion >= 9 ? this.regexp_groupSpecifier(o) : o.current() === 63 && o.raise("Invalid group"), this.regexp_disjunction(o), o.eat(41))
            return o.numCapturingParens += 1, !0;
          o.raise("Unterminated group");
        }
        return !1;
      }, Z.regexp_eatExtendedAtom = function(o) {
        return o.eat(46) || this.regexp_eatReverseSolidusAtomEscape(o) || this.regexp_eatCharacterClass(o) || this.regexp_eatUncapturingGroup(o) || this.regexp_eatCapturingGroup(o) || this.regexp_eatInvalidBracedQuantifier(o) || this.regexp_eatExtendedPatternCharacter(o);
      }, Z.regexp_eatInvalidBracedQuantifier = function(o) {
        return this.regexp_eatBracedQuantifier(o, !0) && o.raise("Nothing to repeat"), !1;
      }, Z.regexp_eatSyntaxCharacter = function(o) {
        var d = o.current();
        return qu(d) ? (o.lastIntValue = d, o.advance(), !0) : !1;
      };
      function qu(o) {
        return o === 36 || o >= 40 && o <= 43 || o === 46 || o === 63 || o >= 91 && o <= 94 || o >= 123 && o <= 125;
      }
      l(qu, "isSyntaxCharacter"), Z.regexp_eatPatternCharacters = function(o) {
        for (var d = o.pos, f = 0; (f = o.current()) !== -1 && !qu(f); )
          o.advance();
        return o.pos !== d;
      }, Z.regexp_eatExtendedPatternCharacter = function(o) {
        var d = o.current();
        return d !== -1 && d !== 36 && !(d >= 40 && d <= 43) && d !== 46 && d !== 63 && d !== 91 && d !== 94 && d !== 124 ? (o.advance(), !0) : !1;
      }, Z.regexp_groupSpecifier = function(o) {
        if (o.eat(63)) {
          if (this.regexp_eatGroupName(o)) {
            o.groupNames.indexOf(o.lastStringValue) !== -1 && o.raise("Duplicate capture group name"), o.groupNames.push(o.lastStringValue);
            return;
          }
          o.raise("Invalid group");
        }
      }, Z.regexp_eatGroupName = function(o) {
        if (o.lastStringValue = "", o.eat(60)) {
          if (this.regexp_eatRegExpIdentifierName(o) && o.eat(62))
            return !0;
          o.raise("Invalid capture group name");
        }
        return !1;
      }, Z.regexp_eatRegExpIdentifierName = function(o) {
        if (o.lastStringValue = "", this.regexp_eatRegExpIdentifierStart(o)) {
          for (o.lastStringValue += he(o.lastIntValue); this.regexp_eatRegExpIdentifierPart(o); )
            o.lastStringValue += he(o.lastIntValue);
          return !0;
        }
        return !1;
      }, Z.regexp_eatRegExpIdentifierStart = function(o) {
        var d = o.pos, f = this.options.ecmaVersion >= 11, g = o.current(f);
        return o.advance(f), g === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(o, f) && (g = o.lastIntValue), Xv(g) ? (o.lastIntValue = g, !0) : (o.pos = d, !1);
      };
      function Xv(o) {
        return k(o, !0) || o === 36 || o === 95;
      }
      l(Xv, "isRegExpIdentifierStart"), Z.regexp_eatRegExpIdentifierPart = function(o) {
        var d = o.pos, f = this.options.ecmaVersion >= 11, g = o.current(f);
        return o.advance(f), g === 92 && this.regexp_eatRegExpUnicodeEscapeSequence(o, f) && (g = o.lastIntValue), Jv(g) ? (o.lastIntValue = g, !0) : (o.pos = d, !1);
      };
      function Jv(o) {
        return D(o, !0) || o === 36 || o === 95 || o === 8204 || o === 8205;
      }
      l(Jv, "isRegExpIdentifierPart"), Z.regexp_eatAtomEscape = function(o) {
        return this.regexp_eatBackReference(o) || this.regexp_eatCharacterClassEscape(o) || this.regexp_eatCharacterEscape(o) || o.switchN && this.regexp_eatKGroupName(o) ? !0 : (o.switchU && (o.current() === 99 && o.raise("Invalid unicode escape"), o.raise("Invalid escape")), !1);
      }, Z.regexp_eatBackReference = function(o) {
        var d = o.pos;
        if (this.regexp_eatDecimalEscape(o)) {
          var f = o.lastIntValue;
          if (o.switchU)
            return f > o.maxBackReference && (o.maxBackReference = f), !0;
          if (f <= o.numCapturingParens)
            return !0;
          o.pos = d;
        }
        return !1;
      }, Z.regexp_eatKGroupName = function(o) {
        if (o.eat(107)) {
          if (this.regexp_eatGroupName(o))
            return o.backReferenceNames.push(o.lastStringValue), !0;
          o.raise("Invalid named reference");
        }
        return !1;
      }, Z.regexp_eatCharacterEscape = function(o) {
        return this.regexp_eatControlEscape(o) || this.regexp_eatCControlLetter(o) || this.regexp_eatZero(o) || this.regexp_eatHexEscapeSequence(o) || this.regexp_eatRegExpUnicodeEscapeSequence(o, !1) || !o.switchU && this.regexp_eatLegacyOctalEscapeSequence(o) || this.regexp_eatIdentityEscape(o);
      }, Z.regexp_eatCControlLetter = function(o) {
        var d = o.pos;
        if (o.eat(99)) {
          if (this.regexp_eatControlLetter(o))
            return !0;
          o.pos = d;
        }
        return !1;
      }, Z.regexp_eatZero = function(o) {
        return o.current() === 48 && !Ar(o.lookahead()) ? (o.lastIntValue = 0, o.advance(), !0) : !1;
      }, Z.regexp_eatControlEscape = function(o) {
        var d = o.current();
        return d === 116 ? (o.lastIntValue = 9, o.advance(), !0) : d === 110 ? (o.lastIntValue = 10, o.advance(), !0) : d === 118 ? (o.lastIntValue = 11, o.advance(), !0) : d === 102 ? (o.lastIntValue = 12, o.advance(), !0) : d === 114 ? (o.lastIntValue = 13, o.advance(), !0) : !1;
      }, Z.regexp_eatControlLetter = function(o) {
        var d = o.current();
        return zu(d) ? (o.lastIntValue = d % 32, o.advance(), !0) : !1;
      };
      function zu(o) {
        return o >= 65 && o <= 90 || o >= 97 && o <= 122;
      }
      l(zu, "isControlLetter"), Z.regexp_eatRegExpUnicodeEscapeSequence = function(o, d) {
        d === void 0 && (d = !1);
        var f = o.pos, g = d || o.switchU;
        if (o.eat(117)) {
          if (this.regexp_eatFixedHexDigits(o, 4)) {
            var S = o.lastIntValue;
            if (g && S >= 55296 && S <= 56319) {
              var T = o.pos;
              if (o.eat(92) && o.eat(117) && this.regexp_eatFixedHexDigits(o, 4)) {
                var A = o.lastIntValue;
                if (A >= 56320 && A <= 57343)
                  return o.lastIntValue = (S - 55296) * 1024 + (A - 56320) + 65536, !0;
              }
              o.pos = T, o.lastIntValue = S;
            }
            return !0;
          }
          if (g && o.eat(123) && this.regexp_eatHexDigits(o) && o.eat(125) && Zv(o.lastIntValue))
            return !0;
          g && o.raise("Invalid unicode escape"), o.pos = f;
        }
        return !1;
      };
      function Zv(o) {
        return o >= 0 && o <= 1114111;
      }
      l(Zv, "isValidUnicode"), Z.regexp_eatIdentityEscape = function(o) {
        if (o.switchU)
          return this.regexp_eatSyntaxCharacter(o) ? !0 : o.eat(47) ? (o.lastIntValue = 47, !0) : !1;
        var d = o.current();
        return d !== 99 && (!o.switchN || d !== 107) ? (o.lastIntValue = d, o.advance(), !0) : !1;
      }, Z.regexp_eatDecimalEscape = function(o) {
        o.lastIntValue = 0;
        var d = o.current();
        if (d >= 49 && d <= 57) {
          do
            o.lastIntValue = 10 * o.lastIntValue + (d - 48), o.advance();
          while ((d = o.current()) >= 48 && d <= 57);
          return !0;
        }
        return !1;
      }, Z.regexp_eatCharacterClassEscape = function(o) {
        var d = o.current();
        if (Qv(d))
          return o.lastIntValue = -1, o.advance(), !0;
        if (o.switchU && this.options.ecmaVersion >= 9 && (d === 80 || d === 112)) {
          if (o.lastIntValue = -1, o.advance(), o.eat(123) && this.regexp_eatUnicodePropertyValueExpression(o) && o.eat(125))
            return !0;
          o.raise("Invalid property name");
        }
        return !1;
      };
      function Qv(o) {
        return o === 100 || o === 68 || o === 115 || o === 83 || o === 119 || o === 87;
      }
      l(Qv, "isCharacterClassEscape"), Z.regexp_eatUnicodePropertyValueExpression = function(o) {
        var d = o.pos;
        if (this.regexp_eatUnicodePropertyName(o) && o.eat(61)) {
          var f = o.lastStringValue;
          if (this.regexp_eatUnicodePropertyValue(o)) {
            var g = o.lastStringValue;
            return this.regexp_validateUnicodePropertyNameAndValue(o, f, g), !0;
          }
        }
        if (o.pos = d, this.regexp_eatLoneUnicodePropertyNameOrValue(o)) {
          var S = o.lastStringValue;
          return this.regexp_validateUnicodePropertyNameOrValue(o, S), !0;
        }
        return !1;
      }, Z.regexp_validateUnicodePropertyNameAndValue = function(o, d, f) {
        Ce(o.unicodeProperties.nonBinary, d) || o.raise("Invalid property name"), o.unicodeProperties.nonBinary[d].test(f) || o.raise("Invalid property value");
      }, Z.regexp_validateUnicodePropertyNameOrValue = function(o, d) {
        o.unicodeProperties.binary.test(d) || o.raise("Invalid property name");
      }, Z.regexp_eatUnicodePropertyName = function(o) {
        var d = 0;
        for (o.lastStringValue = ""; Ku(d = o.current()); )
          o.lastStringValue += he(d), o.advance();
        return o.lastStringValue !== "";
      };
      function Ku(o) {
        return zu(o) || o === 95;
      }
      l(Ku, "isUnicodePropertyNameCharacter"), Z.regexp_eatUnicodePropertyValue = function(o) {
        var d = 0;
        for (o.lastStringValue = ""; e5(d = o.current()); )
          o.lastStringValue += he(d), o.advance();
        return o.lastStringValue !== "";
      };
      function e5(o) {
        return Ku(o) || Ar(o);
      }
      l(e5, "isUnicodePropertyValueCharacter"), Z.regexp_eatLoneUnicodePropertyNameOrValue = function(o) {
        return this.regexp_eatUnicodePropertyValue(o);
      }, Z.regexp_eatCharacterClass = function(o) {
        if (o.eat(91)) {
          if (o.eat(94), this.regexp_classRanges(o), o.eat(93))
            return !0;
          o.raise("Unterminated character class");
        }
        return !1;
      }, Z.regexp_classRanges = function(o) {
        for (; this.regexp_eatClassAtom(o); ) {
          var d = o.lastIntValue;
          if (o.eat(45) && this.regexp_eatClassAtom(o)) {
            var f = o.lastIntValue;
            o.switchU && (d === -1 || f === -1) && o.raise("Invalid character class"), d !== -1 && f !== -1 && d > f && o.raise("Range out of order in character class");
          }
        }
      }, Z.regexp_eatClassAtom = function(o) {
        var d = o.pos;
        if (o.eat(92)) {
          if (this.regexp_eatClassEscape(o))
            return !0;
          if (o.switchU) {
            var f = o.current();
            (f === 99 || Ju(f)) && o.raise("Invalid class escape"), o.raise("Invalid escape");
          }
          o.pos = d;
        }
        var g = o.current();
        return g !== 93 ? (o.lastIntValue = g, o.advance(), !0) : !1;
      }, Z.regexp_eatClassEscape = function(o) {
        var d = o.pos;
        if (o.eat(98))
          return o.lastIntValue = 8, !0;
        if (o.switchU && o.eat(45))
          return o.lastIntValue = 45, !0;
        if (!o.switchU && o.eat(99)) {
          if (this.regexp_eatClassControlLetter(o))
            return !0;
          o.pos = d;
        }
        return this.regexp_eatCharacterClassEscape(o) || this.regexp_eatCharacterEscape(o);
      }, Z.regexp_eatClassControlLetter = function(o) {
        var d = o.current();
        return Ar(d) || d === 95 ? (o.lastIntValue = d % 32, o.advance(), !0) : !1;
      }, Z.regexp_eatHexEscapeSequence = function(o) {
        var d = o.pos;
        if (o.eat(120)) {
          if (this.regexp_eatFixedHexDigits(o, 2))
            return !0;
          o.switchU && o.raise("Invalid escape"), o.pos = d;
        }
        return !1;
      }, Z.regexp_eatDecimalDigits = function(o) {
        var d = o.pos, f = 0;
        for (o.lastIntValue = 0; Ar(f = o.current()); )
          o.lastIntValue = 10 * o.lastIntValue + (f - 48), o.advance();
        return o.pos !== d;
      };
      function Ar(o) {
        return o >= 48 && o <= 57;
      }
      l(Ar, "isDecimalDigit"), Z.regexp_eatHexDigits = function(o) {
        var d = o.pos, f = 0;
        for (o.lastIntValue = 0; Yu(f = o.current()); )
          o.lastIntValue = 16 * o.lastIntValue + Xu(f), o.advance();
        return o.pos !== d;
      };
      function Yu(o) {
        return o >= 48 && o <= 57 || o >= 65 && o <= 70 || o >= 97 && o <= 102;
      }
      l(Yu, "isHexDigit");
      function Xu(o) {
        return o >= 65 && o <= 70 ? 10 + (o - 65) : o >= 97 && o <= 102 ? 10 + (o - 97) : o - 48;
      }
      l(Xu, "hexToInt"), Z.regexp_eatLegacyOctalEscapeSequence = function(o) {
        if (this.regexp_eatOctalDigit(o)) {
          var d = o.lastIntValue;
          if (this.regexp_eatOctalDigit(o)) {
            var f = o.lastIntValue;
            d <= 3 && this.regexp_eatOctalDigit(o) ? o.lastIntValue = d * 64 + f * 8 + o.lastIntValue : o.lastIntValue = d * 8 + f;
          } else
            o.lastIntValue = d;
          return !0;
        }
        return !1;
      }, Z.regexp_eatOctalDigit = function(o) {
        var d = o.current();
        return Ju(d) ? (o.lastIntValue = d - 48, o.advance(), !0) : (o.lastIntValue = 0, !1);
      };
      function Ju(o) {
        return o >= 48 && o <= 55;
      }
      l(Ju, "isOctalDigit"), Z.regexp_eatFixedHexDigits = function(o, d) {
        var f = o.pos;
        o.lastIntValue = 0;
        for (var g = 0; g < d; ++g) {
          var S = o.current();
          if (!Yu(S))
            return o.pos = f, !1;
          o.lastIntValue = 16 * o.lastIntValue + Xu(S), o.advance();
        }
        return !0;
      };
      var ma = /* @__PURE__ */ l(function(d) {
        this.type = d.type, this.value = d.value, this.start = d.start, this.end = d.end, d.options.locations && (this.loc = new ai(d, d.startLoc, d.endLoc)), d.options.ranges && (this.range = [d.start, d.end]);
      }, "Token"), be = Ye.prototype;
      be.next = function(o) {
        !o && this.type.keyword && this.containsEsc && this.raiseRecoverable(this.start, "Escape sequence in keyword " + this.type.keyword), this.options.onToken && this.options.onToken(new ma(this)), this.lastTokEnd = this.end, this.lastTokStart = this.start, this.lastTokEndLoc = this.endLoc, this.lastTokStartLoc = this.startLoc, this.nextToken();
      }, be.getToken = function() {
        return this.next(), new ma(this);
      }, typeof Symbol < "u" && (be[Symbol.iterator] = function() {
        var o = this;
        return {
          next: function() {
            var d = o.getToken();
            return {
              done: d.type === v.eof,
              value: d
            };
          }
        };
      }), be.nextToken = function() {
        var o = this.curContext();
        if ((!o || !o.preserveSpace) && this.skipSpace(), this.start = this.pos, this.options.locations && (this.startLoc = this.curPosition()), this.pos >= this.input.length)
          return this.finishToken(v.eof);
        if (o.override)
          return o.override(this);
        this.readToken(this.fullCharCodeAtPos());
      }, be.readToken = function(o) {
        return k(o, this.options.ecmaVersion >= 6) || o === 92 ? this.readWord() : this.getTokenFromCode(o);
      }, be.fullCharCodeAtPos = function() {
        var o = this.input.charCodeAt(this.pos);
        if (o <= 55295 || o >= 56320)
          return o;
        var d = this.input.charCodeAt(this.pos + 1);
        return d <= 56319 || d >= 57344 ? o : (o << 10) + d - 56613888;
      }, be.skipBlockComment = function() {
        var o = this.options.onComment && this.curPosition(), d = this.pos, f = this.input.indexOf("*/", this.pos += 2);
        if (f === -1 && this.raise(this.pos - 2, "Unterminated comment"), this.pos = f + 2, this.options.locations)
          for (var g = void 0, S = d; (g = Q(this.input, S, this.pos)) > -1; )
            ++this.curLine, S = this.lineStart = g;
        this.options.onComment && this.options.onComment(!0, this.input.slice(d + 2, f), d, this.pos, o, this.curPosition());
      }, be.skipLineComment = function(o) {
        for (var d = this.pos, f = this.options.onComment && this.curPosition(), g = this.input.charCodeAt(this.pos += o); this.pos < this.input.length && !ae(g); )
          g = this.input.charCodeAt(++this.pos);
        this.options.onComment && this.options.onComment(!1, this.input.slice(d + o, this.pos), d, this.pos, f, this.curPosition());
      }, be.skipSpace = function() {
        e:
          for (; this.pos < this.input.length; ) {
            var o = this.input.charCodeAt(this.pos);
            switch (o) {
              case 32:
              case 160:
                ++this.pos;
                break;
              case 13:
                this.input.charCodeAt(this.pos + 1) === 10 && ++this.pos;
              case 10:
              case 8232:
              case 8233:
                ++this.pos, this.options.locations && (++this.curLine, this.lineStart = this.pos);
                break;
              case 47:
                switch (this.input.charCodeAt(this.pos + 1)) {
                  case 42:
                    this.skipBlockComment();
                    break;
                  case 47:
                    this.skipLineComment(2);
                    break;
                  default:
                    break e;
                }
                break;
              default:
                if (o > 8 && o < 14 || o >= 5760 && Xe.test(String.fromCharCode(o)))
                  ++this.pos;
                else
                  break e;
            }
          }
      }, be.finishToken = function(o, d) {
        this.end = this.pos, this.options.locations && (this.endLoc = this.curPosition());
        var f = this.type;
        this.type = o, this.value = d, this.updateContext(f);
      }, be.readToken_dot = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        if (o >= 48 && o <= 57)
          return this.readNumber(!0);
        var d = this.input.charCodeAt(this.pos + 2);
        return this.options.ecmaVersion >= 6 && o === 46 && d === 46 ? (this.pos += 3, this.finishToken(v.ellipsis)) : (++this.pos, this.finishToken(v.dot));
      }, be.readToken_slash = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        return this.exprAllowed ? (++this.pos, this.readRegexp()) : o === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.slash, 1);
      }, be.readToken_mult_modulo_exp = function(o) {
        var d = this.input.charCodeAt(this.pos + 1), f = 1, g = o === 42 ? v.star : v.modulo;
        return this.options.ecmaVersion >= 7 && o === 42 && d === 42 && (++f, g = v.starstar, d = this.input.charCodeAt(this.pos + 2)), d === 61 ? this.finishOp(v.assign, f + 1) : this.finishOp(g, f);
      }, be.readToken_pipe_amp = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        if (d === o) {
          if (this.options.ecmaVersion >= 12) {
            var f = this.input.charCodeAt(this.pos + 2);
            if (f === 61)
              return this.finishOp(v.assign, 3);
          }
          return this.finishOp(o === 124 ? v.logicalOR : v.logicalAND, 2);
        }
        return d === 61 ? this.finishOp(v.assign, 2) : this.finishOp(o === 124 ? v.bitwiseOR : v.bitwiseAND, 1);
      }, be.readToken_caret = function() {
        var o = this.input.charCodeAt(this.pos + 1);
        return o === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.bitwiseXOR, 1);
      }, be.readToken_plus_min = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        return d === o ? d === 45 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 62 && (this.lastTokEnd === 0 || H.test(this.input.slice(this.lastTokEnd, this.pos))) ? (this.skipLineComment(3), this.skipSpace(), this.nextToken()) : this.finishOp(v.incDec, 2) : d === 61 ? this.finishOp(v.assign, 2) : this.finishOp(v.plusMin, 1);
      }, be.readToken_lt_gt = function(o) {
        var d = this.input.charCodeAt(this.pos + 1), f = 1;
        return d === o ? (f = o === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2, this.input.charCodeAt(this.pos + f) === 61 ? this.finishOp(v.assign, f + 1) : this.finishOp(v.bitShift, f)) : d === 33 && o === 60 && !this.inModule && this.input.charCodeAt(this.pos + 2) === 45 && this.input.charCodeAt(this.pos + 3) === 45 ? (this.skipLineComment(4), this.skipSpace(), this.nextToken()) : (d === 61 && (f = 2), this.finishOp(v.relational, f));
      }, be.readToken_eq_excl = function(o) {
        var d = this.input.charCodeAt(this.pos + 1);
        return d === 61 ? this.finishOp(v.equality, this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2) : o === 61 && d === 62 && this.options.ecmaVersion >= 6 ? (this.pos += 2, this.finishToken(v.arrow)) : this.finishOp(o === 61 ? v.eq : v.prefix, 1);
      }, be.readToken_question = function() {
        var o = this.options.ecmaVersion;
        if (o >= 11) {
          var d = this.input.charCodeAt(this.pos + 1);
          if (d === 46) {
            var f = this.input.charCodeAt(this.pos + 2);
            if (f < 48 || f > 57)
              return this.finishOp(v.questionDot, 2);
          }
          if (d === 63) {
            if (o >= 12) {
              var g = this.input.charCodeAt(this.pos + 2);
              if (g === 61)
                return this.finishOp(v.assign, 3);
            }
            return this.finishOp(v.coalesce, 2);
          }
        }
        return this.finishOp(v.question, 1);
      }, be.readToken_numberSign = function() {
        var o = this.options.ecmaVersion, d = 35;
        if (o >= 13 && (++this.pos, d = this.fullCharCodeAtPos(), k(d, !0) || d === 92))
          return this.finishToken(v.privateId, this.readWord1());
        this.raise(this.pos, "Unexpected character '" + he(d) + "'");
      }, be.getTokenFromCode = function(o) {
        switch (o) {
          case 46:
            return this.readToken_dot();
          case 40:
            return ++this.pos, this.finishToken(v.parenL);
          case 41:
            return ++this.pos, this.finishToken(v.parenR);
          case 59:
            return ++this.pos, this.finishToken(v.semi);
          case 44:
            return ++this.pos, this.finishToken(v.comma);
          case 91:
            return ++this.pos, this.finishToken(v.bracketL);
          case 93:
            return ++this.pos, this.finishToken(v.bracketR);
          case 123:
            return ++this.pos, this.finishToken(v.braceL);
          case 125:
            return ++this.pos, this.finishToken(v.braceR);
          case 58:
            return ++this.pos, this.finishToken(v.colon);
          case 96:
            if (this.options.ecmaVersion < 6)
              break;
            return ++this.pos, this.finishToken(v.backQuote);
          case 48:
            var d = this.input.charCodeAt(this.pos + 1);
            if (d === 120 || d === 88)
              return this.readRadixNumber(16);
            if (this.options.ecmaVersion >= 6) {
              if (d === 111 || d === 79)
                return this.readRadixNumber(8);
              if (d === 98 || d === 66)
                return this.readRadixNumber(2);
            }
          case 49:
          case 50:
          case 51:
          case 52:
          case 53:
          case 54:
          case 55:
          case 56:
          case 57:
            return this.readNumber(!1);
          case 34:
          case 39:
            return this.readString(o);
          case 47:
            return this.readToken_slash();
          case 37:
          case 42:
            return this.readToken_mult_modulo_exp(o);
          case 124:
          case 38:
            return this.readToken_pipe_amp(o);
          case 94:
            return this.readToken_caret();
          case 43:
          case 45:
            return this.readToken_plus_min(o);
          case 60:
          case 62:
            return this.readToken_lt_gt(o);
          case 61:
          case 33:
            return this.readToken_eq_excl(o);
          case 63:
            return this.readToken_question();
          case 126:
            return this.finishOp(v.prefix, 1);
          case 35:
            return this.readToken_numberSign();
        }
        this.raise(this.pos, "Unexpected character '" + he(o) + "'");
      }, be.finishOp = function(o, d) {
        var f = this.input.slice(this.pos, this.pos + d);
        return this.pos += d, this.finishToken(o, f);
      }, be.readRegexp = function() {
        for (var o, d, f = this.pos; ; ) {
          this.pos >= this.input.length && this.raise(f, "Unterminated regular expression");
          var g = this.input.charAt(this.pos);
          if (H.test(g) && this.raise(f, "Unterminated regular expression"), o)
            o = !1;
          else {
            if (g === "[")
              d = !0;
            else if (g === "]" && d)
              d = !1;
            else if (g === "/" && !d)
              break;
            o = g === "\\";
          }
          ++this.pos;
        }
        var S = this.input.slice(f, this.pos);
        ++this.pos;
        var T = this.pos, A = this.readWord1();
        this.containsEsc && this.unexpected(T);
        var B = this.regexpState || (this.regexpState = new Gi(this));
        B.reset(f, S, A), this.validateRegExpFlags(B), this.validateRegExpPattern(B);
        var V = null;
        try {
          V = new RegExp(S, A);
        } catch {
        }
        return this.finishToken(v.regexp, { pattern: S, flags: A, value: V });
      }, be.readInt = function(o, d, f) {
        for (var g = this.options.ecmaVersion >= 12 && d === void 0, S = f && this.input.charCodeAt(this.pos) === 48, T = this.pos, A = 0, B = 0, V = 0, ue = d == null ? 1 / 0 : d; V < ue; ++V, ++this.pos) {
          var ge = this.input.charCodeAt(this.pos), mt = void 0;
          if (g && ge === 95) {
            S && this.raiseRecoverable(this.pos, "Numeric separator is not allowed in legacy octal numeric literals"), B === 95 && this.raiseRecoverable(this.pos, "Numeric separator must be exactly one underscore"), V === 0 && this.raiseRecoverable(this.pos, "Numeric separator is not allowed at the first of digits"), B = ge;
            continue;
          }
          if (ge >= 97 ? mt = ge - 97 + 10 : ge >= 65 ? mt = ge - 65 + 10 : ge >= 48 && ge <= 57 ? mt = ge - 48 : mt = 1 / 0, mt >= o)
            break;
          B = ge, A = A * o + mt;
        }
        return g && B === 95 && this.raiseRecoverable(this.pos - 1, "Numeric separator is not allowed at the last of digits"), this.pos === T || d != null && this.pos - T !== d ? null : A;
      };
      function t5(o, d) {
        return d ? parseInt(o, 8) : parseFloat(o.replace(/_/g, ""));
      }
      l(t5, "stringToNumber");
      function Zu(o) {
        return typeof BigInt != "function" ? null : BigInt(o.replace(/_/g, ""));
      }
      l(Zu, "stringToBigInt"), be.readRadixNumber = function(o) {
        var d = this.pos;
        this.pos += 2;
        var f = this.readInt(o);
        return f == null && this.raise(this.start + 2, "Expected number in radix " + o), this.options.ecmaVersion >= 11 && this.input.charCodeAt(this.pos) === 110 ? (f = Zu(this.input.slice(d, this.pos)), ++this.pos) : k(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(v.num, f);
      }, be.readNumber = function(o) {
        var d = this.pos;
        !o && this.readInt(10, void 0, !0) === null && this.raise(d, "Invalid number");
        var f = this.pos - d >= 2 && this.input.charCodeAt(d) === 48;
        f && this.strict && this.raise(d, "Invalid number");
        var g = this.input.charCodeAt(this.pos);
        if (!f && !o && this.options.ecmaVersion >= 11 && g === 110) {
          var S = Zu(this.input.slice(d, this.pos));
          return ++this.pos, k(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number"), this.finishToken(v.num, S);
        }
        f && /[89]/.test(this.input.slice(d, this.pos)) && (f = !1), g === 46 && !f && (++this.pos, this.readInt(10), g = this.input.charCodeAt(this.pos)), (g === 69 || g === 101) && !f && (g = this.input.charCodeAt(++this.pos), (g === 43 || g === 45) && ++this.pos, this.readInt(10) === null && this.raise(d, "Invalid number")), k(this.fullCharCodeAtPos()) && this.raise(this.pos, "Identifier directly after number");
        var T = t5(this.input.slice(d, this.pos), f);
        return this.finishToken(v.num, T);
      }, be.readCodePoint = function() {
        var o = this.input.charCodeAt(this.pos), d;
        if (o === 123) {
          this.options.ecmaVersion < 6 && this.unexpected();
          var f = ++this.pos;
          d = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos), ++this.pos, d > 1114111 && this.invalidStringToken(f, "Code point out of bounds");
        } else
          d = this.readHexChar(4);
        return d;
      }, be.readString = function(o) {
        for (var d = "", f = ++this.pos; ; ) {
          this.pos >= this.input.length && this.raise(this.start, "Unterminated string constant");
          var g = this.input.charCodeAt(this.pos);
          if (g === o)
            break;
          g === 92 ? (d += this.input.slice(f, this.pos), d += this.readEscapedChar(!1), f = this.pos) : g === 8232 || g === 8233 ? (this.options.ecmaVersion < 10 && this.raise(this.start, "Unterminated string constant"), ++this.pos, this.options.locations && (this.curLine++, this.lineStart = this.pos)) : (ae(g) && this.raise(this.start, "Unterminated string constant"), ++this.pos);
        }
        return d += this.input.slice(f, this.pos++), this.finishToken(v.string, d);
      };
      var i5 = {};
      be.tryReadTemplateToken = function() {
        this.inTemplateElement = !0;
        try {
          this.readTmplToken();
        } catch (o) {
          if (o === i5)
            this.readInvalidTemplateToken();
          else
            throw o;
        }
        this.inTemplateElement = !1;
      }, be.invalidStringToken = function(o, d) {
        if (this.inTemplateElement && this.options.ecmaVersion >= 9)
          throw i5;
        this.raise(o, d);
      }, be.readTmplToken = function() {
        for (var o = "", d = this.pos; ; ) {
          this.pos >= this.input.length && this.raise(this.start, "Unterminated template");
          var f = this.input.charCodeAt(this.pos);
          if (f === 96 || f === 36 && this.input.charCodeAt(this.pos + 1) === 123)
            return this.pos === this.start && (this.type === v.template || this.type === v.invalidTemplate) ? f === 36 ? (this.pos += 2, this.finishToken(v.dollarBraceL)) : (++this.pos, this.finishToken(v.backQuote)) : (o += this.input.slice(d, this.pos), this.finishToken(v.template, o));
          if (f === 92)
            o += this.input.slice(d, this.pos), o += this.readEscapedChar(!0), d = this.pos;
          else if (ae(f)) {
            switch (o += this.input.slice(d, this.pos), ++this.pos, f) {
              case 13:
                this.input.charCodeAt(this.pos) === 10 && ++this.pos;
              case 10:
                o += `
`;
                break;
              default:
                o += String.fromCharCode(f);
                break;
            }
            this.options.locations && (++this.curLine, this.lineStart = this.pos), d = this.pos;
          } else
            ++this.pos;
        }
      }, be.readInvalidTemplateToken = function() {
        for (; this.pos < this.input.length; this.pos++)
          switch (this.input[this.pos]) {
            case "\\":
              ++this.pos;
              break;
            case "$":
              if (this.input[this.pos + 1] !== "{")
                break;
            case "`":
              return this.finishToken(v.invalidTemplate, this.input.slice(this.start, this.pos));
          }
        this.raise(this.start, "Unterminated template");
      }, be.readEscapedChar = function(o) {
        var d = this.input.charCodeAt(++this.pos);
        switch (++this.pos, d) {
          case 110:
            return `
`;
          case 114:
            return "\r";
          case 120:
            return String.fromCharCode(this.readHexChar(2));
          case 117:
            return he(this.readCodePoint());
          case 116:
            return "	";
          case 98:
            return "\b";
          case 118:
            return "\v";
          case 102:
            return "\f";
          case 13:
            this.input.charCodeAt(this.pos) === 10 && ++this.pos;
          case 10:
            return this.options.locations && (this.lineStart = this.pos, ++this.curLine), "";
          case 56:
          case 57:
            if (this.strict && this.invalidStringToken(this.pos - 1, "Invalid escape sequence"), o) {
              var f = this.pos - 1;
              return this.invalidStringToken(f, "Invalid escape sequence in template string"), null;
            }
          default:
            if (d >= 48 && d <= 55) {
              var g = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0], S = parseInt(g, 8);
              return S > 255 && (g = g.slice(0, -1), S = parseInt(g, 8)), this.pos += g.length - 1, d = this.input.charCodeAt(this.pos), (g !== "0" || d === 56 || d === 57) && (this.strict || o) && this.invalidStringToken(this.pos - 1 - g.length, o ? "Octal literal in template string" : "Octal literal in strict mode"), String.fromCharCode(S);
            }
            return ae(d) ? "" : String.fromCharCode(d);
        }
      }, be.readHexChar = function(o) {
        var d = this.pos, f = this.readInt(16, o);
        return f === null && this.invalidStringToken(d, "Bad character escape sequence"), f;
      }, be.readWord1 = function() {
        this.containsEsc = !1;
        for (var o = "", d = !0, f = this.pos, g = this.options.ecmaVersion >= 6; this.pos < this.input.length; ) {
          var S = this.fullCharCodeAtPos();
          if (D(S, g))
            this.pos += S <= 65535 ? 1 : 2;
          else if (S === 92) {
            this.containsEsc = !0, o += this.input.slice(f, this.pos);
            var T = this.pos;
            this.input.charCodeAt(++this.pos) !== 117 && this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX"), ++this.pos;
            var A = this.readCodePoint();
            (d ? k : D)(A, g) || this.invalidStringToken(T, "Invalid Unicode escape"), o += he(A), f = this.pos;
          } else
            break;
          d = !1;
        }
        return o + this.input.slice(f, this.pos);
      }, be.readWord = function() {
        var o = this.readWord1(), d = v.name;
        return this.keywords.test(o) && (d = K[o]), this.finishToken(d, o);
      };
      var n5 = "8.8.0";
      Ye.acorn = {
        Parser: Ye,
        version: n5,
        defaultOptions: kt,
        Position: Ut,
        SourceLocation: ai,
        getLineInfo: ln,
        Node: xr,
        TokenType: I,
        tokTypes: v,
        keywordTypes: K,
        TokContext: Zt,
        tokContexts: Ue,
        isIdentifierChar: D,
        isIdentifierStart: k,
        Token: ma,
        isNewLine: ae,
        lineBreak: H,
        lineBreakG: ce,
        nonASCIIwhitespace: Xe
      };
      function s5(o, d) {
        return Ye.parse(o, d);
      }
      l(s5, "parse");
      function r5(o, d, f) {
        return Ye.parseExpressionAt(o, d, f);
      }
      l(r5, "parseExpressionAt");
      function o5(o, d) {
        return Ye.tokenizer(o, d);
      }
      l(o5, "tokenizer"), i.Node = xr, i.Parser = Ye, i.Position = Ut, i.SourceLocation = ai, i.TokContext = Zt, i.Token = ma, i.TokenType = I, i.defaultOptions = kt, i.getLineInfo = ln, i.isIdentifierChar = D, i.isIdentifierStart = k, i.isNewLine = ae, i.keywordTypes = K, i.lineBreak = H, i.lineBreakG = ce, i.nonASCIIwhitespace = Xe, i.parse = s5, i.parseExpressionAt = r5, i.tokContexts = Ue, i.tokTypes = v, i.tokenizer = o5, i.version = n5, Object.defineProperty(i, "__esModule", { value: !0 });
    });
  }
}), H3 = X({
  "node_modules/jintr/dist/src/main.js"(e) {
    var t = e && e.__importDefault || function(r) {
      return r && r.__esModule ? r : { default: r };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(U3()), n = j3(), s = class {
      constructor(r) {
        const a = (0, n.parse)(r, { ecmaVersion: 2020 });
        this.ast = a.body, this.visitor = new i.default(this.ast), this.scope = this.visitor.scope, this.visitor.on("console", (u, c) => {
          if (u.type === "Identifier")
            return console;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((b) => c.visitNode(b)), m = console[h];
          return m ? m(...p) : "proceed";
        }), this.visitor.on("Math", (u, c) => {
          if (u.type === "Identifier")
            return Math;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((b) => c.visitNode(b)), m = Math[h];
          return m ? m(...p) : "proceed";
        }), this.visitor.on("String", (u, c) => {
          if (u.type === "Identifier")
            return String;
          const h = c.visitNode(u.callee.property), p = u.arguments.map((b) => c.visitNode(b)), m = String[h];
          return m ? m(p) : "proceed";
        }), this.visitor.on("Date", (u) => {
          if (u.type === "Identifier")
            return Date;
        });
      }
      interpret() {
        return this.visitor.run();
      }
    };
    l(s, "Jinter"), e.default = s;
  }
}), W3 = X({
  "node_modules/jintr/dist/index.js"(e) {
    var t = e && e.__importDefault || function(n) {
      return n && n.__esModule ? n : { default: n };
    };
    Object.defineProperty(e, "__esModule", { value: !0 });
    var i = t(H3());
    e.default = i.default;
  }
}), $3 = X({
  "node_modules/linkedom/commonjs/perf_hooks.cjs"(e) {
    try {
      const { performance: t } = Y2("perf_hooks");
      e.performance = t;
    } catch {
      e.performance = { now() {
        return +new Date();
      } };
    }
  }
}), fr = X({
  "node_modules/boolbase/index.js"(e, t) {
    t.exports = {
      trueFunc: /* @__PURE__ */ l(function() {
        return !0;
      }, "trueFunc"),
      falseFunc: /* @__PURE__ */ l(function() {
        return !1;
      }, "falseFunc")
    };
  }
}), X2 = X({
  "node_modules/cssom/lib/StyleSheet.js"(e) {
    var t = {};
    t.StyleSheet = /* @__PURE__ */ l(function() {
      this.parentStyleSheet = null;
    }, "StyleSheet"), e.StyleSheet = t.StyleSheet;
  }
}), Jt = X({
  "node_modules/cssom/lib/CSSRule.js"(e) {
    var t = {};
    t.CSSRule = /* @__PURE__ */ l(function() {
      this.parentRule = null, this.parentStyleSheet = null;
    }, "CSSRule"), t.CSSRule.UNKNOWN_RULE = 0, t.CSSRule.STYLE_RULE = 1, t.CSSRule.CHARSET_RULE = 2, t.CSSRule.IMPORT_RULE = 3, t.CSSRule.MEDIA_RULE = 4, t.CSSRule.FONT_FACE_RULE = 5, t.CSSRule.PAGE_RULE = 6, t.CSSRule.KEYFRAMES_RULE = 7, t.CSSRule.KEYFRAME_RULE = 8, t.CSSRule.MARGIN_RULE = 9, t.CSSRule.NAMESPACE_RULE = 10, t.CSSRule.COUNTER_STYLE_RULE = 11, t.CSSRule.SUPPORTS_RULE = 12, t.CSSRule.DOCUMENT_RULE = 13, t.CSSRule.FONT_FEATURE_VALUES_RULE = 14, t.CSSRule.VIEWPORT_RULE = 15, t.CSSRule.REGION_STYLE_RULE = 16, t.CSSRule.prototype = {
      constructor: t.CSSRule
    }, e.CSSRule = t.CSSRule;
  }
}), ql = X({
  "node_modules/cssom/lib/CSSStyleRule.js"(e) {
    var t = {
      CSSStyleDeclaration: vr().CSSStyleDeclaration,
      CSSRule: Jt().CSSRule
    };
    t.CSSStyleRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.selectorText = "", this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSStyleRule"), t.CSSStyleRule.prototype = new t.CSSRule(), t.CSSStyleRule.prototype.constructor = t.CSSStyleRule, t.CSSStyleRule.prototype.type = 1, Object.defineProperty(t.CSSStyleRule.prototype, "cssText", {
      get: function() {
        var i;
        return this.selectorText ? i = this.selectorText + " {" + this.style.cssText + "}" : i = "", i;
      },
      set: function(i) {
        var n = t.CSSStyleRule.parse(i);
        this.style = n.style, this.selectorText = n.selectorText;
      }
    }), t.CSSStyleRule.parse = function(i) {
      for (var n = 0, s = "selector", r, a = n, u = "", c = {
        selector: !0,
        value: !0
      }, h = new t.CSSStyleRule(), p, m = "", b; b = i.charAt(n); n++)
        switch (b) {
          case " ":
          case "	":
          case "\r":
          case `
`:
          case "\f":
            if (c[s])
              switch (i.charAt(n - 1)) {
                case " ":
                case "	":
                case "\r":
                case `
`:
                case "\f":
                  break;
                default:
                  u += " ";
                  break;
              }
            break;
          case '"':
            if (a = n + 1, r = i.indexOf('"', a) + 1, !r)
              throw '" is missing';
            u += i.slice(n, r), n = r - 1;
            break;
          case "'":
            if (a = n + 1, r = i.indexOf("'", a) + 1, !r)
              throw "' is missing";
            u += i.slice(n, r), n = r - 1;
            break;
          case "/":
            if (i.charAt(n + 1) === "*") {
              if (n += 2, r = i.indexOf("*/", n), r === -1)
                throw new SyntaxError("Missing */");
              n = r + 1;
            } else
              u += b;
            break;
          case "{":
            s === "selector" && (h.selectorText = u.trim(), u = "", s = "name");
            break;
          case ":":
            s === "name" ? (p = u.trim(), u = "", s = "value") : u += b;
            break;
          case "!":
            s === "value" && i.indexOf("!important", n) === n ? (m = "important", n += 9) : u += b;
            break;
          case ";":
            s === "value" ? (h.style.setProperty(p, u.trim(), m), m = "", u = "", s = "name") : u += b;
            break;
          case "}":
            if (s === "value")
              h.style.setProperty(p, u.trim(), m), m = "", u = "";
            else {
              if (s === "name")
                break;
              u += b;
            }
            s = "selector";
            break;
          default:
            u += b;
            break;
        }
      return h;
    }, e.CSSStyleRule = t.CSSStyleRule;
  }
}), zl = X({
  "node_modules/cssom/lib/CSSStyleSheet.js"(e) {
    var t = {
      StyleSheet: X2().StyleSheet,
      CSSStyleRule: ql().CSSStyleRule
    };
    t.CSSStyleSheet = /* @__PURE__ */ l(function() {
      t.StyleSheet.call(this), this.cssRules = [];
    }, "CSSStyleSheet"), t.CSSStyleSheet.prototype = new t.StyleSheet(), t.CSSStyleSheet.prototype.constructor = t.CSSStyleSheet, t.CSSStyleSheet.prototype.insertRule = function(i, n) {
      if (n < 0 || n > this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      var s = t.parse(i).cssRules[0];
      return s.parentStyleSheet = this, this.cssRules.splice(n, 0, s), n;
    }, t.CSSStyleSheet.prototype.deleteRule = function(i) {
      if (i < 0 || i >= this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      this.cssRules.splice(i, 1);
    }, t.CSSStyleSheet.prototype.toString = function() {
      for (var i = "", n = this.cssRules, s = 0; s < n.length; s++)
        i += n[s].cssText + `
`;
      return i;
    }, e.CSSStyleSheet = t.CSSStyleSheet, t.parse = Mc().parse;
  }
}), Ec = X({
  "node_modules/cssom/lib/MediaList.js"(e) {
    var t = {};
    t.MediaList = /* @__PURE__ */ l(function() {
      this.length = 0;
    }, "MediaList"), t.MediaList.prototype = {
      constructor: t.MediaList,
      get mediaText() {
        return Array.prototype.join.call(this, ", ");
      },
      set mediaText(i) {
        for (var n = i.split(","), s = this.length = n.length, r = 0; r < s; r++)
          this[r] = n[r].trim();
      },
      appendMedium: function(i) {
        Array.prototype.indexOf.call(this, i) === -1 && (this[this.length] = i, this.length++);
      },
      deleteMedium: function(i) {
        var n = Array.prototype.indexOf.call(this, i);
        n !== -1 && Array.prototype.splice.call(this, n, 1);
      }
    }, e.MediaList = t.MediaList;
  }
}), J2 = X({
  "node_modules/cssom/lib/CSSImportRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      CSSStyleSheet: zl().CSSStyleSheet,
      MediaList: Ec().MediaList
    };
    t.CSSImportRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.href = "", this.media = new t.MediaList(), this.styleSheet = new t.CSSStyleSheet();
    }, "CSSImportRule"), t.CSSImportRule.prototype = new t.CSSRule(), t.CSSImportRule.prototype.constructor = t.CSSImportRule, t.CSSImportRule.prototype.type = 3, Object.defineProperty(t.CSSImportRule.prototype, "cssText", {
      get: function() {
        var i = this.media.mediaText;
        return "@import url(" + this.href + ")" + (i ? " " + i : "") + ";";
      },
      set: function(i) {
        for (var n = 0, s = "", r = "", a, u; u = i.charAt(n); n++)
          switch (u) {
            case " ":
            case "	":
            case "\r":
            case `
`:
            case "\f":
              s === "after-import" ? s = "url" : r += u;
              break;
            case "@":
              !s && i.indexOf("@import", n) === n && (s = "after-import", n += 6, r = "");
              break;
            case "u":
              if (s === "url" && i.indexOf("url(", n) === n) {
                if (a = i.indexOf(")", n + 1), a === -1)
                  throw n + ': ")" not found';
                n += 4;
                var c = i.slice(n, a);
                c[0] === c[c.length - 1] && (c[0] === '"' || c[0] === "'") && (c = c.slice(1, -1)), this.href = c, n = a, s = "media";
              }
              break;
            case '"':
              if (s === "url") {
                if (a = i.indexOf('"', n + 1), !a)
                  throw n + `: '"' not found`;
                this.href = i.slice(n + 1, a), n = a, s = "media";
              }
              break;
            case "'":
              if (s === "url") {
                if (a = i.indexOf("'", n + 1), !a)
                  throw n + `: "'" not found`;
                this.href = i.slice(n + 1, a), n = a, s = "media";
              }
              break;
            case ";":
              s === "media" && r && (this.media.mediaText = r.trim());
              break;
            default:
              s === "media" && (r += u);
              break;
          }
      }
    }), e.CSSImportRule = t.CSSImportRule;
  }
}), mr = X({
  "node_modules/cssom/lib/CSSGroupingRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule
    };
    t.CSSGroupingRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.cssRules = [];
    }, "CSSGroupingRule"), t.CSSGroupingRule.prototype = new t.CSSRule(), t.CSSGroupingRule.prototype.constructor = t.CSSGroupingRule, t.CSSGroupingRule.prototype.insertRule = /* @__PURE__ */ l(function(n, s) {
      if (s < 0 || s > this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      var r = t.parse(n).cssRules[0];
      return r.parentRule = this, this.cssRules.splice(s, 0, r), s;
    }, "insertRule"), t.CSSGroupingRule.prototype.deleteRule = /* @__PURE__ */ l(function(n) {
      if (n < 0 || n >= this.cssRules.length)
        throw new RangeError("INDEX_SIZE_ERR");
      this.cssRules.splice(n, 1)[0].parentRule = null;
    }, "deleteRule"), e.CSSGroupingRule = t.CSSGroupingRule;
  }
}), Xo = X({
  "node_modules/cssom/lib/CSSConditionRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      CSSGroupingRule: mr().CSSGroupingRule
    };
    t.CSSConditionRule = /* @__PURE__ */ l(function() {
      t.CSSGroupingRule.call(this), this.cssRules = [];
    }, "CSSConditionRule"), t.CSSConditionRule.prototype = new t.CSSGroupingRule(), t.CSSConditionRule.prototype.constructor = t.CSSConditionRule, t.CSSConditionRule.prototype.conditionText = "", t.CSSConditionRule.prototype.cssText = "", e.CSSConditionRule = t.CSSConditionRule;
  }
}), Ac = X({
  "node_modules/cssom/lib/CSSMediaRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      CSSGroupingRule: mr().CSSGroupingRule,
      CSSConditionRule: Xo().CSSConditionRule,
      MediaList: Ec().MediaList
    };
    t.CSSMediaRule = /* @__PURE__ */ l(function() {
      t.CSSConditionRule.call(this), this.media = new t.MediaList();
    }, "CSSMediaRule"), t.CSSMediaRule.prototype = new t.CSSConditionRule(), t.CSSMediaRule.prototype.constructor = t.CSSMediaRule, t.CSSMediaRule.prototype.type = 4, Object.defineProperties(t.CSSMediaRule.prototype, {
      conditionText: {
        get: function() {
          return this.media.mediaText;
        },
        set: function(i) {
          this.media.mediaText = i;
        },
        configurable: !0,
        enumerable: !0
      },
      cssText: {
        get: function() {
          for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
            i.push(this.cssRules[n].cssText);
          return "@media " + this.media.mediaText + " {" + i.join("") + "}";
        },
        configurable: !0,
        enumerable: !0
      }
    }), e.CSSMediaRule = t.CSSMediaRule;
  }
}), kc = X({
  "node_modules/cssom/lib/CSSSupportsRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      CSSGroupingRule: mr().CSSGroupingRule,
      CSSConditionRule: Xo().CSSConditionRule
    };
    t.CSSSupportsRule = /* @__PURE__ */ l(function() {
      t.CSSConditionRule.call(this);
    }, "CSSSupportsRule"), t.CSSSupportsRule.prototype = new t.CSSConditionRule(), t.CSSSupportsRule.prototype.constructor = t.CSSSupportsRule, t.CSSSupportsRule.prototype.type = 12, Object.defineProperty(t.CSSSupportsRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@supports " + this.conditionText + " {" + i.join("") + "}";
      }
    }), e.CSSSupportsRule = t.CSSSupportsRule;
  }
}), Z2 = X({
  "node_modules/cssom/lib/CSSFontFaceRule.js"(e) {
    var t = {
      CSSStyleDeclaration: vr().CSSStyleDeclaration,
      CSSRule: Jt().CSSRule
    };
    t.CSSFontFaceRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSFontFaceRule"), t.CSSFontFaceRule.prototype = new t.CSSRule(), t.CSSFontFaceRule.prototype.constructor = t.CSSFontFaceRule, t.CSSFontFaceRule.prototype.type = 5, Object.defineProperty(t.CSSFontFaceRule.prototype, "cssText", {
      get: function() {
        return "@font-face {" + this.style.cssText + "}";
      }
    }), e.CSSFontFaceRule = t.CSSFontFaceRule;
  }
}), Q2 = X({
  "node_modules/cssom/lib/CSSHostRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule
    };
    t.CSSHostRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.cssRules = [];
    }, "CSSHostRule"), t.CSSHostRule.prototype = new t.CSSRule(), t.CSSHostRule.prototype.constructor = t.CSSHostRule, t.CSSHostRule.prototype.type = 1001, Object.defineProperty(t.CSSHostRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@host {" + i.join("") + "}";
      }
    }), e.CSSHostRule = t.CSSHostRule;
  }
}), Ic = X({
  "node_modules/cssom/lib/CSSKeyframeRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      CSSStyleDeclaration: vr().CSSStyleDeclaration
    };
    t.CSSKeyframeRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.keyText = "", this.style = new t.CSSStyleDeclaration(), this.style.parentRule = this;
    }, "CSSKeyframeRule"), t.CSSKeyframeRule.prototype = new t.CSSRule(), t.CSSKeyframeRule.prototype.constructor = t.CSSKeyframeRule, t.CSSKeyframeRule.prototype.type = 8, Object.defineProperty(t.CSSKeyframeRule.prototype, "cssText", {
      get: function() {
        return this.keyText + " {" + this.style.cssText + "} ";
      }
    }), e.CSSKeyframeRule = t.CSSKeyframeRule;
  }
}), Pc = X({
  "node_modules/cssom/lib/CSSKeyframesRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule
    };
    t.CSSKeyframesRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.name = "", this.cssRules = [];
    }, "CSSKeyframesRule"), t.CSSKeyframesRule.prototype = new t.CSSRule(), t.CSSKeyframesRule.prototype.constructor = t.CSSKeyframesRule, t.CSSKeyframesRule.prototype.type = 7, Object.defineProperty(t.CSSKeyframesRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push("  " + this.cssRules[n].cssText);
        return "@" + (this._vendorPrefix || "") + "keyframes " + this.name + ` { 
` + i.join(`
`) + `
}`;
      }
    }), e.CSSKeyframesRule = t.CSSKeyframesRule;
  }
}), e9 = X({
  "node_modules/cssom/lib/CSSValue.js"(e) {
    var t = {};
    t.CSSValue = /* @__PURE__ */ l(function() {
    }, "CSSValue"), t.CSSValue.prototype = {
      constructor: t.CSSValue,
      set cssText(i) {
        var n = this._getConstructorName();
        throw new Error('DOMException: property "cssText" of "' + n + '" is readonly and can not be replaced with "' + i + '"!');
      },
      get cssText() {
        var i = this._getConstructorName();
        throw new Error('getter "cssText" of "' + i + '" is not implemented!');
      },
      _getConstructorName: function() {
        var i = this.constructor.toString(), n = i.match(/function\s([^\(]+)/), s = n[1];
        return s;
      }
    }, e.CSSValue = t.CSSValue;
  }
}), t9 = X({
  "node_modules/cssom/lib/CSSValueExpression.js"(e) {
    var t = {
      CSSValue: e9().CSSValue
    };
    t.CSSValueExpression = /* @__PURE__ */ l(function(n, s) {
      this._token = n, this._idx = s;
    }, "CSSValueExpression"), t.CSSValueExpression.prototype = new t.CSSValue(), t.CSSValueExpression.prototype.constructor = t.CSSValueExpression, t.CSSValueExpression.prototype.parse = function() {
      for (var i = this._token, n = this._idx, s = "", r = "", a = "", u, c = []; ; ++n) {
        if (s = i.charAt(n), s === "") {
          a = "css expression error: unfinished expression!";
          break;
        }
        switch (s) {
          case "(":
            c.push(s), r += s;
            break;
          case ")":
            c.pop(s), r += s;
            break;
          case "/":
            (u = this._parseJSComment(i, n)) ? u.error ? a = "css expression error: unfinished comment in expression!" : n = u.idx : (u = this._parseJSRexExp(i, n)) ? (n = u.idx, r += u.text) : r += s;
            break;
          case "'":
          case '"':
            u = this._parseJSString(i, n, s), u ? (n = u.idx, r += u.text) : r += s;
            break;
          default:
            r += s;
            break;
        }
        if (a || c.length === 0)
          break;
      }
      var h;
      return a ? h = {
        error: a
      } : h = {
        idx: n,
        expression: r
      }, h;
    }, t.CSSValueExpression.prototype._parseJSComment = function(i, n) {
      var s = i.charAt(n + 1), r;
      if (s === "/" || s === "*") {
        var a = n, u, c;
        if (s === "/" ? c = `
` : s === "*" && (c = "*/"), u = i.indexOf(c, a + 1 + 1), u !== -1)
          return u = u + c.length - 1, r = i.substring(n, u + 1), {
            idx: u,
            text: r
          };
        var h = "css expression error: unfinished comment in expression!";
        return {
          error: h
        };
      } else
        return !1;
    }, t.CSSValueExpression.prototype._parseJSString = function(i, n, s) {
      var r = this._findMatchedIdx(i, n, s), a;
      return r === -1 ? !1 : (a = i.substring(n, r + s.length), {
        idx: r,
        text: a
      });
    }, t.CSSValueExpression.prototype._parseJSRexExp = function(i, n) {
      var s = i.substring(0, n).replace(/\s+$/, ""), r = [
        /^$/,
        /\($/,
        /\[$/,
        /\!$/,
        /\+$/,
        /\-$/,
        /\*$/,
        /\/\s+/,
        /\%$/,
        /\=$/,
        /\>$/,
        /<$/,
        /\&$/,
        /\|$/,
        /\^$/,
        /\~$/,
        /\?$/,
        /\,$/,
        /delete$/,
        /in$/,
        /instanceof$/,
        /new$/,
        /typeof$/,
        /void$/
      ], a = r.some(function(c) {
        return c.test(s);
      });
      if (a) {
        var u = "/";
        return this._parseJSString(i, n, u);
      } else
        return !1;
    }, t.CSSValueExpression.prototype._findMatchedIdx = function(i, n, s) {
      for (var r = n, a, u = -1; ; )
        if (a = i.indexOf(s, r + 1), a === -1) {
          a = u;
          break;
        } else {
          var c = i.substring(n + 1, a), h = c.match(/\\+$/);
          if (!h || h[0] % 2 === 0)
            break;
          r = a;
        }
      var p = i.indexOf(`
`, n + 1);
      return p < a && (a = u), a;
    }, e.CSSValueExpression = t.CSSValueExpression;
  }
}), i9 = X({
  "node_modules/cssom/lib/MatcherList.js"(e) {
    var t = {};
    t.MatcherList = /* @__PURE__ */ l(function() {
      this.length = 0;
    }, "MatcherList"), t.MatcherList.prototype = {
      constructor: t.MatcherList,
      get matcherText() {
        return Array.prototype.join.call(this, ", ");
      },
      set matcherText(i) {
        for (var n = i.split(","), s = this.length = n.length, r = 0; r < s; r++)
          this[r] = n[r].trim();
      },
      appendMatcher: function(i) {
        Array.prototype.indexOf.call(this, i) === -1 && (this[this.length] = i, this.length++);
      },
      deleteMatcher: function(i) {
        var n = Array.prototype.indexOf.call(this, i);
        n !== -1 && Array.prototype.splice.call(this, n, 1);
      }
    }, e.MatcherList = t.MatcherList;
  }
}), n9 = X({
  "node_modules/cssom/lib/CSSDocumentRule.js"(e) {
    var t = {
      CSSRule: Jt().CSSRule,
      MatcherList: i9().MatcherList
    };
    t.CSSDocumentRule = /* @__PURE__ */ l(function() {
      t.CSSRule.call(this), this.matcher = new t.MatcherList(), this.cssRules = [];
    }, "CSSDocumentRule"), t.CSSDocumentRule.prototype = new t.CSSRule(), t.CSSDocumentRule.prototype.constructor = t.CSSDocumentRule, t.CSSDocumentRule.prototype.type = 10, Object.defineProperty(t.CSSDocumentRule.prototype, "cssText", {
      get: function() {
        for (var i = [], n = 0, s = this.cssRules.length; n < s; n++)
          i.push(this.cssRules[n].cssText);
        return "@-moz-document " + this.matcher.matcherText + " {" + i.join("") + "}";
      }
    }), e.CSSDocumentRule = t.CSSDocumentRule;
  }
}), Mc = X({
  "node_modules/cssom/lib/parse.js"(e) {
    var t = {};
    t.parse = /* @__PURE__ */ l(function(n) {
      for (var s = 0, r = "before-selector", a, u = "", c = 0, h = {
        selector: !0,
        value: !0,
        "value-parenthesis": !0,
        atRule: !0,
        "importRule-begin": !0,
        importRule: !0,
        atBlock: !0,
        conditionBlock: !0,
        "documentRule-begin": !0
      }, p = new t.CSSStyleSheet(), m = p, b, C = [], k = !1, D, I, $ = "", O, F, K, M, v, H, ce, ae, Q = /@(-(?:\w+-)+)?keyframes/g, Xe = /* @__PURE__ */ l(function(Je) {
        var Ce = n.substring(0, s).split(`
`), nt = Ce.length, De = Ce.pop().length + 1, he = new Error(Je + " (line " + nt + ", char " + De + ")");
        throw he.line = nt, he.char = De, he.styleSheet = p, he;
      }, "parseError"), J; J = n.charAt(s); s++)
        switch (J) {
          case " ":
          case "	":
          case "\r":
          case `
`:
          case "\f":
            h[r] && (u += J);
            break;
          case '"':
            a = s + 1;
            do
              a = n.indexOf('"', a) + 1, a || Xe('Unmatched "');
            while (n[a - 2] === "\\");
            switch (u += n.slice(s, a), s = a - 1, r) {
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            break;
          case "'":
            a = s + 1;
            do
              a = n.indexOf("'", a) + 1, a || Xe("Unmatched '");
            while (n[a - 2] === "\\");
            switch (u += n.slice(s, a), s = a - 1, r) {
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            break;
          case "/":
            n.charAt(s + 1) === "*" ? (s += 2, a = n.indexOf("*/", s), a === -1 ? Xe("Missing */") : s = a + 1) : u += J, r === "importRule-begin" && (u += " ", r = "importRule");
            break;
          case "@":
            if (n.indexOf("@-moz-document", s) === s) {
              r = "documentRule-begin", ce = new t.CSSDocumentRule(), ce.__starts = s, s += 13, u = "";
              break;
            } else if (n.indexOf("@media", s) === s) {
              r = "atBlock", F = new t.CSSMediaRule(), F.__starts = s, s += 5, u = "";
              break;
            } else if (n.indexOf("@supports", s) === s) {
              r = "conditionBlock", K = new t.CSSSupportsRule(), K.__starts = s, s += 8, u = "";
              break;
            } else if (n.indexOf("@host", s) === s) {
              r = "hostRule-begin", s += 4, ae = new t.CSSHostRule(), ae.__starts = s, u = "";
              break;
            } else if (n.indexOf("@import", s) === s) {
              r = "importRule-begin", s += 6, u += "@import";
              break;
            } else if (n.indexOf("@font-face", s) === s) {
              r = "fontFaceRule-begin", s += 9, v = new t.CSSFontFaceRule(), v.__starts = s, u = "";
              break;
            } else {
              Q.lastIndex = s;
              var ee = Q.exec(n);
              if (ee && ee.index === s) {
                r = "keyframesRule-begin", H = new t.CSSKeyframesRule(), H.__starts = s, H._vendorPrefix = ee[1], s += ee[0].length - 1, u = "";
                break;
              } else
                r === "selector" && (r = "atRule");
            }
            u += J;
            break;
          case "{":
            r === "selector" || r === "atRule" ? (O.selectorText = u.trim(), O.style.__starts = s, u = "", r = "before-name") : r === "atBlock" ? (F.media.mediaText = u.trim(), b && C.push(b), m = b = F, F.parentStyleSheet = p, u = "", r = "before-selector") : r === "conditionBlock" ? (K.conditionText = u.trim(), b && C.push(b), m = b = K, K.parentStyleSheet = p, u = "", r = "before-selector") : r === "hostRule-begin" ? (b && C.push(b), m = b = ae, ae.parentStyleSheet = p, u = "", r = "before-selector") : r === "fontFaceRule-begin" ? (b && (v.parentRule = b), v.parentStyleSheet = p, O = v, u = "", r = "before-name") : r === "keyframesRule-begin" ? (H.name = u.trim(), b && (C.push(b), H.parentRule = b), H.parentStyleSheet = p, m = b = H, u = "", r = "keyframeRule-begin") : r === "keyframeRule-begin" ? (O = new t.CSSKeyframeRule(), O.keyText = u.trim(), O.__starts = s, u = "", r = "before-name") : r === "documentRule-begin" && (ce.matcher.matcherText = u.trim(), b && (C.push(b), ce.parentRule = b), m = b = ce, ce.parentStyleSheet = p, u = "", r = "before-selector");
            break;
          case ":":
            r === "name" ? (I = u.trim(), u = "", r = "before-value") : u += J;
            break;
          case "(":
            if (r === "value")
              if (u.trim() === "expression") {
                var ve = new t.CSSValueExpression(n, s).parse();
                ve.error ? Xe(ve.error) : (u += ve.expression, s = ve.idx);
              } else
                r = "value-parenthesis", c = 1, u += J;
            else
              r === "value-parenthesis" && c++, u += J;
            break;
          case ")":
            r === "value-parenthesis" && (c--, c === 0 && (r = "value")), u += J;
            break;
          case "!":
            r === "value" && n.indexOf("!important", s) === s ? ($ = "important", s += 9) : u += J;
            break;
          case ";":
            switch (r) {
              case "value":
                O.style.setProperty(I, u.trim(), $), $ = "", u = "", r = "before-name";
                break;
              case "atRule":
                u = "", r = "before-selector";
                break;
              case "importRule":
                M = new t.CSSImportRule(), M.parentStyleSheet = M.styleSheet.parentStyleSheet = p, M.cssText = u + J, p.cssRules.push(M), u = "", r = "before-selector";
                break;
              default:
                u += J;
                break;
            }
            break;
          case "}":
            switch (r) {
              case "value":
                O.style.setProperty(I, u.trim(), $), $ = "";
              case "before-name":
              case "name":
                O.__ends = s + 1, b && (O.parentRule = b), O.parentStyleSheet = p, m.cssRules.push(O), u = "", m.constructor === t.CSSKeyframesRule ? r = "keyframeRule-begin" : r = "before-selector";
                break;
              case "keyframeRule-begin":
              case "before-selector":
              case "selector":
                for (b || Xe("Unexpected }"), k = C.length > 0; C.length > 0; ) {
                  if (b = C.pop(), b.constructor.name === "CSSMediaRule" || b.constructor.name === "CSSSupportsRule") {
                    D = m, m = b, m.cssRules.push(D);
                    break;
                  }
                  C.length === 0 && (k = !1);
                }
                k || (m.__ends = s + 1, p.cssRules.push(m), m = p, b = null), u = "", r = "before-selector";
                break;
            }
            break;
          default:
            switch (r) {
              case "before-selector":
                r = "selector", O = new t.CSSStyleRule(), O.__starts = s;
                break;
              case "before-name":
                r = "name";
                break;
              case "before-value":
                r = "value";
                break;
              case "importRule-begin":
                r = "importRule";
                break;
            }
            u += J;
            break;
        }
      return p;
    }, "parse"), e.parse = t.parse, t.CSSStyleSheet = zl().CSSStyleSheet, t.CSSStyleRule = ql().CSSStyleRule, t.CSSImportRule = J2().CSSImportRule, t.CSSGroupingRule = mr().CSSGroupingRule, t.CSSMediaRule = Ac().CSSMediaRule, t.CSSConditionRule = Xo().CSSConditionRule, t.CSSSupportsRule = kc().CSSSupportsRule, t.CSSFontFaceRule = Z2().CSSFontFaceRule, t.CSSHostRule = Q2().CSSHostRule, t.CSSStyleDeclaration = vr().CSSStyleDeclaration, t.CSSKeyframeRule = Ic().CSSKeyframeRule, t.CSSKeyframesRule = Pc().CSSKeyframesRule, t.CSSValueExpression = t9().CSSValueExpression, t.CSSDocumentRule = n9().CSSDocumentRule;
  }
}), vr = X({
  "node_modules/cssom/lib/CSSStyleDeclaration.js"(e) {
    var t = {};
    t.CSSStyleDeclaration = /* @__PURE__ */ l(function() {
      this.length = 0, this.parentRule = null, this._importants = {};
    }, "CSSStyleDeclaration"), t.CSSStyleDeclaration.prototype = {
      constructor: t.CSSStyleDeclaration,
      getPropertyValue: function(i) {
        return this[i] || "";
      },
      setProperty: function(i, n, s) {
        if (this[i]) {
          var r = Array.prototype.indexOf.call(this, i);
          r < 0 && (this[this.length] = i, this.length++);
        } else
          this[this.length] = i, this.length++;
        this[i] = n + "", this._importants[i] = s;
      },
      removeProperty: function(i) {
        if (!(i in this))
          return "";
        var n = Array.prototype.indexOf.call(this, i);
        if (n < 0)
          return "";
        var s = this[i];
        return this[i] = "", Array.prototype.splice.call(this, n, 1), s;
      },
      getPropertyCSSValue: function() {
      },
      getPropertyPriority: function(i) {
        return this._importants[i] || "";
      },
      getPropertyShorthand: function() {
      },
      isPropertyImplicit: function() {
      },
      get cssText() {
        for (var i = [], n = 0, s = this.length; n < s; ++n) {
          var r = this[n], a = this.getPropertyValue(r), u = this.getPropertyPriority(r);
          u && (u = " !" + u), i[n] = r + ": " + a + u + ";";
        }
        return i.join(" ");
      },
      set cssText(i) {
        var n, s;
        for (n = this.length; n--; )
          s = this[n], this[s] = "";
        Array.prototype.splice.call(this, 0, this.length), this._importants = {};
        var r = t.parse("#bogus{" + i + "}").cssRules[0].style, a = r.length;
        for (n = 0; n < a; ++n)
          s = r[n], this.setProperty(r[n], r.getPropertyValue(s), r.getPropertyPriority(s));
      }
    }, e.CSSStyleDeclaration = t.CSSStyleDeclaration, t.parse = Mc().parse;
  }
}), G3 = X({
  "node_modules/cssom/lib/clone.js"(e) {
    var t = {
      CSSStyleSheet: zl().CSSStyleSheet,
      CSSRule: Jt().CSSRule,
      CSSStyleRule: ql().CSSStyleRule,
      CSSGroupingRule: mr().CSSGroupingRule,
      CSSConditionRule: Xo().CSSConditionRule,
      CSSMediaRule: Ac().CSSMediaRule,
      CSSSupportsRule: kc().CSSSupportsRule,
      CSSStyleDeclaration: vr().CSSStyleDeclaration,
      CSSKeyframeRule: Ic().CSSKeyframeRule,
      CSSKeyframesRule: Pc().CSSKeyframesRule
    };
    t.clone = /* @__PURE__ */ l(function i(n) {
      var s = new t.CSSStyleSheet(), r = n.cssRules;
      if (!r)
        return s;
      for (var a = 0, u = r.length; a < u; a++) {
        var c = r[a], h = s.cssRules[a] = new c.constructor(), p = c.style;
        if (p) {
          for (var m = h.style = new t.CSSStyleDeclaration(), b = 0, C = p.length; b < C; b++) {
            var k = m[b] = p[b];
            m[k] = p[k], m._importants[k] = p.getPropertyPriority(k);
          }
          m.length = p.length;
        }
        c.hasOwnProperty("keyText") && (h.keyText = c.keyText), c.hasOwnProperty("selectorText") && (h.selectorText = c.selectorText), c.hasOwnProperty("mediaText") && (h.mediaText = c.mediaText), c.hasOwnProperty("conditionText") && (h.conditionText = c.conditionText), c.hasOwnProperty("cssRules") && (h.cssRules = i(c).cssRules);
      }
      return s;
    }, "clone"), e.clone = t.clone;
  }
}), q3 = X({
  "node_modules/cssom/lib/index.js"(e) {
    e.CSSStyleDeclaration = vr().CSSStyleDeclaration, e.CSSRule = Jt().CSSRule, e.CSSGroupingRule = mr().CSSGroupingRule, e.CSSConditionRule = Xo().CSSConditionRule, e.CSSStyleRule = ql().CSSStyleRule, e.MediaList = Ec().MediaList, e.CSSMediaRule = Ac().CSSMediaRule, e.CSSSupportsRule = kc().CSSSupportsRule, e.CSSImportRule = J2().CSSImportRule, e.CSSFontFaceRule = Z2().CSSFontFaceRule, e.CSSHostRule = Q2().CSSHostRule, e.StyleSheet = X2().StyleSheet, e.CSSStyleSheet = zl().CSSStyleSheet, e.CSSKeyframesRule = Pc().CSSKeyframesRule, e.CSSKeyframeRule = Ic().CSSKeyframeRule, e.MatcherList = i9().MatcherList, e.CSSDocumentRule = n9().CSSDocumentRule, e.CSSValue = e9().CSSValue, e.CSSValueExpression = t9().CSSValueExpression, e.parse = Mc().parse, e.clone = G3().clone;
  }
}), z3 = X({
  "node_modules/linkedom/commonjs/canvas.cjs"(e, t) {
    try {
      t.exports = Y2("canvas");
    } catch {
      class n {
        constructor(r, a) {
          this.width = r, this.height = a;
        }
        getContext() {
          return null;
        }
        toDataURL() {
          return "";
        }
      }
      l(n, "Canvas"), t.exports = {
        createCanvas: (s, r) => new n(s, r)
      };
    }
  }
}), K3 = {};
Yo(K3, {
  DownloadError: () => r9,
  InnertubeError: () => x,
  MissingParamError: () => di,
  NoStreamingDataError: () => a9,
  OAuthError: () => ss,
  ParsingError: () => nn,
  PlayerError: () => xn,
  SessionError: () => Nc,
  UnavailableContentError: () => o9,
  debugFetch: () => J3,
  deepCompare: () => wl,
  escapeStringRegexp: () => Sl,
  generateRandomString: () => vs,
  generateSidAuth: () => Lc,
  getRandomUserAgent: () => Jo,
  getRuntime: () => vi,
  getStringBetweenStrings: () => Ri,
  hasKeys: () => Xi,
  isServer: () => Dc,
  sha1Hash: () => Rc,
  streamToIterable: () => Bc,
  throwIfMissing: () => Be,
  timeToSeconds: () => ji,
  u8ToBase64: () => Nt,
  uuidv4: () => lr
});
var Fr = {
  name: "youtubei.js",
  version: "2.2.3",
  description: "Full-featured wrapper around YouTube's private API.",
  main: "./dist/index.js",
  browser: "./bundle/browser.js",
  types: "./dist",
  author: "LuanRT <luan.lrt4@gmail.com> (https://github.com/LuanRT)",
  funding: [
    "https://github.com/sponsors/LuanRT"
  ],
  contributors: [
    "Wykerd (https://github.com/wykerd/)",
    "MasterOfBob777 (https://github.com/MasterOfBob777)",
    "patrickkfkan (https://github.com/patrickkfkan)"
  ],
  directories: {
    test: "./test",
    examples: "./examples",
    dist: "./dist"
  },
  scripts: {
    test: "npx jest --verbose",
    lint: "npx eslint ./src",
    "lint:fix": "npx eslint --fix ./src",
    build: "npm run build:parser-map && npm run build:proto && npm run bundle:browser && npm run bundle:browser:prod && npm run build:node",
    "build:node": "npx tsc",
    "bundle:browser": 'npx tsc --module esnext && npx esbuild ./dist/browser.js --banner:js="/* eslint-disable */" --bundle --target=chrome58 --keep-names --format=esm --sourcemap --define:global=globalThis --outfile=./bundle/browser.js --platform=browser',
    "bundle:browser:prod": "npm run bundle:browser -- --outfile=./bundle/browser.min.js --minify",
    "build:parser-map": "node ./scripts/build-parser-map.js",
    "build:proto": "npx protoc --ts_out ./src/proto --proto_path ./src/proto ./src/proto/youtube.proto",
    prepare: "npm run build",
    watch: "npx tsc --watch"
  },
  repository: {
    type: "git",
    url: "git+https://github.com/LuanRT/YouTube.js.git"
  },
  license: "MIT",
  dependencies: {
    "@protobuf-ts/runtime": "^2.7.0",
    jintr: "^0.3.1",
    linkedom: "^0.14.12",
    undici: "^5.7.0"
  },
  devDependencies: {
    "@protobuf-ts/plugin": "^2.7.0",
    "@types/jest": "^28.1.7",
    "@types/node": "^17.0.45",
    "@typescript-eslint/eslint-plugin": "^5.30.6",
    "@typescript-eslint/parser": "^5.30.6",
    esbuild: "^0.14.49",
    eslint: "^8.19.0",
    "eslint-plugin-tsdoc": "^0.2.16",
    glob: "^8.0.3",
    jest: "^28.1.3",
    "ts-jest": "^28.0.8",
    typescript: "^4.7.4"
  },
  bugs: {
    url: "https://github.com/LuanRT/YouTube.js/issues"
  },
  homepage: "https://github.com/LuanRT/YouTube.js#readme",
  keywords: [
    "yt",
    "dl",
    "ytdl",
    "youtube",
    "youtubedl",
    "youtube-dl",
    "youtube-downloader",
    "youtube-music",
    "innertubeapi",
    "innertube",
    "unofficial",
    "downloader",
    "livechat",
    "studio",
    "upload",
    "ytmusic",
    "search",
    "comment",
    "music",
    "api"
  ]
}, Y3 = {
  desktop: [
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.62",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.53 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/104.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.114 Safari/537.36 Edg/103.0.1264.49",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.64 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36"
  ],
  mobile: [
    "Mozilla/5.0 (Linux; Android 12; SAMSUNG SM-S908B) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/17.0 Chrome/96.0.4664.104 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; SM-G781B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.141 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; arm_64; Android 12; RMX3081) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.148 YaBrowser/22.7.3.82.00 SA/3 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; GM1900) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0675.117 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; 21061119BI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 10; HarmonyOS; TEL-AN10; HMSCore 6.6.0.312) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.105 HuaweiBrowser/12.1.1.321 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; U; Android 8.0.0; zh-cn; Mi Note 2 Build/OPR1.170623.032) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/61.0.3163.128 Mobile Safari/537.36 XiaoMi/MiuiBrowser/10.1.1",
    "Mozilla/5.0 (Linux; Android 12; IN2013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; Redmi Note 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/103.0.5060.63 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 9; moto e6s) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; ONEPLUS A6013) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G986B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.25 (KHTML, like Gecko) Version/11.0 Mobile/15A372 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 7.1.2; Redmi Note 5A Prime) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 15_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.5 Mobile/15E148 Safari/604.1"
  ]
}, s9 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, nr = function(e) {
  return this instanceof nr ? (this.v = e, this) : new nr(e);
}, X3 = function(e, t, i) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var n = i.apply(e, t || []), s, r = [];
  return s = {}, a("next"), a("throw"), a("return"), s[Symbol.asyncIterator] = function() {
    return this;
  }, s;
  function a(b) {
    n[b] && (s[b] = function(C) {
      return new Promise(function(k, D) {
        r.push([b, C, k, D]) > 1 || u(b, C);
      });
    });
  }
  function u(b, C) {
    try {
      c(n[b](C));
    } catch (k) {
      m(r[0][3], k);
    }
  }
  function c(b) {
    b.value instanceof nr ? Promise.resolve(b.value.v).then(h, p) : m(r[0][2], b);
  }
  function h(b) {
    u("next", b);
  }
  function p(b) {
    u("throw", b);
  }
  function m(b, C) {
    b(C), r.shift(), r.length && u(r[0][0], r[0][1]);
  }
}, x = class extends Error {
  constructor(e, t) {
    super(e), t && (this.info = t), this.date = new Date(), this.version = Fr.version;
  }
};
l(x, "InnertubeError");
var nn = class extends x {
};
l(nn, "ParsingError");
var r9 = class extends x {
};
l(r9, "DownloadError");
var di = class extends x {
};
l(di, "MissingParamError");
var o9 = class extends x {
};
l(o9, "UnavailableContentError");
var a9 = class extends x {
};
l(a9, "NoStreamingDataError");
var ss = class extends x {
};
l(ss, "OAuthError");
var xn = class extends Error {
};
l(xn, "PlayerError");
var Nc = class extends Error {
};
l(Nc, "SessionError");
function wl(e, t) {
  return Reflect.ownKeys(e).some((n) => {
    var s;
    const r = ((s = t[n]) === null || s === void 0 ? void 0 : s.constructor.name) === "Text";
    return !r && typeof t[n] == "object" ? JSON.stringify(e[n]) === JSON.stringify(t[n]) : e[n] === (r ? t[n].toString() : t[n]);
  });
}
l(wl, "deepCompare");
function Ri(e, t, i) {
  const n = new RegExp(`${Sl(t)}(.*?)${Sl(i)}`, "s"), s = e.match(n);
  return s ? s[1] : void 0;
}
l(Ri, "getStringBetweenStrings");
function Sl(e) {
  return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
l(Sl, "escapeStringRegexp");
function Jo(e) {
  const t = Y3[e], i = Math.floor(Math.random() * t.length);
  return t[i];
}
l(Jo, "getRandomUserAgent");
function Rc(e) {
  return s9(this, void 0, void 0, function* () {
    const t = vi() === "node" ? Reflect.get(module, "require")("crypto").webcrypto.subtle : window.crypto.subtle, i = [
      "00",
      "01",
      "02",
      "03",
      "04",
      "05",
      "06",
      "07",
      "08",
      "09",
      "0a",
      "0b",
      "0c",
      "0d",
      "0e",
      "0f",
      "10",
      "11",
      "12",
      "13",
      "14",
      "15",
      "16",
      "17",
      "18",
      "19",
      "1a",
      "1b",
      "1c",
      "1d",
      "1e",
      "1f",
      "20",
      "21",
      "22",
      "23",
      "24",
      "25",
      "26",
      "27",
      "28",
      "29",
      "2a",
      "2b",
      "2c",
      "2d",
      "2e",
      "2f",
      "30",
      "31",
      "32",
      "33",
      "34",
      "35",
      "36",
      "37",
      "38",
      "39",
      "3a",
      "3b",
      "3c",
      "3d",
      "3e",
      "3f",
      "40",
      "41",
      "42",
      "43",
      "44",
      "45",
      "46",
      "47",
      "48",
      "49",
      "4a",
      "4b",
      "4c",
      "4d",
      "4e",
      "4f",
      "50",
      "51",
      "52",
      "53",
      "54",
      "55",
      "56",
      "57",
      "58",
      "59",
      "5a",
      "5b",
      "5c",
      "5d",
      "5e",
      "5f",
      "60",
      "61",
      "62",
      "63",
      "64",
      "65",
      "66",
      "67",
      "68",
      "69",
      "6a",
      "6b",
      "6c",
      "6d",
      "6e",
      "6f",
      "70",
      "71",
      "72",
      "73",
      "74",
      "75",
      "76",
      "77",
      "78",
      "79",
      "7a",
      "7b",
      "7c",
      "7d",
      "7e",
      "7f",
      "80",
      "81",
      "82",
      "83",
      "84",
      "85",
      "86",
      "87",
      "88",
      "89",
      "8a",
      "8b",
      "8c",
      "8d",
      "8e",
      "8f",
      "90",
      "91",
      "92",
      "93",
      "94",
      "95",
      "96",
      "97",
      "98",
      "99",
      "9a",
      "9b",
      "9c",
      "9d",
      "9e",
      "9f",
      "a0",
      "a1",
      "a2",
      "a3",
      "a4",
      "a5",
      "a6",
      "a7",
      "a8",
      "a9",
      "aa",
      "ab",
      "ac",
      "ad",
      "ae",
      "af",
      "b0",
      "b1",
      "b2",
      "b3",
      "b4",
      "b5",
      "b6",
      "b7",
      "b8",
      "b9",
      "ba",
      "bb",
      "bc",
      "bd",
      "be",
      "bf",
      "c0",
      "c1",
      "c2",
      "c3",
      "c4",
      "c5",
      "c6",
      "c7",
      "c8",
      "c9",
      "ca",
      "cb",
      "cc",
      "cd",
      "ce",
      "cf",
      "d0",
      "d1",
      "d2",
      "d3",
      "d4",
      "d5",
      "d6",
      "d7",
      "d8",
      "d9",
      "da",
      "db",
      "dc",
      "dd",
      "de",
      "df",
      "e0",
      "e1",
      "e2",
      "e3",
      "e4",
      "e5",
      "e6",
      "e7",
      "e8",
      "e9",
      "ea",
      "eb",
      "ec",
      "ed",
      "ee",
      "ef",
      "f0",
      "f1",
      "f2",
      "f3",
      "f4",
      "f5",
      "f6",
      "f7",
      "f8",
      "f9",
      "fa",
      "fb",
      "fc",
      "fd",
      "fe",
      "ff"
    ];
    function n(s) {
      const r = new Uint8Array(s), a = [];
      for (let u = 0; u < r.length; ++u)
        a.push(i[r[u]]);
      return a.join("");
    }
    return l(n, "hex"), n(yield t.digest("SHA-1", new TextEncoder().encode(e)));
  });
}
l(Rc, "sha1Hash");
function Lc(e) {
  return s9(this, void 0, void 0, function* () {
    const t = "https://www.youtube.com", i = Math.floor(new Date().getTime() / 1e3), n = [i, e, t].join(" "), s = yield Rc(n);
    return ["SAPISIDHASH", [i, s].join("_")].join(" ");
  });
}
l(Lc, "generateSidAuth");
function vs(e) {
  const t = [], i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  for (let n = 0; n < e; n++)
    t.push(i.charAt(Math.floor(Math.random() * i.length)));
  return t.join("");
}
l(vs, "generateRandomString");
function ji(e) {
  const t = e.split(":").map((i) => parseInt(i));
  switch (t.length) {
    case 1:
      return t[0];
    case 2:
      return t[0] * 60 + t[1];
    case 3:
      return t[0] * 3600 + t[1] * 60 + t[2];
    default:
      throw new Error("Invalid time string");
  }
}
l(ji, "timeToSeconds");
function Be(e) {
  for (const [t, i] of Object.entries(e))
    if (!i)
      throw new di(`${t} is missing`);
}
l(Be, "throwIfMissing");
function Xi(e, ...t) {
  for (const i of t)
    if (!Reflect.has(e, i) || e[i] === void 0)
      return !1;
  return !0;
}
l(Xi, "hasKeys");
function lr() {
  var e;
  return vi() === "node" ? Reflect.get(module, "require")("crypto").webcrypto.randomUUID() : !((e = globalThis.crypto) === null || e === void 0) && e.randomUUID() ? globalThis.crypto.randomUUID() : "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (t) => {
    const i = parseInt(t);
    return (i ^ window.crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> i / 4).toString(16);
  });
}
l(lr, "uuidv4");
function vi() {
  var e;
  return typeof process < "u" && ((e = process == null ? void 0 : process.versions) === null || e === void 0 ? void 0 : e.node) ? "node" : Reflect.has(globalThis, "Deno") ? "deno" : "browser";
}
l(vi, "getRuntime");
function Dc() {
  return ["node", "deno"].includes(vi());
}
l(Dc, "isServer");
function Bc(e) {
  return X3(this, arguments, /* @__PURE__ */ l(function* () {
    const i = e.getReader();
    try {
      for (; ; ) {
        const { done: n, value: s } = yield nr(i.read());
        if (n)
          return yield nr(void 0);
        yield yield nr(s);
      }
    } finally {
      i.releaseLock();
    }
  }, "streamToIterable_1"));
}
l(Bc, "streamToIterable");
var J3 = /* @__PURE__ */ l((e, t) => {
  const i = typeof e == "string" ? new URL(e) : e instanceof URL ? e : new URL(e.url), n = t != null && t.headers ? new Headers(t.headers) : e instanceof Request ? e.headers : new Headers(), s = [...n], r = t != null && t.body ? typeof t.body == "string" ? n.get("content-type") === "application/json" ? JSON.stringify(JSON.parse(t.body), null, 2) : t.body : "    <binary>" : "    (none)", a = s.length > 0 ? `${s.map(([u, c]) => `    ${u}: ${c}`).join(`
`)}` : "    (none)";
  return console.log(`YouTube.js Fetch:
  url: ${i.toString()}
  method: ${(t == null ? void 0 : t.method) || "GET"}
  headers:
${a}
' + 
    '  body:
${r}`), globalThis.fetch(e, t);
}, "debugFetch");
function Nt(e) {
  return btoa(String.fromCharCode.apply(null, Array.from(e)));
}
l(Nt, "u8ToBase64");
var l9 = {};
Yo(l9, {
  CLIENTS: () => Cl,
  INNERTUBE_HEADERS_BASE: () => d9,
  OAUTH: () => c9,
  STREAM_HEADERS: () => h9,
  URLS: () => u9,
  default: () => pe
});
var u9 = Object.freeze({
  YT_BASE: "https://www.youtube.com",
  YT_MUSIC_BASE: "https://music.youtube.com",
  YT_SUGGESTIONS: "https://suggestqueries.google.com/complete/",
  YT_UPLOAD: "https://upload.youtube.com/",
  API: Object.freeze({
    BASE: "https://youtubei.googleapis.com",
    PRODUCTION_1: "https://www.youtube.com/youtubei/",
    PRODUCTION_2: "https://youtubei.googleapis.com/youtubei/",
    STAGING: "https://green-youtubei.sandbox.googleapis.com/youtubei/",
    RELEASE: "https://release-youtubei.sandbox.googleapis.com/youtubei/",
    TEST: "https://test-youtubei.sandbox.googleapis.com/youtubei/",
    CAMI: "http://cami-youtubei.sandbox.googleapis.com/youtubei/",
    UYTFE: "https://uytfe.sandbox.google.com/youtubei/"
  })
}), c9 = Object.freeze({
  SCOPE: "http://gdata.youtube.com https://www.googleapis.com/auth/youtube-paid-content",
  GRANT_TYPE: "http://oauth.net/grant_type/device/1.0",
  MODEL_NAME: "ytlr::",
  HEADERS: Object.freeze({
    accept: "*/*",
    origin: "https://www.youtube.com",
    "user-agent": "Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version",
    "content-type": "application/json",
    referer: "https://www.youtube.com/tv",
    "accept-language": "en-US"
  }),
  REGEX: Object.freeze({
    AUTH_SCRIPT: /<script id="base-js" src="(.*?)" nonce=".*?"><\/script>/,
    CLIENT_IDENTITY: new RegExp('.+?={};var .+?={clientId:"(?<client_id>.+?)",.+?:"(?<client_secret>.+?)"},')
  })
}), Cl = Object.freeze({
  WEB: {
    NAME: "WEB",
    VERSION: "2.20220902.01.00"
  },
  YTMUSIC: {
    NAME: "WEB_REMIX",
    VERSION: "1.20211213.00.00"
  },
  ANDROID: {
    NAME: "ANDROID",
    VERSION: "17.17.32",
    SDK_VERSION: "29"
  },
  YTMUSIC_ANDROID: {
    NAME: "ANDROID_MUSIC",
    VERSION: "5.17.51"
  },
  TV_EMBEDDED: {
    NAME: "TVHTML5_SIMPLY_EMBEDDED_PLAYER",
    VERSION: "2.0"
  }
}), h9 = Object.freeze({
  accept: "*/*",
  origin: "https://www.youtube.com",
  referer: "https://www.youtube.com",
  DNT: "?1"
}), d9 = Object.freeze({
  accept: "*/*",
  "accept-encoding": "gzip, deflate",
  "content-type": "application/json"
}), pe = {
  URLS: u9,
  OAUTH: c9,
  CLIENTS: Cl,
  STREAM_HEADERS: h9,
  INNERTUBE_HEADERS_BASE: d9
}, _5 = Wi(W3()), _a = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, ba = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Si = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Os, Fs, Vr, Ur, En = class {
  constructor(e, t, i, n) {
    Os.set(this, void 0), Fs.set(this, void 0), Vr.set(this, void 0), Ur.set(this, void 0), ba(this, Os, i, "f"), ba(this, Fs, t, "f"), ba(this, Vr, e, "f"), ba(this, Ur, n, "f");
  }
  static create(e, t = globalThis.fetch) {
    return _a(this, void 0, void 0, function* () {
      const i = new URL("/iframe_api", pe.URLS.YT_BASE), n = yield t(i);
      if (n.status !== 200)
        throw new xn("Failed to request player id");
      const s = yield n.text(), r = Ri(s, "player\\/", "\\/");
      if (!r)
        throw new xn("Failed to get player id");
      if (e) {
        const b = yield En.fromCache(e, r);
        if (b)
          return b;
      }
      const a = new URL(`/s/player/${r}/player_ias.vflset/en_US/base.js`, pe.URLS.YT_BASE), u = yield t(a, {
        headers: {
          "user-agent": Jo("desktop")
        }
      });
      if (!u.ok)
        throw new xn(`Failed to get player data: ${u.status}`);
      const c = yield u.text(), h = this.extractSigTimestamp(c), p = this.extractSigSourceCode(c), m = this.extractNSigSourceCode(c);
      return yield En.fromSource(e, h, p, m, r);
    });
  }
  decipher(e, t, i) {
    if (e = e || t || i, !e)
      throw new xn("No valid URL to decipher");
    const n = new URLSearchParams(e), s = new URL(n.get("url") || e);
    if (s.searchParams.set("ratebypass", "yes"), t || i) {
      const a = new _5.default(Si(this, Fs, "f"));
      a.scope.set("sig", n.get("s"));
      const u = a.interpret(), c = n.get("sp");
      c ? s.searchParams.set(c, u) : s.searchParams.set("signature", u);
    }
    const r = s.searchParams.get("n");
    if (r) {
      const a = new _5.default(Si(this, Os, "f"));
      a.scope.set("nsig", r);
      const u = a.interpret();
      u.startsWith("enhanced_except_") && console.warn(`Warning:
Could not transform nsig, download may be throttled.
Changing the InnerTube client to "ANDROID" might help!`), s.searchParams.set("n", u);
    }
    return s.toString();
  }
  static fromCache(e, t) {
    return _a(this, void 0, void 0, function* () {
      const i = yield e.get(t);
      if (!i)
        return null;
      const n = new DataView(i);
      if (n.getUint32(0, !0) !== En.LIBRARY_VERSION)
        return null;
      const r = n.getUint32(4, !0), a = n.getUint32(8, !0), u = i.slice(12, 12 + a), c = i.slice(12 + a), h = new TextDecoder(), p = h.decode(u), m = h.decode(c);
      return new En(r, p, m, t);
    });
  }
  static fromSource(e, t, i, n, s) {
    return _a(this, void 0, void 0, function* () {
      const r = new En(t, i, n, s);
      return yield r.cache(e), r;
    });
  }
  cache(e) {
    return _a(this, void 0, void 0, function* () {
      if (!e)
        return;
      const t = new TextEncoder(), i = t.encode(Si(this, Fs, "f")), n = t.encode(Si(this, Os, "f")), s = new ArrayBuffer(12 + i.byteLength + n.byteLength), r = new DataView(s);
      r.setUint32(0, En.LIBRARY_VERSION, !0), r.setUint32(4, Si(this, Vr, "f"), !0), r.setUint32(8, i.byteLength, !0), new Uint8Array(s).set(i, 12), new Uint8Array(s).set(n, 12 + i.byteLength), yield e.set(Si(this, Ur, "f"), new Uint8Array(s));
    });
  }
  static extractSigTimestamp(e) {
    return parseInt(Ri(e, "signatureTimestamp:", ",") || "0");
  }
  static extractSigSourceCode(e) {
    var t, i;
    const n = Ri(e, 'function(a){a=a.split("")', 'return a.join("")}'), s = (i = (t = n == null ? void 0 : n.split(".")) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.replace(";", ""), r = Ri(e, `var ${s}=`, "};");
    return (!r || !n) && console.warn(new xn("Failed to extract signature decipher algorithm")), `function descramble_sig(a) { a = a.split(""); let ${s}=${r}}${n} return a.join("") } descramble_sig(sig);`;
  }
  static extractNSigSourceCode(e) {
    const t = `function descramble_nsig(a) { let b=a.split("")${Ri(e, 'b=a.split("")', '}return b.join("")}')}} return b.join(""); } descramble_nsig(nsig)`;
    return t || console.warn(new xn("Failed to extract n-token decipher algorithm")), t;
  }
  get url() {
    return new URL(`/s/player/${Si(this, Ur, "f")}/player_ias.vflset/en_US/base.js`, pe.URLS.YT_BASE).toString();
  }
  get sts() {
    return Si(this, Vr, "f");
  }
  get nsig_sc() {
    return Si(this, Os, "f");
  }
  get sig_sc() {
    return Si(this, Fs, "f");
  }
  static get LIBRARY_VERSION() {
    return 2;
  }
};
l(En, "Player");
Os = /* @__PURE__ */ new WeakMap(), Fs = /* @__PURE__ */ new WeakMap(), Vr = /* @__PURE__ */ new WeakMap(), Ur = /* @__PURE__ */ new WeakMap();
function Oc(e) {
  let t = typeof e;
  if (t == "object") {
    if (Array.isArray(e))
      return "array";
    if (e === null)
      return "null";
  }
  return t;
}
l(Oc, "typeofJsonValue");
function p9(e) {
  return e !== null && typeof e == "object" && !Array.isArray(e);
}
l(p9, "isJsonObject");
var Zi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split(""), Kl = [];
for (let e = 0; e < Zi.length; e++)
  Kl[Zi[e].charCodeAt(0)] = e;
Kl["-".charCodeAt(0)] = Zi.indexOf("+");
Kl["_".charCodeAt(0)] = Zi.indexOf("/");
function f9(e) {
  let t = e.length * 3 / 4;
  e[e.length - 2] == "=" ? t -= 2 : e[e.length - 1] == "=" && (t -= 1);
  let i = new Uint8Array(t), n = 0, s = 0, r, a = 0;
  for (let u = 0; u < e.length; u++) {
    if (r = Kl[e.charCodeAt(u)], r === void 0)
      switch (e[u]) {
        case "=":
          s = 0;
        case `
`:
        case "\r":
        case "	":
        case " ":
          continue;
        default:
          throw Error("invalid base64 string.");
      }
    switch (s) {
      case 0:
        a = r, s = 1;
        break;
      case 1:
        i[n++] = a << 2 | (r & 48) >> 4, a = r, s = 2;
        break;
      case 2:
        i[n++] = (a & 15) << 4 | (r & 60) >> 2, a = r, s = 3;
        break;
      case 3:
        i[n++] = (a & 3) << 6 | r, s = 0;
        break;
    }
  }
  if (s == 1)
    throw Error("invalid base64 string.");
  return i.subarray(0, n);
}
l(f9, "base64decode");
function m9(e) {
  let t = "", i = 0, n, s = 0;
  for (let r = 0; r < e.length; r++)
    switch (n = e[r], i) {
      case 0:
        t += Zi[n >> 2], s = (n & 3) << 4, i = 1;
        break;
      case 1:
        t += Zi[s | n >> 4], s = (n & 15) << 2, i = 2;
        break;
      case 2:
        t += Zi[s | n >> 6], t += Zi[n & 63], i = 0;
        break;
    }
  return i && (t += Zi[s], t += "=", i == 1 && (t += "=")), t;
}
l(m9, "base64encode");
var U;
(function(e) {
  e.symbol = Symbol.for("protobuf-ts/unknown"), e.onRead = (i, n, s, r, a) => {
    (t(n) ? n[e.symbol] : n[e.symbol] = []).push({ no: s, wireType: r, data: a });
  }, e.onWrite = (i, n, s) => {
    for (let { no: r, wireType: a, data: u } of e.list(n))
      s.tag(r, a).raw(u);
  }, e.list = (i, n) => {
    if (t(i)) {
      let s = i[e.symbol];
      return n ? s.filter((r) => r.no == n) : s;
    }
    return [];
  }, e.last = (i, n) => e.list(i, n).slice(-1)[0];
  const t = /* @__PURE__ */ l((i) => i && Array.isArray(i[e.symbol]), "is");
})(U || (U = {}));
var R;
(function(e) {
  e[e.Varint = 0] = "Varint", e[e.Bit64 = 1] = "Bit64", e[e.LengthDelimited = 2] = "LengthDelimited", e[e.StartGroup = 3] = "StartGroup", e[e.EndGroup = 4] = "EndGroup", e[e.Bit32 = 5] = "Bit32";
})(R || (R = {}));
function v9() {
  let e = 0, t = 0;
  for (let n = 0; n < 28; n += 7) {
    let s = this.buf[this.pos++];
    if (e |= (s & 127) << n, (s & 128) == 0)
      return this.assertBounds(), [e, t];
  }
  let i = this.buf[this.pos++];
  if (e |= (i & 15) << 28, t = (i & 112) >> 4, (i & 128) == 0)
    return this.assertBounds(), [e, t];
  for (let n = 3; n <= 31; n += 7) {
    let s = this.buf[this.pos++];
    if (t |= (s & 127) << n, (s & 128) == 0)
      return this.assertBounds(), [e, t];
  }
  throw new Error("invalid varint");
}
l(v9, "varint64read");
function Ua(e, t, i) {
  for (let r = 0; r < 28; r = r + 7) {
    const a = e >>> r, u = !(a >>> 7 == 0 && t == 0), c = (u ? a | 128 : a) & 255;
    if (i.push(c), !u)
      return;
  }
  const n = e >>> 28 & 15 | (t & 7) << 4, s = t >> 3 != 0;
  if (i.push((s ? n | 128 : n) & 255), !!s) {
    for (let r = 3; r < 31; r = r + 7) {
      const a = t >>> r, u = a >>> 7 != 0, c = (u ? a | 128 : a) & 255;
      if (i.push(c), !u)
        return;
    }
    i.push(t >>> 31 & 1);
  }
}
l(Ua, "varint64write");
var ja = (1 << 16) * (1 << 16);
function Fc(e) {
  let t = e[0] == "-";
  t && (e = e.slice(1));
  const i = 1e6;
  let n = 0, s = 0;
  function r(a, u) {
    const c = Number(e.slice(a, u));
    s *= i, n = n * i + c, n >= ja && (s = s + (n / ja | 0), n = n % ja);
  }
  return l(r, "add1e6digit"), r(-24, -18), r(-18, -12), r(-12, -6), r(-6), [t, n, s];
}
l(Fc, "int64fromString");
function Tl(e, t) {
  if (t <= 2097151)
    return "" + (ja * t + e);
  let i = e & 16777215, n = (e >>> 24 | t << 8) >>> 0 & 16777215, s = t >> 16 & 65535, r = i + n * 6777216 + s * 6710656, a = n + s * 8147497, u = s * 2, c = 1e7;
  r >= c && (a += Math.floor(r / c), r %= c), a >= c && (u += Math.floor(a / c), a %= c);
  function h(p, m) {
    let b = p ? String(p) : "";
    return m ? "0000000".slice(b.length) + b : b;
  }
  return l(h, "decimalFrom1e7"), h(u, 0) + h(a, u) + h(r, 1);
}
l(Tl, "int64toString");
function W1(e, t) {
  if (e >= 0) {
    for (; e > 127; )
      t.push(e & 127 | 128), e = e >>> 7;
    t.push(e);
  } else {
    for (let i = 0; i < 9; i++)
      t.push(e & 127 | 128), e = e >> 7;
    t.push(1);
  }
}
l(W1, "varint32write");
function g9() {
  let e = this.buf[this.pos++], t = e & 127;
  if ((e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 7, (e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 14, (e & 128) == 0)
    return this.assertBounds(), t;
  if (e = this.buf[this.pos++], t |= (e & 127) << 21, (e & 128) == 0)
    return this.assertBounds(), t;
  e = this.buf[this.pos++], t |= (e & 15) << 28;
  for (let i = 5; (e & 128) !== 0 && i < 10; i++)
    e = this.buf[this.pos++];
  if ((e & 128) != 0)
    throw new Error("invalid varint");
  return this.assertBounds(), t >>> 0;
}
l(g9, "varint32read");
function y9() {
  const e = new DataView(new ArrayBuffer(8));
  return globalThis.BigInt !== void 0 && typeof e.getBigInt64 == "function" && typeof e.getBigUint64 == "function" && typeof e.setBigInt64 == "function" && typeof e.setBigUint64 == "function" ? {
    MIN: BigInt("-9223372036854775808"),
    MAX: BigInt("9223372036854775807"),
    UMIN: BigInt("0"),
    UMAX: BigInt("18446744073709551615"),
    C: BigInt,
    V: e
  } : void 0;
}
l(y9, "detectBi");
var Oe = y9();
function Vc(e) {
  if (!e)
    throw new Error("BigInt unavailable, see https://github.com/timostamm/protobuf-ts/blob/v1.0.8/MANUAL.md#bigint-support");
}
l(Vc, "assertBi");
var _9 = /^-?[0-9]+$/, xl = (1 << 16) * (1 << 16), Uc = class {
  constructor(e, t) {
    this.lo = e | 0, this.hi = t | 0;
  }
  isZero() {
    return this.lo == 0 && this.hi == 0;
  }
  toNumber() {
    let e = this.hi * xl + (this.lo >>> 0);
    if (!Number.isSafeInteger(e))
      throw new Error("cannot convert to safe number");
    return e;
  }
};
l(Uc, "SharedPbLong");
var bt = class extends Uc {
  static from(e) {
    if (Oe)
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e == "")
            throw new Error("string is no integer");
          e = Oe.C(e);
        case "number":
          if (e === 0)
            return this.ZERO;
          e = Oe.C(e);
        case "bigint":
          if (!e)
            return this.ZERO;
          if (e < Oe.UMIN)
            throw new Error("signed value for ulong");
          if (e > Oe.UMAX)
            throw new Error("ulong too large");
          return Oe.V.setBigUint64(0, e, !0), new bt(Oe.V.getInt32(0, !0), Oe.V.getInt32(4, !0));
      }
    else
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e = e.trim(), !_9.test(e))
            throw new Error("string is no integer");
          let [t, i, n] = Fc(e);
          if (t)
            throw new Error("signed value");
          return new bt(i, n);
        case "number":
          if (e == 0)
            return this.ZERO;
          if (!Number.isSafeInteger(e))
            throw new Error("number is no integer");
          if (e < 0)
            throw new Error("signed value for ulong");
          return new bt(e, e / xl);
      }
    throw new Error("unknown value " + typeof e);
  }
  toString() {
    return Oe ? this.toBigInt().toString() : Tl(this.lo, this.hi);
  }
  toBigInt() {
    return Vc(Oe), Oe.V.setInt32(0, this.lo, !0), Oe.V.setInt32(4, this.hi, !0), Oe.V.getBigUint64(0, !0);
  }
};
l(bt, "PbULong");
bt.ZERO = new bt(0, 0);
var tt = class extends Uc {
  static from(e) {
    if (Oe)
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e == "")
            throw new Error("string is no integer");
          e = Oe.C(e);
        case "number":
          if (e === 0)
            return this.ZERO;
          e = Oe.C(e);
        case "bigint":
          if (!e)
            return this.ZERO;
          if (e < Oe.MIN)
            throw new Error("ulong too small");
          if (e > Oe.MAX)
            throw new Error("ulong too large");
          return Oe.V.setBigInt64(0, e, !0), new tt(Oe.V.getInt32(0, !0), Oe.V.getInt32(4, !0));
      }
    else
      switch (typeof e) {
        case "string":
          if (e == "0")
            return this.ZERO;
          if (e = e.trim(), !_9.test(e))
            throw new Error("string is no integer");
          let [t, i, n] = Fc(e), s = new tt(i, n);
          return t ? s.negate() : s;
        case "number":
          if (e == 0)
            return this.ZERO;
          if (!Number.isSafeInteger(e))
            throw new Error("number is no integer");
          return e > 0 ? new tt(e, e / xl) : new tt(-e, -e / xl).negate();
      }
    throw new Error("unknown value " + typeof e);
  }
  isNegative() {
    return (this.hi & 2147483648) !== 0;
  }
  negate() {
    let e = ~this.hi, t = this.lo;
    return t ? t = ~t + 1 : e += 1, new tt(t, e);
  }
  toString() {
    if (Oe)
      return this.toBigInt().toString();
    if (this.isNegative()) {
      let e = this.negate();
      return "-" + Tl(e.lo, e.hi);
    }
    return Tl(this.lo, this.hi);
  }
  toBigInt() {
    return Vc(Oe), Oe.V.setInt32(0, this.lo, !0), Oe.V.setInt32(4, this.hi, !0), Oe.V.getBigInt64(0, !0);
  }
};
l(tt, "PbLong");
tt.ZERO = new tt(0, 0);
var b5 = {
  readUnknownField: !0,
  readerFactory: (e) => new w9(e)
};
function b9(e) {
  return e ? Object.assign(Object.assign({}, b5), e) : b5;
}
l(b9, "binaryReadOptions");
var w9 = class {
  constructor(e, t) {
    this.varint64 = v9, this.uint32 = g9, this.buf = e, this.len = e.length, this.pos = 0, this.view = new DataView(e.buffer, e.byteOffset, e.byteLength), this.textDecoder = t != null ? t : new TextDecoder("utf-8", {
      fatal: !0
    });
  }
  tag() {
    let e = this.uint32(), t = e >>> 3, i = e & 7;
    if (t <= 0 || i < 0 || i > 5)
      throw new Error("illegal tag: field no " + t + " wire type " + i);
    return [t, i];
  }
  skip(e) {
    let t = this.pos;
    switch (e) {
      case R.Varint:
        for (; this.buf[this.pos++] & 128; )
          ;
        break;
      case R.Bit64:
        this.pos += 4;
      case R.Bit32:
        this.pos += 4;
        break;
      case R.LengthDelimited:
        let i = this.uint32();
        this.pos += i;
        break;
      case R.StartGroup:
        let n;
        for (; (n = this.tag()[1]) !== R.EndGroup; )
          this.skip(n);
        break;
      default:
        throw new Error("cant skip wire type " + e);
    }
    return this.assertBounds(), this.buf.subarray(t, this.pos);
  }
  assertBounds() {
    if (this.pos > this.len)
      throw new RangeError("premature EOF");
  }
  int32() {
    return this.uint32() | 0;
  }
  sint32() {
    let e = this.uint32();
    return e >>> 1 ^ -(e & 1);
  }
  int64() {
    return new tt(...this.varint64());
  }
  uint64() {
    return new bt(...this.varint64());
  }
  sint64() {
    let [e, t] = this.varint64(), i = -(e & 1);
    return e = (e >>> 1 | (t & 1) << 31) ^ i, t = t >>> 1 ^ i, new tt(e, t);
  }
  bool() {
    let [e, t] = this.varint64();
    return e !== 0 || t !== 0;
  }
  fixed32() {
    return this.view.getUint32((this.pos += 4) - 4, !0);
  }
  sfixed32() {
    return this.view.getInt32((this.pos += 4) - 4, !0);
  }
  fixed64() {
    return new bt(this.sfixed32(), this.sfixed32());
  }
  sfixed64() {
    return new tt(this.sfixed32(), this.sfixed32());
  }
  float() {
    return this.view.getFloat32((this.pos += 4) - 4, !0);
  }
  double() {
    return this.view.getFloat64((this.pos += 8) - 8, !0);
  }
  bytes() {
    let e = this.uint32(), t = this.pos;
    return this.pos += e, this.assertBounds(), this.buf.subarray(t, t + e);
  }
  string() {
    return this.textDecoder.decode(this.bytes());
  }
};
l(w9, "BinaryReader");
function Ae(e, t) {
  if (!e)
    throw new Error(t);
}
l(Ae, "assert");
var Z3 = 34028234663852886e22, Q3 = -34028234663852886e22, e7 = 4294967295, t7 = 2147483647, i7 = -2147483648;
function sr(e) {
  if (typeof e != "number")
    throw new Error("invalid int 32: " + typeof e);
  if (!Number.isInteger(e) || e > t7 || e < i7)
    throw new Error("invalid int 32: " + e);
}
l(sr, "assertInt32");
function Vo(e) {
  if (typeof e != "number")
    throw new Error("invalid uint 32: " + typeof e);
  if (!Number.isInteger(e) || e > e7 || e < 0)
    throw new Error("invalid uint 32: " + e);
}
l(Vo, "assertUInt32");
function Yl(e) {
  if (typeof e != "number")
    throw new Error("invalid float 32: " + typeof e);
  if (!!Number.isFinite(e) && (e > Z3 || e < Q3))
    throw new Error("invalid float 32: " + e);
}
l(Yl, "assertFloat32");
var w5 = {
  writeUnknownFields: !0,
  writerFactory: () => new C9()
};
function S9(e) {
  return e ? Object.assign(Object.assign({}, w5), e) : w5;
}
l(S9, "binaryWriteOptions");
var C9 = class {
  constructor(e) {
    this.stack = [], this.textEncoder = e != null ? e : new TextEncoder(), this.chunks = [], this.buf = [];
  }
  finish() {
    this.chunks.push(new Uint8Array(this.buf));
    let e = 0;
    for (let n = 0; n < this.chunks.length; n++)
      e += this.chunks[n].length;
    let t = new Uint8Array(e), i = 0;
    for (let n = 0; n < this.chunks.length; n++)
      t.set(this.chunks[n], i), i += this.chunks[n].length;
    return this.chunks = [], t;
  }
  fork() {
    return this.stack.push({ chunks: this.chunks, buf: this.buf }), this.chunks = [], this.buf = [], this;
  }
  join() {
    let e = this.finish(), t = this.stack.pop();
    if (!t)
      throw new Error("invalid state, fork stack empty");
    return this.chunks = t.chunks, this.buf = t.buf, this.uint32(e.byteLength), this.raw(e);
  }
  tag(e, t) {
    return this.uint32((e << 3 | t) >>> 0);
  }
  raw(e) {
    return this.buf.length && (this.chunks.push(new Uint8Array(this.buf)), this.buf = []), this.chunks.push(e), this;
  }
  uint32(e) {
    for (Vo(e); e > 127; )
      this.buf.push(e & 127 | 128), e = e >>> 7;
    return this.buf.push(e), this;
  }
  int32(e) {
    return sr(e), W1(e, this.buf), this;
  }
  bool(e) {
    return this.buf.push(e ? 1 : 0), this;
  }
  bytes(e) {
    return this.uint32(e.byteLength), this.raw(e);
  }
  string(e) {
    let t = this.textEncoder.encode(e);
    return this.uint32(t.byteLength), this.raw(t);
  }
  float(e) {
    Yl(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setFloat32(0, e, !0), this.raw(t);
  }
  double(e) {
    let t = new Uint8Array(8);
    return new DataView(t.buffer).setFloat64(0, e, !0), this.raw(t);
  }
  fixed32(e) {
    Vo(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setUint32(0, e, !0), this.raw(t);
  }
  sfixed32(e) {
    sr(e);
    let t = new Uint8Array(4);
    return new DataView(t.buffer).setInt32(0, e, !0), this.raw(t);
  }
  sint32(e) {
    return sr(e), e = (e << 1 ^ e >> 31) >>> 0, W1(e, this.buf), this;
  }
  sfixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), n = tt.from(e);
    return i.setInt32(0, n.lo, !0), i.setInt32(4, n.hi, !0), this.raw(t);
  }
  fixed64(e) {
    let t = new Uint8Array(8), i = new DataView(t.buffer), n = bt.from(e);
    return i.setInt32(0, n.lo, !0), i.setInt32(4, n.hi, !0), this.raw(t);
  }
  int64(e) {
    let t = tt.from(e);
    return Ua(t.lo, t.hi, this.buf), this;
  }
  sint64(e) {
    let t = tt.from(e), i = t.hi >> 31, n = t.lo << 1 ^ i, s = (t.hi << 1 | t.lo >>> 31) ^ i;
    return Ua(n, s, this.buf), this;
  }
  uint64(e) {
    let t = bt.from(e);
    return Ua(t.lo, t.hi, this.buf), this;
  }
};
l(C9, "BinaryWriter");
var S5 = {
  emitDefaultValues: !1,
  enumAsInteger: !1,
  useProtoFieldName: !1,
  prettySpaces: 0
}, C5 = {
  ignoreUnknownFields: !1
};
function T9(e) {
  return e ? Object.assign(Object.assign({}, C5), e) : C5;
}
l(T9, "jsonReadOptions");
function x9(e) {
  return e ? Object.assign(Object.assign({}, S5), e) : S5;
}
l(x9, "jsonWriteOptions");
var ye = Symbol.for("protobuf-ts/message-type");
function $1(e) {
  let t = !1;
  const i = [];
  for (let n = 0; n < e.length; n++) {
    let s = e.charAt(n);
    s == "_" ? t = !0 : /\d/.test(s) ? (i.push(s), t = !0) : t ? (i.push(s.toUpperCase()), t = !1) : n == 0 ? i.push(s.toLowerCase()) : i.push(s);
  }
  return i.join("");
}
l($1, "lowerCamelCase");
var P;
(function(e) {
  e[e.DOUBLE = 1] = "DOUBLE", e[e.FLOAT = 2] = "FLOAT", e[e.INT64 = 3] = "INT64", e[e.UINT64 = 4] = "UINT64", e[e.INT32 = 5] = "INT32", e[e.FIXED64 = 6] = "FIXED64", e[e.FIXED32 = 7] = "FIXED32", e[e.BOOL = 8] = "BOOL", e[e.STRING = 9] = "STRING", e[e.BYTES = 12] = "BYTES", e[e.UINT32 = 13] = "UINT32", e[e.SFIXED32 = 15] = "SFIXED32", e[e.SFIXED64 = 16] = "SFIXED64", e[e.SINT32 = 17] = "SINT32", e[e.SINT64 = 18] = "SINT64";
})(P || (P = {}));
var Bi;
(function(e) {
  e[e.BIGINT = 0] = "BIGINT", e[e.STRING = 1] = "STRING", e[e.NUMBER = 2] = "NUMBER";
})(Bi || (Bi = {}));
var El;
(function(e) {
  e[e.NO = 0] = "NO", e[e.PACKED = 1] = "PACKED", e[e.UNPACKED = 2] = "UNPACKED";
})(El || (El = {}));
function E9(e) {
  var t, i, n, s;
  return e.localName = (t = e.localName) !== null && t !== void 0 ? t : $1(e.name), e.jsonName = (i = e.jsonName) !== null && i !== void 0 ? i : $1(e.name), e.repeat = (n = e.repeat) !== null && n !== void 0 ? n : El.NO, e.opt = (s = e.opt) !== null && s !== void 0 ? s : e.repeat || e.oneof ? !1 : e.kind == "message", e;
}
l(E9, "normalizeFieldInfo");
function A9(e) {
  if (typeof e != "object" || e === null || !e.hasOwnProperty("oneofKind"))
    return !1;
  switch (typeof e.oneofKind) {
    case "string":
      return e[e.oneofKind] === void 0 ? !1 : Object.keys(e).length == 2;
    case "undefined":
      return Object.keys(e).length == 1;
    default:
      return !1;
  }
}
l(A9, "isOneofGroup");
var k9 = class {
  constructor(e) {
    var t;
    this.fields = (t = e.fields) !== null && t !== void 0 ? t : [];
  }
  prepare() {
    if (this.data)
      return;
    const e = [], t = [], i = [];
    for (let n of this.fields)
      if (n.oneof)
        i.includes(n.oneof) || (i.push(n.oneof), e.push(n.oneof), t.push(n.oneof));
      else
        switch (t.push(n.localName), n.kind) {
          case "scalar":
          case "enum":
            (!n.opt || n.repeat) && e.push(n.localName);
            break;
          case "message":
            n.repeat && e.push(n.localName);
            break;
          case "map":
            e.push(n.localName);
            break;
        }
    this.data = { req: e, known: t, oneofs: Object.values(i) };
  }
  is(e, t, i = !1) {
    if (t < 0)
      return !0;
    if (e == null || typeof e != "object")
      return !1;
    this.prepare();
    let n = Object.keys(e), s = this.data;
    if (n.length < s.req.length || s.req.some((r) => !n.includes(r)) || !i && n.some((r) => !s.known.includes(r)))
      return !1;
    if (t < 1)
      return !0;
    for (const r of s.oneofs) {
      const a = e[r];
      if (!A9(a))
        return !1;
      if (a.oneofKind === void 0)
        continue;
      const u = this.fields.find((c) => c.localName === a.oneofKind);
      if (!u || !this.field(a[a.oneofKind], u, i, t))
        return !1;
    }
    for (const r of this.fields)
      if (r.oneof === void 0 && !this.field(e[r.localName], r, i, t))
        return !1;
    return !0;
  }
  field(e, t, i, n) {
    let s = t.repeat;
    switch (t.kind) {
      case "scalar":
        return e === void 0 ? t.opt : s ? this.scalars(e, t.T, n, t.L) : this.scalar(e, t.T, t.L);
      case "enum":
        return e === void 0 ? t.opt : s ? this.scalars(e, P.INT32, n) : this.scalar(e, P.INT32);
      case "message":
        return e === void 0 ? !0 : s ? this.messages(e, t.T(), i, n) : this.message(e, t.T(), i, n);
      case "map":
        if (typeof e != "object" || e === null)
          return !1;
        if (n < 2)
          return !0;
        if (!this.mapKeys(e, t.K, n))
          return !1;
        switch (t.V.kind) {
          case "scalar":
            return this.scalars(Object.values(e), t.V.T, n, t.V.L);
          case "enum":
            return this.scalars(Object.values(e), P.INT32, n);
          case "message":
            return this.messages(Object.values(e), t.V.T(), i, n);
        }
        break;
    }
    return !0;
  }
  message(e, t, i, n) {
    return i ? t.isAssignable(e, n) : t.is(e, n);
  }
  messages(e, t, i, n) {
    if (!Array.isArray(e))
      return !1;
    if (n < 2)
      return !0;
    if (i) {
      for (let s = 0; s < e.length && s < n; s++)
        if (!t.isAssignable(e[s], n - 1))
          return !1;
    } else
      for (let s = 0; s < e.length && s < n; s++)
        if (!t.is(e[s], n - 1))
          return !1;
    return !0;
  }
  scalar(e, t, i) {
    let n = typeof e;
    switch (t) {
      case P.UINT64:
      case P.FIXED64:
      case P.INT64:
      case P.SFIXED64:
      case P.SINT64:
        switch (i) {
          case Bi.BIGINT:
            return n == "bigint";
          case Bi.NUMBER:
            return n == "number" && !isNaN(e);
          default:
            return n == "string";
        }
      case P.BOOL:
        return n == "boolean";
      case P.STRING:
        return n == "string";
      case P.BYTES:
        return e instanceof Uint8Array;
      case P.DOUBLE:
      case P.FLOAT:
        return n == "number" && !isNaN(e);
      default:
        return n == "number" && Number.isInteger(e);
    }
  }
  scalars(e, t, i, n) {
    if (!Array.isArray(e))
      return !1;
    if (i < 2)
      return !0;
    if (Array.isArray(e)) {
      for (let s = 0; s < e.length && s < i; s++)
        if (!this.scalar(e[s], t, n))
          return !1;
    }
    return !0;
  }
  mapKeys(e, t, i) {
    let n = Object.keys(e);
    switch (t) {
      case P.INT32:
      case P.FIXED32:
      case P.SFIXED32:
      case P.SINT32:
      case P.UINT32:
        return this.scalars(n.slice(0, i).map((s) => parseInt(s)), t, i);
      case P.BOOL:
        return this.scalars(n.slice(0, i).map((s) => s == "true" ? !0 : s == "false" ? !1 : s), t, i);
      default:
        return this.scalars(n, t, i, Bi.STRING);
    }
  }
};
l(k9, "ReflectionTypeCheck");
function ni(e, t) {
  switch (t) {
    case Bi.BIGINT:
      return e.toBigInt();
    case Bi.NUMBER:
      return e.toNumber();
    default:
      return e.toString();
  }
}
l(ni, "reflectionLongConvert");
var I9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    var e;
    if (this.fMap === void 0) {
      this.fMap = {};
      const t = (e = this.info.fields) !== null && e !== void 0 ? e : [];
      for (const i of t)
        this.fMap[i.name] = i, this.fMap[i.jsonName] = i, this.fMap[i.localName] = i;
    }
  }
  assert(e, t, i) {
    if (!e) {
      let n = Oc(i);
      throw (n == "number" || n == "boolean") && (n = i.toString()), new Error(`Cannot parse JSON ${n} for ${this.info.typeName}#${t}`);
    }
  }
  read(e, t, i) {
    this.prepare();
    const n = [];
    for (const [s, r] of Object.entries(e)) {
      const a = this.fMap[s];
      if (!a) {
        if (!i.ignoreUnknownFields)
          throw new Error(`Found unknown field while reading ${this.info.typeName} from JSON format. JSON key: ${s}`);
        continue;
      }
      const u = a.localName;
      let c;
      if (a.oneof) {
        if (n.includes(a.oneof))
          throw new Error(`Multiple members of the oneof group "${a.oneof}" of ${this.info.typeName} are present in JSON.`);
        n.push(a.oneof), c = t[a.oneof] = {
          oneofKind: u
        };
      } else
        c = t;
      if (a.kind == "map") {
        if (r === null)
          continue;
        this.assert(p9(r), a.name, r);
        const h = c[u];
        for (const [p, m] of Object.entries(r)) {
          this.assert(m !== null, a.name + " map value", null);
          let b;
          switch (a.V.kind) {
            case "message":
              b = a.V.T().internalJsonRead(m, i);
              break;
            case "enum":
              if (b = this.enum(a.V.T(), m, a.name, i.ignoreUnknownFields), b === !1)
                continue;
              break;
            case "scalar":
              b = this.scalar(m, a.V.T, a.V.L, a.name);
              break;
          }
          this.assert(b !== void 0, a.name + " map value", m);
          let C = p;
          a.K == P.BOOL && (C = C == "true" ? !0 : C == "false" ? !1 : C), C = this.scalar(C, a.K, Bi.STRING, a.name).toString(), h[C] = b;
        }
      } else if (a.repeat) {
        if (r === null)
          continue;
        this.assert(Array.isArray(r), a.name, r);
        const h = c[u];
        for (const p of r) {
          this.assert(p !== null, a.name, null);
          let m;
          switch (a.kind) {
            case "message":
              m = a.T().internalJsonRead(p, i);
              break;
            case "enum":
              if (m = this.enum(a.T(), p, a.name, i.ignoreUnknownFields), m === !1)
                continue;
              break;
            case "scalar":
              m = this.scalar(p, a.T, a.L, a.name);
              break;
          }
          this.assert(m !== void 0, a.name, r), h.push(m);
        }
      } else
        switch (a.kind) {
          case "message":
            if (r === null && a.T().typeName != "google.protobuf.Value") {
              this.assert(a.oneof === void 0, a.name + " (oneof member)", null);
              continue;
            }
            c[u] = a.T().internalJsonRead(r, i, c[u]);
            break;
          case "enum":
            let h = this.enum(a.T(), r, a.name, i.ignoreUnknownFields);
            if (h === !1)
              continue;
            c[u] = h;
            break;
          case "scalar":
            c[u] = this.scalar(r, a.T, a.L, a.name);
            break;
        }
    }
  }
  enum(e, t, i, n) {
    if (e[0] == "google.protobuf.NullValue" && Ae(t === null, `Unable to parse field ${this.info.typeName}#${i}, enum ${e[0]} only accepts null.`), t === null)
      return 0;
    switch (typeof t) {
      case "number":
        return Ae(Number.isInteger(t), `Unable to parse field ${this.info.typeName}#${i}, enum can only be integral number, got ${t}.`), t;
      case "string":
        let s = t;
        e[2] && t.substring(0, e[2].length) === e[2] && (s = t.substring(e[2].length));
        let r = e[1][s];
        return typeof r > "u" && n ? !1 : (Ae(typeof r == "number", `Unable to parse field ${this.info.typeName}#${i}, enum ${e[0]} has no value for "${t}".`), r);
    }
    Ae(!1, `Unable to parse field ${this.info.typeName}#${i}, cannot parse enum value from ${typeof t}".`);
  }
  scalar(e, t, i, n) {
    let s;
    try {
      switch (t) {
        case P.DOUBLE:
        case P.FLOAT:
          if (e === null)
            return 0;
          if (e === "NaN")
            return Number.NaN;
          if (e === "Infinity")
            return Number.POSITIVE_INFINITY;
          if (e === "-Infinity")
            return Number.NEGATIVE_INFINITY;
          if (e === "") {
            s = "empty string";
            break;
          }
          if (typeof e == "string" && e.trim().length !== e.length) {
            s = "extra whitespace";
            break;
          }
          if (typeof e != "string" && typeof e != "number")
            break;
          let r = Number(e);
          if (Number.isNaN(r)) {
            s = "not a number";
            break;
          }
          if (!Number.isFinite(r)) {
            s = "too large or small";
            break;
          }
          return t == P.FLOAT && Yl(r), r;
        case P.INT32:
        case P.FIXED32:
        case P.SFIXED32:
        case P.SINT32:
        case P.UINT32:
          if (e === null)
            return 0;
          let a;
          if (typeof e == "number" ? a = e : e === "" ? s = "empty string" : typeof e == "string" && (e.trim().length !== e.length ? s = "extra whitespace" : a = Number(e)), a === void 0)
            break;
          return t == P.UINT32 ? Vo(a) : sr(a), a;
        case P.INT64:
        case P.SFIXED64:
        case P.SINT64:
          if (e === null)
            return ni(tt.ZERO, i);
          if (typeof e != "number" && typeof e != "string")
            break;
          return ni(tt.from(e), i);
        case P.FIXED64:
        case P.UINT64:
          if (e === null)
            return ni(bt.ZERO, i);
          if (typeof e != "number" && typeof e != "string")
            break;
          return ni(bt.from(e), i);
        case P.BOOL:
          if (e === null)
            return !1;
          if (typeof e != "boolean")
            break;
          return e;
        case P.STRING:
          if (e === null)
            return "";
          if (typeof e != "string") {
            s = "extra whitespace";
            break;
          }
          try {
            encodeURIComponent(e);
          } catch (u) {
            u = "invalid UTF8";
            break;
          }
          return e;
        case P.BYTES:
          if (e === null || e === "")
            return new Uint8Array(0);
          if (typeof e != "string")
            break;
          return f9(e);
      }
    } catch (r) {
      s = r.message;
    }
    this.assert(!1, n + (s ? " - " + s : ""), e);
  }
};
l(I9, "ReflectionJsonReader");
var P9 = class {
  constructor(e) {
    var t;
    this.fields = (t = e.fields) !== null && t !== void 0 ? t : [];
  }
  write(e, t) {
    const i = {}, n = e;
    for (const s of this.fields) {
      if (!s.oneof) {
        let c = this.field(s, n[s.localName], t);
        c !== void 0 && (i[t.useProtoFieldName ? s.name : s.jsonName] = c);
        continue;
      }
      const r = n[s.oneof];
      if (r.oneofKind !== s.localName)
        continue;
      const a = s.kind == "scalar" || s.kind == "enum" ? Object.assign(Object.assign({}, t), { emitDefaultValues: !0 }) : t;
      let u = this.field(s, r[s.localName], a);
      Ae(u !== void 0), i[t.useProtoFieldName ? s.name : s.jsonName] = u;
    }
    return i;
  }
  field(e, t, i) {
    let n;
    if (e.kind == "map") {
      Ae(typeof t == "object" && t !== null);
      const s = {};
      switch (e.V.kind) {
        case "scalar":
          for (const [u, c] of Object.entries(t)) {
            const h = this.scalar(e.V.T, c, e.name, !1, !0);
            Ae(h !== void 0), s[u.toString()] = h;
          }
          break;
        case "message":
          const r = e.V.T();
          for (const [u, c] of Object.entries(t)) {
            const h = this.message(r, c, e.name, i);
            Ae(h !== void 0), s[u.toString()] = h;
          }
          break;
        case "enum":
          const a = e.V.T();
          for (const [u, c] of Object.entries(t)) {
            Ae(c === void 0 || typeof c == "number");
            const h = this.enum(a, c, e.name, !1, !0, i.enumAsInteger);
            Ae(h !== void 0), s[u.toString()] = h;
          }
          break;
      }
      (i.emitDefaultValues || Object.keys(s).length > 0) && (n = s);
    } else if (e.repeat) {
      Ae(Array.isArray(t));
      const s = [];
      switch (e.kind) {
        case "scalar":
          for (let u = 0; u < t.length; u++) {
            const c = this.scalar(e.T, t[u], e.name, e.opt, !0);
            Ae(c !== void 0), s.push(c);
          }
          break;
        case "enum":
          const r = e.T();
          for (let u = 0; u < t.length; u++) {
            Ae(t[u] === void 0 || typeof t[u] == "number");
            const c = this.enum(r, t[u], e.name, e.opt, !0, i.enumAsInteger);
            Ae(c !== void 0), s.push(c);
          }
          break;
        case "message":
          const a = e.T();
          for (let u = 0; u < t.length; u++) {
            const c = this.message(a, t[u], e.name, i);
            Ae(c !== void 0), s.push(c);
          }
          break;
      }
      (i.emitDefaultValues || s.length > 0 || i.emitDefaultValues) && (n = s);
    } else
      switch (e.kind) {
        case "scalar":
          n = this.scalar(e.T, t, e.name, e.opt, i.emitDefaultValues);
          break;
        case "enum":
          n = this.enum(e.T(), t, e.name, e.opt, i.emitDefaultValues, i.enumAsInteger);
          break;
        case "message":
          n = this.message(e.T(), t, e.name, i);
          break;
      }
    return n;
  }
  enum(e, t, i, n, s, r) {
    if (e[0] == "google.protobuf.NullValue")
      return null;
    if (t === void 0) {
      Ae(n);
      return;
    }
    if (!(t === 0 && !s && !n))
      return Ae(typeof t == "number"), Ae(Number.isInteger(t)), r || !e[1].hasOwnProperty(t) ? t : e[2] ? e[2] + e[1][t] : e[1][t];
  }
  message(e, t, i, n) {
    return t === void 0 ? n.emitDefaultValues ? null : void 0 : e.internalJsonWrite(t, n);
  }
  scalar(e, t, i, n, s) {
    if (t === void 0) {
      Ae(n);
      return;
    }
    const r = s || n;
    switch (e) {
      case P.INT32:
      case P.SFIXED32:
      case P.SINT32:
        return t === 0 ? r ? 0 : void 0 : (sr(t), t);
      case P.FIXED32:
      case P.UINT32:
        return t === 0 ? r ? 0 : void 0 : (Vo(t), t);
      case P.FLOAT:
        Yl(t);
      case P.DOUBLE:
        return t === 0 ? r ? 0 : void 0 : (Ae(typeof t == "number"), Number.isNaN(t) ? "NaN" : t === Number.POSITIVE_INFINITY ? "Infinity" : t === Number.NEGATIVE_INFINITY ? "-Infinity" : t);
      case P.STRING:
        return t === "" ? r ? "" : void 0 : (Ae(typeof t == "string"), t);
      case P.BOOL:
        return t === !1 ? r ? !1 : void 0 : (Ae(typeof t == "boolean"), t);
      case P.UINT64:
      case P.FIXED64:
        Ae(typeof t == "number" || typeof t == "string" || typeof t == "bigint");
        let a = bt.from(t);
        return a.isZero() && !r ? void 0 : a.toString();
      case P.INT64:
      case P.SFIXED64:
      case P.SINT64:
        Ae(typeof t == "number" || typeof t == "string" || typeof t == "bigint");
        let u = tt.from(t);
        return u.isZero() && !r ? void 0 : u.toString();
      case P.BYTES:
        return Ae(t instanceof Uint8Array), t.byteLength ? m9(t) : r ? "" : void 0;
    }
  }
};
l(P9, "ReflectionJsonWriter");
function Al(e, t = Bi.STRING) {
  switch (e) {
    case P.BOOL:
      return !1;
    case P.UINT64:
    case P.FIXED64:
      return ni(bt.ZERO, t);
    case P.INT64:
    case P.SFIXED64:
    case P.SINT64:
      return ni(tt.ZERO, t);
    case P.DOUBLE:
    case P.FLOAT:
      return 0;
    case P.BYTES:
      return new Uint8Array(0);
    case P.STRING:
      return "";
    default:
      return 0;
  }
}
l(Al, "reflectionScalarDefault");
var M9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    var e;
    if (!this.fieldNoToField) {
      const t = (e = this.info.fields) !== null && e !== void 0 ? e : [];
      this.fieldNoToField = new Map(t.map((i) => [i.no, i]));
    }
  }
  read(e, t, i, n) {
    this.prepare();
    const s = n === void 0 ? e.len : e.pos + n;
    for (; e.pos < s; ) {
      const [r, a] = e.tag(), u = this.fieldNoToField.get(r);
      if (!u) {
        let m = i.readUnknownField;
        if (m == "throw")
          throw new Error(`Unknown field ${r} (wire type ${a}) for ${this.info.typeName}`);
        let b = e.skip(a);
        m !== !1 && (m === !0 ? U.onRead : m)(this.info.typeName, t, r, a, b);
        continue;
      }
      let c = t, h = u.repeat, p = u.localName;
      switch (u.oneof && (c = c[u.oneof], c.oneofKind !== p && (c = t[u.oneof] = {
        oneofKind: p
      })), u.kind) {
        case "scalar":
        case "enum":
          let m = u.kind == "enum" ? P.INT32 : u.T, b = u.kind == "scalar" ? u.L : void 0;
          if (h) {
            let D = c[p];
            if (a == R.LengthDelimited && m != P.STRING && m != P.BYTES) {
              let I = e.uint32() + e.pos;
              for (; e.pos < I; )
                D.push(this.scalar(e, m, b));
            } else
              D.push(this.scalar(e, m, b));
          } else
            c[p] = this.scalar(e, m, b);
          break;
        case "message":
          if (h) {
            let D = c[p], I = u.T().internalBinaryRead(e, e.uint32(), i);
            D.push(I);
          } else
            c[p] = u.T().internalBinaryRead(e, e.uint32(), i, c[p]);
          break;
        case "map":
          let [C, k] = this.mapEntry(u, e, i);
          c[p][C] = k;
          break;
      }
    }
  }
  mapEntry(e, t, i) {
    let n = t.uint32(), s = t.pos + n, r, a;
    for (; t.pos < s; ) {
      let [u, c] = t.tag();
      switch (u) {
        case 1:
          e.K == P.BOOL ? r = t.bool().toString() : r = this.scalar(t, e.K, Bi.STRING);
          break;
        case 2:
          switch (e.V.kind) {
            case "scalar":
              a = this.scalar(t, e.V.T, e.V.L);
              break;
            case "enum":
              a = t.int32();
              break;
            case "message":
              a = e.V.T().internalBinaryRead(t, t.uint32(), i);
              break;
          }
          break;
        default:
          throw new Error(`Unknown field ${u} (wire type ${c}) in map entry for ${this.info.typeName}#${e.name}`);
      }
    }
    if (r === void 0) {
      let u = Al(e.K);
      r = e.K == P.BOOL ? u.toString() : u;
    }
    if (a === void 0)
      switch (e.V.kind) {
        case "scalar":
          a = Al(e.V.T, e.V.L);
          break;
        case "enum":
          a = 0;
          break;
        case "message":
          a = e.V.T().create();
          break;
      }
    return [r, a];
  }
  scalar(e, t, i) {
    switch (t) {
      case P.INT32:
        return e.int32();
      case P.STRING:
        return e.string();
      case P.BOOL:
        return e.bool();
      case P.DOUBLE:
        return e.double();
      case P.FLOAT:
        return e.float();
      case P.INT64:
        return ni(e.int64(), i);
      case P.UINT64:
        return ni(e.uint64(), i);
      case P.FIXED64:
        return ni(e.fixed64(), i);
      case P.FIXED32:
        return e.fixed32();
      case P.BYTES:
        return e.bytes();
      case P.UINT32:
        return e.uint32();
      case P.SFIXED32:
        return e.sfixed32();
      case P.SFIXED64:
        return ni(e.sfixed64(), i);
      case P.SINT32:
        return e.sint32();
      case P.SINT64:
        return ni(e.sint64(), i);
    }
  }
};
l(M9, "ReflectionBinaryReader");
var N9 = class {
  constructor(e) {
    this.info = e;
  }
  prepare() {
    if (!this.fields) {
      const e = this.info.fields ? this.info.fields.concat() : [];
      this.fields = e.sort((t, i) => t.no - i.no);
    }
  }
  write(e, t, i) {
    this.prepare();
    for (const s of this.fields) {
      let r, a, u = s.repeat, c = s.localName;
      if (s.oneof) {
        const h = e[s.oneof];
        if (h.oneofKind !== c)
          continue;
        r = h[c], a = !0;
      } else
        r = e[c], a = !1;
      switch (s.kind) {
        case "scalar":
        case "enum":
          let h = s.kind == "enum" ? P.INT32 : s.T;
          if (u)
            if (Ae(Array.isArray(r)), u == El.PACKED)
              this.packed(t, h, s.no, r);
            else
              for (const p of r)
                this.scalar(t, h, s.no, p, !0);
          else
            r === void 0 ? Ae(s.opt) : this.scalar(t, h, s.no, r, a || s.opt);
          break;
        case "message":
          if (u) {
            Ae(Array.isArray(r));
            for (const p of r)
              this.message(t, i, s.T(), s.no, p);
          } else
            this.message(t, i, s.T(), s.no, r);
          break;
        case "map":
          Ae(typeof r == "object" && r !== null);
          for (const [p, m] of Object.entries(r))
            this.mapEntry(t, i, s, p, m);
          break;
      }
    }
    let n = i.writeUnknownFields;
    n !== !1 && (n === !0 ? U.onWrite : n)(this.info.typeName, e, t);
  }
  mapEntry(e, t, i, n, s) {
    e.tag(i.no, R.LengthDelimited), e.fork();
    let r = n;
    switch (i.K) {
      case P.INT32:
      case P.FIXED32:
      case P.UINT32:
      case P.SFIXED32:
      case P.SINT32:
        r = Number.parseInt(n);
        break;
      case P.BOOL:
        Ae(n == "true" || n == "false"), r = n == "true";
        break;
    }
    switch (this.scalar(e, i.K, 1, r, !0), i.V.kind) {
      case "scalar":
        this.scalar(e, i.V.T, 2, s, !0);
        break;
      case "enum":
        this.scalar(e, P.INT32, 2, s, !0);
        break;
      case "message":
        this.message(e, t, i.V.T(), 2, s);
        break;
    }
    e.join();
  }
  message(e, t, i, n, s) {
    s !== void 0 && (i.internalBinaryWrite(s, e.tag(n, R.LengthDelimited).fork(), t), e.join());
  }
  scalar(e, t, i, n, s) {
    let [r, a, u] = this.scalarInfo(t, n);
    (!u || s) && (e.tag(i, r), e[a](n));
  }
  packed(e, t, i, n) {
    if (!n.length)
      return;
    Ae(t !== P.BYTES && t !== P.STRING), e.tag(i, R.LengthDelimited), e.fork();
    let [, s] = this.scalarInfo(t);
    for (let r = 0; r < n.length; r++)
      e[s](n[r]);
    e.join();
  }
  scalarInfo(e, t) {
    let i = R.Varint, n, s = t === void 0, r = t === 0;
    switch (e) {
      case P.INT32:
        n = "int32";
        break;
      case P.STRING:
        r = s || !t.length, i = R.LengthDelimited, n = "string";
        break;
      case P.BOOL:
        r = t === !1, n = "bool";
        break;
      case P.UINT32:
        n = "uint32";
        break;
      case P.DOUBLE:
        i = R.Bit64, n = "double";
        break;
      case P.FLOAT:
        i = R.Bit32, n = "float";
        break;
      case P.INT64:
        r = s || tt.from(t).isZero(), n = "int64";
        break;
      case P.UINT64:
        r = s || bt.from(t).isZero(), n = "uint64";
        break;
      case P.FIXED64:
        r = s || bt.from(t).isZero(), i = R.Bit64, n = "fixed64";
        break;
      case P.BYTES:
        r = s || !t.byteLength, i = R.LengthDelimited, n = "bytes";
        break;
      case P.FIXED32:
        i = R.Bit32, n = "fixed32";
        break;
      case P.SFIXED32:
        i = R.Bit32, n = "sfixed32";
        break;
      case P.SFIXED64:
        r = s || tt.from(t).isZero(), i = R.Bit64, n = "sfixed64";
        break;
      case P.SINT32:
        n = "sint32";
        break;
      case P.SINT64:
        r = s || tt.from(t).isZero(), n = "sint64";
        break;
    }
    return [i, n, s || r];
  }
};
l(N9, "ReflectionBinaryWriter");
function R9(e) {
  const t = {};
  Object.defineProperty(t, ye, { enumerable: !1, value: e });
  for (let i of e.fields) {
    let n = i.localName;
    if (!i.opt)
      if (i.oneof)
        t[i.oneof] = { oneofKind: void 0 };
      else if (i.repeat)
        t[n] = [];
      else
        switch (i.kind) {
          case "scalar":
            t[n] = Al(i.T, i.L);
            break;
          case "enum":
            t[n] = 0;
            break;
          case "map":
            t[n] = {};
            break;
        }
  }
  return t;
}
l(R9, "reflectionCreate");
function fe(e, t, i) {
  let n, s = i, r;
  for (let a of e.fields) {
    let u = a.localName;
    if (a.oneof) {
      const c = s[a.oneof];
      if (c == null)
        continue;
      if (n = c[u], r = t[a.oneof], r.oneofKind = c.oneofKind, n == null) {
        delete r[u];
        continue;
      }
    } else if (n = s[u], r = t, n == null)
      continue;
    switch (a.kind) {
      case "scalar":
      case "enum":
        a.repeat ? r[u] = n.concat() : r[u] = n;
        break;
      case "message":
        let c = a.T();
        if (a.repeat)
          for (let h = 0; h < n.length; h++)
            r[u][h] = c.create(n[h]);
        else
          r[u] === void 0 ? r[u] = c.create(n) : c.mergePartial(r[u], n);
        break;
      case "map":
        switch (a.V.kind) {
          case "scalar":
          case "enum":
            Object.assign(r[u], n);
            break;
          case "message":
            let h = a.V.T();
            for (let p of Object.keys(n))
              r[u][p] = h.create(n[p]);
            break;
        }
        break;
    }
  }
}
l(fe, "reflectionMergePartial");
function L9(e, t, i) {
  if (t === i)
    return !0;
  if (!t || !i)
    return !1;
  for (let n of e.fields) {
    let s = n.localName, r = n.oneof ? t[n.oneof][s] : t[s], a = n.oneof ? i[n.oneof][s] : i[s];
    switch (n.kind) {
      case "enum":
      case "scalar":
        let u = n.kind == "enum" ? P.INT32 : n.T;
        if (!(n.repeat ? G1(u, r, a) : jc(u, r, a)))
          return !1;
        break;
      case "map":
        if (!(n.V.kind == "message" ? q1(n.V.T(), wa(r), wa(a)) : G1(n.V.kind == "enum" ? P.INT32 : n.V.T, wa(r), wa(a))))
          return !1;
        break;
      case "message":
        let c = n.T();
        if (!(n.repeat ? q1(c, r, a) : c.equals(r, a)))
          return !1;
        break;
    }
  }
  return !0;
}
l(L9, "reflectionEquals");
var wa = Object.values;
function jc(e, t, i) {
  if (t === i)
    return !0;
  if (e !== P.BYTES)
    return !1;
  let n = t, s = i;
  if (n.length !== s.length)
    return !1;
  for (let r = 0; r < n.length; r++)
    if (n[r] != s[r])
      return !1;
  return !0;
}
l(jc, "primitiveEq");
function G1(e, t, i) {
  if (t.length !== i.length)
    return !1;
  for (let n = 0; n < t.length; n++)
    if (!jc(e, t[n], i[n]))
      return !1;
  return !0;
}
l(G1, "repeatedPrimitiveEq");
function q1(e, t, i) {
  if (t.length !== i.length)
    return !1;
  for (let n = 0; n < t.length; n++)
    if (!e.equals(t[n], i[n]))
      return !1;
  return !0;
}
l(q1, "repeatedMsgEq");
var _e = class {
  constructor(e, t, i) {
    this.defaultCheckDepth = 16, this.typeName = e, this.fields = t.map(E9), this.options = i != null ? i : {}, this.refTypeCheck = new k9(this), this.refJsonReader = new I9(this), this.refJsonWriter = new P9(this), this.refBinReader = new M9(this), this.refBinWriter = new N9(this);
  }
  create(e) {
    let t = R9(this);
    return e !== void 0 && fe(this, t, e), t;
  }
  clone(e) {
    let t = this.create();
    return fe(this, t, e), t;
  }
  equals(e, t) {
    return L9(this, e, t);
  }
  is(e, t = this.defaultCheckDepth) {
    return this.refTypeCheck.is(e, t, !1);
  }
  isAssignable(e, t = this.defaultCheckDepth) {
    return this.refTypeCheck.is(e, t, !0);
  }
  mergePartial(e, t) {
    fe(this, e, t);
  }
  fromBinary(e, t) {
    let i = b9(t);
    return this.internalBinaryRead(i.readerFactory(e), e.byteLength, i);
  }
  fromJson(e, t) {
    return this.internalJsonRead(e, T9(t));
  }
  fromJsonString(e, t) {
    let i = JSON.parse(e);
    return this.fromJson(i, t);
  }
  toJson(e, t) {
    return this.internalJsonWrite(e, x9(t));
  }
  toJsonString(e, t) {
    var i;
    let n = this.toJson(e, t);
    return JSON.stringify(n, null, (i = t == null ? void 0 : t.prettySpaces) !== null && i !== void 0 ? i : 0);
  }
  toBinary(e, t) {
    let i = S9(t);
    return this.internalBinaryWrite(e, i.writerFactory(), i).finish();
  }
  internalJsonRead(e, t, i) {
    if (e !== null && typeof e == "object" && !Array.isArray(e)) {
      let n = i != null ? i : this.create();
      return this.refJsonReader.read(e, n, t), n;
    }
    throw new Error(`Unable to parse message ${this.typeName} from JSON ${Oc(e)}.`);
  }
  internalJsonWrite(e, t) {
    return this.refJsonWriter.write(e, t);
  }
  internalBinaryWrite(e, t, i) {
    return this.refBinWriter.write(e, t, i), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create();
    return this.refBinReader.read(e, s, i, t), s;
  }
};
l(_e, "MessageType");
var D9 = class extends _e {
  constructor() {
    super("youtube.VisitorData", [
      { no: 1, name: "id", kind: "scalar", T: 9 },
      { no: 5, name: "timestamp", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { id: "", timestamp: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.id = e.string();
          break;
        case 5:
          s.timestamp = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.id !== "" && t.tag(1, R.LengthDelimited).string(e.id), e.timestamp !== 0 && t.tag(5, R.Varint).int32(e.timestamp);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(D9, "VisitorData$Type");
var n7 = new D9(), B9 = class extends _e {
  constructor() {
    super("youtube.ChannelAnalytics", [
      { no: 32, name: "params", kind: "message", T: () => e1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 32:
          s.params = e1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && e1.internalBinaryWrite(e.params, t.tag(32, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(B9, "ChannelAnalytics$Type");
var s7 = new B9(), O9 = class extends _e {
  constructor() {
    super("youtube.ChannelAnalytics.Params", [
      { no: 1001, name: "channel_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { channelId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1001:
          s.channelId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1001, R.LengthDelimited).string(e.channelId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(O9, "ChannelAnalytics_Params$Type");
var e1 = new O9(), F9 = class extends _e {
  constructor() {
    super("youtube.InnertubePayload", [
      { no: 1, name: "context", kind: "message", T: () => t1 },
      { no: 2, name: "target", kind: "scalar", opt: !0, T: 9 },
      { no: 20, name: "video_settings", kind: "message", T: () => n1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.context = t1.internalBinaryRead(e, e.uint32(), i, s.context);
          break;
        case 2:
          s.target = e.string();
          break;
        case 20:
          s.videoSettings = n1.internalBinaryRead(e, e.uint32(), i, s.videoSettings);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.context && t1.internalBinaryWrite(e.context, t.tag(1, R.LengthDelimited).fork(), i).join(), e.target !== void 0 && t.tag(2, R.LengthDelimited).string(e.target), e.videoSettings && n1.internalBinaryWrite(e.videoSettings, t.tag(20, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(F9, "InnertubePayload$Type");
var r7 = new F9(), V9 = class extends _e {
  constructor() {
    super("youtube.InnertubePayload.Context", [
      { no: 1, name: "client", kind: "message", T: () => i1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.client = i1.internalBinaryRead(e, e.uint32(), i, s.client);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.client && i1.internalBinaryWrite(e.client, t.tag(1, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(V9, "InnertubePayload_Context$Type");
var t1 = new V9(), U9 = class extends _e {
  constructor() {
    super("youtube.InnertubePayload.Context.Client", [
      { no: 16, name: "unkparam", kind: "scalar", T: 5 },
      { no: 17, name: "client_version", kind: "scalar", T: 9 },
      { no: 18, name: "client_name", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { unkparam: 0, clientVersion: "", clientName: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 16:
          s.unkparam = e.int32();
          break;
        case 17:
          s.clientVersion = e.string();
          break;
        case 18:
          s.clientName = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkparam !== 0 && t.tag(16, R.Varint).int32(e.unkparam), e.clientVersion !== "" && t.tag(17, R.LengthDelimited).string(e.clientVersion), e.clientName !== "" && t.tag(18, R.LengthDelimited).string(e.clientName);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(U9, "InnertubePayload_Context_Client$Type");
var i1 = new U9(), j9 = class extends _e {
  constructor() {
    super("youtube.InnertubePayload.VideoSettings", [
      { no: 1, name: "type", kind: "scalar", T: 5 },
      { no: 3, name: "thumbnail", kind: "message", T: () => s1 }
    ]);
  }
  create(e) {
    const t = { type: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.type = e.int32();
          break;
        case 3:
          s.thumbnail = s1.internalBinaryRead(e, e.uint32(), i, s.thumbnail);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type !== 0 && t.tag(1, R.Varint).int32(e.type), e.thumbnail && s1.internalBinaryWrite(e.thumbnail, t.tag(3, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(j9, "InnertubePayload_VideoSettings$Type");
var n1 = new j9(), H9 = class extends _e {
  constructor() {
    super("youtube.InnertubePayload.VideoSettings.Thumbnail", [
      { no: 1, name: "image_data", kind: "scalar", T: 12 }
    ]);
  }
  create(e) {
    const t = { imageData: new Uint8Array(0) };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.imageData = e.bytes();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.imageData.length && t.tag(1, R.LengthDelimited).bytes(e.imageData);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(H9, "InnertubePayload_VideoSettings_Thumbnail$Type");
var s1 = new H9(), W9 = class extends _e {
  constructor() {
    super("youtube.SoundInfoParams", [
      { no: 94, name: "sound", kind: "message", T: () => r1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 94:
          s.sound = r1.internalBinaryRead(e, e.uint32(), i, s.sound);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.sound && r1.internalBinaryWrite(e.sound, t.tag(94, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(W9, "SoundInfoParams$Type");
var o7 = new W9(), $9 = class extends _e {
  constructor() {
    super("youtube.SoundInfoParams.Sound", [
      { no: 1, name: "params", kind: "message", T: () => o1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.params = o1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && o1.internalBinaryWrite(e.params, t.tag(1, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l($9, "SoundInfoParams_Sound$Type");
var r1 = new $9(), G9 = class extends _e {
  constructor() {
    super("youtube.SoundInfoParams.Sound.Params", [
      { no: 2, name: "ids", kind: "message", T: () => a1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.ids = a1.internalBinaryRead(e, e.uint32(), i, s.ids);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ids && a1.internalBinaryWrite(e.ids, t.tag(2, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(G9, "SoundInfoParams_Sound_Params$Type");
var o1 = new G9(), q9 = class extends _e {
  constructor() {
    super("youtube.SoundInfoParams.Sound.Params.Ids", [
      { no: 1, name: "id_1", kind: "scalar", T: 9 },
      { no: 2, name: "id_2", kind: "scalar", T: 9 },
      { no: 3, name: "id_3", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { id1: "", id2: "", id3: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.id1 = e.string();
          break;
        case 2:
          s.id2 = e.string();
          break;
        case 3:
          s.id3 = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.id1 !== "" && t.tag(1, R.LengthDelimited).string(e.id1), e.id2 !== "" && t.tag(2, R.LengthDelimited).string(e.id2), e.id3 !== "" && t.tag(3, R.LengthDelimited).string(e.id3);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(q9, "SoundInfoParams_Sound_Params_Ids$Type");
var a1 = new q9(), z9 = class extends _e {
  constructor() {
    super("youtube.NotificationPreferences", [
      { no: 1, name: "channel_id", kind: "scalar", T: 9 },
      { no: 2, name: "pref_id", kind: "message", T: () => l1 },
      { no: 3, name: "number_0", kind: "scalar", opt: !0, T: 5 },
      { no: 4, name: "number_1", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = { channelId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.channelId = e.string();
          break;
        case 2:
          s.prefId = l1.internalBinaryRead(e, e.uint32(), i, s.prefId);
          break;
        case 3:
          s.number0 = e.int32();
          break;
        case 4:
          s.number1 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1, R.LengthDelimited).string(e.channelId), e.prefId && l1.internalBinaryWrite(e.prefId, t.tag(2, R.LengthDelimited).fork(), i).join(), e.number0 !== void 0 && t.tag(3, R.Varint).int32(e.number0), e.number1 !== void 0 && t.tag(4, R.Varint).int32(e.number1);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(z9, "NotificationPreferences$Type");
var a7 = new z9(), K9 = class extends _e {
  constructor() {
    super("youtube.NotificationPreferences.Preference", [
      { no: 1, name: "index", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { index: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.index = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.index !== 0 && t.tag(1, R.Varint).int32(e.index);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(K9, "NotificationPreferences_Preference$Type");
var l1 = new K9(), Y9 = class extends _e {
  constructor() {
    super("youtube.LiveMessageParams", [
      { no: 1, name: "params", kind: "message", T: () => u1 },
      { no: 2, name: "number_0", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "number_1", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.params = u1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 2:
          s.number0 = e.int32();
          break;
        case 3:
          s.number1 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && u1.internalBinaryWrite(e.params, t.tag(1, R.LengthDelimited).fork(), i).join(), e.number0 !== void 0 && t.tag(2, R.Varint).int32(e.number0), e.number1 !== void 0 && t.tag(3, R.Varint).int32(e.number1);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Y9, "LiveMessageParams$Type");
var l7 = new Y9(), X9 = class extends _e {
  constructor() {
    super("youtube.LiveMessageParams.Params", [
      { no: 5, name: "ids", kind: "message", T: () => c1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 5:
          s.ids = c1.internalBinaryRead(e, e.uint32(), i, s.ids);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ids && c1.internalBinaryWrite(e.ids, t.tag(5, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(X9, "LiveMessageParams_Params$Type");
var u1 = new X9(), J9 = class extends _e {
  constructor() {
    super("youtube.LiveMessageParams.Params.Ids", [
      { no: 1, name: "channel_id", kind: "scalar", T: 9 },
      { no: 2, name: "video_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { channelId: "", videoId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.channelId = e.string();
          break;
        case 2:
          s.videoId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.channelId !== "" && t.tag(1, R.LengthDelimited).string(e.channelId), e.videoId !== "" && t.tag(2, R.LengthDelimited).string(e.videoId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(J9, "LiveMessageParams_Params_Ids$Type");
var c1 = new J9(), Z9 = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams", [
      { no: 2, name: "ctx", kind: "message", T: () => h1 },
      { no: 3, name: "unk_param", kind: "scalar", T: 5 },
      { no: 6, name: "params", kind: "message", T: () => d1 }
    ]);
  }
  create(e) {
    const t = { unkParam: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.ctx = h1.internalBinaryRead(e, e.uint32(), i, s.ctx);
          break;
        case 3:
          s.unkParam = e.int32();
          break;
        case 6:
          s.params = d1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.ctx && h1.internalBinaryWrite(e.ctx, t.tag(2, R.LengthDelimited).fork(), i).join(), e.unkParam !== 0 && t.tag(3, R.Varint).int32(e.unkParam), e.params && d1.internalBinaryWrite(e.params, t.tag(6, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Z9, "GetCommentsSectionParams$Type");
var T5 = new Z9(), Q9 = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams.Context", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { videoId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, R.LengthDelimited).string(e.videoId);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(Q9, "GetCommentsSectionParams_Context$Type");
var h1 = new Q9(), eg = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params", [
      { no: 1, name: "unk_token", kind: "scalar", opt: !0, T: 9 },
      { no: 4, name: "opts", kind: "message", T: () => p1 },
      { no: 3, name: "replies_opts", kind: "message", T: () => f1 },
      { no: 5, name: "page", kind: "scalar", opt: !0, T: 5 },
      { no: 8, name: "target", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { target: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkToken = e.string();
          break;
        case 4:
          s.opts = p1.internalBinaryRead(e, e.uint32(), i, s.opts);
          break;
        case 3:
          s.repliesOpts = f1.internalBinaryRead(e, e.uint32(), i, s.repliesOpts);
          break;
        case 5:
          s.page = e.int32();
          break;
        case 8:
          s.target = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkToken !== void 0 && t.tag(1, R.LengthDelimited).string(e.unkToken), e.opts && p1.internalBinaryWrite(e.opts, t.tag(4, R.LengthDelimited).fork(), i).join(), e.repliesOpts && f1.internalBinaryWrite(e.repliesOpts, t.tag(3, R.LengthDelimited).fork(), i).join(), e.page !== void 0 && t.tag(5, R.Varint).int32(e.page), e.target !== "" && t.tag(8, R.LengthDelimited).string(e.target);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(eg, "GetCommentsSectionParams_Params$Type");
var d1 = new eg(), tg = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.Options", [
      { no: 4, name: "video_id", kind: "scalar", T: 9 },
      { no: 6, name: "sort_by", kind: "scalar", T: 5 },
      { no: 15, name: "type", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", sortBy: 0, type: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 4:
          s.videoId = e.string();
          break;
        case 6:
          s.sortBy = e.int32();
          break;
        case 15:
          s.type = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(4, R.LengthDelimited).string(e.videoId), e.sortBy !== 0 && t.tag(6, R.Varint).int32(e.sortBy), e.type !== 0 && t.tag(15, R.Varint).int32(e.type);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(tg, "GetCommentsSectionParams_Params_Options$Type");
var p1 = new tg(), ig = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.RepliesOptions", [
      { no: 2, name: "comment_id", kind: "scalar", T: 9 },
      { no: 4, name: "unkopts", kind: "message", T: () => m1 },
      { no: 5, name: "channel_id", kind: "scalar", opt: !0, T: 9 },
      { no: 6, name: "video_id", kind: "scalar", T: 9 },
      { no: 8, name: "unk_param_1", kind: "scalar", T: 5 },
      { no: 9, name: "unk_param_2", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { commentId: "", videoId: "", unkParam1: 0, unkParam2: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.commentId = e.string();
          break;
        case 4:
          s.unkopts = m1.internalBinaryRead(e, e.uint32(), i, s.unkopts);
          break;
        case 5:
          s.channelId = e.string();
          break;
        case 6:
          s.videoId = e.string();
          break;
        case 8:
          s.unkParam1 = e.int32();
          break;
        case 9:
          s.unkParam2 = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.commentId !== "" && t.tag(2, R.LengthDelimited).string(e.commentId), e.unkopts && m1.internalBinaryWrite(e.unkopts, t.tag(4, R.LengthDelimited).fork(), i).join(), e.channelId !== void 0 && t.tag(5, R.LengthDelimited).string(e.channelId), e.videoId !== "" && t.tag(6, R.LengthDelimited).string(e.videoId), e.unkParam1 !== 0 && t.tag(8, R.Varint).int32(e.unkParam1), e.unkParam2 !== 0 && t.tag(9, R.Varint).int32(e.unkParam2);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ig, "GetCommentsSectionParams_Params_RepliesOptions$Type");
var f1 = new ig(), ng = class extends _e {
  constructor() {
    super("youtube.GetCommentsSectionParams.Params.RepliesOptions.UnkOpts", [
      { no: 1, name: "unk_param", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { unkParam: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkParam = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkParam !== 0 && t.tag(1, R.Varint).int32(e.unkParam);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ng, "GetCommentsSectionParams_Params_RepliesOptions_UnkOpts$Type");
var m1 = new ng(), sg = class extends _e {
  constructor() {
    super("youtube.CreateCommentParams", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 },
      { no: 5, name: "params", kind: "message", T: () => v1 },
      { no: 10, name: "number", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", number: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        case 5:
          s.params = v1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 10:
          s.number = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, R.LengthDelimited).string(e.videoId), e.params && v1.internalBinaryWrite(e.params, t.tag(5, R.LengthDelimited).fork(), i).join(), e.number !== 0 && t.tag(10, R.Varint).int32(e.number);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(sg, "CreateCommentParams$Type");
var u7 = new sg(), rg = class extends _e {
  constructor() {
    super("youtube.CreateCommentParams.Params", [
      { no: 1, name: "index", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { index: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.index = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.index !== 0 && t.tag(1, R.Varint).int32(e.index);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(rg, "CreateCommentParams_Params$Type");
var v1 = new rg(), og = class extends _e {
  constructor() {
    super("youtube.CreateCommentReplyParams", [
      { no: 2, name: "video_id", kind: "scalar", T: 9 },
      { no: 4, name: "comment_id", kind: "scalar", T: 9 },
      { no: 5, name: "params", kind: "message", T: () => g1 },
      { no: 10, name: "unk_num", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = { videoId: "", commentId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.videoId = e.string();
          break;
        case 4:
          s.commentId = e.string();
          break;
        case 5:
          s.params = g1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 10:
          s.unkNum = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.videoId !== "" && t.tag(2, R.LengthDelimited).string(e.videoId), e.commentId !== "" && t.tag(4, R.LengthDelimited).string(e.commentId), e.params && g1.internalBinaryWrite(e.params, t.tag(5, R.LengthDelimited).fork(), i).join(), e.unkNum !== void 0 && t.tag(10, R.Varint).int32(e.unkNum);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(og, "CreateCommentReplyParams$Type");
var c7 = new og(), ag = class extends _e {
  constructor() {
    super("youtube.CreateCommentReplyParams.UnknownParams", [
      { no: 1, name: "unk_num", kind: "scalar", T: 5 }
    ]);
  }
  create(e) {
    const t = { unkNum: 0 };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.unkNum = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.unkNum !== 0 && t.tag(1, R.Varint).int32(e.unkNum);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ag, "CreateCommentReplyParams_UnknownParams$Type");
var g1 = new ag(), lg = class extends _e {
  constructor() {
    super("youtube.PeformCommentActionParams", [
      { no: 1, name: "type", kind: "scalar", T: 5 },
      { no: 3, name: "comment_id", kind: "scalar", T: 9 },
      { no: 5, name: "video_id", kind: "scalar", T: 9 },
      { no: 2, name: "unk_num", kind: "scalar", opt: !0, T: 5 },
      { no: 23, name: "channel_id", kind: "scalar", opt: !0, T: 9 },
      { no: 31, name: "translate_comment_params", kind: "message", T: () => y1 }
    ]);
  }
  create(e) {
    const t = { type: 0, commentId: "", videoId: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.type = e.int32();
          break;
        case 3:
          s.commentId = e.string();
          break;
        case 5:
          s.videoId = e.string();
          break;
        case 2:
          s.unkNum = e.int32();
          break;
        case 23:
          s.channelId = e.string();
          break;
        case 31:
          s.translateCommentParams = y1.internalBinaryRead(e, e.uint32(), i, s.translateCommentParams);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type !== 0 && t.tag(1, R.Varint).int32(e.type), e.commentId !== "" && t.tag(3, R.LengthDelimited).string(e.commentId), e.videoId !== "" && t.tag(5, R.LengthDelimited).string(e.videoId), e.unkNum !== void 0 && t.tag(2, R.Varint).int32(e.unkNum), e.channelId !== void 0 && t.tag(23, R.LengthDelimited).string(e.channelId), e.translateCommentParams && y1.internalBinaryWrite(e.translateCommentParams, t.tag(31, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(lg, "PeformCommentActionParams$Type");
var h7 = new lg(), ug = class extends _e {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams", [
      { no: 3, name: "params", kind: "message", T: () => _1 },
      { no: 2, name: "comment_id", kind: "scalar", T: 9 },
      { no: 4, name: "target_language", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { commentId: "", targetLanguage: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 3:
          s.params = _1.internalBinaryRead(e, e.uint32(), i, s.params);
          break;
        case 2:
          s.commentId = e.string();
          break;
        case 4:
          s.targetLanguage = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.params && _1.internalBinaryWrite(e.params, t.tag(3, R.LengthDelimited).fork(), i).join(), e.commentId !== "" && t.tag(2, R.LengthDelimited).string(e.commentId), e.targetLanguage !== "" && t.tag(4, R.LengthDelimited).string(e.targetLanguage);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(ug, "PeformCommentActionParams_TranslateCommentParams$Type");
var y1 = new ug(), cg = class extends _e {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams.Params", [
      { no: 1, name: "comment", kind: "message", T: () => b1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.comment = b1.internalBinaryRead(e, e.uint32(), i, s.comment);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.comment && b1.internalBinaryWrite(e.comment, t.tag(1, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(cg, "PeformCommentActionParams_TranslateCommentParams_Params$Type");
var _1 = new cg(), hg = class extends _e {
  constructor() {
    super("youtube.PeformCommentActionParams.TranslateCommentParams.Params.Comment", [
      { no: 1, name: "text", kind: "scalar", T: 9 }
    ]);
  }
  create(e) {
    const t = { text: "" };
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.text = e.string();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.text !== "" && t.tag(1, R.LengthDelimited).string(e.text);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(hg, "PeformCommentActionParams_TranslateCommentParams_Params_Comment$Type");
var b1 = new hg(), dg = class extends _e {
  constructor() {
    super("youtube.MusicSearchFilter", [
      { no: 2, name: "filters", kind: "message", T: () => w1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 2:
          s.filters = w1.internalBinaryRead(e, e.uint32(), i, s.filters);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.filters && w1.internalBinaryWrite(e.filters, t.tag(2, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(dg, "MusicSearchFilter$Type");
var d7 = new dg(), pg = class extends _e {
  constructor() {
    super("youtube.MusicSearchFilter.Filters", [
      { no: 17, name: "type", kind: "message", T: () => S1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 17:
          s.type = S1.internalBinaryRead(e, e.uint32(), i, s.type);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.type && S1.internalBinaryWrite(e.type, t.tag(17, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(pg, "MusicSearchFilter_Filters$Type");
var w1 = new pg(), fg = class extends _e {
  constructor() {
    super("youtube.MusicSearchFilter.Filters.Type", [
      { no: 1, name: "song", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "video", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "album", kind: "scalar", opt: !0, T: 5 },
      { no: 4, name: "artist", kind: "scalar", opt: !0, T: 5 },
      { no: 5, name: "playlist", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.song = e.int32();
          break;
        case 2:
          s.video = e.int32();
          break;
        case 3:
          s.album = e.int32();
          break;
        case 4:
          s.artist = e.int32();
          break;
        case 5:
          s.playlist = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.song !== void 0 && t.tag(1, R.Varint).int32(e.song), e.video !== void 0 && t.tag(2, R.Varint).int32(e.video), e.album !== void 0 && t.tag(3, R.Varint).int32(e.album), e.artist !== void 0 && t.tag(4, R.Varint).int32(e.artist), e.playlist !== void 0 && t.tag(5, R.Varint).int32(e.playlist);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(fg, "MusicSearchFilter_Filters_Type$Type");
var S1 = new fg(), mg = class extends _e {
  constructor() {
    super("youtube.SearchFilter", [
      { no: 1, name: "sort_by", kind: "scalar", opt: !0, T: 5 },
      { no: 19, name: "no_filter", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "filters", kind: "message", T: () => C1 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.sortBy = e.int32();
          break;
        case 19:
          s.noFilter = e.int32();
          break;
        case 2:
          s.filters = C1.internalBinaryRead(e, e.uint32(), i, s.filters);
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.sortBy !== void 0 && t.tag(1, R.Varint).int32(e.sortBy), e.noFilter !== void 0 && t.tag(19, R.Varint).int32(e.noFilter), e.filters && C1.internalBinaryWrite(e.filters, t.tag(2, R.LengthDelimited).fork(), i).join();
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(mg, "SearchFilter$Type");
var p7 = new mg(), vg = class extends _e {
  constructor() {
    super("youtube.SearchFilter.Filters", [
      { no: 1, name: "upload_date", kind: "scalar", opt: !0, T: 5 },
      { no: 2, name: "type", kind: "scalar", opt: !0, T: 5 },
      { no: 3, name: "duration", kind: "scalar", opt: !0, T: 5 }
    ]);
  }
  create(e) {
    const t = {};
    return globalThis.Object.defineProperty(t, ye, { enumerable: !1, value: this }), e !== void 0 && fe(this, t, e), t;
  }
  internalBinaryRead(e, t, i, n) {
    let s = n != null ? n : this.create(), r = e.pos + t;
    for (; e.pos < r; ) {
      let [a, u] = e.tag();
      switch (a) {
        case 1:
          s.uploadDate = e.int32();
          break;
        case 2:
          s.type = e.int32();
          break;
        case 3:
          s.duration = e.int32();
          break;
        default:
          let c = i.readUnknownField;
          if (c === "throw")
            throw new globalThis.Error(`Unknown field ${a} (wire type ${u}) for ${this.typeName}`);
          let h = e.skip(u);
          c !== !1 && (c === !0 ? U.onRead : c)(this.typeName, s, a, u, h);
      }
    }
    return s;
  }
  internalBinaryWrite(e, t, i) {
    e.uploadDate !== void 0 && t.tag(1, R.Varint).int32(e.uploadDate), e.type !== void 0 && t.tag(2, R.Varint).int32(e.type), e.duration !== void 0 && t.tag(3, R.Varint).int32(e.duration);
    let n = i.writeUnknownFields;
    return n !== !1 && (n == !0 ? U.onWrite : n)(this.typeName, e, t), t;
  }
};
l(vg, "SearchFilter_Filters$Type");
var C1 = new vg(), gg = class {
  static encodeVisitorData(e, t) {
    const i = n7.toBinary({
      id: e,
      timestamp: t
    });
    return encodeURIComponent(Nt(i).replace(/\/|\+/g, "_"));
  }
  static encodeChannelAnalyticsParams(e) {
    const t = s7.toBinary({
      params: {
        channelId: e
      }
    });
    return encodeURIComponent(Nt(t));
  }
  static encodeSearchFilters(e) {
    const t = {
      all: void 0,
      hour: 1,
      today: 2,
      week: 3,
      month: 4,
      year: 5
    }, i = {
      all: void 0,
      video: 1,
      channel: 2,
      playlist: 3,
      movie: 4
    }, n = {
      all: void 0,
      short: 1,
      long: 2,
      medium: 3
    }, s = {
      relevance: void 0,
      rating: 1,
      upload_date: 2,
      view_count: 3
    }, r = {};
    if (e ? r.filters = {} : r.noFilter = 0, r.filters) {
      if (e.upload_date && e.type !== "video")
        throw new Error(`Upload date filter cannot be used with type ${e.type}`);
      e.upload_date && (r.filters.uploadDate = t[e.upload_date]), e.type && (r.filters.type = i[e.type]), e.duration && (r.filters.duration = n[e.duration]), e.sort_by && e.sort_by !== "relevance" && (r.sortBy = s[e.sort_by]);
    }
    const a = p7.toBinary(r);
    return encodeURIComponent(Nt(a));
  }
  static encodeMusicSearchFilters(e) {
    var t;
    const i = {
      filters: {
        type: {}
      }
    };
    e.type && e.type !== "all" && ((t = i.filters) === null || t === void 0 ? void 0 : t.type) && (i.filters.type[e.type] = 1);
    const n = d7.toBinary(i);
    return encodeURIComponent(Nt(n));
  }
  static encodeMessageParams(e, t) {
    const i = l7.toBinary({
      params: {
        ids: {
          channelId: e,
          videoId: t
        }
      },
      number0: 1,
      number1: 4
    });
    return btoa(encodeURIComponent(Nt(i)));
  }
  static encodeCommentsSectionParams(e, t = {}) {
    const i = {
      TOP_COMMENTS: 0,
      NEWEST_FIRST: 1
    }, n = T5.toBinary({
      ctx: {
        videoId: e
      },
      unkParam: 6,
      params: {
        opts: {
          videoId: e,
          sortBy: i[t.sort_by || "TOP_COMMENTS"],
          type: t.type || 2
        },
        target: "comments-section"
      }
    });
    return encodeURIComponent(Nt(n));
  }
  static encodeCommentRepliesParams(e, t) {
    const i = T5.toBinary({
      ctx: {
        videoId: e
      },
      unkParam: 6,
      params: {
        repliesOpts: {
          videoId: e,
          commentId: t,
          unkopts: {
            unkParam: 0
          },
          unkParam1: 1,
          unkParam2: 10,
          channelId: " "
        },
        target: `comment-replies-item-${t}`
      }
    });
    return encodeURIComponent(Nt(i));
  }
  static encodeCommentParams(e) {
    const t = u7.toBinary({
      videoId: e,
      params: {
        index: 0
      },
      number: 7
    });
    return encodeURIComponent(Nt(t));
  }
  static encodeCommentReplyParams(e, t) {
    const i = c7.toBinary({
      videoId: t,
      commentId: e,
      params: {
        unkNum: 0
      },
      unkNum: 7
    });
    return encodeURIComponent(Nt(i));
  }
  static encodeCommentActionParams(e, t = {}) {
    const i = {
      type: e,
      commentId: t.comment_id || " ",
      videoId: t.video_id || " ",
      unkNum: 2
    };
    if (t.hasOwnProperty("text")) {
      if (typeof t.target_language != "string")
        throw new Error("target_language must be a string");
      t.comment_id && delete i.unkNum, i.translateCommentParams = {
        params: {
          comment: {
            text: t.text
          }
        },
        commentId: t.comment_id || " ",
        targetLanguage: t.target_language
      };
    }
    const n = h7.toBinary(i);
    return encodeURIComponent(Nt(n));
  }
  static encodeNotificationPref(e, t) {
    const i = a7.toBinary({
      channelId: e,
      prefId: {
        index: t
      },
      number0: 0,
      number1: 4
    });
    return encodeURIComponent(Nt(i));
  }
  static encodeCustomThumbnailPayload(e, t) {
    const i = {
      context: {
        client: {
          unkparam: 14,
          clientName: Cl.ANDROID.NAME,
          clientVersion: Cl.ANDROID.VERSION
        }
      },
      target: e,
      videoSettings: {
        type: 3,
        thumbnail: {
          imageData: t
        }
      }
    };
    return r7.toBinary(i);
  }
  static encodeSoundInfoParams(e) {
    const t = {
      sound: {
        params: {
          ids: {
            id1: e,
            id2: e,
            id3: e
          }
        }
      }
    }, i = o7.toBinary(t);
    return encodeURIComponent(Nt(i));
  }
};
l(gg, "Proto");
var Rt = gg, yg = class {
  constructor(e) {
    this.itag = e.itag, this.mime_type = e.mimeType, this.bitrate = e.bitrate, this.average_bitrate = e.averageBitrate, this.width = e.width || void 0, this.height = e.height || void 0, this.init_range = e.initRange ? {
      start: parseInt(e.initRange.start),
      end: parseInt(e.initRange.end)
    } : void 0, this.index_range = e.indexRange ? {
      start: parseInt(e.indexRange.start),
      end: parseInt(e.indexRange.end)
    } : void 0, this.last_modified = new Date(Math.floor(parseInt(e.lastModified) / 1e3)), this.content_length = parseInt(e.contentLength), this.quality = e.quality, this.quality_label = e.qualityLabel || void 0, this.fps = e.fps || void 0, this.url = e.url || void 0, this.cipher = e.cipher || void 0, this.signature_cipher = e.signatureCipher || void 0, this.audio_quality = e.audioQuality || void 0, this.approx_duration_ms = parseInt(e.approxDurationMs), this.audio_sample_rate = parseInt(e.audioSampleRate), this.audio_channels = e.audioChannels, this.loudness_db = e.loudnessDb, this.has_audio = !!e.audioBitrate || !!e.audioQuality, this.has_video = !!e.qualityLabel;
  }
  decipher(e) {
    return e.decipher(this.url, this.signature_cipher, this.cipher);
  }
};
l(yg, "Format");
var f7 = yg, Hc = class {
  constructor(e) {
    this.url = e.url, this.width = e.width, this.height = e.height;
  }
  static fromResponse(e) {
    return !e || !e.thumbnails ? [] : e.thumbnails.map((t) => new Hc(t)).sort((t, i) => i.width - t.width);
  }
};
l(Hc, "Thumbnail");
var j = Hc, _g = class {
  constructor(e) {
    this.id = e.videoId, this.channel_id = e.channelId, this.title = e.title, this.duration = parseInt(e.lengthSeconds), this.keywords = e.keywords, this.is_owner_viewing = !!e.isOwnerViewing, this.short_description = e.shortDescription, this.thumbnail = j.fromResponse(e.thumbnail), this.allow_ratings = !!e.allowRatings, this.view_count = parseInt(e.viewCount), this.author = e.author, this.is_private = !!e.isPrivate, this.is_live_content = !!e.isLiveContent, this.is_crawlable = !!e.isCrawlable;
  }
};
l(_g, "VideoDetails");
var m7 = _g, se = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, bg = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, z1, wg, rt, Ne, Pi, zi, Jn, Sg = Symbol("ObservedArray.isObserved"), w = class {
  constructor() {
    z1.add(this), this.type = this.constructor.type;
  }
  is(...e) {
    return e.some((t) => se(this, z1, "m", wg).call(this, t));
  }
  as(...e) {
    if (!this.is(...e))
      throw new nn(`Cannot cast ${this.type} to one of ${e.map((t) => t.type).join(", ")}`);
    return this;
  }
  hasKey(e) {
    return Reflect.has(this, e);
  }
  key(e) {
    if (!this.hasKey(e))
      throw new nn(`Missing key ${e}`);
    return new Wc(this[e]);
  }
};
l(w, "YTNode");
z1 = /* @__PURE__ */ new WeakSet(), wg = /* @__PURE__ */ l(function(t) {
  return this.type === t.type;
}, "_YTNode_is");
w.type = "YTNode";
var Wc = class {
  constructor(e) {
    rt.add(this), Ne.set(this, void 0), bg(this, Ne, e, "f");
  }
  get typeof() {
    return typeof se(this, Ne, "f");
  }
  string() {
    return se(this, rt, "m", zi).call(this, "string");
  }
  isString() {
    return se(this, rt, "m", Pi).call(this, "string");
  }
  number() {
    return se(this, rt, "m", zi).call(this, "number");
  }
  isNumber() {
    return se(this, rt, "m", Pi).call(this, "number");
  }
  bigint() {
    return se(this, rt, "m", zi).call(this, "bigint");
  }
  isBigint() {
    return se(this, rt, "m", Pi).call(this, "bigint");
  }
  boolean() {
    return se(this, rt, "m", zi).call(this, "boolean");
  }
  isBoolean() {
    return se(this, rt, "m", Pi).call(this, "boolean");
  }
  symbol() {
    return se(this, rt, "m", zi).call(this, "symbol");
  }
  isSymbol() {
    return se(this, rt, "m", Pi).call(this, "symbol");
  }
  undefined() {
    return se(this, rt, "m", zi).call(this, "undefined");
  }
  isUndefined() {
    return se(this, rt, "m", Pi).call(this, "undefined");
  }
  null() {
    if (se(this, Ne, "f") !== null)
      throw new TypeError(`Expected null, got ${typeof se(this, Ne, "f")}`);
    return se(this, Ne, "f");
  }
  isNull() {
    return se(this, Ne, "f") === null;
  }
  object() {
    return se(this, rt, "m", zi).call(this, "object");
  }
  isObject() {
    return se(this, rt, "m", Pi).call(this, "object");
  }
  function() {
    return se(this, rt, "m", zi).call(this, "function");
  }
  isFunction() {
    return se(this, rt, "m", Pi).call(this, "function");
  }
  array() {
    if (!Array.isArray(se(this, Ne, "f")))
      throw new TypeError(`Expected array, got ${typeof se(this, Ne, "f")}`);
    return se(this, Ne, "f");
  }
  arrayOfMaybe() {
    const e = [];
    return new Proxy(this.array(), {
      get(t, i) {
        return Reflect.has(e, i) ? Reflect.get(t, i) : new Wc(Reflect.get(t, i));
      }
    });
  }
  isArray() {
    return Array.isArray(se(this, Ne, "f"));
  }
  node() {
    if (!(se(this, Ne, "f") instanceof w))
      throw new TypeError(`Expected YTNode, got ${se(this, Ne, "f").constructor.name}`);
    return se(this, Ne, "f");
  }
  isNode() {
    return se(this, Ne, "f") instanceof w;
  }
  nodeOfType(...e) {
    return this.node().as(...e);
  }
  isNodeOfType(...e) {
    return this.isNode() && this.node().is(...e);
  }
  observed() {
    if (!this.isObserved())
      throw new TypeError(`Expected ObservedArray, got ${typeof se(this, Ne, "f")}`);
    return se(this, Ne, "f");
  }
  isObserved() {
    var e;
    return (e = se(this, Ne, "f")) === null || e === void 0 ? void 0 : e[Sg];
  }
  parsed() {
    if (!(se(this, Ne, "f") instanceof rr))
      throw new TypeError(`Expected SuperParsedResult, got ${typeof se(this, Ne, "f")}`);
    return se(this, Ne, "f");
  }
  isParsed() {
    return se(this, Ne, "f") instanceof rr;
  }
  any() {
    return console.warn("This call is not meant to be used outside of debugging. Please use the specific type getter instead."), se(this, Ne, "f");
  }
  instanceof(e) {
    if (!this.isInstanceof(e))
      throw new TypeError(`Expected instance of ${e.name}, got ${se(this, Ne, "f").constructor.name}`);
    return se(this, Ne, "f");
  }
  isInstanceof(e) {
    return se(this, Ne, "f") instanceof e;
  }
};
l(Wc, "Maybe");
Ne = /* @__PURE__ */ new WeakMap(), rt = /* @__PURE__ */ new WeakSet(), Pi = /* @__PURE__ */ l(function(t) {
  return typeof se(this, Ne, "f") === t;
}, "_Maybe_checkPrimative"), zi = /* @__PURE__ */ l(function(t) {
  if (!se(this, rt, "m", Pi).call(this, t))
    throw new TypeError(`Expected ${t}, got ${this.typeof}`);
  return se(this, Ne, "f");
}, "_Maybe_assertPrimative");
var rr = class {
  constructor(e) {
    Jn.set(this, void 0), bg(this, Jn, e, "f");
  }
  get is_null() {
    return se(this, Jn, "f") === null;
  }
  get is_array() {
    return !this.is_null && Array.isArray(se(this, Jn, "f"));
  }
  get is_node() {
    return !this.is_array;
  }
  array() {
    if (!this.is_array)
      throw new TypeError("Expected an array, got a node");
    return se(this, Jn, "f");
  }
  item() {
    if (!this.is_node)
      throw new TypeError("Expected a node, got an array");
    return se(this, Jn, "f");
  }
};
l(rr, "SuperParsedResult");
Jn = /* @__PURE__ */ new WeakMap();
function zt(e) {
  return new Proxy(e, {
    get(t, i) {
      return i == "get" ? (n, s) => t.find((r, a) => {
        const u = wl(n, r);
        return u && s && t.splice(a, 1), u;
      }) : i == Sg ? !0 : i == "getAll" ? (n, s) => t.filter((r, a) => {
        const u = wl(n, r);
        return u && s && t.splice(a, 1), u;
      }) : i == "filterType" ? (...n) => zt(t.filter((s) => !!s.is(...n))) : i == "firstOfType" ? (...n) => t.find((s) => !!s.is(...n)) : i == "as" ? (...n) => zt(t.map((s) => {
        if (s.is(...n))
          return s;
        throw new nn(`Expected node of any type ${n.map((r) => r.type).join(", ")}, got ${s.type}`);
      })) : i == "remove" ? (n) => t.splice(n, 1) : Reflect.get(t, i);
    }
  });
}
l(zt, "observe");
var Cg = class extends Map {
  getType(e) {
    return Array.isArray(e) ? zt(e.flatMap((t) => this.get(t.type) || [])) : zt(this.get(e.type) || []);
  }
};
l(Cg, "Memo");
var $c = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.label = new _(e.label).toString(), this.selected = !!e.isSelected, e.int32Value ? this.value = e.int32Value : e.stringValue && (this.value = e.stringValue), !((t = e.onSelectCommand) === null || t === void 0) && t.browseEndpoint && (this.endpoint = new L(e.onSelectCommand)), !((i = e.icon) === null || i === void 0) && i.iconType && (this.icon_type = (n = e.icon) === null || n === void 0 ? void 0 : n.iconType), e.descriptionText && (this.description = new _(e.descriptionText).toString());
  }
};
l($c, "DropdownItem");
$c.type = "DropdownItem";
var Uo = $c, Gc = class extends w {
  constructor(e) {
    super(), this.label = e.label || "", this.entries = y.parseArray(e.entries, Uo);
  }
};
l(Gc, "Dropdown");
Gc.type = "Dropdown";
var qc = Gc, zc = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new _(e.dialogTitle).toString(), this.title_placeholder = e.titlePlaceholder || "", this.privacy_option = ((t = y.parseItem(e.privacyOption, qc)) === null || t === void 0 ? void 0 : t.entries) || null, this.create_button = y.parseItem(e.cancelButton), this.cancel_button = y.parseItem(e.cancelButton);
  }
};
l(zc, "CreatePlaylistDialog");
zc.type = "CreatePlaylistDialog";
var Tg = zc, xg = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, x5 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ha, K1, Kc = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p, m, b, C, k, D, I, $, O, F, K, M, v, H, ce;
    super(), Ha.add(this), Reflect.has(e || {}, "innertubeCommand") && (e = e.innertubeCommand);
    const ae = Object.keys(e || {}).find((Q) => Q.endsWith("Endpoint") || Q.endsWith("Command"));
    if (this.payload = ae ? Reflect.get(e, ae) : {}, Reflect.has(this.payload, "dialog") && (this.dialog = y.parse(this.payload.dialog)), e != null && e.serviceEndpoint && (e = e.serviceEndpoint), this.metadata = {}, !((i = (t = e == null ? void 0 : e.commandMetadata) === null || t === void 0 ? void 0 : t.webCommandMetadata) === null || i === void 0) && i.url && (this.metadata.url = e.commandMetadata.webCommandMetadata.url), !((s = (n = e == null ? void 0 : e.commandMetadata) === null || n === void 0 ? void 0 : n.webCommandMetadata) === null || s === void 0) && s.webPageType && (this.metadata.page_type = e.commandMetadata.webCommandMetadata.webPageType), !((a = (r = e == null ? void 0 : e.commandMetadata) === null || r === void 0 ? void 0 : r.webCommandMetadata) === null || a === void 0) && a.apiUrl ? this.metadata.api_url = e.commandMetadata.webCommandMetadata.apiUrl.replace("/youtubei/v1/", "") : ae && (this.metadata.api_url = this.getEndpoint(ae)), !((c = (u = e == null ? void 0 : e.commandMetadata) === null || u === void 0 ? void 0 : u.webCommandMetadata) === null || c === void 0) && c.sendPost && (this.metadata.send_post = e.commandMetadata.webCommandMetadata.sendPost), e != null && e.browseEndpoint) {
      const Q = (p = (h = e == null ? void 0 : e.browseEndpoint) === null || h === void 0 ? void 0 : h.browseEndpointContextSupportedConfigs) === null || p === void 0 ? void 0 : p.browseEndpointContextMusicConfig;
      this.browse = {
        id: ((m = e == null ? void 0 : e.browseEndpoint) === null || m === void 0 ? void 0 : m.browseId) || null,
        params: (e == null ? void 0 : e.browseEndpoint.params) || null,
        base_url: ((b = e == null ? void 0 : e.browseEndpoint) === null || b === void 0 ? void 0 : b.canonicalBaseUrl) || null,
        page_type: (Q == null ? void 0 : Q.pageType) || null
      };
    }
    if (e != null && e.watchEndpoint) {
      const Q = (k = (C = e == null ? void 0 : e.watchEndpoint) === null || C === void 0 ? void 0 : C.watchEndpointMusicSupportedConfigs) === null || k === void 0 ? void 0 : k.watchEndpointMusicConfig;
      this.watch = {
        video_id: (D = e == null ? void 0 : e.watchEndpoint) === null || D === void 0 ? void 0 : D.videoId,
        playlist_id: (e == null ? void 0 : e.watchEndpoint.playlistId) || null,
        params: (e == null ? void 0 : e.watchEndpoint.params) || null,
        index: (e == null ? void 0 : e.watchEndpoint.index) || null,
        supported_onesie_config: (I = e == null ? void 0 : e.watchEndpoint) === null || I === void 0 ? void 0 : I.watchEndpointSupportedOnesieConfig,
        music_video_type: (Q == null ? void 0 : Q.musicVideoType) || null
      };
    }
    e != null && e.searchEndpoint && (this.search = {
      query: e.searchEndpoint.query,
      params: e.searchEndpoint.params
    }), e != null && e.subscribeEndpoint && (this.subscribe = {
      channel_ids: e.subscribeEndpoint.channelIds,
      params: e.subscribeEndpoint.params
    }), e != null && e.unsubscribeEndpoint && (this.unsubscribe = {
      channel_ids: e.unsubscribeEndpoint.channelIds,
      params: e.unsubscribeEndpoint.params
    }), e != null && e.likeEndpoint && (this.like = {
      status: e.likeEndpoint.status,
      target: {
        video_id: e.likeEndpoint.target.videoId,
        playlist_id: e.likeEndpoint.target.playlistId
      },
      params: (($ = e.likeEndpoint) === null || $ === void 0 ? void 0 : $.removeLikeParams) || ((O = e.likeEndpoint) === null || O === void 0 ? void 0 : O.likeParams) || ((F = e.likeEndpoint) === null || F === void 0 ? void 0 : F.dislikeParams)
    }), e != null && e.performCommentActionEndpoint && (this.perform_comment_action = {
      action: e == null ? void 0 : e.performCommentActionEndpoint.action
    }), e != null && e.offlineVideoEndpoint && (this.offline_video = {
      video_id: e.offlineVideoEndpoint.videoId,
      on_add_command: {
        get_download_action: {
          video_id: e.offlineVideoEndpoint.videoId,
          params: e.offlineVideoEndpoint.onAddCommand.getDownloadActionCommand.params
        }
      }
    }), e != null && e.continuationCommand && (this.continuation = {
      request: ((K = e == null ? void 0 : e.continuationCommand) === null || K === void 0 ? void 0 : K.request) || null,
      token: ((M = e == null ? void 0 : e.continuationCommand) === null || M === void 0 ? void 0 : M.token) || null
    }), e != null && e.feedbackEndpoint && (this.feedback = {
      token: e.feedbackEndpoint.feedbackToken
    }), e != null && e.watchPlaylistEndpoint && (this.watch_playlist = {
      playlist_id: (v = e.watchPlaylistEndpoint) === null || v === void 0 ? void 0 : v.playlistId,
      params: ((H = e.watchPlaylistEndpoint) === null || H === void 0 ? void 0 : H.params) || null
    }), e != null && e.playlistEditEndpoint && (this.playlist_edit = {
      playlist_id: e.playlistEditEndpoint.playlistId,
      actions: e.playlistEditEndpoint.actions.map((Q) => ({
        action: Q.action,
        removed_video_id: Q.removedVideoId
      }))
    }), e != null && e.addToPlaylistEndpoint && (this.add_to_playlist = {
      video_id: e.addToPlaylistEndpoint.videoId
    }), e != null && e.addToPlaylistServiceEndpoint && (this.add_to_playlist = {
      video_id: e.addToPlaylistServiceEndpoint.videoId
    }), e != null && e.createPlaylistEndpoint && (e != null && e.createPlaylistEndpoint.createPlaylistDialog && (this.dialog = y.parseItem(e == null ? void 0 : e.createPlaylistEndpoint.createPlaylistDialog, Tg)), this.create_playlist = {}), e != null && e.getReportFormEndpoint && (this.get_report_form = {
      params: e.getReportFormEndpoint.params
    }), e != null && e.liveChatItemContextMenuEndpoint && (this.live_chat_item_context_menu = {
      params: (ce = e == null ? void 0 : e.liveChatItemContextMenuEndpoint) === null || ce === void 0 ? void 0 : ce.params
    }), e != null && e.sendLiveChatVoteEndpoint && (this.send_live_chat_vote = {
      params: e.sendLiveChatVoteEndpoint.params
    }), e != null && e.liveChatItemContextMenuEndpoint && (this.live_chat_item_context_menu = {
      params: e.liveChatItemContextMenuEndpoint.params
    });
  }
  getEndpoint(e) {
    switch (e) {
      case "browseEndpoint":
        return "/browse";
      case "watchEndpoint":
        return "/player";
      case "watchPlaylistEndpoint":
        return "/next";
    }
  }
  callTest(e, t) {
    if (!e)
      throw new Error("An active caller must be provided");
    if (!this.metadata.api_url)
      throw new Error("Expected an api_url, but none was found, this is a bug.");
    return e.execute(this.metadata.api_url, Object.assign(Object.assign({}, this.payload), t));
  }
  call(e, t, i) {
    return xg(this, void 0, void 0, function* () {
      const n = yield x5(this, Ha, "m", K1).call(this, e, t);
      return i && n ? y.parseResponse(n.data) : x5(this, Ha, "m", K1).call(this, e, t);
    });
  }
};
l(Kc, "NavigationEndpoint");
Ha = /* @__PURE__ */ new WeakSet(), K1 = /* @__PURE__ */ l(function(t, i) {
  return xg(this, void 0, void 0, function* () {
    if (!t)
      throw new Error("An active caller must be provided");
    if (this.continuation)
      switch (this.continuation.request) {
        case "CONTINUATION_REQUEST_TYPE_BROWSE":
          return yield t.browse(this.continuation.token, { is_ctoken: !0 });
        case "CONTINUATION_REQUEST_TYPE_SEARCH":
          return yield t.search({ ctoken: this.continuation.token });
        case "CONTINUATION_REQUEST_TYPE_WATCH_NEXT":
          return yield t.next({ ctoken: this.continuation.token });
        default:
          throw new Error(`${this.continuation.request} not implemented`);
      }
    if (this.search)
      return yield t.search({ query: this.search.query, params: this.search.params, client: i });
    if (this.browse)
      return yield t.browse(this.browse.id, Object.assign(Object.assign({}, this.browse), { client: i }));
    if (this.like) {
      if (!this.metadata.api_url)
        throw new Error("Like endpoint requires an api_url, but was not parsed from the response.");
      return yield t.engage(this.metadata.api_url, { video_id: this.like.target.video_id, params: this.like.params });
    }
  });
}, "_NavigationEndpoint_call");
Kc.type = "NavigationEndpoint";
var L = Kc, Eg = class {
  constructor(e) {
    this.text = e.text, this.endpoint = e.navigationEndpoint ? new L(e.navigationEndpoint) : void 0;
  }
};
l(Eg, "TextRun");
var v7 = Eg, Ag = class {
  constructor(e) {
    var t, i, n;
    this.text = ((t = e.emoji) === null || t === void 0 ? void 0 : t.emojiId) || ((n = (i = e.emoji) === null || i === void 0 ? void 0 : i.shortcuts) === null || n === void 0 ? void 0 : n[0]) || "", this.emoji = {
      emoji_id: e.emoji.emojiId,
      shortcuts: e.emoji.shortcuts,
      search_terms: e.emoji.searchTerms,
      image: j.fromResponse(e.emoji.image)
    };
  }
};
l(Ag, "EmojiRun");
var g7 = Ag, kg = class {
  constructor(e) {
    (e == null ? void 0 : e.hasOwnProperty("runs")) && Array.isArray(e.runs) ? (this.runs = e.runs.map((t) => t.emoji ? new g7(t) : new v7(t)), this.text = this.runs.map((t) => t.text).join("")) : this.text = (e == null ? void 0 : e.simpleText) || "N/A";
  }
  toString() {
    return this.text;
  }
};
l(kg, "Text");
var _ = kg, Yc = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.endpoint = new L(e.navigationEndpoint);
  }
};
l(Yc, "AccountChannel");
Yc.type = "AccountChannel";
var Ig = Yc, Xc = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(Xc, "AccountItemSectionHeader");
Xc.type = "AccountItemSectionHeader";
var Pg = Xc, Jc = class {
  constructor(e) {
    this.account_name = new _(e.accountName), this.account_photo = j.fromResponse(e.accountPhoto), this.is_selected = e.isSelected, this.is_disabled = e.isDisabled, this.has_channel = e.hasChannel, this.endpoint = new L(e.serviceEndpoint), this.account_byline = new _(e.accountByline);
  }
};
l(Jc, "AccountItem");
Jc.type = "AccountItem";
var Zc = class extends w {
  constructor(e) {
    super(), this.contents = e.contents.map((t) => new Jc(t.accountItem)), this.header = y.parseItem(e.header, Pg);
  }
};
l(Zc, "AccountItemSection");
Zc.type = "AccountItemSection";
var Mg = Zc, Qc = class extends w {
  constructor(e) {
    super(), this.contents = y.parseItem(e.contents[0], Mg), this.footers = y.parseItem(e.footers[0], Ig);
  }
};
l(Qc, "AccountSectionList");
Qc.type = "AccountSectionList";
var Ng = Qc, eh = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.continuationItems), this.target = e.target;
  }
};
l(eh, "AppendContinuationItemsAction");
eh.type = "AppendContinuationItemsAction";
var Rg = eh, th = class extends w {
  constructor(e) {
    super(), this.popup = y.parse(e.popup), this.popup_type = e.popupType;
  }
};
l(th, "OpenPopupAction");
th.type = "OpenPopupAction";
var y7 = th, ih = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.subtitle = e.subtitle, this.metric_value = e.metricValue, this.comparison_indicator = e.comparisonIndicator;
    const t = e.seriesConfiguration.lineSeries;
    this.series_configuration = {
      line_series: {
        lines_data: {
          x: t.linesData[0].x,
          y: t.linesData[0].y,
          style: {
            line_width: t.linesData[0].style.lineWidth,
            line_color: t.linesData[0].style.lineColor
          }
        },
        domain_axis: {
          tick_values: t.domainAxis.tickValues,
          custom_formatter: t.domainAxis.customFormatter
        },
        measure_axis: {
          tick_values: t.measureAxis.tickValues,
          custom_formatter: t.measureAxis.customFormatter
        }
      }
    };
  }
};
l(ih, "DataModelSection");
ih.type = "DataModelSection";
var Lg = ih, nh = class extends w {
  constructor(e) {
    super(), this.period = e.cardData.periodLabel;
    const t = e.cardData.sections[0].analyticsKeyMetricsData;
    this.sections = t.dataModel.sections.map((i) => new Lg(i));
  }
};
l(nh, "AnalyticsMainAppKeyMetrics");
nh.type = "AnalyticsMainAppKeyMetrics";
var _7 = nh, sh = class extends w {
  constructor(e) {
    super();
    const t = e.analyticsTableCarouselData.data.tableCards;
    this.title = e.analyticsTableCarouselData.carouselTitle, this.selected_card_index_key = e.analyticsTableCarouselData.selectedCardIndexKey, this.table_cards = t.map((i) => ({
      title: i.cardData.title,
      rows: i.cardData.rows.map((n) => ({
        label: n.label,
        display_value: n.displayValue,
        display_value_a11y: n.displayValueA11y,
        bar_ratio: n.barRatio,
        bar_color: n.barColor,
        bar_opacity: n.barOpacity
      }))
    })), this.use_main_app_specs = e.analyticsTableCarouselData.useMainAppSpecs;
  }
};
l(sh, "AnalyticsRoot");
sh.type = "AnalyticsRoot";
var b7 = sh, rh = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.shorts = e.shortsCarouselData.shorts.map((t) => ({
      description: t.shortsDescription,
      thumbnail_url: t.thumbnailUrl,
      endpoint: new L(t.videoEndpoint)
    }));
  }
};
l(rh, "AnalyticsShortsCarouselCard");
rh.type = "AnalyticsShortsCarouselCard";
var w7 = rh, oh = class extends w {
  constructor(e) {
    super(), this.title = e.videoTitle, this.metadata = {
      views: e.videoDescription.split("\xB7")[0].trim(),
      published: e.videoDescription.split("\xB7")[1].trim(),
      thumbnails: j.fromResponse(e.thumbnailDetails),
      duration: e.formattedLength,
      is_short: e.isShort
    };
  }
};
l(oh, "AnalyticsVideo");
oh.type = "AnalyticsVideo";
var Dg = oh, ah = class extends w {
  constructor(e) {
    var t;
    super(), this.title = e.title, e.noDataMessage && (this.no_data_message = e.noDataMessage), this.videos = ((t = e.videoCarouselData) === null || t === void 0 ? void 0 : t.videos.map((i) => new Dg(i))) || null;
  }
};
l(ah, "AnalyticsVodCarouselCard");
ah.type = "AnalyticsVodCarouselCard";
var S7 = ah, lh = class extends w {
  constructor(e) {
    super(), this.title = e.buttonLabel, this.use_new_specs = e.useNewSpecs;
  }
};
l(lh, "CtaGoToCreatorStudio");
lh.type = "CtaGoToCreatorStudio";
var C7 = lh, uh = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.contents = new _(e.contents);
  }
};
l(uh, "StatRow");
uh.type = "StatRow";
var T7 = uh, ch = class extends w {
  constructor(e) {
    super(), this.audio_only_availability = e.audioOnlyAvailability;
  }
};
l(ch, "AudioOnlyPlayability");
ch.type = "AudioOnlyPlayability";
var Bg = ch, hh = class extends w {
  constructor(e) {
    var t, i;
    super(), !((i = (t = e == null ? void 0 : e.content) === null || t === void 0 ? void 0 : t.automixPlaylistVideoRenderer) === null || i === void 0) && i.navigationEndpoint && (this.playlist_video = {
      endpoint: new L(e.content.automixPlaylistVideoRenderer.navigationEndpoint)
    });
  }
};
l(hh, "AutomixPreviewVideo");
hh.type = "AutomixPreviewVideo";
var dh = hh, ph = class extends w {
  constructor(e) {
    super(), this.image = j.fromResponse(e.image);
  }
};
l(ph, "BackstageImage");
ph.type = "BackstageImage";
var x7 = ph, fh = class extends _ {
  constructor(e) {
    var t, i;
    super(e), this.endpoint = !((i = (t = e.runs) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0) && i.navigationEndpoint ? new L(e.runs[0].navigationEndpoint) : e.navigationEndpoint ? new L(e.navigationEndpoint) : e.titleNavigationEndpoint ? new L(e.titleNavigationEndpoint) : null;
  }
  toJSON() {
    return this;
  }
};
l(fh, "NavigatableText");
fh.type = "NavigatableText";
var Og = fh, E7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ci = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, jt, Fg = class {
  constructor(e, t, i) {
    var n, s, r, a, u, c, h, p, m, b, C, k, D, I, $, O, F, K, M, v, H, ce, ae, Q, Xe, J, ee, ve, Je, Ce, nt;
    jt.set(this, void 0), E7(this, jt, new Og(e), "f"), this.id = ((a = (r = (s = (n = Ci(this, jt, "f").runs) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.id) || ((h = (c = (u = Ci(this, jt, "f")) === null || u === void 0 ? void 0 : u.endpoint) === null || c === void 0 ? void 0 : c.browse) === null || h === void 0 ? void 0 : h.id) || "N/A", this.name = Ci(this, jt, "f").text || "N/A", this.thumbnails = i ? j.fromResponse(i) : [], this.endpoint = ((m = (p = Ci(this, jt, "f").runs) === null || p === void 0 ? void 0 : p[0]) === null || m === void 0 ? void 0 : m.endpoint) || Ci(this, jt, "f").endpoint, this.badges = Array.isArray(t) ? y.parseArray(t) : [], this.is_verified = ((b = this.badges) === null || b === void 0 ? void 0 : b.some((De) => De.style == "BADGE_STYLE_TYPE_VERIFIED")) || null, this.is_verified_artist = ((C = this.badges) === null || C === void 0 ? void 0 : C.some((De) => De.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST")) || null, this.url = (($ = (I = (D = (k = Ci(this, jt, "f")) === null || k === void 0 ? void 0 : k.runs) === null || D === void 0 ? void 0 : D[0]) === null || I === void 0 ? void 0 : I.endpoint) === null || $ === void 0 ? void 0 : $.browse) && `${pe.URLS.YT_BASE}${((v = (M = (K = (F = (O = Ci(this, jt, "f")) === null || O === void 0 ? void 0 : O.runs) === null || F === void 0 ? void 0 : F[0]) === null || K === void 0 ? void 0 : K.endpoint) === null || M === void 0 ? void 0 : M.browse) === null || v === void 0 ? void 0 : v.base_url) || `/u/${(Xe = (Q = (ae = (ce = (H = Ci(this, jt, "f")) === null || H === void 0 ? void 0 : H.runs) === null || ce === void 0 ? void 0 : ce[0]) === null || ae === void 0 ? void 0 : ae.endpoint) === null || Q === void 0 ? void 0 : Q.browse) === null || Xe === void 0 ? void 0 : Xe.id}`}` || `${pe.URLS.YT_BASE}${((ve = (ee = (J = Ci(this, jt, "f")) === null || J === void 0 ? void 0 : J.endpoint) === null || ee === void 0 ? void 0 : ee.browse) === null || ve === void 0 ? void 0 : ve.base_url) || `/u/${(nt = (Ce = (Je = Ci(this, jt, "f")) === null || Je === void 0 ? void 0 : Je.endpoint) === null || Ce === void 0 ? void 0 : Ce.browse) === null || nt === void 0 ? void 0 : nt.id}`}` || null;
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(Fg, "Author");
jt = /* @__PURE__ */ new WeakMap();
var Ft = Fg, mh = class extends w {
  constructor(e) {
    super(), this.id = e.postId, this.author = new Ft(Object.assign(Object.assign({}, e.authorText), { navigationEndpoint: e.authorEndpoint }), null, e.authorThumbnail), this.content = new _(e.contentText), this.published = new _(e.publishedTimeText), this.poll_status = e.pollStatus, this.vote_status = e.voteStatus, this.likes = new _(e.voteCount), this.menu = y.parse(e.actionMenu) || null, this.actions = y.parse(e.actionButtons), this.vote_button = y.parse(e.voteButton), this.surface = e.surface, this.endpoint = new L(e.navigationEndpoint), this.attachment = y.parse(e.backstageAttachment) || null;
  }
};
l(mh, "BackstagePost");
mh.type = "BackstagePost";
var vh = mh, gh = class extends w {
  constructor(e) {
    super(), this.post = y.parse(e.post);
  }
};
l(gh, "BackstagePostThread");
gh.type = "BackstagePostThread";
var A7 = gh, yh = class extends w {
  constructor(e) {
    super(), this.contents = y.parseArray(e.contents);
  }
};
l(yh, "BrowseFeedActions");
yh.type = "BrowseFeedActions";
var Vg = yh, _h = class extends w {
  constructor(e) {
    super(), this.album = new _(e.album), this.thumbnails = j.fromResponse(e.thumbnailDetails);
  }
};
l(_h, "BrowserMediaSession");
_h.type = "BrowserMediaSession";
var k7 = _h, bh = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.text = new _(e.text).toString(), !((t = e.accessibility) === null || t === void 0) && t.label && (this.label = (i = e.accessibility) === null || i === void 0 ? void 0 : i.label), e.tooltip && (this.tooltip = e.tooltip), !((n = e.icon) === null || n === void 0) && n.iconType && (this.icon_type = (s = e.icon) === null || s === void 0 ? void 0 : s.iconType), this.endpoint = new L(e.navigationEndpoint || e.serviceEndpoint || e.command);
  }
};
l(bh, "Button");
bh.type = "Button";
var at = bh, wh = class extends w {
  constructor(e) {
    super(), this.author = new Ft({
      simpleText: e.title,
      navigationEndpoint: e.navigationEndpoint
    }, e.badges, e.avatar), this.banner = e.banner ? j.fromResponse(e.banner) : [], this.tv_banner = e.tvBanner ? j.fromResponse(e.tvBanner) : [], this.mobile_banner = e.mobileBanner ? j.fromResponse(e.mobileBanner) : [], this.subscribers = new _(e.subscriberCountText), this.sponsor_button = e.sponsorButton ? y.parseItem(e.sponsorButton) : void 0, this.subscribe_button = e.subscribeButton ? y.parseItem(e.subscribeButton) : void 0, this.header_links = e.headerLinks ? y.parse(e.headerLinks) : void 0;
  }
};
l(wh, "C4TabbedHeader");
wh.type = "C4TabbedHeader";
var Ug = wh, Sh = class extends w {
  constructor(e) {
    super(), this.label = new _(e.label), this.icon_type = e.icon.iconType, this.style = e.style;
  }
};
l(Sh, "CallToActionButton");
Sh.type = "CallToActionButton";
var I7 = Sh, Ch = class extends w {
  constructor(e) {
    super(), this.teaser = y.parseItem(e.teaser), this.content = y.parseItem(e.content), this.card_id = e.cardId || null, this.feature = e.feature || null, this.cue_ranges = e.cueRanges.map((t) => ({
      start_card_active_ms: t.startCardActiveMs,
      end_card_active_ms: t.endCardActiveMs,
      teaser_duration_ms: t.teaserDurationMs,
      icon_after_teaser_ms: t.iconAfterTeaserMs
    }));
  }
};
l(Ch, "Card");
Ch.type = "Card";
var P7 = Ch, Th = class extends w {
  constructor(e) {
    super(), this.cards = y.parseArray(e.cards), this.header = new _(e.headerText), this.allow_teaser_dismiss = e.allowTeaserDismiss;
  }
};
l(Th, "CardCollection");
Th.type = "CardCollection";
var jg = Th, xh = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.author = new Ft(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.ownerBadges, e.thumbnail), this.subscribers = new _(e.subscriberCountText), this.videos = new _(e.videoCountText), this.endpoint = new L(e.navigationEndpoint), this.description_snippet = new _(e.descriptionSnippet);
  }
};
l(xh, "Channel");
xh.type = "Channel";
var Hg = xh, Eh = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.name = new _(e.title), this.avatar = j.fromResponse(e.avatar), this.canonical_channel_url = e.canonicalChannelUrl, this.views = new _(e.viewCountText), this.joined = new _(e.joinedDateText), this.description = new _(e.description), this.email_reveal = new L(e.onBusinessEmailRevealClickCommand), this.can_reveal_email = !e.signInForBusinessEmail, this.country = new _(e.country), this.buttons = y.parse(e.actionButtons);
  }
};
l(Eh, "ChannelAboutFullMetadata");
Eh.type = "ChannelAboutFullMetadata";
var Wg = Eh, Ah = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.items = y.parse(e.items);
  }
};
l(Ah, "ChannelFeaturedContent");
Ah.type = "ChannelFeaturedContent";
var M7 = Ah, Y1 = class {
  constructor(e) {
    this.endpoint = new L(e.navigationEndpoint), this.icon = j.fromResponse(e.icon), this.title = new _(e.title);
  }
};
l(Y1, "HeaderLink");
var kh = class extends w {
  constructor(e) {
    var t, i;
    super(), this.primary = ((t = e.primaryLinks) === null || t === void 0 ? void 0 : t.map((n) => new Y1(n))) || [], this.secondary = ((i = e.secondaryLinks) === null || i === void 0 ? void 0 : i.map((n) => new Y1(n))) || [];
  }
};
l(kh, "ChannelHeaderLinks");
kh.type = "ChannelHeaderLinks";
var N7 = kh, Ih = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description, this.url = e.channelUrl, this.rss_urls = e.rssUrl, this.vanity_channel_url = e.vanityChannelUrl, this.external_id = e.externalId, this.is_family_safe = e.isFamilySafe, this.keywords = e.keywords, this.avatar = j.fromResponse(e.avatar), this.available_countries = e.availableCountryCodes, this.android_deep_link = e.androidDeepLink, this.android_appindexing_link = e.androidAppindexingLink, this.ios_appindexing_link = e.iosAppindexingLink;
  }
};
l(Ih, "ChannelMetadata");
Ih.type = "ChannelMetadata";
var $g = Ih, Ph = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(Ph, "ChannelMobileHeader");
Ph.type = "ChannelMobileHeader";
var R7 = Ph, Mh = class extends w {
  constructor(e) {
    super(), this.avatar = j.fromResponse(e.avatar), this.endpoint = new L(e.avatarEndpoint), this.name = e.name, this.links = e.links.map((t) => new _(t));
  }
};
l(Mh, "ChannelOptions");
Mh.type = "ChannelOptions";
var Gg = Mh, Nh = class extends w {
  constructor(e) {
    super(), this.thumbnails = j.fromResponse(e.thumbnail), this.endpoint = new L(e.navigationEndpoint), this.label = e.accessibility.accessibilityData.label;
  }
};
l(Nh, "ChannelThumbnailWithLink");
Nh.type = "ChannelThumbnailWithLink";
var L7 = Nh, Rh = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new _(e.title), this.description = new _(e.description), this.views = new _(e.viewCountText), this.published = new _(e.publishedTimeText);
  }
};
l(Rh, "ChannelVideoPlayer");
Rh.type = "ChannelVideoPlayer";
var D7 = Rh, Lh = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new _(e.title), this.duration = {
      text: e.lengthText.simpleText,
      seconds: ji(e.lengthText.simpleText)
    }, this.endpoint = new L(e.navigationEndpoint);
  }
};
l(Lh, "ChildVideo");
Lh.type = "ChildVideo";
var B7 = Lh, Dh = class extends w {
  constructor(e) {
    super(), this.is_selected = e.isSelected, this.endpoint = e.navigationEndpoint ? new L(e.navigationEndpoint) : void 0, this.text = new _(e.text).toString();
  }
};
l(Dh, "ChipCloudChip");
Dh.type = "ChipCloudChip";
var jo = Dh, Bh = class extends w {
  constructor(e) {
    super(), this.chips = y.parseArray(e.chips, jo), this.next_button = y.parseItem(e.nextButton, at), this.previous_button = y.parseItem(e.previousButton, at), this.horizontal_scrollable = e.horizontalScrollable;
  }
};
l(Bh, "ChipCloud");
Bh.type = "ChipCloud";
var Oh = Bh, Fh = class extends w {
  constructor(e) {
    super(), this.channel_avatar = j.fromResponse(e.channelAvatar), this.custom_text = new _(e.customText), this.channel_name = new _(e.channelName), this.subscriber_count = new _(e.subscriberCountText), this.endpoint = new L(e.endpoint);
  }
};
l(Fh, "CollaboratorInfoCardContent");
Fh.type = "CollaboratorInfoCardContent";
var O7 = Fh, Vh = class extends w {
  constructor(e) {
    super(), this.left = j.fromResponse(e.leftThumbnail), this.top_right = j.fromResponse(e.topRightThumbnail), this.bottom_right = j.fromResponse(e.bottomRightThumbnail), this.endpoint = new L(e.navigationEndpoint);
  }
};
l(Vh, "CollageHeroImage");
Vh.type = "CollageHeroImage";
var F7 = Vh, V7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, U7 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Wa, Uh = class extends w {
  constructor(e) {
    var t;
    super(), Wa.set(this, void 0), this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.iconType) || null, this.tooltip = e.iconTooltip, this.tooltip === "Verified" && (this.style = "BADGE_STYLE_TYPE_VERIFIED") && (e.style = "BADGE_STYLE_TYPE_VERIFIED"), V7(this, Wa, e, "f");
  }
  get orig_badge() {
    return U7(this, Wa, "f");
  }
};
l(Uh, "AuthorCommentBadge");
Wa = /* @__PURE__ */ new WeakMap();
Uh.type = "AuthorCommentBadge";
var qg = Uh, jh = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p;
    super(), this.text = new _(e.defaultText), this.toggled_text = new _(e.toggledText), this.tooltip = e.defaultTooltip, this.toggled_tooltip = e.toggledTooltip, this.is_toggled = e.isToggled, this.is_disabled = e.isDisabled, this.icon_type = e.defaultIcon.iconType;
    const m = ((n = (i = (t = e == null ? void 0 : e.defaultText) === null || t === void 0 ? void 0 : t.accessibility) === null || i === void 0 ? void 0 : i.accessibilityData) === null || n === void 0 ? void 0 : n.label) || ((r = (s = e == null ? void 0 : e.accessibilityData) === null || s === void 0 ? void 0 : s.accessibilityData) === null || r === void 0 ? void 0 : r.label) || ((a = e == null ? void 0 : e.accessibility) === null || a === void 0 ? void 0 : a.label);
    this.icon_type == "LIKE" && (this.like_count = parseInt(m.replace(/\D/g, "")), this.short_like_count = new _(e.defaultText).toString()), this.endpoint = !((c = (u = e.defaultServiceEndpoint) === null || u === void 0 ? void 0 : u.commandExecutorCommand) === null || c === void 0) && c.commands ? new L(e.defaultServiceEndpoint.commandExecutorCommand.commands.pop()) : new L(e.defaultServiceEndpoint), this.toggled_endpoint = new L(e.toggledServiceEndpoint), this.button_id = ((p = (h = e.toggleButtonSupportedData) === null || h === void 0 ? void 0 : h.toggleButtonIdData) === null || p === void 0 ? void 0 : p.id) || null, this.target_id = e.targetId || null;
  }
};
l(jh, "ToggleButton");
jh.type = "ToggleButton";
var gt = jh, Hh = class extends w {
  constructor(e) {
    super(), this.reply_button = y.parse(e.replyButton), this.cancel_button = y.parse(e.cancelButton), this.author_thumbnail = j.fromResponse(e.authorThumbnail), this.placeholder = new _(e.placeholderText), this.error_message = new _(e.errorMessage);
  }
};
l(Hh, "CommentReplyDialog");
Hh.type = "CommentReplyDialog";
var zg = Hh, Wh = class extends w {
  constructor(e) {
    super(), this.like_button = y.parse(e.likeButton), this.dislike_button = y.parse(e.dislikeButton), this.reply_button = y.parse(e.replyButton);
  }
};
l(Wh, "CommentActionButtons");
Wh.type = "CommentActionButtons";
var Zn = Wh, Sa = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, cn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, j7 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ui, $h = class extends w {
  constructor(e) {
    var t, i;
    super(), ui.set(this, void 0), this.content = new _(e.contentText), this.published = new _(e.publishedTimeText), this.author_is_channel_owner = e.authorIsChannelOwner, this.current_user_reply_thumbnail = j.fromResponse(e.currentUserReplyThumbnail), this.author_badge = y.parseItem(e.authorCommentBadge, qg), this.author = new Ft(Object.assign(Object.assign({}, e.authorText), { navigationEndpoint: e.authorEndpoint }), this.author_badge ? [{
      metadataBadgeRenderer: (t = this.author_badge) === null || t === void 0 ? void 0 : t.orig_badge
    }] : null, e.authorThumbnail), this.action_menu = y.parse(e.actionMenu), this.action_buttons = y.parse(e.actionButtons), this.comment_id = e.commentId, this.vote_status = e.voteStatus, this.vote_count = {
      text: e.voteCount ? (i = e.voteCount.accessibility.accessibilityData) === null || i === void 0 ? void 0 : i.label.replace(/\D/g, "") : "0",
      short_text: e.voteCount ? new _(e.voteCount).toString() : "0"
    }, this.reply_count = e.replyCount || 0, this.is_liked = this.action_buttons.item().as(Zn).like_button.item().as(gt).is_toggled, this.is_disliked = this.action_buttons.item().as(Zn).dislike_button.item().as(gt).is_toggled, this.is_pinned = !!e.pinnedCommentBadge;
  }
  like() {
    return Sa(this, void 0, void 0, function* () {
      if (!cn(this, ui, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const e = this.action_buttons.item().as(Zn).like_button.item().as(gt);
      if (e.is_toggled)
        throw new x("This comment is already liked", { comment_id: this.comment_id });
      return yield e.endpoint.callTest(cn(this, ui, "f"), { parse: !1 });
    });
  }
  dislike() {
    return Sa(this, void 0, void 0, function* () {
      if (!cn(this, ui, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const e = this.action_buttons.item().as(Zn).dislike_button.item().as(gt);
      if (e.is_toggled)
        throw new x("This comment is already disliked", { comment_id: this.comment_id });
      return yield e.endpoint.callTest(cn(this, ui, "f"), { parse: !1 });
    });
  }
  reply(e) {
    return Sa(this, void 0, void 0, function* () {
      if (!cn(this, ui, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      if (!this.action_buttons.item().as(Zn).reply_button)
        throw new x("Cannot reply to another reply. Try mentioning the user instead.", { comment_id: this.comment_id });
      const t = this.action_buttons.item().as(Zn).reply_button.item().as(gt);
      if (!t.endpoint.dialog)
        throw new x("Reply button endpoint did not have a dialog.");
      const n = t.endpoint.dialog.item().as(zg).reply_button.item().as(gt), s = {
        commentText: e
      };
      return yield n.endpoint.callTest(cn(this, ui, "f"), s);
    });
  }
  translate(e) {
    return Sa(this, void 0, void 0, function* () {
      if (!cn(this, ui, "f"))
        throw new x("An active caller must be provide to perform this operation.");
      const i = {
        text: this.content.toString().replace(/[^\p{L}\p{N}\p{P}\p{Z}]/gu, ""),
        target_language: e,
        comment_id: this.comment_id
      }, n = Rt.encodeCommentActionParams(22, i), s = yield cn(this, ui, "f").execute("comment/perform_comment_action", { action: n, client: "ANDROID" }), a = s.data.frameworkUpdates.entityBatchUpdate.mutations[0].payload.commentEntityPayload.translatedContent.content;
      return Object.assign(Object.assign({}, s), { content: a });
    });
  }
  setActions(e) {
    j7(this, ui, e, "f");
  }
};
l($h, "Comment");
ui = /* @__PURE__ */ new WeakMap();
$h.type = "Comment";
var $a = $h, Gh = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents), this.view_replies = y.parse(e.viewReplies), this.hide_replies = y.parse(e.hideReplies);
  }
};
l(Gh, "CommentReplies");
Gh.type = "CommentReplies";
var H7 = Gh, qh = class extends w {
  constructor(e) {
    super(), this.header = new _(e.headerText), this.comment_count = new _(e.commentCount), this.teaser_avatar = j.fromResponse(e.teaserAvatar || e.simpleboxAvatar), this.teaser_content = new _(e.teaserContent), this.simplebox_placeholder = new _(e.simpleboxPlaceholder);
  }
};
l(qh, "CommentsEntryPointHeader");
qh.type = "CommentsEntryPointHeader";
var Kg = qh, zh = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new _(e.titleText), this.count = new _(e.countText), this.comments_count = new _(e.commentsCount), this.create_renderer = y.parseItem(e.createRenderer), this.sort_menu = y.parse(e.sortMenu), this.custom_emojis = ((t = e.customEmojis) === null || t === void 0 ? void 0 : t.map((i) => ({
      emoji_id: i.emojiId,
      shortcuts: i.shortcuts,
      search_terms: i.searchTerms,
      image: j.fromResponse(i.image),
      is_custom_emoji: i.isCustomEmoji
    }))) || null;
  }
};
l(zh, "CommentsHeader");
zh.type = "CommentsHeader";
var Yg = zh, Kh = class extends w {
  constructor(e) {
    super(), this.submit_button = y.parse(e.submitButton), this.cancel_button = y.parse(e.cancelButton), this.author_thumbnails = j.fromResponse(e.authorThumbnail), this.placeholder = new _(e.placeholderText), this.avatar_size = e.avatarSize;
  }
};
l(Kh, "CommentSimplebox");
Kh.type = "CommentSimplebox";
var Xg = Kh, Yh = class extends w {
  constructor(e) {
    super(), this.trigger = e.trigger, e.button && (this.button = y.parse(e.button)), this.endpoint = new L(e.continuationEndpoint);
  }
};
l(Yh, "ContinuationItem");
Yh.type = "ContinuationItem";
var sn = Yh, E5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ca = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ti = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, jr, Ki, Vs, Xh = class extends w {
  constructor(e) {
    super(), jr.set(this, void 0), Ki.set(this, void 0), Vs.set(this, void 0), this.comment = y.parseItem(e.comment, $a), Ca(this, jr, y.parseItem(e.replies), "f"), this.is_moderated_elq_comment = e.isModeratedElqComment;
  }
  getReplies() {
    var e, t, i, n;
    return E5(this, void 0, void 0, function* () {
      if (!Ti(this, Ki, "f"))
        throw new x("Actions not set for this CommentThread.");
      if (!Ti(this, jr, "f"))
        throw new x("This comment has no replies.", { comment_id: (e = this.comment) === null || e === void 0 ? void 0 : e.comment_id });
      const s = (t = Ti(this, jr, "f").key("contents").parsed().array().get({ type: "ContinuationItem" })) === null || t === void 0 ? void 0 : t.as(sn), r = yield s == null ? void 0 : s.endpoint.callTest(Ti(this, Ki, "f"), { parse: !0 });
      return this.replies = (i = r == null ? void 0 : r.on_response_received_endpoints_memo) === null || i === void 0 ? void 0 : i.getType($a).map((a) => (a.setActions(Ti(this, Ki, "f")), a)), Ca(this, Vs, (n = r == null ? void 0 : r.on_response_received_endpoints_memo.getType(sn)) === null || n === void 0 ? void 0 : n[0], "f"), this;
    });
  }
  getContinuation() {
    var e, t;
    return E5(this, void 0, void 0, function* () {
      if (!this.replies)
        throw new x("Continuation not available.");
      if (!Ti(this, Vs, "f"))
        throw new x("Continuation not found.");
      if (!Ti(this, Ki, "f"))
        throw new x("Actions not set for this CommentThread.");
      const i = yield (e = Ti(this, Vs, "f").button) === null || e === void 0 ? void 0 : e.item().key("endpoint").nodeOfType(L).callTest(Ti(this, Ki, "f"), { parse: !0 });
      return this.replies = i == null ? void 0 : i.on_response_received_endpoints_memo.getType($a).map((n) => (n.setActions(Ti(this, Ki, "f")), n)), Ca(this, Vs, (t = i == null ? void 0 : i.on_response_received_endpoints_memo.getType(sn)) === null || t === void 0 ? void 0 : t[0], "f"), this;
    });
  }
  setActions(e) {
    Ca(this, Ki, e, "f");
  }
};
l(Xh, "CommentThread");
jr = /* @__PURE__ */ new WeakMap(), Ki = /* @__PURE__ */ new WeakMap(), Vs = /* @__PURE__ */ new WeakMap();
Xh.type = "CommentThread";
var Jg = Xh, Jh = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title).toString(), this.endpoint = new L(e.navigationEndpoint), this.style = e.style;
  }
};
l(Jh, "CompactLink");
Jh.type = "CompactLink";
var Zg = Jh, Qg = class extends Ft {
  constructor(e, t, i) {
    super(e, t, i), delete this.badges, delete this.is_verified, delete this.is_verified_artist;
  }
};
l(Qg, "PlaylistAuthor");
var Xl = Qg, Zh = class extends w {
  constructor(e) {
    var t;
    super(), this.id = e.playlistId, this.title = new _(e.title), this.author = !((t = e.shortBylineText) === null || t === void 0) && t.simpleText ? new _(e.shortBylineText) : new Xl(e.longBylineText, e.ownerBadges, null), this.thumbnails = j.fromResponse(e.thumbnail || { thumbnails: e.thumbnails.map((i) => i.thumbnails).flat(1) }), this.video_count = new _(e.thumbnailText), this.video_count_short = new _(e.videoCountShortText), this.first_videos = y.parse(e.videos) || [], this.share_url = e.shareUrl || null, this.menu = y.parse(e.menu), this.badges = y.parse(e.ownerBadges), this.endpoint = new L(e.navigationEndpoint), this.thumbnail_overlays = y.parse(e.thumbnailOverlays) || [];
  }
};
l(Zh, "Playlist");
Zh.type = "Playlist";
var Zo = Zh, Qh = class extends Zo {
  constructor(e) {
    super(e);
  }
};
l(Qh, "CompactMix");
Qh.type = "CompactMix";
var W7 = Qh, ed = class extends Zo {
  constructor(e) {
    super(e);
  }
};
l(ed, "CompactPlaylist");
ed.type = "CompactPlaylist";
var $7 = ed, td = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.thumbnails = j.fromResponse(e.thumbnail) || null, this.rich_thumbnail = e.richThumbnail && y.parse(e.richThumbnail), this.title = new _(e.title), this.author = new Ft(e.longBylineText, e.ownerBadges, e.channelThumbnail), this.view_count = new _(e.viewCountText), this.short_view_count = new _(e.shortViewCountText), this.published = new _(e.publishedTimeText), this.duration = {
      text: new _(e.lengthText).toString(),
      seconds: ji(new _(e.lengthText).toString())
    }, this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.endpoint = new L(e.navigationEndpoint), this.menu = y.parse(e.menu);
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(td, "CompactVideo");
td.type = "CompactVideo";
var ey = td, id = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.confirm_button = y.parseItem(e.confirmButton, at), this.cancel_button = y.parseItem(e.cancelButton, at), this.dialog_messages = e.dialogMessages.map((t) => new _(t));
  }
};
l(id, "ConfirmDialog");
id.type = "ConfirmDialog";
var G7 = id, nd = class extends w {
  constructor(e) {
    super(), this.copy_button = y.parseItem(e.copyButton, at), this.short_url = e.shortUrl, this.style = e.style;
  }
};
l(nd, "CopyLink");
nd.type = "CopyLink";
var ty = nd, sd = class extends w {
  constructor(e) {
    super(), this.text = new _(e.didYouMean).toString(), this.corrected_query = new _(e.correctedQuery), this.endpoint = new L(e.navigationEndpoint || e.correctedQueryEndpoint);
  }
};
l(sd, "DidYouMean");
sd.type = "DidYouMean";
var iy = sd, rd = class extends w {
  constructor(e) {
    super(), this.style = e.style, this.size = e.size, this.endpoint = new L(e.command), this.target_id = e.targetId;
  }
};
l(rd, "DownloadButton");
rd.type = "DownloadButton";
var q7 = rd, Jl = class {
  constructor(e) {
    var t, i;
    this.text = ((i = (t = e.type.textType) === null || t === void 0 ? void 0 : t.text) === null || i === void 0 ? void 0 : i.content) || null, this.properties = e.properties, e.childElements && (this.child_elements = e.childElements.map((n) => new Jl(n)));
  }
};
l(Jl, "ChildElement");
Jl.type = "ChildElement";
var z7 = Jl, Zl = class extends w {
  constructor(e) {
    var t, i, n;
    if (super(), Reflect.has(e, "elementRenderer"))
      return y.parseItem(e, Zl);
    const s = e.newElement.type.componentType;
    this.model = y.parse(s == null ? void 0 : s.model), !((t = e.newElement) === null || t === void 0) && t.childElements && (this.child_elements = ((n = (i = e.newElement) === null || i === void 0 ? void 0 : i.childElements) === null || n === void 0 ? void 0 : n.map((r) => new z7(r))) || null);
  }
};
l(Zl, "Element");
Zl.type = "Element";
var od = Zl, ad = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.first_option = y.parse(e.firstOption), this.menu = y.parse(e.menu);
  }
};
l(ad, "EmergencyOnebox");
ad.type = "EmergencyOnebox";
var K7 = ad, ld = class extends w {
  constructor(e) {
    super(), this.elements = y.parseArray(e.elements), this.start_ms = e.startMs;
  }
};
l(ld, "Endscreen");
ld.type = "Endscreen";
var ny = ld, ud = class extends w {
  constructor(e) {
    super(), this.style = `${e.style}`, this.title = new _(e.title), this.endpoint = new L(e.endpoint), e.image && (this.image = j.fromResponse(e.image)), e.icon && (this.icon = j.fromResponse(e.icon)), e.metadata && (this.metadata = new _(e.metadata)), e.callToAction && (this.call_to_action = new _(e.callToAction)), e.hovercardButton && (this.hovercard_button = y.parseItem(e.hovercardButton)), e.isSubscribe && (this.is_subscribe = !!e.isSubscribe), e.playlistLength && (this.playlist_length = new _(e.playlistLength)), this.thumbnail_overlays = e.thumbnailOverlays ? y.parseArray(e.thumbnailOverlays) : void 0, this.left = parseFloat(e.left), this.width = parseFloat(e.width), this.top = parseFloat(e.top), this.aspect_ratio = parseFloat(e.aspectRatio), this.start_ms = parseFloat(e.startMs), this.end_ms = parseFloat(e.endMs), this.id = e.id;
  }
};
l(ud, "EndscreenElement");
ud.type = "EndscreenElement";
var Y7 = ud, cd = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.title = new _(e.title), this.author = new _(e.longBylineText), this.endpoint = new L(e.navigationEndpoint), this.thumbnails = j.fromResponse(e.thumbnail), this.video_count = new _(e.videoCountText);
  }
};
l(cd, "EndScreenPlaylist");
cd.type = "EndScreenPlaylist";
var sy = cd, hd = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new _(e.title), this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new Ft(e.shortBylineText, e.ownerBadges), this.endpoint = new L(e.navigationEndpoint), this.short_view_count = new _(e.shortViewCountText), this.badges = y.parse(e.badges), this.duration = {
      text: new _(e.lengthText).toString(),
      seconds: e.lengthInSeconds
    };
  }
};
l(hd, "EndScreenVideo");
hd.type = "EndScreenVideo";
var ry = hd, dd = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.endpoint = new L(e.endpoint), this.selected = e.selected, this.content = e.content ? y.parse(e.content) : null;
  }
};
l(dd, "ExpandableTab");
dd.type = "ExpandableTab";
var X7 = dd, pd = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(pd, "ExpandedShelfContents");
pd.type = "ExpandedShelfContents";
var J7 = pd, fd = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(fd, "FeedFilterChipBar");
fd.type = "FeedFilterChipBar";
var X1 = fd, md = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(md, "FeedTabbedHeader");
md.type = "FeedTabbedHeader";
var Z7 = md, vd = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.items = y.parse(e.items), this.is_collapsible = e.isCollapsible, this.visible_row_count = e.visibleRowCount, this.target_id = e.targetId, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || null, e.header && (this.header = y.parse(e.header));
  }
  get contents() {
    return this.items;
  }
};
l(vd, "Grid");
vd.type = "Grid";
var oy = vd, gd = class extends w {
  constructor(e) {
    super(), this.id = e.channelId, this.author = new Ft(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.ownerBadges, e.thumbnail), this.subscribers = new _(e.subscriberCountText), this.video_count = new _(e.videoCountText), this.endpoint = new L(e.navigationEndpoint), this.subscribe_button = y.parse(e.subscribeButton);
  }
};
l(gd, "GridChannel");
gd.type = "GridChannel";
var ay = gd, yd = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(yd, "GridHeader");
yd.type = "GridHeader";
var Q7 = yd, _d = class extends w {
  constructor(e) {
    var t;
    super(), this.id = e.playlistId, this.title = new _(e.title), e.shortBylineText && (this.author = new Xl(e.shortBylineText, e.ownerBadges)), this.badges = y.parse(e.ownerBadges), this.endpoint = new L(e.navigationEndpoint), this.view_playlist = new Og(e.viewPlaylistText), this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_renderer = y.parse(e.thumbnailRenderer), this.sidebar_thumbnails = [].concat(...((t = e.sidebarThumbnails) === null || t === void 0 ? void 0 : t.map((i) => j.fromResponse(i))) || []) || null, this.video_count = new _(e.thumbnailText), this.video_count_short = new _(e.videoCountShortText);
  }
};
l(_d, "GridPlaylist");
_d.type = "GridPlaylist";
var ly = _d, bd = class extends w {
  constructor(e) {
    var t;
    super();
    const i = (t = e.thumbnailOverlays.find((n) => n.hasOwnProperty("thumbnailOverlayTimeStatusRenderer"))) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer;
    this.id = e.videoId, this.title = new _(e.title), this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.rich_thumbnail = e.richThumbnail && y.parse(e.richThumbnail), this.published = new _(e.publishedTimeText), this.duration = e.lengthText ? new _(e.lengthText) : i != null && i.text ? new _(i.text) : "", this.author = e.shortBylineText && new Ft(e.shortBylineText, e.ownerBadges), this.views = new _(e.viewCountText), this.short_view_count = new _(e.shortViewCountText), this.endpoint = new L(e.navigationEndpoint), this.menu = y.parse(e.menu);
  }
};
l(bd, "GridVideo");
bd.type = "GridVideo";
var uy = bd, wd = class {
  constructor(e) {
    this.thumbnail = {
      image: e.thumbnail.image.sources,
      endpoint: new L(e.thumbnail.onTap),
      on_long_press_endpoint: new L(e.thumbnail.onLongPress),
      content_mode: e.thumbnail.contentMode,
      crop_options: e.thumbnail.cropOptions
    }, this.background_image = {
      image: e.backgroundImage.image.sources,
      gradient_image: e.backgroundImage.gradientImage.sources
    }, this.strapline = e.strapline, this.title = e.title, this.description = e.description, this.cta = {
      icon_name: e.cta.iconName,
      title: e.cta.title,
      endpoint: new L(e.cta.onTap),
      accessibility_text: e.cta.accessibilityText,
      state: e.cta.state
    }, this.text_on_tap_endpoint = new L(e.textOnTap);
  }
};
l(wd, "Panel");
wd.type = "Panel";
var Sd = class extends w {
  constructor(e) {
    super(), this.panels = e.highlightsCarousel.panels.map((t) => new wd(t));
  }
};
l(Sd, "HighlightsCarousel");
Sd.type = "HighlightsCarousel";
var J1 = Sd, Cd = class extends w {
  constructor(e) {
    super(), this.suggestion = new _(e.suggestion), this.endpoint = new L(e.navigationEndpoint), this.icon_type = e.icon.iconType, e.serviceEndpoint && (this.service_endpoint = new L(e.serviceEndpoint));
  }
};
l(Cd, "SearchSuggestion");
Cd.type = "SearchSuggestion";
var cy = Cd, Td = class extends cy {
  constructor(e) {
    super(e);
  }
};
l(Td, "HistorySuggestion");
Td.type = "HistorySuggestion";
var eS = Td, xd = class extends w {
  constructor(e) {
    super(), this.cards = y.parse(e.cards), this.header = y.parse(e.header), this.previous_button = y.parse(e.previousButton), this.next_button = y.parse(e.nextButton);
  }
};
l(xd, "HorizontalCardList");
xd.type = "HorizontalCardList";
var hy = xd, Ed = class extends w {
  constructor(e) {
    super(), this.visible_item_count = e.visibleItemCount, this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Ed, "HorizontalList");
Ed.type = "HorizontalList";
var tS = Ed, Ad = class extends w {
  constructor(e) {
    var t;
    super(), this.icon_type = (t = e.icon) === null || t === void 0 ? void 0 : t.iconType, e.tooltip && (this.tooltip = new _(e.tooltip).toString()), this.endpoint = new L(e.navigationEndpoint);
  }
};
l(Ad, "IconLink");
Ad.type = "IconLink";
var dy = Ad, kd = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(kd, "ItemSectionHeader");
kd.type = "ItemSectionHeader";
var py = kd, Id = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.selected = e.selected || !1, this.endpoint = new L(e.endpoint);
  }
};
l(Id, "ItemSectionTab");
Id.type = "Tab";
var fy = Id, Pd = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.tabs = y.parseArray(e.tabs, fy), e.endItems && (this.end_items = y.parseArray(e.endItems));
  }
};
l(Pd, "ItemSectionTabbedHeader");
Pd.type = "ItemSectionTabbedHeader";
var my = Pd, Md = class extends w {
  constructor(e) {
    super(), this.header = y.parseItem(e.header, [py, my]), this.contents = y.parse(e.contents, !0), (e.targetId || e.sectionIdentifier) && (this.target_id = (e == null ? void 0 : e.target_id) || (e == null ? void 0 : e.sectionIdentifier));
  }
};
l(Md, "ItemSection");
Md.type = "ItemSection";
var Hi = Md, Nd = class extends w {
  constructor(e) {
    var t;
    super(), this.target = {
      video_id: e.target.videoId
    }, this.like_status = e.likeStatus, this.likes_allowed = e.likesAllowed, e.serviceEndpoints && (this.endpoints = (t = e.serviceEndpoints) === null || t === void 0 ? void 0 : t.map((i) => new L(i)));
  }
};
l(Nd, "LikeButton");
Nd.type = "LikeButton";
var iS = Nd, Rd = class extends w {
  constructor(e) {
    var t, i;
    super(), this.header = y.parse(e.header), this.initial_display_state = e.initialDisplayState, this.continuation = (i = (t = e.continuations[0]) === null || t === void 0 ? void 0 : t.reloadContinuationData) === null || i === void 0 ? void 0 : i.continuation, this.client_messages = {
      reconnect_message: new _(e.clientMessages.reconnectMessage),
      unable_to_reconnect_message: new _(e.clientMessages.unableToReconnectMessage),
      fatal_error: new _(e.clientMessages.fatalError),
      reconnected_message: new _(e.clientMessages.reconnectedMessage),
      generic_error: new _(e.clientMessages.genericError)
    }, this.is_replay = e.isReplay || !1;
  }
};
l(Rd, "LiveChat");
Rd.type = "LiveChat";
var vy = Rd, Ld = class extends w {
  constructor(e) {
    super(), this.banner = y.parse(e.bannerRenderer);
  }
};
l(Ld, "AddBannerToLiveChatCommand");
Ld.type = "AddBannerToLiveChatCommand";
var nS = Ld, Dd = class extends w {
  constructor(e) {
    super(), this.item = y.parseItem(e.item), this.client_id = e.clientId || null;
  }
};
l(Dd, "AddChatItemAction");
Dd.type = "AddChatItemAction";
var gy = Dd, Bd = class extends w {
  constructor(e) {
    super(), this.item = y.parseItem(e.item), this.duration_sec = e.durationSec;
  }
};
l(Bd, "AddLiveChatTickerItemAction");
Bd.type = "AddLiveChatTickerItemAction";
var sS = Bd, Od = class extends w {
  constructor(e) {
    super(), this.auto_moderated_item = y.parse(e.autoModeratedItem), this.header_text = new _(e.headerText), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.id = e.id;
  }
};
l(Od, "LiveChatAutoModMessage");
Od.type = "LiveChatAutoModMessage";
var rS = Od, Fd = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.contents = y.parse(e.contents), this.action_id = e.actionId, this.viewer_is_creator = e.viewerIsCreator, this.target_id = e.targetId, this.is_stackable = e.isStackable, this.background_type = e.backgroundType;
  }
};
l(Fd, "LiveChatBanner");
Fd.type = "LiveChatBanner";
var oS = Fd, Vd = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString(), this.icon_type = e.icon.iconType, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(Vd, "LiveChatBannerHeader");
Vd.type = "LiveChatBannerHeader";
var aS = Vd, Ud = class extends w {
  constructor(e) {
    super(), this.poll_question = new _(e.pollQuestion), this.author_photo = j.fromResponse(e.authorPhoto), this.choices = e.pollChoices.map((t) => ({
      option_id: t.pollOptionId,
      text: new _(t.text).toString()
    })), this.collapsed_state_entity_key = e.collapsedStateEntityKey, this.live_chat_poll_state_entity_key = e.liveChatPollStateEntityKey, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(Ud, "LiveChatBannerPoll");
Ud.type = "LiveChatBannerPoll";
var lS = Ud, jd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.header_subtext = new _(e.headerSubtext), this.author = {
      id: e.authorExternalChannelId,
      name: new _(e == null ? void 0 : e.authorName),
      thumbnails: j.fromResponse(e.authorPhoto),
      badges: y.parse(e.authorBadges)
    }, this.menu_endpoint = new L(e.contextMenuEndpoint);
  }
};
l(jd, "LiveChatMembershipItem");
jd.type = "LiveChatMembershipItem";
var uS = jd, Hd = class extends w {
  constructor(e) {
    super(), e != null && e.icon && (this.icon_type = e.icon.iconType), e != null && e.style && (this.style = e.style), this.tooltip = (e == null ? void 0 : e.tooltip) || (e == null ? void 0 : e.iconTooltip) || null;
  }
};
l(Hd, "MetadataBadge");
Hd.type = "MetadataBadge";
var gs = Hd, Wd = class extends gs {
  constructor(e) {
    super(e), this.custom_thumbnail = e.customThumbnail ? j.fromResponse(e.customThumbnail) : null;
  }
};
l(Wd, "LiveChatAuthorBadge");
Wd.type = "LiveChatAuthorBadge";
var ur = Wd, $d = class extends w {
  constructor(e) {
    super(), this.message = new _(e.message), this.author = {
      id: e.authorExternalChannelId,
      name: new _(e.authorName),
      thumbnails: j.fromResponse(e.authorPhoto),
      badges: y.parseArray(e.authorBadges, [gs, ur]),
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [gs, ur]);
    this.author.badges = t, this.author.is_moderator = (t == null ? void 0 : t.some((i) => i.icon_type == "MODERATOR")) || null, this.author.is_verified = (t == null ? void 0 : t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED")) || null, this.author.is_verified_artist = (t == null ? void 0 : t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST")) || null, this.header_background_color = e.headerBackgroundColor, this.header_text_color = e.headerTextColor, this.body_background_color = e.bodyBackgroundColor, this.body_text_color = e.bodyTextColor, this.purchase_amount = new _(e.purchaseAmountText).toString(), this.menu_endpoint = new L(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.timestamp_text = new _(e.timestampText).toString(), this.id = e.id;
  }
};
l($d, "LiveChatPaidMessage");
$d.type = "LiveChatPaidMessage";
var cS = $d, Gd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.author = {
      id: e.authorExternalChannelId,
      name: new _(e.authorName),
      thumbnails: j.fromResponse(e.authorPhoto),
      badges: y.parse(e.authorBadges)
    }, this.money_chip_background_color = e.moneyChipBackgroundColor, this.money_chip_text_color = e.moneyChipTextColor, this.background_color = e.backgroundColor, this.author_name_text_color = e.authorNameTextColor, this.sticker = j.fromResponse(e.sticker), this.purchase_amount = new _(e.purchaseAmountText).toString(), this.context_menu = new L(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3);
  }
};
l(Gd, "LiveChatPaidSticker");
Gd.type = "LiveChatPaidSticker";
var hS = Gd, qd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3);
  }
};
l(qd, "LiveChatPlaceholderItem");
qd.type = "LiveChatPlaceholderItem";
var dS = qd, zd = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.accessibility_title = e.accessibilityTitle, this.thumbnail = j.fromResponse(e.thumbnail), this.price = e.price, this.vendor_name = e.vendorName, this.from_vendor_text = e.fromVendorText, this.information_button = y.parse(e.informationButton), this.endpoint = new L(e.onClickCommand), this.creator_message = e.creatorMessage, this.creator_name = e.creatorName, this.author_photo = j.fromResponse(e.authorPhoto), this.information_dialog = y.parse(e.informationDialog), this.is_verified = e.isVerified, this.creator_custom_message = new _(e.creatorCustomMessage);
  }
};
l(zd, "LiveChatProductItem");
zd.type = "LiveChatProductItem";
var pS = zd, Kd = class extends w {
  constructor(e) {
    super(), this.message = new _(e.message), this.author = {
      id: e.authorExternalChannelId,
      name: new _(e.authorName),
      thumbnails: j.fromResponse(e.authorPhoto),
      badges: [],
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [gs, ur]);
    this.author.badges = t, this.author.is_moderator = t ? t.some((i) => i.icon_type == "MODERATOR") : null, this.author.is_verified = t ? t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED") : null, this.author.is_verified_artist = t ? t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST") : null, this.menu_endpoint = new L(e.contextMenuEndpoint), this.timestamp = Math.floor(parseInt(e.timestampUsec) / 1e3), this.id = e.id;
  }
};
l(Kd, "LiveChatTextMessage");
Kd.type = "LiveChatTextMessage";
var yy = Kd, Yd = class extends w {
  constructor(e) {
    super(), this.author = {
      id: e.authorExternalChannelId,
      thumbnails: j.fromResponse(e.authorPhoto),
      badges: y.parseArray(e.authorBadges, [gs, ur]),
      is_moderator: null,
      is_verified: null,
      is_verified_artist: null
    };
    const t = y.parseArray(e.authorBadges, [gs, ur]);
    this.author.badges = t, this.author.is_moderator = (t == null ? void 0 : t.some((i) => i.icon_type == "MODERATOR")) || null, this.author.is_verified = (t == null ? void 0 : t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED")) || null, this.author.is_verified_artist = (t == null ? void 0 : t.some((i) => i.style == "BADGE_STYLE_TYPE_VERIFIED_ARTIST")) || null, this.amount = new _(e.amount), this.duration_sec = e.durationSec, this.full_duration_sec = e.fullDurationSec, this.show_item = y.parse(e.showItemEndpoint.showLiveChatItemEndpoint.renderer), this.show_item_endpoint = new L(e.showItemEndpoint), this.id = e.id;
  }
};
l(Yd, "LiveChatTickerPaidMessageItem");
Yd.type = "LiveChatTickerPaidMessageItem";
var fS = Yd, Xd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.detail_text = new _(e.detailText).toString(), this.author = {
      id: e.authorExternalChannelId,
      name: new _(e == null ? void 0 : e.authorName),
      thumbnails: j.fromResponse(e.sponsorPhoto)
    }, this.duration_sec = e.durationSec;
  }
};
l(Xd, "LiveChatTickerSponsorItem");
Xd.type = "LiveChatTickerSponsorItem";
var mS = Xd, Jd = class extends yy {
  constructor(e) {
    super(e), delete this.author, delete this.menu_endpoint, this.icon_type = e.icon.iconType, this.action_button = y.parse(e.actionButton);
  }
};
l(Jd, "LiveChatViewerEngagementMessage");
Jd.type = "LiveChatViewerEngagementMessage";
var vS = Jd, Zd = class extends w {
  constructor(e) {
    super(), this.poll_question = new _(e.pollQuestion), this.thumbnails = j.fromResponse(e.thumbnail), this.metadata = new _(e.metadataText), this.live_chat_poll_type = e.liveChatPollType, this.context_menu_button = y.parse(e.contextMenuButton);
  }
};
l(Zd, "PollHeader");
Zd.type = "PollHeader";
var gS = Zd, Qd = class extends w {
  constructor(e) {
    super(), this.id = e.id, this.contents = y.parse(e.contents), this.target_id = e.targetId;
  }
};
l(Qd, "LiveChatActionPanel");
Qd.type = "LiveChatActionPanel";
var yS = Qd, ep = class extends w {
  constructor(e) {
    super(), this.deleted_state_message = new _(e.deletedStateMessage), this.target_item_id = e.targetItemId;
  }
};
l(ep, "MarkChatItemAsDeletedAction");
ep.type = "MarkChatItemAsDeletedAction";
var _S = ep, tp = class extends w {
  constructor(e) {
    super(), this.deleted_state_message = new _(e.deletedStateMessage), this.channel_id = e.externalChannelId;
  }
};
l(tp, "MarkChatItemsByAuthorAsDeletedAction");
tp.type = "MarkChatItemsByAuthorAsDeletedAction";
var bS = tp, ip = class extends w {
  constructor(e) {
    super(), this.target_action_id = e.targetActionId;
  }
};
l(ip, "RemoveBannerForLiveChatCommand");
ip.type = "RemoveBannerForLiveChatCommand";
var wS = ip, np = class extends w {
  constructor(e) {
    super(), this.target_item_id = e.targetItemId, this.replacement_item = y.parse(e.replacementItem);
  }
};
l(np, "ReplaceChatItemAction");
np.type = "ReplaceChatItemAction";
var SS = np, sp = class extends w {
  constructor(e) {
    var t;
    super(), this.actions = y.parse((t = e.actions) === null || t === void 0 ? void 0 : t.map((i) => (delete i.clickTrackingParams, i))) || [], this.video_offset_time_msec = e.videoOffsetTimeMsec;
  }
};
l(sp, "ReplayChatItemAction");
sp.type = "ReplayChatItemAction";
var CS = sp, rp = class extends w {
  constructor(e) {
    super(), this.panel_to_show = y.parse(e.panelToShow);
  }
};
l(rp, "ShowLiveChatActionPanelAction");
rp.type = "ShowLiveChatActionPanelAction";
var TS = rp, op = class extends w {
  constructor(e) {
    super(), this.tooltip = y.parse(e.tooltip);
  }
};
l(op, "ShowLiveChatTooltipCommand");
op.type = "ShowLiveChatTooltipCommand";
var xS = op, ap = class extends w {
  constructor(e) {
    super(), this.date_text = new _(e.dateText).toString();
  }
};
l(ap, "UpdateDateTextAction");
ap.type = "UpdateDateTextAction";
var _y = ap, lp = class extends w {
  constructor(e) {
    super(), this.description = new _(e.description);
  }
};
l(lp, "UpdateDescriptionAction");
lp.type = "UpdateDescriptionAction";
var by = lp, up = class extends w {
  constructor(e) {
    super(), this.poll_to_update = y.parse(e.pollToUpdate);
  }
};
l(up, "UpdateLiveChatPollAction");
up.type = "UpdateLiveChatPollAction";
var ES = up, cp = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(cp, "UpdateTitleAction");
cp.type = "UpdateTitleAction";
var wy = cp, hp = class extends w {
  constructor(e) {
    super(), this.default_text = new _(e.defaultText).toString(), this.toggled_text = new _(e.toggledText).toString(), this.button_id = e.buttonId;
  }
};
l(hp, "UpdateToggleButtonTextAction");
hp.type = "UpdateToggleButtonTextAction";
var Sy = hp, dp = class extends w {
  constructor(e) {
    super();
    const t = e.viewCount.videoViewCountRenderer;
    this.view_count = new _(t.viewCount), this.extra_short_view_count = new _(t.extraShortViewCount), this.is_live = t.isLive;
  }
};
l(dp, "UpdateViewershipAction");
dp.type = "UpdateViewershipAction";
var Cy = dp, pp = class extends w {
  constructor(e) {
    super(), this.confirm_button = y.parseItem(e.confirmButton, at), this.dialog_messages = e.dialogMessages.map((t) => new _(t));
  }
};
l(pp, "LiveChatDialog");
pp.type = "LiveChatDialog";
var AS = pp, fp = class extends w {
  constructor(e) {
    super(), this.overflow_menu = y.parse(e.overflowMenu), this.collapse_button = y.parse(e.collapseButton), this.view_selector = y.parse(e.viewSelector);
  }
};
l(fp, "LiveChatHeader");
fp.type = "LiveChatHeader";
var kS = fp, mp = class extends w {
  constructor(e) {
    super(), this.max_items_to_display = e.maxItemsToDisplay, this.more_comments_below_button = y.parse(e.moreCommentsBelowButton);
  }
};
l(mp, "LiveChatItemList");
mp.type = "LiveChatItemList";
var IS = mp, vp = class extends w {
  constructor(e) {
    super(), this.author_name = new _(e.authorName), this.author_photo = j.fromResponse(e.authorPhoto), this.send_button = y.parse(e.sendButton), this.target_id = e.targetId;
  }
};
l(vp, "LiveChatMessageInput");
vp.type = "LiveChatMessageInput";
var PS = vp, gp = class extends w {
  constructor(e) {
    super(), this.name = new _(e.authorName), this.photo = j.fromResponse(e.authorPhoto), this.badges = y.parse(e.authorBadges);
  }
};
l(gp, "LiveChatParticipant");
gp.type = "LiveChatParticipant";
var MS = gp, yp = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.participants = y.parse(e.participants);
  }
};
l(yp, "LiveChatParticipantsList");
yp.type = "LiveChatParticipantsList";
var NS = yp, _p = class extends w {
  constructor(e) {
    var t, i;
    super(), this.items = y.parseArray(e.items), this.top_level_buttons = y.parseArray(e.topLevelButtons), this.label = ((i = (t = e.accessibility) === null || t === void 0 ? void 0 : t.accessibilityData) === null || i === void 0 ? void 0 : i.label) || null;
  }
  get contents() {
    return this.items;
  }
};
l(_p, "Menu");
_p.type = "Menu";
var rn = _p, bp = class extends at {
  constructor(e) {
    super(e);
  }
};
l(bp, "MenuNavigationItem");
bp.type = "MenuNavigationItem";
var RS = bp, wp = class extends at {
  constructor(e) {
    super(e);
  }
};
l(wp, "MenuServiceItem");
wp.type = "MenuServiceItem";
var LS = wp, Sp = class extends w {
  constructor(e) {
    super(), this.has_separator = e.hasSeparator, this.endpoint = new L(e.navigationEndpoint || e.serviceEndpoint);
  }
};
l(Sp, "MenuServiceItemDownload");
Sp.type = "MenuServiceItemDownload";
var DS = Sp, Cp = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.sections = y.parse(e.sections), this.style = e.style;
  }
};
l(Cp, "MultiPageMenu");
Cp.type = "MultiPageMenu";
var BS = Cp, Tp = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Tp, "MultiPageMenuNotificationSection");
Tp.type = "MultiPageMenuNotificationSection";
var OS = Tp, xp = class extends w {
  constructor(e) {
    super();
  }
};
l(xp, "MusicMenuItemDivider");
xp.type = "MusicMenuItemDivider";
var Ty = xp, Ep = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.title = new _(e.title).text, this.form_item_entity_key = e.formItemEntityKey, this.selected_icon_type = ((t = e.selectedIcon) === null || t === void 0 ? void 0 : t.iconType) || null;
    const r = (s = (n = (i = e.selectedCommand) === null || i === void 0 ? void 0 : i.commandExecutorCommand) === null || n === void 0 ? void 0 : n.commands) === null || s === void 0 ? void 0 : s.find((a) => {
      var u;
      return (u = a.musicBrowseFormBinderCommand) === null || u === void 0 ? void 0 : u.browseEndpoint;
    });
    r && (this.endpoint = new L(r.musicBrowseFormBinderCommand)), this.selected = !!this.endpoint;
  }
};
l(Ep, "MusicMultiSelectMenuItem");
Ep.type = "MusicMultiSelectMenuItem";
var Ap = Ep, kp = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new _((t = e.title.musicMenuTitleRenderer) === null || t === void 0 ? void 0 : t.primaryText).text, this.options = y.parseArray(e.options, [Ap, Ty]);
  }
};
l(kp, "MusicMultiSelectMenu");
kp.type = "MusicMultiSelectMenu";
var xy = kp, Ip = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.buttons = y.parse(e.buttons);
  }
};
l(Ip, "SimpleMenuHeader");
Ip.type = "SimpleMenuHeader";
var Ey = Ip, Pp = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description, this.thumbnails = j.fromResponse(e.thumbnail), this.price = e.price, this.vendor_name = e.vendorName, this.button_text = e.buttonText, this.button_accessibility_text = e.buttonAccessibilityText, this.from_vendor_text = e.fromVendorText, this.additional_fees_text = e.additionalFeesText, this.region_format = e.regionFormat, this.endpoint = new L(e.buttonCommand);
  }
};
l(Pp, "MerchandiseItem");
Pp.type = "MerchandiseItem";
var FS = Pp, Mp = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.menu = y.parse(e.actionButton), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Mp, "MerchandiseShelf");
Mp.type = "MerchandiseShelf";
var Ay = Mp, Np = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString();
  }
};
l(Np, "Message");
Np.type = "Message";
var Qo = Np, Rp = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.contents = e.contents.map((t) => new _(t));
  }
};
l(Rp, "MetadataRow");
Rp.type = "MetadataRow";
var VS = Rp, Lp = class extends w {
  constructor(e) {
    super(), this.rows = y.parseArray(e.rows), this.collapsed_item_count = e.collapsedItemCount;
  }
};
l(Lp, "MetadataRowContainer");
Lp.type = "MetadataRowContainer";
var ky = Lp, Dp = class extends w {
  constructor(e) {
    super(), this.content = new _(e.content), this.has_divider_line = e.hasDividerLine;
  }
};
l(Dp, "MetadataRowHeader");
Dp.type = "MetadataRowHeader";
var US = Dp, Bp = class extends w {
  constructor(e) {
    super(), this.section_list = y.parseItem(e);
  }
};
l(Bp, "MetadataScreen");
Bp.type = "MetadataScreen";
var jS = Bp, Op = class extends w {
  constructor(e) {
    super(), this.url_canonical = e.urlCanonical, this.title = e.title, this.description = e.description, this.thumbnail = e.thumbnail ? j.fromResponse(e.thumbnail) : null, this.site_name = e.siteName, this.app_name = e.appName, this.android_package = e.androidPackage, this.ios_app_store_id = e.iosAppStoreId, this.ios_app_arguments = e.iosAppArguments, this.og_type = e.ogType, this.url_applinks_web = e.urlApplinksWeb, this.url_applinks_ios = e.urlApplinksIos, this.url_applinks_android = e.urlApplinksAndroid, this.url_twitter_ios = e.urlTwitterIos, this.url_twitter_android = e.urlTwitterAndroid, this.twitter_card_type = e.twitterCardType, this.twitter_site_handle = e.twitterSiteHandle, this.schema_dot_org_type = e.schemaDotOrgType, this.noindex = e.noindex, this.is_unlisted = e.unlisted, this.is_family_safe = e.familySafe, this.tags = e.tags, this.available_countries = e.availableCountries;
  }
};
l(Op, "MicroformatData");
Op.type = "MicroformatData";
var ea = Op, Fp = class extends Zo {
  constructor(e) {
    super(e);
  }
};
l(Fp, "Mix");
Fp.type = "Mix";
var HS = Fp, Vp = class extends w {
  constructor(e) {
    var t, i, n;
    super();
    const s = ((t = e.thumbnailOverlays.find((r) => r.thumbnailOverlayTimeStatusRenderer)) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer.text) || "N/A";
    this.id = e.videoId, this.title = new _(e.title), this.description_snippet = e.descriptionSnippet ? new _(e.descriptionSnippet) : null, this.top_metadata_items = new _(e.topMetadataItems), this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new Ft(e.longBylineText, e.ownerBadges, (n = (i = e.channelThumbnailSupportedRenderers) === null || i === void 0 ? void 0 : i.channelThumbnailWithLinkRenderer) === null || n === void 0 ? void 0 : n.thumbnail), this.duration = {
      text: e.lengthText ? new _(e.lengthText).text : new _(s).text,
      seconds: ji(e.lengthText ? new _(e.lengthText).text : new _(s).text)
    }, this.endpoint = new L(e.navigationEndpoint), this.badges = y.parse(e.badges), this.use_vertical_poster = e.useVerticalPoster, this.show_action_menu = e.showActionMenu, this.menu = y.parse(e.menu);
  }
};
l(Vp, "Movie");
Vp.type = "Movie";
var WS = Vp, Up = class extends w {
  constructor(e) {
    var t;
    return super(), (t = e.movingThumbnailDetails) === null || t === void 0 ? void 0 : t.thumbnails.map((i) => new j(i)).sort((i, n) => n.width - i.width);
  }
};
l(Up, "MovingThumbnail");
Up.type = "MovingThumbnail";
var $S = Up, jp = class extends w {
  constructor(e) {
    var t;
    super(), this.endpoint = new L(e.playNavigationEndpoint), this.play_icon_type = e.playIcon.iconType, this.pause_icon_type = e.pauseIcon.iconType, e.accessibilityPlayData && (this.play_label = e.accessibilityPlayData.accessibilityData.label), e.accessibilityPlayData && (this.pause_label = (t = e.accessibilityPauseData) === null || t === void 0 ? void 0 : t.accessibilityData.label), this.icon_color = e.iconColor;
  }
};
l(jp, "MusicPlayButton");
jp.type = "MusicPlayButton";
var Iy = jp, Hp = class extends w {
  constructor(e) {
    super(), this.content = y.parseItem(e.content, Iy), this.content_position = e.contentPosition, this.display_style = e.displayStyle;
  }
};
l(Hp, "MusicItemThumbnailOverlay");
Hp.type = "MusicItemThumbnailOverlay";
var Wp = Hp, $p = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h, p, m, b, C, k, D, I, $, O, F;
    switch (super(), this.title = new _(e.title), this.endpoint = new L(e.navigationEndpoint), this.id = ((i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id) || ((s = (n = this.endpoint) === null || n === void 0 ? void 0 : n.watch) === null || s === void 0 ? void 0 : s.video_id), this.subtitle = new _(e.subtitle), this.badges = y.parse(e.subtitleBadges), (a = (r = this.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.page_type) {
      case "MUSIC_PAGE_TYPE_ARTIST":
        this.item_type = "artist";
        break;
      case "MUSIC_PAGE_TYPE_PLAYLIST":
        this.item_type = "playlist";
        break;
      case "MUSIC_PAGE_TYPE_ALBUM":
        this.item_type = "album";
        break;
      default:
        !((u = this.endpoint) === null || u === void 0) && u.watch_playlist ? this.item_type = "endpoint" : !((c = this.subtitle.runs) === null || c === void 0) && c[0] ? this.subtitle.runs[0].text !== "Song" ? this.item_type = "video" : this.item_type = "song" : this.endpoint ? this.item_type = "endpoint" : this.item_type = "unknown";
        break;
    }
    if (this.item_type == "artist")
      this.subscribers = ((p = (h = this.subtitle.runs) === null || h === void 0 ? void 0 : h.find((K) => /^(\d*\.)?\d+[M|K]? subscribers?$/i.test(K.text))) === null || p === void 0 ? void 0 : p.text) || "";
    else if (this.item_type == "playlist") {
      const K = (m = this.subtitle.runs) === null || m === void 0 ? void 0 : m.find((M) => M.text.match(/\d+ songs|song/));
      this.item_count = K ? K.text : null;
    } else if (this.item_type == "album") {
      const K = (b = this.subtitle.runs) === null || b === void 0 ? void 0 : b.filter((M) => {
        var v, H;
        return (H = (v = M.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || H === void 0 ? void 0 : H.id.startsWith("UC");
      });
      K && (this.artists = K.map((M) => ({
        name: M.text,
        channel_id: M.endpoint.browse.id,
        endpoint: M.endpoint
      }))), this.year = (C = this.subtitle.runs) === null || C === void 0 ? void 0 : C.slice(-1)[0].text, isNaN(Number(this.year)) && delete this.year;
    } else if (this.item_type == "video") {
      this.views = ((D = (k = this === null || this === void 0 ? void 0 : this.subtitle.runs) === null || k === void 0 ? void 0 : k.find((M) => M == null ? void 0 : M.text.match(/(.*?) views/))) === null || D === void 0 ? void 0 : D.text) || "N/A";
      const K = (I = this.subtitle.runs) === null || I === void 0 ? void 0 : I.find((M) => {
        var v, H, ce;
        return (ce = (H = (v = M.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || H === void 0 ? void 0 : H.id) === null || ce === void 0 ? void 0 : ce.startsWith("UC");
      });
      K && (this.author = {
        name: K == null ? void 0 : K.text,
        channel_id: (O = ($ = K == null ? void 0 : K.endpoint) === null || $ === void 0 ? void 0 : $.browse) === null || O === void 0 ? void 0 : O.id,
        endpoint: K == null ? void 0 : K.endpoint
      });
    } else if (this.item_type == "song") {
      const K = (F = this.subtitle.runs) === null || F === void 0 ? void 0 : F.filter((M) => {
        var v, H;
        return (H = (v = M.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || H === void 0 ? void 0 : H.id.startsWith("UC");
      });
      K && (this.artists = K.map((M) => {
        var v, H;
        return {
          name: M == null ? void 0 : M.text,
          channel_id: (H = (v = M == null ? void 0 : M.endpoint) === null || v === void 0 ? void 0 : v.browse) === null || H === void 0 ? void 0 : H.id,
          endpoint: M == null ? void 0 : M.endpoint
        };
      }));
    }
    this.thumbnail = j.fromResponse(e.thumbnailRenderer.musicThumbnailRenderer.thumbnail), this.thumbnail_overlay = y.parseItem(e.thumbnailOverlay, Wp), this.menu = y.parseItem(e.menu, rn);
  }
};
l($p, "MusicTwoRowItem");
$p.type = "MusicTwoRowItem";
var Gp = $p, qp = class extends w {
  constructor(e) {
    super(), this.title = new _(e.text), this.display_priority = e.displayPriority;
  }
};
l(qp, "MusicResponsiveListItemFlexColumn");
qp.type = "musicResponsiveListItemFlexColumnRenderer";
var Py = qp, zp = class extends w {
  constructor(e) {
    super(), this.title = new _(e.text), this.display_priority = e.displayPriority;
  }
};
l(zp, "MusicResponsiveListItemFixedColumn");
zp.type = "musicResponsiveListItemFlexColumnRenderer";
var My = zp, T1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Te = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ni, je, Co, To, Ny, Ry, A5, k5, Ly, Dy, By, Oy, Kp = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    switch (super(), Ni.add(this), je.set(this, void 0), Co.set(this, void 0), To.set(this, void 0), T1(this, je, y.parseArray(e.flexColumns, Py), "f"), T1(this, Co, y.parseArray(e.fixedColumns, My), "f"), T1(this, To, {
      video_id: ((t = e == null ? void 0 : e.playlistItemData) === null || t === void 0 ? void 0 : t.videoId) || null,
      playlist_set_video_id: ((i = e == null ? void 0 : e.playlistItemData) === null || i === void 0 ? void 0 : i.playlistSetVideoId) || null
    }, "f"), this.endpoint = e.navigationEndpoint ? new L(e.navigationEndpoint) : null, (s = (n = this.endpoint) === null || n === void 0 ? void 0 : n.browse) === null || s === void 0 ? void 0 : s.page_type) {
      case "MUSIC_PAGE_TYPE_ALBUM":
        this.item_type = "album", Te(this, Ni, "m", By).call(this);
        break;
      case "MUSIC_PAGE_TYPE_PLAYLIST":
        this.item_type = "playlist", Te(this, Ni, "m", Oy).call(this);
        break;
      case "MUSIC_PAGE_TYPE_ARTIST":
      case "MUSIC_PAGE_TYPE_USER_CHANNEL":
        this.item_type = "artist", Te(this, Ni, "m", Ly).call(this);
        break;
      case "MUSIC_PAGE_TYPE_LIBRARY_ARTIST":
        this.item_type = "library_artist", Te(this, Ni, "m", Dy).call(this);
        break;
      default:
        Te(this, je, "f")[1] ? Te(this, Ni, "m", Ry).call(this) : Te(this, Ni, "m", Ny).call(this);
        break;
    }
    e.index && (this.index = new _(e.index)), this.thumbnails = e.thumbnail ? j.fromResponse((r = e.thumbnail.musicThumbnailRenderer) === null || r === void 0 ? void 0 : r.thumbnail) : [], this.badges = y.parseArray(e.badges), this.menu = y.parseItem(e.menu, rn), this.overlay = y.parseItem(e.overlay, Wp);
  }
};
l(Kp, "MusicResponsiveListItem");
je = /* @__PURE__ */ new WeakMap(), Co = /* @__PURE__ */ new WeakMap(), To = /* @__PURE__ */ new WeakMap(), Ni = /* @__PURE__ */ new WeakSet(), Ny = /* @__PURE__ */ l(function() {
  this.title = Te(this, je, "f")[0].key("title").instanceof(_).toString(), this.endpoint ? this.item_type = "endpoint" : this.item_type = "unknown";
}, "_MusicResponsiveListItem_parseOther"), Ry = /* @__PURE__ */ l(function() {
  var t;
  ((t = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || t === void 0 ? void 0 : t.some((n) => n.text.match(/(.*?) views/))) ? (this.item_type = "video", Te(this, Ni, "m", k5).call(this)) : (this.item_type = "song", Te(this, Ni, "m", A5).call(this));
}, "_MusicResponsiveListItem_parseVideoOrSong"), A5 = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u, c, h, p, m, b, C;
  this.id = Te(this, To, "f").video_id || ((i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.watch) === null || i === void 0 ? void 0 : i.video_id), this.title = Te(this, je, "f")[0].key("title").instanceof(_).toString();
  const k = ((s = (n = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || n === void 0 ? void 0 : n.find(($) => /^\d+$/.test($.text.replace(/:/g, "")))) === null || s === void 0 ? void 0 : s.text) || ((u = (a = (r = Te(this, Co, "f")) === null || r === void 0 ? void 0 : r[0]) === null || a === void 0 ? void 0 : a.key("title").instanceof(_)) === null || u === void 0 ? void 0 : u.toString());
  k && (this.duration = {
    text: k,
    seconds: ji(k)
  });
  const D = ((c = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || c === void 0 ? void 0 : c.find(($) => {
    var O, F;
    return (F = (O = Reflect.get($, "endpoint")) === null || O === void 0 ? void 0 : O.browse) === null || F === void 0 ? void 0 : F.id.startsWith("MPR");
  })) || ((p = (h = Te(this, je, "f")[2]) === null || h === void 0 ? void 0 : h.key("title").instanceof(_).runs) === null || p === void 0 ? void 0 : p.find(($) => {
    var O, F;
    return (F = (O = Reflect.get($, "endpoint")) === null || O === void 0 ? void 0 : O.browse) === null || F === void 0 ? void 0 : F.id.startsWith("MPR");
  }));
  D && (this.album = {
    id: (b = (m = D.endpoint) === null || m === void 0 ? void 0 : m.browse) === null || b === void 0 ? void 0 : b.id,
    name: D.text,
    endpoint: D.endpoint
  });
  const I = (C = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || C === void 0 ? void 0 : C.filter(($) => {
    var O, F;
    return (F = (O = Reflect.get($, "endpoint")) === null || O === void 0 ? void 0 : O.browse) === null || F === void 0 ? void 0 : F.id.startsWith("UC");
  });
  I && (this.artists = I.map(($) => {
    var O, F;
    return {
      name: $.text,
      channel_id: (F = (O = $.endpoint) === null || O === void 0 ? void 0 : O.browse) === null || F === void 0 ? void 0 : F.id,
      endpoint: $.endpoint
    };
  }));
}, "_MusicResponsiveListItem_parseSong"), k5 = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u, c;
  this.id = Te(this, To, "f").video_id, this.title = Te(this, je, "f")[0].key("title").instanceof(_).toString(), this.views = (i = (t = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || t === void 0 ? void 0 : t.find((m) => m.text.match(/(.*?) views/))) === null || i === void 0 ? void 0 : i.text;
  const h = (n = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || n === void 0 ? void 0 : n.filter((m) => {
    var b, C;
    return (C = (b = Reflect.get(m, "endpoint")) === null || b === void 0 ? void 0 : b.browse) === null || C === void 0 ? void 0 : C.id.startsWith("UC");
  });
  h && (this.authors = h.map((m) => {
    var b, C;
    return {
      name: m.text,
      channel_id: (C = (b = m.endpoint) === null || b === void 0 ? void 0 : b.browse) === null || C === void 0 ? void 0 : C.id,
      endpoint: m.endpoint
    };
  }));
  const p = ((r = (s = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || s === void 0 ? void 0 : s.find((m) => /^\d+$/.test(m.text.replace(/:/g, "")))) === null || r === void 0 ? void 0 : r.text) || ((c = (u = (a = Te(this, Co, "f")[0]) === null || a === void 0 ? void 0 : a.key("title").instanceof(_).runs) === null || u === void 0 ? void 0 : u.find((m) => /^\d+$/.test(m.text.replace(/:/g, "")))) === null || c === void 0 ? void 0 : c.text);
  p && (this.duration = {
    text: p,
    seconds: ji(p)
  });
}, "_MusicResponsiveListItem_parseVideo"), Ly = /* @__PURE__ */ l(function() {
  var t, i, n, s;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.name = Te(this, je, "f")[0].key("title").instanceof(_).toString(), this.subtitle = Te(this, je, "f")[1].key("title").instanceof(_), this.subscribers = ((s = (n = this.subtitle.runs) === null || n === void 0 ? void 0 : n.find((r) => /^(\d*\.)?\d+[M|K]? subscribers?$/i.test(r.text))) === null || s === void 0 ? void 0 : s.text) || "";
}, "_MusicResponsiveListItem_parseArtist"), Dy = /* @__PURE__ */ l(function() {
  var t, i, n;
  this.name = Te(this, je, "f")[0].key("title").instanceof(_).toString(), this.subtitle = Te(this, je, "f")[1].key("title").instanceof(_), this.song_count = ((n = (i = (t = this.subtitle) === null || t === void 0 ? void 0 : t.runs) === null || i === void 0 ? void 0 : i.find((s) => /^\d+(,\d+)? songs?$/i.test(s.text))) === null || n === void 0 ? void 0 : n.text) || "";
}, "_MusicResponsiveListItem_parseLibraryArtist"), By = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a, u;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.title = Te(this, je, "f")[0].key("title").instanceof(_).toString();
  const c = (n = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || n === void 0 ? void 0 : n.find((h) => {
    var p, m;
    return (m = (p = Reflect.get(h, "endpoint")) === null || p === void 0 ? void 0 : p.browse) === null || m === void 0 ? void 0 : m.id.startsWith("UC");
  });
  c && (this.author = {
    name: c.text,
    channel_id: (r = (s = c.endpoint) === null || s === void 0 ? void 0 : s.browse) === null || r === void 0 ? void 0 : r.id,
    endpoint: c.endpoint
  }), this.year = (u = (a = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || a === void 0 ? void 0 : a.find((h) => /^[12][0-9]{3}$/.test(h.text))) === null || u === void 0 ? void 0 : u.text;
}, "_MusicResponsiveListItem_parseAlbum"), Oy = /* @__PURE__ */ l(function() {
  var t, i, n, s, r, a;
  this.id = (i = (t = this.endpoint) === null || t === void 0 ? void 0 : t.browse) === null || i === void 0 ? void 0 : i.id, this.title = Te(this, je, "f")[0].key("title").instanceof(_).toString();
  const u = (n = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || n === void 0 ? void 0 : n.find((h) => h.text.match(/\d+ (song|songs)/));
  this.item_count = u ? u.text : void 0;
  const c = (s = Te(this, je, "f")[1].key("title").instanceof(_).runs) === null || s === void 0 ? void 0 : s.find((h) => {
    var p, m;
    return (m = (p = Reflect.get(h, "endpoint")) === null || p === void 0 ? void 0 : p.browse) === null || m === void 0 ? void 0 : m.id.startsWith("UC");
  });
  c && (this.author = {
    name: c.text,
    channel_id: (a = (r = c.endpoint) === null || r === void 0 ? void 0 : r.browse) === null || a === void 0 ? void 0 : a.id,
    endpoint: c.endpoint
  });
}, "_MusicResponsiveListItem_parsePlaylist");
Kp.type = "MusicResponsiveListItem";
var ta = Kp, Yp = class extends w {
  constructor(e) {
    super(), this.contents = j.fromResponse(e.thumbnail);
  }
};
l(Yp, "MusicThumbnail");
Yp.type = "MusicThumbnail";
var Xp = Yp, Jp = class extends w {
  constructor(e) {
    super(), e.strapline && (this.strapline = new _(e.strapline)), this.title = new _(e.title), e.thumbnail && (this.thumbnail = y.parseItem(e.thumbnail, Xp)), e.moreContentButton && (this.more_content = y.parseItem(e.moreContentButton, at)), e.endIcons && (this.end_icons = y.parseArray(e.endIcons, dy));
  }
};
l(Jp, "MusicCarouselShelfBasicHeader");
Jp.type = "MusicCarouselShelfBasicHeader";
var Fy = Jp, Zp = class extends w {
  constructor(e) {
    super(), this.button_text = new _(e.buttonText).toString(), this.endpoint = new L(e.clickCommand);
  }
};
l(Zp, "MusicNavigationButton");
Zp.type = "MusicNavigationButton";
var Qp = Zp, ef = class extends w {
  constructor(e) {
    super(), this.header = y.parseItem(e.header, Fy), this.contents = y.parseArray(e.contents, [Gp, ta, Qp]), this.num_items_per_column = Reflect.has(e, "numItemsPerColumn") ? parseInt(e.numItemsPerColumn) : null;
  }
};
l(ef, "MusicCarouselShelf");
ef.type = "MusicCarouselShelf";
var cr = ef, tf = class extends w {
  constructor(e) {
    super(), this.description = new _(e.description), this.max_collapsed_lines && (this.max_collapsed_lines = e.maxCollapsedLines), this.max_expanded_lines && (this.max_expanded_lines = e.maxExpandedLines), this.footer = new _(e.footer);
  }
};
l(tf, "MusicDescriptionShelf");
tf.type = "MusicDescriptionShelf";
var kl = tf, nf = class extends w {
  constructor(e) {
    var t, i, n, s, r, a, u, c, h;
    super(), this.title = new _(e.title), this.description = new _(e.description), this.subtitle = new _(e.subtitle), this.second_subtitle = new _(e.secondSubtitle), this.year = ((i = (t = this.subtitle.runs) === null || t === void 0 ? void 0 : t.find((m) => /^[12][0-9]{3}$/.test(m.text))) === null || i === void 0 ? void 0 : i.text) || "", this.song_count = ((s = (n = this.second_subtitle.runs) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.text) || "", this.total_duration = ((a = (r = this.second_subtitle.runs) === null || r === void 0 ? void 0 : r[2]) === null || a === void 0 ? void 0 : a.text) || "", this.thumbnails = j.fromResponse(e.thumbnail.croppedSquareThumbnailRenderer.thumbnail), this.badges = y.parse(e.subtitleBadges);
    const p = (u = this.subtitle.runs) === null || u === void 0 ? void 0 : u.find((m) => {
      var b, C;
      return (C = (b = m == null ? void 0 : m.endpoint) === null || b === void 0 ? void 0 : b.browse) === null || C === void 0 ? void 0 : C.id.startsWith("UC");
    });
    p && (this.author = {
      name: p.text,
      channel_id: (h = (c = p.endpoint) === null || c === void 0 ? void 0 : c.browse) === null || h === void 0 ? void 0 : h.id,
      endpoint: p.endpoint
    }), this.menu = y.parse(e.menu);
  }
};
l(nf, "MusicDetailHeader");
nf.type = "MusicDetailHeader";
var Il = nf, sf = class extends w {
  constructor(e) {
    super(), this.playlist_id = e.playlistId, this.supported_download_states = e.supportedDownloadStates;
  }
};
l(sf, "MusicDownloadStateBadge");
sf.type = "MusicDownloadStateBadge";
var GS = sf, rf = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header);
  }
};
l(rf, "MusicEditablePlaylistDetailHeader");
rf.type = "MusicEditablePlaylistDetailHeader";
var Vy = rf, of = class extends w {
  constructor(e) {
    super(), this.element = Reflect.has(e, "elementRenderer") ? y.parseItem(e, od) : null;
  }
};
l(of, "MusicElementHeader");
of.type = "MusicElementHeader";
var Z1 = of, af = class extends w {
  constructor(e) {
    super(), e.header && (this.header = y.parse(e.header)), e.title && (this.title = new _(e.title));
  }
};
l(af, "MusicHeader");
af.type = "MusicHeader";
var lf = af, uf = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.description = new _(e.description), this.thumbnail = y.parseItem(e.thumbnail, Xp);
  }
};
l(uf, "MusicImmersiveHeader");
uf.type = "MusicImmersiveHeader";
var Uy = uf, cf = class extends w {
  constructor(e) {
    super(), this.icon_type = e.icon.iconType, this.label = e.accessibilityData.accessibilityData.label;
  }
};
l(cf, "MusicInlineBadge");
cf.type = "MusicInlineBadge";
var qS = cf, hf = class {
  constructor(e) {
    this.icon_name = e.iconName, this.endpoint = new L(e.onTap), this.a11y_text = e.a11yText, this.style = e.style;
  }
};
l(hf, "ActionButton");
hf.type = "ActionButton";
var df = class {
  constructor(e) {
    this.image = e.image.image.sources, this.content_mode = e.image.contentMode, this.crop_options = e.image.cropOptions, this.image_aspect_ratio = e.imageAspectRatio, this.caption = e.caption, this.action_buttons = e.actionButtons.map((t) => new hf(t));
  }
};
l(df, "Panel");
df.type = "Panel";
var pf = class extends w {
  constructor(e) {
    super(), this.header = e.shelf.header, this.panels = e.shelf.panels.map((t) => new df(t));
  }
};
l(pf, "MusicLargeCardItemCarousel");
pf.type = "MusicLargeCardItemCarousel";
var zS = pf, ff = class extends w {
  constructor(e) {
    var t, i, n;
    super(), this.playlist_id = e.playlistId, this.contents = y.parseArray(e.contents, ta), this.collapsed_item_count = e.collapsedItemCount, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || null;
  }
};
l(ff, "MusicPlaylistShelf");
ff.type = "MusicPlaylistShelf";
var Pl = ff, mf = class extends w {
  constructor(e) {
    var t, i, n, s, r, a;
    super(), this.title = e.title, this.title_text = new _(e.titleText), this.contents = y.parseArray(e.contents), this.playlist_id = e.playlistId, this.is_infinite = e.isInfinite, this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextRadioContinuationData) === null || n === void 0 ? void 0 : n.continuation) || ((a = (r = (s = e.continuations) === null || s === void 0 ? void 0 : s[0]) === null || r === void 0 ? void 0 : r.nextContinuationData) === null || a === void 0 ? void 0 : a.continuation), this.is_editable = e.isEditable, this.preview_description = e.previewDescription, this.num_items_to_show = e.numItemsToShow;
  }
};
l(mf, "PlaylistPanel");
mf.type = "PlaylistPanel";
var ys = mf, vf = class extends w {
  constructor(e) {
    super(), this.content = y.parseItem(e.content, ys);
  }
};
l(vf, "MusicQueue");
vf.type = "MusicQueue";
var gf = vf, yf = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.title = new _(e.title), this.contents = y.parseArray(e.contents, ta), this.endpoint = Reflect.has(e, "bottomEndpoint") ? new L(e.bottomEndpoint) : null, this.continuation = ((i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData) === null || i === void 0 ? void 0 : i.continuation) || ((s = (n = e.continuations) === null || n === void 0 ? void 0 : n[0].reloadContinuationData) === null || s === void 0 ? void 0 : s.continuation) || null, this.bottom_text = Reflect.has(e, "bottomText") ? new _(e.bottomText) : null, this.bottom_button = y.parseItem(e.bottomButton, at), e.subheaders && (this.subheaders = y.parseArray(e.subheaders));
  }
};
l(yf, "MusicShelf");
yf.type = "MusicShelf";
var cs = yf, _f = class extends w {
  constructor(e) {
    super(), e.startItems && (this.start_items = y.parseArray(e.startItems));
  }
};
l(_f, "MusicSideAlignedItem");
_f.type = "MusicSideAlignedItem";
var KS = _f, bf = class extends w {
  constructor(e) {
    var t;
    super(), this.title = new _(e.title).text, this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.icon_type) || null, this.menu = y.parseItem(e.menu, xy);
  }
};
l(bf, "MusicSortFilterButton");
bf.type = "MusicSortFilterButton";
var YS = bf, wf = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new _(e.title), this.thumbnails = e.thumbnail ? j.fromResponse((t = e.thumbnail.musicThumbnailRenderer) === null || t === void 0 ? void 0 : t.thumbnail) : [], this.menu = y.parseItem(e.menu, rn), this.foreground_thumbnails = e.foregroundThumbnail ? j.fromResponse((i = e.foregroundThumbnail.musicThumbnailRenderer) === null || i === void 0 ? void 0 : i.thumbnail) : [];
  }
};
l(wf, "MusicVisualHeader");
wf.type = "MusicVisualHeader";
var jy = wf, Sf = class extends w {
  constructor(e) {
    super(), this.thumbnails = j.fromResponse(e.thumbnail), this.video_thumbnails = j.fromResponse(e.videoThumbnail), this.short_message = new _(e.shortMessage), this.sent_time = new _(e.sentTimeText), this.notification_id = e.notificationId, this.endpoint = new L(e.navigationEndpoint), this.record_click_endpoint = new L(e.recordClickEndpoint), this.menu = y.parse(e.contextualMenu), this.read = e.read;
  }
};
l(Sf, "Notification");
Sf.type = "Notification";
var XS = Sf, Cf = class extends w {
  constructor(e) {
    super(), this.header_text = new _(e.headerText).toString(), this.body_text = new _(e.bodyText).toString(), this.page_title = new _(e.pageTitle).toString(), this.header_icon_type = e.headerIcon.iconType;
  }
};
l(Cf, "PageIntroduction");
Cf.type = "PageIntroduction";
var Hy = Cf, Tf = class extends w {
  constructor(e) {
    super(), this.featured_channel = {
      start_time_ms: e.featuredChannel.startTimeMs,
      end_time_ms: e.featuredChannel.endTimeMs,
      watermark: j.fromResponse(e.featuredChannel.watermark),
      channel_name: e.featuredChannel.channelName,
      endpoint: new L(e.featuredChannel.navigationEndpoint),
      subscribe_button: y.parse(e.featuredChannel.subscribeButton)
    }, this.allow_swipe_dismiss = e.allowSwipeDismiss, this.annotation_id = e.annotationId;
  }
};
l(Tf, "PlayerAnnotationsExpanded");
Tf.type = "PlayerAnnotationsExpanded";
var Wy = Tf, xf = class extends w {
  constructor(e) {
    super(), this.caption_tracks = e.captionTracks.map((t) => ({
      base_url: t.baseUrl,
      name: new _(t.name),
      vss_id: t.vssId,
      language_code: t.languageCode,
      kind: t.kind,
      is_translatable: t.isTranslatable
    })), this.audio_tracks = e.audioTracks.map((t) => ({
      caption_track_indices: t.captionTrackIndices
    })), this.translation_languages = e.translationLanguages.map((t) => ({
      language_code: t.languageCode,
      language_name: new _(t.languageName)
    }));
  }
};
l(xf, "PlayerCaptionsTracklist");
xf.type = "PlayerCaptionsTracklist";
var $y = xf, Ef = class extends w {
  constructor(e) {
    var t;
    super(), this.subreason = new _(e.subreason), this.reason = new _(e.reason), this.proceed_button = y.parseItem(e.proceedButton, at), this.thumbnails = j.fromResponse(e.thumbnail), this.icon_type = ((t = e.icon) === null || t === void 0 ? void 0 : t.iconType) || null;
  }
};
l(Ef, "PlayerErrorMessage");
Ef.type = "PlayerErrorMessage";
var JS = Ef, Af = class extends w {
  constructor() {
    super();
  }
};
l(Af, "PlayerLiveStoryboardSpec");
Af.type = "PlayerLiveStoryboardSpec";
var Gy = Af, kf = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.description = new _(e.description), this.thumbnails = j.fromResponse(e.thumbnail), this.embed = {
      iframe_url: e.embed.iframeUrl,
      flash_url: e.embed.flashUrl,
      flash_secure_url: e.embed.flashSecureUrl,
      width: e.embed.width,
      height: e.embed.height
    }, this.length_seconds = parseInt(e.lengthSeconds), this.channel = {
      id: e.externalChannelId,
      name: e.ownerChannelName,
      url: e.ownerProfileUrl
    }, this.is_family_safe = !!e.isFamilySafe, this.is_unlisted = !!e.isUnlisted, this.has_ypc_metadata = !!e.hasYpcMetadata, this.view_count = parseInt(e.viewCount), this.category = e.category, this.publish_date = e.publishDate, this.upload_date = e.uploadDate, this.available_countries = e.availableCountries;
  }
};
l(kf, "PlayerMicroformat");
kf.type = "PlayerMicroformat";
var Hr = kf, If = class extends w {
  constructor(e) {
    super(), this.results = y.parseArray(e.results, [ry, sy]), this.title = new _(e.title).toString();
  }
};
l(If, "WatchNextEndScreen");
If.type = "WatchNextEndScreen";
var qy = If, Pf = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.video_id = e.videoId, this.video_title = new _(e.videoTitle), this.short_view_count = new _(e.shortViewCountText), this.prefer_immediate_redirect = e.preferImmediateRedirect, this.count_down_secs_for_fullscreen = e.countDownSecsForFullscreen, this.published = new _(e.publishedTimeText), this.background = j.fromResponse(e.background), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.author = new Ft(e.byline), this.cancel_button = y.parseItem(e.cancelButton, at), this.next_button = y.parseItem(e.nextButton, at), this.close_button = y.parseItem(e.closeButton, at);
  }
};
l(Pf, "PlayerOverlayAutoplay");
Pf.type = "PlayerOverlayAutoplay";
var zy = Pf, Mf = class extends w {
  constructor(e) {
    super(), this.end_screen = y.parseItem(e.endScreen, qy), this.autoplay = y.parseItem(e.autoplay, zy), this.share_button = y.parseItem(e.shareButton, at), this.add_to_menu = y.parseItem(e.addToMenu, rn), this.fullscreen_engagement = y.parse(e.fullscreenEngagement), this.actions = y.parseArray(e.actions), this.browser_media_session = y.parseItem(e.browserMediaSession);
  }
};
l(Mf, "PlayerOverlay");
Mf.type = "PlayerOverlay";
var Nf = Mf, Rf = class extends w {
  constructor(e) {
    super();
    const t = e.spec.split("|"), i = new URL(t.shift());
    this.boards = t.map((n, s) => {
      const [r, a, u, c, h, p, m, b] = n.split("#");
      i.searchParams.set("sigh", b);
      const C = Math.ceil(parseInt(u, 10) / (parseInt(c, 10) * parseInt(h, 10)));
      return {
        template_url: i.toString().replace("$L", s).replace("$N", m),
        thumbnail_width: parseInt(r, 10),
        thumbnail_height: parseInt(a, 10),
        thumbnail_count: parseInt(u, 10),
        interval: parseInt(p, 10),
        columns: parseInt(c, 10),
        rows: parseInt(h, 10),
        storyboard_count: C
      };
    });
  }
};
l(Rf, "PlayerStoryboardSpec");
Rf.type = "PlayerStoryboardSpec";
var Ky = Rf, Lf = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.title = new _(e.title), this.stats = e.stats.map((t) => new _(t)), this.brief_stats = e.briefStats.map((t) => new _(t)), this.author = new Xl(Object.assign(Object.assign({}, e.ownerText), { navigationEndpoint: e.ownerEndpoint }), e.ownerBadges, null), this.description = new _(e.descriptionText), this.num_videos = new _(e.numVideosText), this.view_count = new _(e.viewCountText), this.can_share = e.shareData.canShare, this.can_delete = e.editableDetails.canDelete, this.is_editable = e.isEditable, this.privacy = e.privacy, this.save_button = y.parse(e.saveButton), this.shuffle_play_button = y.parse(e.shufflePlayButton), this.menu = y.parse(e.moreActionsMenu);
  }
};
l(Lf, "PlaylistHeader");
Lf.type = "PlaylistHeader";
var Yy = Lf, Df = class extends w {
  constructor(e) {
    super(), this.title = new _(e.playlistTitle), this.thumbnails = j.fromResponse(e.thumbnail), this.video_count = new _(e.playlistVideoCount), this.channel_name = new _(e.channelName), this.endpoint = new L(e.action);
  }
};
l(Df, "PlaylistInfoCardContent");
Df.type = "PlaylistInfoCardContent";
var ZS = Df, Bf = class extends w {
  constructor(e) {
    super(), this.title = e.title, this.description = e.description || null;
  }
};
l(Bf, "PlaylistMetadata");
Bf.type = "PlaylistMetadata";
var Xy = Bf, Of = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    super(), this.title = new _(e.title), this.thumbnail = j.fromResponse(e.thumbnail), this.endpoint = new L(e.navigationEndpoint), this.selected = e.selected, this.video_id = e.videoId, this.duration = {
      text: new _(e.lengthText).toString(),
      seconds: ji(new _(e.lengthText).toString())
    };
    const a = (t = new _(e.longBylineText).runs) === null || t === void 0 ? void 0 : t.find((c) => {
      var h, p;
      return (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id.startsWith("MPR");
    }), u = (i = new _(e.longBylineText).runs) === null || i === void 0 ? void 0 : i.filter((c) => {
      var h, p;
      return (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id.startsWith("UC");
    });
    this.author = new _(e.shortBylineText).toString(), a && (this.album = {
      id: (s = (n = a.endpoint) === null || n === void 0 ? void 0 : n.browse) === null || s === void 0 ? void 0 : s.id,
      name: a.text,
      year: (r = new _(e.longBylineText).runs) === null || r === void 0 ? void 0 : r.slice(-1)[0].text,
      endpoint: a.endpoint
    }), u && (this.artists = u.map((c) => {
      var h, p;
      return {
        name: c.text,
        channel_id: (p = (h = c.endpoint) === null || h === void 0 ? void 0 : h.browse) === null || p === void 0 ? void 0 : p.id,
        endpoint: c.endpoint
      };
    })), this.badges = y.parse(e.badges), this.menu = y.parse(e.menu), this.set_video_id = e.playlistSetVideoId;
  }
};
l(Of, "PlaylistPanelVideo");
Of.type = "PlaylistPanelVideo";
var Jy = Of, Ff = class extends w {
  constructor(e) {
    var t;
    super(), this.primary = y.parseItem(e.primaryRenderer), this.counterpart = ((t = e.counterpart) === null || t === void 0 ? void 0 : t.map((i) => y.parseItem(i.counterpartRenderer))) || [];
  }
};
l(Ff, "PlaylistPanelVideoWrapper");
Ff.type = "PlaylistPanelVideoWrapper";
var QS = Ff, Vf = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Vf, "PlaylistSidebar");
Vf.type = "PlaylistSidebar";
var Q1 = Vf, Uf = class extends w {
  constructor(e) {
    super(), this.stats = e.stats.map((t) => new _(t)), this.thumbnail_renderer = y.parse(e.thumbnailRenderer), this.title = new _(e.title), this.menu = e.menu && y.parse(e.menu), this.endpoint = new L(e.navigationEndpoint), this.description = new _(e.description);
  }
};
l(Uf, "PlaylistSidebarPrimaryInfo");
Uf.type = "PlaylistSidebarPrimaryInfo";
var Zy = Uf, jf = class extends w {
  constructor(e) {
    super(), this.owner = y.parse(e.videoOwner) || null, this.button = y.parse(e.button) || null;
  }
};
l(jf, "PlaylistSidebarSecondaryInfo");
jf.type = "PlaylistSidebarSecondaryInfo";
var Qy = jf, Hf = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.index = new _(e.index), this.title = new _(e.title), this.author = new Xl(e.shortBylineText), this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parse(e.thumbnailOverlays), this.set_video_id = e == null ? void 0 : e.setVideoId, this.endpoint = new L(e.navigationEndpoint), this.is_playable = e.isPlayable, this.menu = y.parse(e.menu), this.duration = {
      text: new _(e.lengthText).text,
      seconds: parseInt(e.lengthSeconds)
    };
  }
};
l(Hf, "PlaylistVideo");
Hf.type = "PlaylistVideo";
var e_ = Hf, Wf = class extends w {
  constructor(e) {
    super(), this.id = e.playlistId, this.is_editable = e.isEditable, this.can_reorder = e.canReorder, this.videos = y.parse(e.contents);
  }
};
l(Wf, "PlaylistVideoList");
Wf.type = "PlaylistVideoList";
var e8 = Wf, $f = class extends w {
  constructor(e) {
    super(), this.thumbnail = j.fromResponse(e.thumbnail);
  }
};
l($f, "PlaylistVideoThumbnail");
$f.type = "PlaylistVideoThumbnail";
var t_ = $f, Gf = class extends w {
  constructor(e) {
    super(), this.choices = e.choices.map((t) => ({
      text: new _(t.text).toString(),
      select_endpoint: t.selectServiceEndpoint ? new L(t.selectServiceEndpoint) : null,
      deselect_endpoint: t.deselectServiceEndpoint ? new L(t.deselectServiceEndpoint) : null,
      vote_ratio_if_selected: (t == null ? void 0 : t.voteRatioIfSelected) || null,
      vote_percentage_if_selected: new _(t.votePercentageIfSelected),
      vote_ratio_if_not_selected: (t == null ? void 0 : t.voteRatioIfSelected) || null,
      vote_percentage_if_not_selected: new _(t.votePercentageIfSelected),
      image: t.image ? j.fromResponse(t.image) : null
    })), e.type && (this.poll_type = e.type), e.totalVotes && (this.total_votes = new _(e.totalVotes)), e.liveChatPollId && (this.live_chat_poll_id = e.liveChatPollId);
  }
};
l(Gf, "Poll");
Gf.type = "Poll";
var t8 = Gf, qf = class extends vh {
  constructor(e) {
    super(e);
  }
};
l(qf, "Post");
qf.type = "Post";
var i_ = qf, zf = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(zf, "ProfileColumn");
zf.type = "ProfileColumn";
var ec = zf, Kf = class extends w {
  constructor(e) {
    super(), this.items = y.parseArray(e.items);
  }
  get contents() {
    return this.items;
  }
};
l(Kf, "ProfileColumnStats");
Kf.type = "ProfileColumnStats";
var n_ = Kf, Yf = class extends w {
  constructor(e) {
    super(), this.label = new _(e.label), this.value = new _(e.value);
  }
};
l(Yf, "ProfileColumnStatsEntry");
Yf.type = "ProfileColumnStatsEntry";
var i8 = Yf, Xf = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.thumbnails = j.fromResponse(e.thumbnail);
  }
};
l(Xf, "ProfileColumnUserInfo");
Xf.type = "ProfileColumnUserInfo";
var s_ = Xf, Jf = class extends w {
  constructor(e) {
    super(), this.id = e.videoId, this.title = new _(e.headline), this.thumbnails = j.fromResponse(e.thumbnail), this.views = new _(e.viewCountText), this.endpoint = new L(e.navigationEndpoint);
  }
};
l(Jf, "ReelItem");
Jf.type = "ReelItem";
var n8 = Jf, Zf = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.items = y.parse(e.items), this.endpoint = e.endpoint ? new L(e.endpoint) : null;
  }
  get contents() {
    return this.items;
  }
};
l(Zf, "ReelShelf");
Zf.type = "ReelShelf";
var r_ = Zf, Qf = class extends w {
  constructor(e) {
    super(), this.content = y.parse(e.content);
  }
};
l(Qf, "RelatedChipCloud");
Qf.type = "RelatedChipCloud";
var o_ = Qf, e0 = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.contents = y.parse(e.contents);
  }
};
l(e0, "RichGrid");
e0.type = "RichGrid";
var a_ = e0, t0 = class extends w {
  constructor(e) {
    super(), this.content = y.parse(e.content);
  }
};
l(t0, "RichItem");
t0.type = "RichItem";
var s8 = t0, i0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.icon_type = e.icon.iconType;
  }
};
l(i0, "RichListHeader");
i0.type = "RichListHeader";
var l_ = i0, n0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.content);
  }
};
l(n0, "RichSection");
n0.type = "RichSection";
var r8 = n0, s0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.contents = y.parse(e.contents), this.endpoint = e.endpoint ? new L(e.endpoint) : null;
  }
};
l(s0, "RichShelf");
s0.type = "RichShelf";
var u_ = s0, r0 = class extends w {
  constructor(e) {
    super(), this.endpoint = new L(e.endpoint), this.search_button = y.parse(e.searchButton), this.clear_button = y.parse(e.clearButton), this.placeholder_text = new _(e.placeholderText);
  }
};
l(r0, "SearchBox");
r0.type = "SearchBox";
var o8 = r0, o0 = class extends w {
  constructor(e) {
    super(), this.thumbnails = j.fromResponse(e.thumbnail), this.endpoint = new L(e.searchEndpoint), this.query = new _(e.query).toString();
  }
};
l(o0, "SearchRefinementCard");
o0.type = "SearchRefinementCard";
var c_ = o0, a0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(a0, "SearchSuggestionsSection");
a0.type = "SearchSuggestionsSection";
var h_ = a0, l0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.contents);
  }
};
l(l0, "SecondarySearchContainer");
l0.type = "SecondarySearchContainer";
var a8 = l0, u0 = class extends w {
  constructor(e) {
    super(), e.targetId && (this.target_id = e.targetId), this.contents = y.parse(e.contents), e.continuations && (e.continuations[0].nextContinuationData ? this.continuation = e.continuations[0].nextContinuationData.continuation : e.continuations[0].reloadContinuationData && (this.continuation = e.continuations[0].reloadContinuationData.continuation)), e.header && (this.header = y.parse(e.header));
  }
};
l(u0, "SectionList");
u0.type = "SectionList";
var dt = u0, c0 = class extends w {
  constructor(e) {
    super(), this.like_button = y.parseItem(e.likeButton, gt), this.dislike_button = y.parseItem(e.dislikeButton, gt);
  }
};
l(c0, "SegmentedLikeDislikeButton");
c0.type = "SegmentedLikeDislikeButton";
var Wr = c0, h0 = class extends w {
  constructor(e) {
    super(), e.title && (this.title = new _(e.title)), e.summary && (this.summary = new _(e.summary)), e.enableServiceEndpoint && (this.enable_endpoint = new L(e.enableServiceEndpoint)), e.disableServiceEndpoint && (this.disable_endpoint = new L(e.disableServiceEndpoint)), this.item_id = e.itemId;
  }
};
l(h0, "SettingBoolean");
h0.type = "SettingBoolean";
var l8 = h0, d0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.help_text = new _(e.helpText), this.enabled = e.enabled, this.disabled = e.disabled, this.id = e.id;
  }
};
l(d0, "SettingsCheckbox");
d0.type = "SettingsCheckbox";
var d_ = d0, p0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.subtitle = new _(e.subtitle), this.enabled = e.enabled, this.enable_endpoint = new L(e.enableServiceEndpoint), this.disable_endpoint = new L(e.disableServiceEndpoint);
  }
};
l(p0, "SettingsSwitch");
p0.type = "SettingsSwitch";
var f0 = p0, m0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), Reflect.has(e, "text") && (this.text = new _(e.text).toString()), Reflect.has(e, "options") && (this.options = y.parseArray(e.options, [
      f0,
      qc,
      ty,
      d_,
      Gg
    ]));
  }
};
l(m0, "SettingsOptions");
m0.type = "SettingsOptions";
var Ga = m0, v0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.items = y.parseArray(e.items, Zg);
  }
  get contents() {
    return this.items;
  }
};
l(v0, "SettingsSidebar");
v0.type = "SettingsSidebar";
var p_ = v0, g0 = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new _(e.title), e.endpoint && (this.endpoint = new L(e.endpoint)), this.content = y.parse(e.content) || null, !((t = e.icon) === null || t === void 0) && t.iconType && (this.icon_type = (i = e.icon) === null || i === void 0 ? void 0 : i.iconType), e.menu && (this.menu = y.parse(e.menu));
  }
};
l(g0, "Shelf");
g0.type = "Shelf";
var y0 = g0, _0 = class extends w {
  constructor(e) {
    super(), this.corrected_query = new _(e.correctedQuery), this.endpoint = new L(e.correctedQueryEndpoint), this.original_query_endpoint = new L(e.originalQueryEndpoint);
  }
};
l(_0, "ShowingResultsFor");
_0.type = "ShowingResultsFor";
var f_ = _0, b0 = class extends w {
  constructor(e) {
    super(), this.image = j.fromResponse(e.image), this.title = new _(e.title), this.display_domain = new _(e.displayDomain), this.show_link_icon = e.showLinkIcon, this.call_to_action = e.callToAction, this.endpoint = new L(e.command);
  }
};
l(b0, "SimpleCardContent");
b0.type = "SimpleCardContent";
var u8 = b0, w0 = class extends w {
  constructor(e) {
    super(), this.message = new _(e.message), this.prominent = e.prominent;
  }
};
l(w0, "SimpleCardTeaser");
w0.type = "SimpleCardTeaser";
var c8 = w0, S0 = class extends w {
  constructor(e) {
    super(), this.lines = e.lines.map((t) => new _(t)), this.style = e.layoutStyle;
  }
};
l(S0, "SimpleTextSection");
S0.type = "SimpleTextSection";
var h8 = S0, C0 = class extends w {
  constructor(e) {
    super(), this.action_text = new _(e.actionText), this.nav_text = new _(e.navigationText), this.details = new _(e.detailsText), this.icon_type = e.icon.iconType, this.endpoint = new L(e.navigationEndpoint);
  }
};
l(C0, "SingleActionEmergencySupport");
C0.type = "SingleActionEmergencySupport";
var d8 = C0, T0 = class extends w {
  constructor(e) {
    super(), this.title = e.title || "N/A", this.selected = e.selected || !1, this.endpoint = new L(e.endpoint), this.content = y.parseItem(e.content, [dt, gf, a_]);
  }
};
l(T0, "Tab");
T0.type = "Tab";
var Bt = T0, x0 = class extends w {
  constructor(e) {
    super(), this.tabs = y.parseArray(e.tabs, Bt);
  }
};
l(x0, "SingleColumnBrowseResults");
x0.type = "SingleColumnBrowseResults";
var ia = x0, E0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e);
  }
};
l(E0, "SingleColumnMusicWatchNextResults");
E0.type = "SingleColumnMusicWatchNextResults";
var xo = E0, A0 = class extends w {
  constructor(e) {
    super(), this.thumbnails = j.fromResponse(e.thumbnail), this.style = e.style;
  }
};
l(A0, "SingleHeroImage");
A0.type = "SingleHeroImage";
var p8 = A0, k0 = class extends w {
  constructor(e) {
    super(), this.sub_menu_items = e.subMenuItems.map((t) => {
      var i;
      return {
        title: t.title,
        selected: t.selected,
        continuation: (i = t.continuation) === null || i === void 0 ? void 0 : i.reloadContinuationData.continuation,
        subtitle: t.subtitle
      };
    }), this.label = e.accessibility.accessibilityData.label;
  }
};
l(k0, "SortFilterSubMenu");
k0.type = "SortFilterSubMenu";
var f8 = k0, I0 = class extends w {
  constructor(e) {
    super(), this.name = new _(e.name), this.is_selected = e.isSelected, this.endpoint = new L(e.navigationEndpoint);
  }
};
l(I0, "SubFeedOption");
I0.type = "SubFeedOption";
var m8 = I0, P0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.options = y.parse(e.options);
  }
};
l(P0, "SubFeedSelector");
P0.type = "SubFeedSelector";
var v8 = P0, M0 = class extends w {
  constructor(e) {
    super(), this.states = e.states.map((t) => ({
      id: t.stateId,
      next_id: t.nextStateId,
      state: y.parse(t.state)
    })), this.current_state_id = e.currentStateId, this.target_id = e.targetId;
  }
};
l(M0, "SubscriptionNotificationToggleButton");
M0.type = "SubscriptionNotificationToggleButton";
var m_ = M0, N0 = class extends w {
  constructor(e) {
    var t, i;
    super(), this.title = new _(e.buttonText), this.subscribed = e.subscribed, this.enabled = e.enabled, this.item_type = e.type, this.channel_id = e.channelId, this.show_preferences = e.showPreferences, this.subscribed_text = new _(e.subscribedButtonText), this.unsubscribed_text = new _(e.unsubscribedButtonText), this.notification_preference_button = y.parseItem(e.notificationPreferenceButton, m_), this.endpoint = new L(((t = e.serviceEndpoints) === null || t === void 0 ? void 0 : t[0]) || ((i = e.onSubscribeEndpoints) === null || i === void 0 ? void 0 : i[0]));
  }
};
l(N0, "SubscribeButton");
N0.type = "SubscribeButton";
var v_ = N0, R0 = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e);
  }
};
l(R0, "Tabbed");
R0.type = "Tabbed";
var Eo = R0, L0 = class extends w {
  constructor(e) {
    super(), this.tabs = y.parseArray(e.tabs, Bt);
  }
};
l(L0, "TabbedSearchResults");
L0.type = "TabbedSearchResults";
var g_ = L0, D0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.style = e.style;
  }
};
l(D0, "TextHeader");
D0.type = "TextHeader";
var g8 = D0, B0 = class extends w {
  constructor(e) {
    super(), this.icon_type = e.icon.iconType;
  }
};
l(B0, "ThumbnailOverlayBottomPanel");
B0.type = "ThumbnailOverlayBottomPanel";
var y8 = B0, O0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString();
  }
};
l(O0, "ThumbnailOverlayEndorsement");
O0.type = "ThumbnailOverlayEndorsement";
var _8 = O0, F0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text), this.icon_type = e.icon.iconType;
  }
};
l(F0, "ThumbnailOverlayHoverText");
F0.type = "ThumbnailOverlayHoverText";
var b8 = F0, V0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString(), this.icon_type = e.icon.iconType;
  }
};
l(V0, "ThumbnailOverlayInlineUnplayable");
V0.type = "ThumbnailOverlayInlineUnplayable";
var w8 = V0, U0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text);
  }
};
l(U0, "ThumbnailOverlayLoadingPreview");
U0.type = "ThumbnailOverlayLoadingPreview";
var S8 = U0, j0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString();
  }
};
l(j0, "ThumbnailOverlayNowPlaying");
j0.type = "ThumbnailOverlayNowPlaying";
var C8 = j0, H0 = class extends w {
  constructor(e) {
    super(), this.hack = e.hack;
  }
};
l(H0, "ThumbnailOverlayPinking");
H0.type = "ThumbnailOverlayPinking";
var T8 = H0, W0 = class extends w {
  constructor(e) {
    super(), this.text = e.texts.map((t) => new _(t))[0].toString();
  }
};
l(W0, "ThumbnailOverlayPlaybackStatus");
W0.type = "ThumbnailOverlayPlaybackStatus";
var x8 = W0, $0 = class extends w {
  constructor(e) {
    super(), this.percent_duration_watched = e.percentDurationWatched;
  }
};
l($0, "ThumbnailOverlayResumePlayback");
$0.type = "ThumbnailOverlayResumePlayback";
var E8 = $0, G0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text), this.icon_type = e.icon.iconType;
  }
};
l(G0, "ThumbnailOverlaySidePanel");
G0.type = "ThumbnailOverlaySidePanel";
var A8 = G0, q0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.text).toString();
  }
};
l(q0, "ThumbnailOverlayTimeStatus");
q0.type = "ThumbnailOverlayTimeStatus";
var k8 = q0, z0 = class extends w {
  constructor(e) {
    super(), this.is_toggled = e.isToggled || null, this.icon_type = {
      toggled: e.toggledIcon.iconType,
      untoggled: e.untoggledIcon.iconType
    }, this.tooltip = {
      toggled: e.toggledTooltip,
      untoggled: e.untoggledTooltip
    }, this.toggled_endpoint = new L(e.toggledServiceEndpoint), this.untoggled_endpoint = new L(e.untoggledServiceEndpoint);
  }
};
l(z0, "ThumbnailOverlayToggleButton");
z0.type = "ThumbnailOverlayToggleButton";
var I8 = z0, K0 = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title);
  }
};
l(K0, "TitleAndButtonListHeader");
K0.type = "TitleAndButtonListHeader";
var P8 = K0, Y0 = class extends w {
  constructor(e) {
    super(), this.text = new _(e.defaultText), this.toggled_text = new _(e.toggledText), this.icon_type = e.defaultIcon.iconType, this.toggled_icon_type = e.toggledIcon.iconType, this.endpoint = new L(e.toggledServiceEndpoint);
  }
};
l(Y0, "ToggleMenuServiceItem");
Y0.type = "ToggleMenuServiceItem";
var M8 = Y0, X0 = class extends w {
  constructor(e) {
    super(), this.promo_config = {
      promo_id: e.promoConfig.promoId,
      impression_endpoints: e.promoConfig.impressionEndpoints.map((t) => new L(t)),
      accept: new L(e.promoConfig.acceptCommand),
      dismiss: new L(e.promoConfig.dismissCommand)
    }, this.target_id = e.targetId, this.details = new _(e.detailsText), this.suggested_position = e.suggestedPosition.type, this.dismiss_stratedy = e.dismissStrategy.type, this.dwell_time_ms = parseInt(e.dwellTimeMs);
  }
};
l(X0, "Tooltip");
X0.type = "Tooltip";
var N8 = X0, J0 = class extends w {
  constructor(e) {
    super(), this.tabs = y.parse(e.tabs), this.secondary_contents = y.parse(e.secondaryContents);
  }
};
l(J0, "TwoColumnBrowseResults");
J0.type = "TwoColumnBrowseResults";
var na = J0, Z0 = class extends w {
  constructor(e) {
    super(), this.primary_contents = y.parse(e.primaryContents), this.secondary_contents = y.parse(e.secondaryContents);
  }
};
l(Z0, "TwoColumnSearchResults");
Z0.type = "TwoColumnSearchResults";
var Q0 = Z0, em = class extends w {
  constructor(e) {
    var t, i;
    super(), this.results = y.parse((t = e.results) === null || t === void 0 ? void 0 : t.results.contents, !0), this.secondary_results = y.parse((i = e.secondaryResults) === null || i === void 0 ? void 0 : i.secondaryResults.results, !0), this.conversation_bar = y.parse(e == null ? void 0 : e.conversationBar);
  }
};
l(em, "TwoColumnWatchNextResults");
em.type = "TwoColumnWatchNextResults";
var y_ = em, tm = class extends w {
  constructor(e) {
    super(), this.header = y.parse(e.header), this.call_to_action = y.parse(e.callToAction), this.sections = y.parse(e.sections);
  }
};
l(tm, "UniversalWatchCard");
tm.type = "UniversalWatchCard";
var __ = tm, im = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items), this.collapsed_item_count = e.collapsedItemCount, this.collapsed_state_button_text = new _(e.collapsedStateButtonText);
  }
  get contents() {
    return this.items;
  }
};
l(im, "VerticalList");
im.type = "VerticalList";
var R8 = im, nm = class extends w {
  constructor(e) {
    super(), this.items = y.parse(e.items), this.contents = this.items, this.view_all_text = new _(e.viewAllText), this.view_all_endpoint = new L(e.viewAllEndpoint);
  }
};
l(nm, "VerticalWatchCardList");
nm.type = "VerticalWatchCardList";
var L8 = nm, sm = class extends w {
  constructor(e) {
    var t, i, n, s;
    super();
    const r = ((t = e.thumbnailOverlays.find((u) => u.thumbnailOverlayTimeStatusRenderer)) === null || t === void 0 ? void 0 : t.thumbnailOverlayTimeStatusRenderer.text) || "N/A";
    this.id = e.videoId, this.title = new _(e.title), this.description_snippet = e.descriptionSnippet ? new _(e.descriptionSnippet) : null, this.snippets = ((i = e.detailedMetadataSnippets) === null || i === void 0 ? void 0 : i.map((u) => ({
      text: new _(u.snippetText),
      hover_text: new _(u.snippetHoverText)
    }))) || [], this.thumbnails = j.fromResponse(e.thumbnail), this.thumbnail_overlays = y.parseArray(e.thumbnailOverlays), this.rich_thumbnail = e.richThumbnail ? y.parse(e.richThumbnail) : null, this.author = new Ft(e.ownerText, e.ownerBadges, (s = (n = e.channelThumbnailSupportedRenderers) === null || n === void 0 ? void 0 : n.channelThumbnailWithLinkRenderer) === null || s === void 0 ? void 0 : s.thumbnail), this.endpoint = new L(e.navigationEndpoint), this.published = new _(e.publishedTimeText), this.view_count = new _(e.viewCountText), this.short_view_count = new _(e.shortViewCountText);
    const a = e.upcomingEventData && Number(`${e.upcomingEventData.startTime}000`);
    a && (this.upcoming = new Date(a)), this.duration = {
      text: e.lengthText ? new _(e.lengthText).text : new _(r).text,
      seconds: ji(e.lengthText ? new _(e.lengthText).text : new _(r).text)
    }, this.show_action_menu = e.showActionMenu, this.is_watched = e.isWatched || !1, this.menu = y.parseItem(e.menu, rn);
  }
  get description() {
    var e;
    return this.snippets.length > 0 ? this.snippets.map((t) => t.text.toString()).join("") : ((e = this.description_snippet) === null || e === void 0 ? void 0 : e.toString()) || "";
  }
  get is_upcoming() {
    return this.upcoming && this.upcoming > new Date();
  }
  get best_thumbnail() {
    return this.thumbnails[0];
  }
};
l(sm, "Video");
sm.type = "Video";
var b_ = sm, rm = class extends w {
  constructor(e) {
    super(), this.title = new _(e.videoTitle), this.channel_name = new _(e.channelName), this.view_count = new _(e.viewCountText), this.video_thumbnails = j.fromResponse(e.videoThumbnail), this.duration = new _(e.lengthString), this.endpoint = new L(e.action);
  }
};
l(rm, "VideoInfoCardContent");
rm.type = "VideoInfoCardContent";
var D8 = rm, om = class extends w {
  constructor(e) {
    super(), this.subscription_button = e.subscriptionButton || null, this.subscriber_count = new _(e.subscriberCountText), this.author = new Ft(Object.assign(Object.assign({}, e.title), { navigationEndpoint: e.navigationEndpoint }), e.badges, e.thumbnail);
  }
};
l(om, "VideoOwner");
om.type = "VideoOwner";
var w_ = om, am = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.super_title_link = new _(e.superTitleLink), this.view_count = new _(e.viewCount.videoViewCountRenderer.viewCount), this.short_view_count = new _(e.viewCount.videoViewCountRenderer.shortViewCount), this.published = new _(e.dateText), this.menu = y.parseItem(e.videoActions, rn);
  }
};
l(am, "VideoPrimaryInfo");
am.type = "VideoPrimaryInfo";
var S_ = am, lm = class extends w {
  constructor(e) {
    super(), this.owner = y.parseItem(e.owner), this.description = new _(e.description), this.subscribe_button = y.parseItem(e.subscribeButton, [v_, at]), this.metadata = y.parseItem(e.metadataRowContainer, ky), this.show_more_text = e.showMoreText, this.show_less_text = e.showLessText, this.default_expanded = e.defaultExpanded, this.description_collapsed_lines = e.descriptionCollapsedLines;
  }
};
l(lm, "VideoSecondaryInfo");
lm.type = "VideoSecondaryInfo";
var C_ = lm, um = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.subtitle = new _(e.subtitle), this.duration = {
      text: new _(e.lengthText).toString(),
      seconds: ji(e.lengthText.simpleText)
    }, this.style = e.style;
  }
};
l(um, "WatchCardCompactVideo");
um.type = "WatchCardCompactVideo";
var T_ = um, cm = class extends w {
  constructor(e) {
    super(), this.endpoint = new L(e.navigationEndpoint), this.call_to_action_button = y.parse(e.callToActionButton), this.hero_image = y.parse(e.heroImage), this.label = e.accessibility.accessibilityData.label;
  }
};
l(cm, "WatchCardHeroVideo");
cm.type = "WatchCardHeroVideo";
var x_ = cm, hm = class extends w {
  constructor(e) {
    super(), this.title = new _(e.title), this.title_endpoint = new L(e.titleNavigationEndpoint), this.subtitle = new _(e.subtitle), this.author = new Ft(e, e.titleBadge ? [e.titleBadge] : null, e.avatar), this.author.name = this.title.toString(), this.style = e.style;
  }
};
l(hm, "WatchCardRichHeader");
hm.type = "WatchCardRichHeader";
var B8 = hm, dm = class extends w {
  constructor(e) {
    super(), this.lists = y.parse(e.lists);
  }
};
l(dm, "WatchCardSectionSequence");
dm.type = "WatchCardSectionSequence";
var E_ = dm, pm = class extends na {
  constructor(e) {
    super(e);
  }
};
l(pm, "WatchNextTabbedResults");
pm.type = "WatchNextTabbedResults";
var Ao = pm, O8 = {
  AccountChannel: Ig,
  AccountItemSection: Mg,
  AccountItemSectionHeader: Pg,
  AccountSectionList: Ng,
  AppendContinuationItemsAction: Rg,
  OpenPopupAction: y7,
  AnalyticsMainAppKeyMetrics: _7,
  AnalyticsRoot: b7,
  AnalyticsShortsCarouselCard: w7,
  AnalyticsVideo: Dg,
  AnalyticsVodCarouselCard: S7,
  CtaGoToCreatorStudio: C7,
  DataModelSection: Lg,
  StatRow: T7,
  AudioOnlyPlayability: Bg,
  AutomixPreviewVideo: dh,
  BackstageImage: x7,
  BackstagePost: vh,
  BackstagePostThread: A7,
  BrowseFeedActions: Vg,
  BrowserMediaSession: k7,
  Button: at,
  C4TabbedHeader: Ug,
  CallToActionButton: I7,
  Card: P7,
  CardCollection: jg,
  Channel: Hg,
  ChannelAboutFullMetadata: Wg,
  ChannelFeaturedContent: M7,
  ChannelHeaderLinks: N7,
  ChannelMetadata: $g,
  ChannelMobileHeader: R7,
  ChannelOptions: Gg,
  ChannelThumbnailWithLink: L7,
  ChannelVideoPlayer: D7,
  ChildVideo: B7,
  ChipCloud: Oh,
  ChipCloudChip: jo,
  CollaboratorInfoCardContent: O7,
  CollageHeroImage: F7,
  AuthorCommentBadge: qg,
  Comment: $a,
  CommentActionButtons: Zn,
  CommentReplies: H7,
  CommentReplyDialog: zg,
  CommentsEntryPointHeader: Kg,
  CommentsHeader: Yg,
  CommentSimplebox: Xg,
  CommentThread: Jg,
  CompactLink: Zg,
  CompactMix: W7,
  CompactPlaylist: $7,
  CompactVideo: ey,
  ConfirmDialog: G7,
  ContinuationItem: sn,
  CopyLink: ty,
  CreatePlaylistDialog: Tg,
  DidYouMean: iy,
  DownloadButton: q7,
  Dropdown: qc,
  DropdownItem: Uo,
  Element: od,
  EmergencyOnebox: K7,
  Endscreen: ny,
  EndscreenElement: Y7,
  EndScreenPlaylist: sy,
  EndScreenVideo: ry,
  ExpandableTab: X7,
  ExpandedShelfContents: J7,
  FeedFilterChipBar: X1,
  FeedTabbedHeader: Z7,
  Grid: oy,
  GridChannel: ay,
  GridHeader: Q7,
  GridPlaylist: ly,
  GridVideo: uy,
  HighlightsCarousel: J1,
  HistorySuggestion: eS,
  HorizontalCardList: hy,
  HorizontalList: tS,
  IconLink: dy,
  ItemSection: Hi,
  ItemSectionHeader: py,
  ItemSectionTab: fy,
  ItemSectionTabbedHeader: my,
  LikeButton: iS,
  LiveChat: vy,
  AddBannerToLiveChatCommand: nS,
  AddChatItemAction: gy,
  AddLiveChatTickerItemAction: sS,
  LiveChatAutoModMessage: rS,
  LiveChatBanner: oS,
  LiveChatBannerHeader: aS,
  LiveChatBannerPoll: lS,
  LiveChatMembershipItem: uS,
  LiveChatPaidMessage: cS,
  LiveChatPaidSticker: hS,
  LiveChatPlaceholderItem: dS,
  LiveChatProductItem: pS,
  LiveChatTextMessage: yy,
  LiveChatTickerPaidMessageItem: fS,
  LiveChatTickerSponsorItem: mS,
  LiveChatViewerEngagementMessage: vS,
  PollHeader: gS,
  LiveChatActionPanel: yS,
  MarkChatItemAsDeletedAction: _S,
  MarkChatItemsByAuthorAsDeletedAction: bS,
  RemoveBannerForLiveChatCommand: wS,
  ReplaceChatItemAction: SS,
  ReplayChatItemAction: CS,
  ShowLiveChatActionPanelAction: TS,
  ShowLiveChatTooltipCommand: xS,
  UpdateDateTextAction: _y,
  UpdateDescriptionAction: by,
  UpdateLiveChatPollAction: ES,
  UpdateTitleAction: wy,
  UpdateToggleButtonTextAction: Sy,
  UpdateViewershipAction: Cy,
  LiveChatAuthorBadge: ur,
  LiveChatDialog: AS,
  LiveChatHeader: kS,
  LiveChatItemList: IS,
  LiveChatMessageInput: PS,
  LiveChatParticipant: MS,
  LiveChatParticipantsList: NS,
  Menu: rn,
  MenuNavigationItem: RS,
  MenuServiceItem: LS,
  MenuServiceItemDownload: DS,
  MultiPageMenu: BS,
  MultiPageMenuNotificationSection: OS,
  MusicMenuItemDivider: Ty,
  MusicMultiSelectMenu: xy,
  MusicMultiSelectMenuItem: Ap,
  SimpleMenuHeader: Ey,
  MerchandiseItem: FS,
  MerchandiseShelf: Ay,
  Message: Qo,
  MetadataBadge: gs,
  MetadataRow: VS,
  MetadataRowContainer: ky,
  MetadataRowHeader: US,
  MetadataScreen: jS,
  MicroformatData: ea,
  Mix: HS,
  Movie: WS,
  MovingThumbnail: $S,
  MusicCarouselShelf: cr,
  MusicCarouselShelfBasicHeader: Fy,
  MusicDescriptionShelf: kl,
  MusicDetailHeader: Il,
  MusicDownloadStateBadge: GS,
  MusicEditablePlaylistDetailHeader: Vy,
  MusicElementHeader: Z1,
  MusicHeader: lf,
  MusicImmersiveHeader: Uy,
  MusicInlineBadge: qS,
  MusicItemThumbnailOverlay: Wp,
  MusicLargeCardItemCarousel: zS,
  MusicNavigationButton: Qp,
  MusicPlayButton: Iy,
  MusicPlaylistShelf: Pl,
  MusicQueue: gf,
  MusicResponsiveListItem: ta,
  MusicResponsiveListItemFixedColumn: My,
  MusicResponsiveListItemFlexColumn: Py,
  MusicShelf: cs,
  MusicSideAlignedItem: KS,
  MusicSortFilterButton: YS,
  MusicThumbnail: Xp,
  MusicTwoRowItem: Gp,
  MusicVisualHeader: jy,
  NavigationEndpoint: L,
  Notification: XS,
  PageIntroduction: Hy,
  PlayerAnnotationsExpanded: Wy,
  PlayerCaptionsTracklist: $y,
  PlayerErrorMessage: JS,
  PlayerLiveStoryboardSpec: Gy,
  PlayerMicroformat: Hr,
  PlayerOverlay: Nf,
  PlayerOverlayAutoplay: zy,
  PlayerStoryboardSpec: Ky,
  Playlist: Zo,
  PlaylistHeader: Yy,
  PlaylistInfoCardContent: ZS,
  PlaylistMetadata: Xy,
  PlaylistPanel: ys,
  PlaylistPanelVideo: Jy,
  PlaylistPanelVideoWrapper: QS,
  PlaylistSidebar: Q1,
  PlaylistSidebarPrimaryInfo: Zy,
  PlaylistSidebarSecondaryInfo: Qy,
  PlaylistVideo: e_,
  PlaylistVideoList: e8,
  PlaylistVideoThumbnail: t_,
  Poll: t8,
  Post: i_,
  ProfileColumn: ec,
  ProfileColumnStats: n_,
  ProfileColumnStatsEntry: i8,
  ProfileColumnUserInfo: s_,
  ReelItem: n8,
  ReelShelf: r_,
  RelatedChipCloud: o_,
  RichGrid: a_,
  RichItem: s8,
  RichListHeader: l_,
  RichSection: r8,
  RichShelf: u_,
  SearchBox: o8,
  SearchRefinementCard: c_,
  SearchSuggestion: cy,
  SearchSuggestionsSection: h_,
  SecondarySearchContainer: a8,
  SectionList: dt,
  SegmentedLikeDislikeButton: Wr,
  SettingBoolean: l8,
  SettingsCheckbox: d_,
  SettingsOptions: Ga,
  SettingsSidebar: p_,
  SettingsSwitch: f0,
  Shelf: y0,
  ShowingResultsFor: f_,
  SimpleCardContent: u8,
  SimpleCardTeaser: c8,
  SimpleTextSection: h8,
  SingleActionEmergencySupport: d8,
  SingleColumnBrowseResults: ia,
  SingleColumnMusicWatchNextResults: xo,
  SingleHeroImage: p8,
  SortFilterSubMenu: f8,
  SubFeedOption: m8,
  SubFeedSelector: v8,
  SubscribeButton: v_,
  SubscriptionNotificationToggleButton: m_,
  Tab: Bt,
  Tabbed: Eo,
  TabbedSearchResults: g_,
  TextHeader: g8,
  ThumbnailOverlayBottomPanel: y8,
  ThumbnailOverlayEndorsement: _8,
  ThumbnailOverlayHoverText: b8,
  ThumbnailOverlayInlineUnplayable: w8,
  ThumbnailOverlayLoadingPreview: S8,
  ThumbnailOverlayNowPlaying: C8,
  ThumbnailOverlayPinking: T8,
  ThumbnailOverlayPlaybackStatus: x8,
  ThumbnailOverlayResumePlayback: E8,
  ThumbnailOverlaySidePanel: A8,
  ThumbnailOverlayTimeStatus: k8,
  ThumbnailOverlayToggleButton: I8,
  TitleAndButtonListHeader: P8,
  ToggleButton: gt,
  ToggleMenuServiceItem: M8,
  Tooltip: N8,
  TwoColumnBrowseResults: na,
  TwoColumnSearchResults: Q0,
  TwoColumnWatchNextResults: y_,
  UniversalWatchCard: __,
  VerticalList: R8,
  VerticalWatchCardList: L8,
  Video: b_,
  VideoInfoCardContent: D8,
  VideoOwner: w_,
  VideoPrimaryInfo: S_,
  VideoSecondaryInfo: C_,
  WatchCardCompactVideo: T_,
  WatchCardHeroVideo: x_,
  WatchCardRichHeader: B8,
  WatchCardSectionSequence: E_,
  WatchNextEndScreen: qy,
  WatchNextTabbedResults: Ao
};
function A_(e) {
  const t = O8[e];
  if (!t) {
    const i = new Error(`Module not found: ${e}`);
    throw i.code = "MODULE_NOT_FOUND", i;
  }
  return t;
}
l(A_, "GetParserByName");
var I5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, et = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ge, mn, Us, js, k_, Hs, fm = class extends w {
  constructor(e) {
    super(), this.contents = y.parse(e.continuationItems, !0);
  }
};
l(fm, "AppendContinuationItemsAction");
fm.type = "appendContinuationItemsAction";
var Ql = class extends w {
  constructor(e) {
    super(), this.target_id = e.targetId, this.contents = y.parse(e.continuationItems, !0);
  }
};
l(Ql, "ReloadContinuationItemsCommand");
Ql.type = "reloadContinuationItemsCommand";
var _s = class extends w {
  constructor(e) {
    var t;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
};
l(_s, "SectionListContinuation");
_s.type = "sectionListContinuation";
var eu = class extends w {
  constructor(e) {
    var t;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
};
l(eu, "MusicPlaylistShelfContinuation");
eu.type = "musicPlaylistShelfContinuation";
var sa = class extends w {
  constructor(e) {
    var t, i, n, s;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData) === null || i === void 0 ? void 0 : i.continuation) || ((s = (n = e.continuations) === null || n === void 0 ? void 0 : n[0].reloadContinuationData) === null || s === void 0 ? void 0 : s.continuation) || null;
  }
};
l(sa, "MusicShelfContinuation");
sa.type = "musicShelfContinuation";
var tu = class extends w {
  constructor(e) {
    var t;
    super(), this.items = y.parse(e.items, !0), this.continuation = ((t = e.continuations) === null || t === void 0 ? void 0 : t[0].nextContinuationData.continuation) || null;
  }
  get contents() {
    return this.items;
  }
};
l(tu, "GridContinuation");
tu.type = "gridContinuation";
var iu = class extends w {
  constructor(e) {
    var t, i, n, s, r, a;
    super(), this.contents = y.parse(e.contents, !0), this.continuation = ((n = (i = (t = e.continuations) === null || t === void 0 ? void 0 : t[0]) === null || i === void 0 ? void 0 : i.nextContinuationData) === null || n === void 0 ? void 0 : n.continuation) || ((a = (r = (s = e.continuations) === null || s === void 0 ? void 0 : s[0]) === null || r === void 0 ? void 0 : r.nextRadioContinuationData) === null || a === void 0 ? void 0 : a.continuation) || null;
  }
};
l(iu, "PlaylistPanelContinuation");
iu.type = "playlistPanelContinuation";
var nu = class extends w {
  constructor(e) {
    super(), this.timeout_ms = e.timeoutMs || e.timeUntilLastMessageMsec, this.token = e.continuation;
  }
};
l(nu, "TimedContinuation");
nu.type = "timedContinuationData";
var su = class extends w {
  constructor(e) {
    var t, i, n, s, r;
    super(), this.actions = y.parse((t = e.actions) === null || t === void 0 ? void 0 : t.map((a) => (delete a.clickTrackingParams, a)), !0) || zt([]), this.action_panel = y.parseItem(e.actionPanel), this.item_list = y.parseItem(e.itemList), this.header = y.parseItem(e.header), this.participants_list = y.parseItem(e.participantsList), this.popout_message = y.parseItem(e.popoutMessage), this.emojis = ((i = e.emojis) === null || i === void 0 ? void 0 : i.map((a) => ({
      emoji_id: a.emojiId,
      shortcuts: a.shortcuts,
      search_terms: a.searchTerms,
      image: a.image,
      is_custom_emoji: a.isCustomEmoji
    }))) || null, this.continuation = new nu(((n = e.continuations) === null || n === void 0 ? void 0 : n[0].timedContinuationData) || ((s = e.continuations) === null || s === void 0 ? void 0 : s[0].invalidationContinuationData) || ((r = e.continuations) === null || r === void 0 ? void 0 : r[0].liveChatReplayContinuationData)), this.viewer_name = e.viewerName;
  }
};
l(su, "LiveChatContinuation");
su.type = "liveChatContinuation";
var y = class {
  static parseResponse(e) {
    var t, i, n, s, r;
    et(this, Ge, "m", js).call(this);
    const a = y.parse(e.contents), u = et(this, Ge, "m", Hs).call(this);
    et(this, Ge, "m", Us).call(this), et(this, Ge, "m", js).call(this);
    const c = e.onResponseReceivedActions ? y.parseRR(e.onResponseReceivedActions) : null, h = et(this, Ge, "m", Hs).call(this);
    et(this, Ge, "m", Us).call(this), et(this, Ge, "m", js).call(this);
    const p = e.onResponseReceivedEndpoints ? y.parseRR(e.onResponseReceivedEndpoints) : null, m = et(this, Ge, "m", Hs).call(this);
    et(this, Ge, "m", Us).call(this), et(this, Ge, "m", js).call(this);
    const b = e.onResponseReceivedCommands ? y.parseRR(e.onResponseReceivedCommands) : null, C = et(this, Ge, "m", Hs).call(this);
    et(this, Ge, "m", Us).call(this), et(this, Ge, "m", js).call(this);
    const k = e.actions ? y.parseActions(e.actions) : null, D = et(this, Ge, "m", Hs).call(this);
    return et(this, Ge, "m", Us).call(this), this.applyMutations(u, (i = (t = e.frameworkUpdates) === null || t === void 0 ? void 0 : t.entityBatchUpdate) === null || i === void 0 ? void 0 : i.mutations), {
      actions: k,
      actions_memo: D,
      contents: a,
      contents_memo: u,
      on_response_received_actions: c,
      on_response_received_actions_memo: h,
      on_response_received_endpoints: p,
      on_response_received_endpoints_memo: m,
      on_response_received_commands: b,
      on_response_received_commands_memo: C,
      continuation: e.continuation ? y.parseC(e.continuation) : null,
      continuation_contents: e.continuationContents ? y.parseLC(e.continuationContents) : null,
      metadata: y.parse(e.metadata),
      header: y.parse(e.header),
      microformat: e.microformat ? y.parseItem(e.microformat) : null,
      sidebar: y.parseItem(e.sidebar),
      overlay: y.parseItem(e.overlay),
      refinements: e.refinements || null,
      estimated_results: e.estimatedResults ? parseInt(e.estimatedResults) : null,
      player_overlays: y.parse(e.playerOverlays),
      playback_tracking: e.playbackTracking ? {
        videostats_watchtime_url: e.playbackTracking.videostatsWatchtimeUrl.baseUrl,
        videostats_playback_url: e.playbackTracking.videostatsPlaybackUrl.baseUrl
      } : null,
      playability_status: e.playabilityStatus ? {
        status: e.playabilityStatus.status,
        error_screen: y.parseItem(e.playabilityStatus.errorScreen),
        audio_only_playablility: y.parseItem(e.playabilityStatus.audioOnlyPlayability, Bg),
        embeddable: !!e.playabilityStatus.playableInEmbed || !1,
        reason: ((n = e.playabilityStatus) === null || n === void 0 ? void 0 : n.reason) || ""
      } : void 0,
      streaming_data: e.streamingData ? {
        expires: new Date(Date.now() + parseInt(e.streamingData.expiresInSeconds) * 1e3),
        formats: y.parseFormats(e.streamingData.formats),
        adaptive_formats: y.parseFormats(e.streamingData.adaptiveFormats),
        dash_manifest_url: ((s = e.streamingData) === null || s === void 0 ? void 0 : s.dashManifestUrl) || null,
        dls_manifest_url: ((r = e.streamingData) === null || r === void 0 ? void 0 : r.dashManifestUrl) || null
      } : void 0,
      current_video_endpoint: e.currentVideoEndpoint ? new L(e.currentVideoEndpoint) : null,
      captions: y.parseItem(e.captions, $y),
      video_details: e.videoDetails ? new m7(e.videoDetails) : void 0,
      annotations: y.parseArray(e.annotations, Wy),
      storyboards: y.parseItem(e.storyboards, [Ky, Gy]),
      endscreen: y.parseItem(e.endscreen, ny),
      cards: y.parseItem(e.cards, jg)
    };
  }
  static parseC(e) {
    if (e.timedContinuationData)
      return new nu(e.timedContinuationData);
  }
  static parseLC(e) {
    if (e.sectionListContinuation)
      return new _s(e.sectionListContinuation);
    if (e.liveChatContinuation)
      return new su(e.liveChatContinuation);
    if (e.musicPlaylistShelfContinuation)
      return new eu(e.musicPlaylistShelfContinuation);
    if (e.musicShelfContinuation)
      return new sa(e.musicShelfContinuation);
    if (e.gridContinuation)
      return new tu(e.gridContinuation);
    if (e.playlistPanelContinuation)
      return new iu(e.playlistPanelContinuation);
  }
  static parseRR(e) {
    return zt(e.map((t) => {
      if (t.reloadContinuationItemsCommand)
        return new Ql(t.reloadContinuationItemsCommand);
      if (t.appendContinuationItemsAction)
        return new fm(t.appendContinuationItemsAction);
    }).filter((t) => t));
  }
  static parseActions(e) {
    return Array.isArray(e) ? y.parse(e.map((t) => (delete t.clickTrackingParams, t))) : new rr(y.parseItem(e));
  }
  static parseFormats(e) {
    return (e == null ? void 0 : e.map((t) => new f7(t))) || [];
  }
  static parseItem(e, t) {
    if (!e)
      return null;
    const i = Object.keys(e), n = this.sanitizeClassName(i[0]);
    if (!this.shouldIgnore(n))
      try {
        const s = A_(n);
        if (t) {
          if (Array.isArray(t)) {
            if (!t.some((a) => a.type === s.type))
              throw new nn(`Type mismatch, got ${n} but expected one of ${t.map((a) => a.type).join(", ")}`);
          } else if (s.type !== t.type)
            throw new nn(`Type mismatch, got ${n} but expected ${t.type}`);
        }
        const r = new s(e[i[0]]);
        return et(this, Ge, "m", k_).call(this, n, r), r;
      } catch (s) {
        return this.formatError({ classname: n, classdata: e[i[0]], err: s }), null;
      }
    return null;
  }
  static parseArray(e, t) {
    if (Array.isArray(e)) {
      const i = [];
      for (const n of e) {
        const s = this.parseItem(n, t);
        s && i.push(s);
      }
      return zt(i);
    } else if (!e)
      return zt([]);
    throw new nn("Expected array but got a single item");
  }
  static parse(e, t, i) {
    if (!e)
      return null;
    if (Array.isArray(e)) {
      const n = [];
      for (const r of e) {
        const a = this.parseItem(r, i);
        a && n.push(a);
      }
      const s = zt(n);
      return t ? s : new rr(zt(n));
    } else if (t)
      throw new nn("Expected array but got a single item");
    return new rr(this.parseItem(e, i));
  }
  static applyMutations(e, t) {
    var i;
    const n = e.getType(Ap);
    if (n.length > 0 && !t)
      console.warn(new x(`Mutation data required for processing MusicMultiSelectMenuItems, but none found.
This is a bug, please report it at ${Fr.bugs.url}`));
    else {
      const s = [];
      for (const r of n) {
        const a = t.find((c) => {
          var h, p;
          return ((p = (h = c.payload) === null || h === void 0 ? void 0 : h.musicFormBooleanChoice) === null || p === void 0 ? void 0 : p.id) === r.form_item_entity_key;
        }), u = a == null ? void 0 : a.payload.musicFormBooleanChoice;
        (u == null ? void 0 : u.selected) !== void 0 && (u == null ? void 0 : u.opaqueToken) ? (r.selected = u.selected, !((i = r.endpoint) === null || i === void 0) && i.browse && (r.endpoint.browse.form_data = {
          selectedValues: [u.opaqueToken]
        })) : s.push(`'${r.title}'`);
      }
      s.length > 0 && console.warn(new x(`Mutation data missing or invalid for ${s.length} out of ${n.length} MusicMultiSelectMenuItems. The titles of the failed items are: ${s.join(", ")}.
This is a bug, please report it at ${Fr.bugs.url}`));
    }
  }
  static formatError({ classname: e, classdata: t, err: i }) {
    if (i.code == "MODULE_NOT_FOUND")
      return console.warn(new x(`${e} not found!
This is a bug, please report it at ${Fr.bugs.url}`, t));
    console.warn(new x(`Something went wrong at ${e}!
This is a bug, please report it at ${Fr.bugs.url}`, { stack: i.stack }));
  }
  static sanitizeClassName(e) {
    return (e.charAt(0).toUpperCase() + e.slice(1)).replace(/Renderer|Model/g, "").replace(/Radio/g, "Mix").trim();
  }
  static shouldIgnore(e) {
    return this.ignore_list.has(e);
  }
};
l(y, "Parser");
Ge = y, Us = /* @__PURE__ */ l(function() {
  I5(y, Ge, null, "f", mn);
}, "_Parser_clearMemo"), js = /* @__PURE__ */ l(function() {
  I5(y, Ge, new Cg(), "f", mn);
}, "_Parser_createMemo"), k_ = /* @__PURE__ */ l(function(t, i) {
  if (!et(y, Ge, "f", mn))
    return;
  const n = et(y, Ge, "f", mn).get(t);
  if (!n)
    return et(y, Ge, "f", mn).set(t, [i]);
  n.push(i);
}, "_Parser_addToMemo"), Hs = /* @__PURE__ */ l(function() {
  if (!et(y, Ge, "f", mn))
    throw new Error("Parser#getMemo() called before Parser#createMemo()");
  return et(y, Ge, "f", mn);
}, "_Parser_getMemo");
mn = { value: null };
y.ignore_list = /* @__PURE__ */ new Set([
  "DisplayAd",
  "SearchPyv",
  "MealbarPromo",
  "BackgroundPromo",
  "PromotedSparklesWeb",
  "RunAttestationCommand",
  "CompactPromotedVideo",
  "StatementBanner"
]);
var st = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, F8 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ie = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ze, xe, lt, tc, I_ = class {
  constructor(e) {
    Ze.add(this), xe.set(this, void 0), F8(this, xe, e, "f");
  }
  get session() {
    return ie(this, xe, "f");
  }
  browse(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (ie(this, Ze, "m", tc).call(this, e) && !ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      t.params && (i.params = t.params), t.is_ctoken ? i.continuation = e : i.browseId = e, t.form_data && (i.formData = t.form_data), t.client && (i.client = t.client);
      const n = yield ie(this, xe, "f").http.fetch("/browse", {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  engage(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in && !t.hasOwnProperty("text"))
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "like/like":
        case "like/dislike":
        case "like/removelike":
          if (!Xi(t, "video_id"))
            throw new di("Arguments lacks video_id");
          i.target = {}, i.target.videoId = t.video_id, t.params && (i.params = t.params);
          break;
        case "subscription/subscribe":
        case "subscription/unsubscribe":
          if (!Xi(t, "channel_id"))
            throw new di("Arguments lacks channel_id");
          i.channelIds = [t.channel_id], i.params = e === "subscription/subscribe" ? "EgIIAhgA" : "CgIIAhgA";
          break;
        case "comment/create_comment":
          if (i.commentText = t.text, !Xi(t, "video_id"))
            throw new di("Arguments lacks video_id");
          i.createCommentParams = Rt.encodeCommentParams(t.video_id);
          break;
        case "comment/create_comment_reply":
          if (!Xi(t, "comment_id", "video_id", "text"))
            throw new di("Arguments lacks comment_id, video_id or text");
          i.createReplyParams = Rt.encodeCommentReplyParams(t.comment_id, t.video_id), i.commentText = t.text;
          break;
        case "comment/perform_comment_action":
          const s = (() => {
            switch (t.comment_action) {
              case "like":
                return Rt.encodeCommentActionParams(5, t);
              case "dislike":
                return Rt.encodeCommentActionParams(4, t);
              case "translate":
                return Rt.encodeCommentActionParams(22, t);
            }
          })();
          i.actions = [s];
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  account(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = { client: t.client };
      switch (e) {
        case "account/set_setting":
          i.newValue = {
            boolValue: t.new_value
          }, i.settingItemId = t.setting_item_id;
          break;
        case "account/accounts_list":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  search(e = {}) {
    var t;
    return st(this, void 0, void 0, function* () {
      const i = { client: e.client };
      e.query && (i.query = e.query), e.ctoken && (i.continuation = e.ctoken), e.params && (i.params = e.params), e.filters && (e.client == "YTMUSIC" && ((t = e.filters) === null || t === void 0 ? void 0 : t.type) && e.filters.type !== "all" ? i.params = Rt.encodeMusicSearchFilters(e.filters) : i.params = Rt.encodeSearchFilters(e.filters));
      const n = yield ie(this, xe, "f").http.fetch("/search", {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  searchSound(e) {
    return st(this, void 0, void 0, function* () {
      const t = {
        query: e.query,
        client: "ANDROID"
      }, i = yield ie(this, xe, "f").http.fetch("/sfv/search", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, i);
    });
  }
  channel(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = { client: t.client || "ANDROID" };
      switch (e) {
        case "channel/edit_name":
          i.givenName = t.new_name;
          break;
        case "channel/edit_description":
          i.description = t.new_description;
          break;
        case "channel/get_profile_editor":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  playlist(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "playlist/create":
          i.title = t.title, i.videoIds = t.ids;
          break;
        case "playlist/delete":
          i.playlistId = t.playlist_id;
          break;
        case "browse/edit_playlist":
          if (!Xi(t, "ids"))
            throw new di("Arguments lacks ids");
          i.playlistId = t.playlist_id, i.actions = t.ids.map((s) => {
            switch (t.action) {
              case "ACTION_ADD_VIDEO":
                return {
                  action: t.action,
                  addedVideoId: s
                };
              case "ACTION_REMOVE_VIDEO":
                return {
                  action: t.action,
                  setVideoId: s
                };
            }
          });
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  notifications(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "modify_channel_preference":
          if (!Xi(t, "channel_id", "pref"))
            throw new di("Arguments lacks channel_id or pref");
          const s = {
            PERSONALIZED: 1,
            ALL: 2,
            NONE: 3
          };
          if (!Object.keys(s).includes(t.pref.toUpperCase()))
            throw new x("Invalid preference type", t.pref);
          i.params = Rt.encodeNotificationPref(t.channel_id, s[t.pref.toUpperCase()]);
          break;
        case "get_notification_menu":
          i.notificationsMenuRequestType = "NOTIFICATIONS_MENU_REQUEST_TYPE_INBOX", t.ctoken && (i.ctoken = t.ctoken);
          break;
        case "record_interactions":
          i.serializedRecordNotificationInteractionsRequest = t.params;
          break;
        case "get_unseen_count":
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/notification/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  livechat(e, t = {}) {
    return st(this, void 0, void 0, function* () {
      const i = { client: t.client };
      switch (e) {
        case "live_chat/get_live_chat":
        case "live_chat/get_live_chat_replay":
          i.continuation = t.ctoken;
          break;
        case "live_chat/send_message":
          if (!Xi(t, "channel_id", "video_id", "text"))
            throw new di("Arguments lacks channel_id, video_id or text");
          i.params = Rt.encodeMessageParams(t.channel_id, t.video_id), i.clientMessageId = lr(), i.richMessage = {
            textSegments: [{
              text: t.text
            }]
          };
          break;
        case "live_chat/get_item_context_menu":
          break;
        case "live_chat/moderate":
          i.params = t.params;
          break;
        case "updated_metadata":
          i.videoId = t.video_id, t.ctoken && (i.continuation = t.ctoken);
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  thumbnails(e) {
    return st(this, void 0, void 0, function* () {
      const t = {
        client: "ANDROID",
        videoId: e.video_id
      }, i = yield ie(this, xe, "f").http.fetch("/thumbnails", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, i);
    });
  }
  geo(e, t) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = {
        input: t.input,
        client: "ANDROID"
      }, n = yield ie(this, xe, "f").http.fetch(`/geo/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  flag(e, t) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const i = {};
      switch (e) {
        case "flag/flag":
          i.action = t.action;
          break;
        case "flag/get_form":
          i.params = t.params;
          break;
        default:
          throw new x("Action not implemented", e);
      }
      const n = yield ie(this, xe, "f").http.fetch(`/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  music(e, t) {
    return st(this, void 0, void 0, function* () {
      const i = {
        input: t.input || "",
        client: "YTMUSIC"
      }, n = yield ie(this, xe, "f").http.fetch(`/music/${e}`, {
        method: "POST",
        body: JSON.stringify(i),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, n);
    });
  }
  next(e = {}) {
    return st(this, void 0, void 0, function* () {
      const t = { client: e.client };
      e.ctoken && (t.continuation = e.ctoken), e.video_id && (t.videoId = e.video_id), e.playlist_id && (t.playlistId = e.playlist_id), e.params && (t.params = e.params);
      const i = yield ie(this, xe, "f").http.fetch("/next", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, i);
    });
  }
  getVideoInfo(e, t, i, n) {
    return st(this, void 0, void 0, function* () {
      const s = {
        playbackContext: {
          contentPlaybackContext: {
            vis: 0,
            splay: !1,
            referer: "https://www.youtube.com",
            currentUrl: `/watch?v=${e}`,
            autonavState: "STATE_OFF",
            signatureTimestamp: ie(this, xe, "f").player.sts,
            autoCaptionsDefaultOn: !1,
            html5Preference: "HTML5_PREF_WANTS",
            lactMilliseconds: "-1"
          }
        },
        attestationRequest: {
          omitBotguardData: !0
        },
        videoId: e
      };
      i && (s.client = i), t && (s.cpn = t), n && (s.playlistId = n);
      const r = yield ie(this, xe, "f").http.fetch("/player", {
        method: "POST",
        body: JSON.stringify(s),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, r);
    });
  }
  getUserMentionSuggestions(e) {
    return st(this, void 0, void 0, function* () {
      if (!ie(this, xe, "f").logged_in)
        throw new x("You are not signed in");
      const t = {
        input: e.input,
        client: "ANDROID"
      }, i = yield ie(this, xe, "f").http.fetch("/get_user_mention_suggestions", {
        method: "POST",
        body: JSON.stringify(t),
        headers: {
          "Content-Type": "application/json"
        }
      });
      return ie(this, Ze, "m", lt).call(this, i);
    });
  }
  stats(e, t, i) {
    return st(this, void 0, void 0, function* () {
      const n = new URL(e);
      n.searchParams.set("ver", "2"), n.searchParams.set("c", t.client_name.toLowerCase()), n.searchParams.set("cbrver", t.client_version), n.searchParams.set("cver", t.client_version);
      for (const r of Object.keys(i))
        n.searchParams.set(r, i[r]);
      return yield ie(this, xe, "f").http.fetch(n);
    });
  }
  execute(e, t) {
    return st(this, void 0, void 0, function* () {
      let i;
      if (t.protobuf)
        i = t.serialized_data;
      else {
        if (i = Object.assign({}, t), Reflect.has(i, "browseId") && ie(this, Ze, "m", tc).call(this, i.browseId) && !ie(this, xe, "f").logged_in)
          throw new x("You are not signed in");
        Reflect.has(i, "override_endpoint") && delete i.override_endpoint, Reflect.has(i, "parse") && delete i.parse, Reflect.has(i, "request") && delete i.request, Reflect.has(i, "clientActions") && delete i.clientActions, Reflect.has(i, "settingItemIdForClient") && delete i.settingItemIdForClient, Reflect.has(i, "action") && (i.actions = [i.action], delete i.action), Reflect.has(i, "boolValue") && (i.newValue = { boolValue: i.boolValue }, delete i.boolValue), Reflect.has(i, "token") && (i.continuation = i.token, delete i.token), (i == null ? void 0 : i.client) === "YTMUSIC" && (i.isAudioOnly = !0);
      }
      const n = Reflect.has(t, "override_endpoint") ? t.override_endpoint : e, s = yield ie(this, xe, "f").http.fetch(n, {
        method: "POST",
        body: t.protobuf ? i : JSON.stringify(i),
        headers: {
          "Content-Type": t.protobuf ? "application/x-protobuf" : "application/json"
        }
      });
      return t.parse ? y.parseResponse(yield s.json()) : ie(this, Ze, "m", lt).call(this, s);
    });
  }
};
l(I_, "Actions");
xe = /* @__PURE__ */ new WeakMap(), Ze = /* @__PURE__ */ new WeakSet(), lt = /* @__PURE__ */ l(function(t) {
  return st(this, void 0, void 0, function* () {
    return {
      success: t.ok,
      status_code: t.status,
      data: JSON.parse(yield t.text())
    };
  });
}, "_Actions_wrap"), tc = /* @__PURE__ */ l(function(t) {
  return [
    "FElibrary",
    "FEhistory",
    "FEsubscriptions",
    "FEmusic_listening_review",
    "SPaccount_notifications",
    "SPaccount_privacy",
    "SPtime_watched"
  ].includes(t);
}, "_Actions_needsLogin");
var V8 = I_, U8 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, $r = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ta, Ws;
if (!Reflect.has(globalThis, "CustomEvent")) {
  class e extends Event {
    constructor(i, n) {
      var s;
      super(i, n), Ta.set(this, void 0), U8(this, Ta, (s = n == null ? void 0 : n.detail) !== null && s !== void 0 ? s : null, "f");
    }
    get detail() {
      return $r(this, Ta, "f");
    }
  }
  l(e, "CustomEvent"), Ta = /* @__PURE__ */ new WeakMap(), Reflect.set(globalThis, "CustomEvent", e);
}
var mm = class extends EventTarget {
  constructor() {
    super(), Ws.set(this, /* @__PURE__ */ new Map());
  }
  emit(e, ...t) {
    const i = new CustomEvent(e, { detail: t });
    this.dispatchEvent(i);
  }
  on(e, t) {
    const i = /* @__PURE__ */ l((n) => {
      n instanceof CustomEvent ? t(...n.detail) : t(n);
    }, "wrapper");
    $r(this, Ws, "f").set(t, i), this.addEventListener(e, i);
  }
  once(e, t) {
    const i = /* @__PURE__ */ l((n) => {
      n instanceof CustomEvent ? t(...n.detail) : t(n), this.off(e, t);
    }, "wrapper");
    $r(this, Ws, "f").set(t, i), this.addEventListener(e, i);
  }
  off(e, t) {
    const i = $r(this, Ws, "f").get(t);
    i && (this.removeEventListener(e, i), $r(this, Ws, "f").delete(t));
  }
};
l(mm, "EventEmitterLike");
Ws = /* @__PURE__ */ new WeakMap();
var j8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, x1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, It = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, ic, ci, $s, Gr, P_, M_ = class {
  constructor(e, t, i) {
    ic.add(this), ci.set(this, void 0), $s.set(this, void 0), Gr.set(this, void 0), x1(this, ci, e, "f"), x1(this, $s, t, "f"), x1(this, Gr, i || globalThis.fetch, "f");
  }
  get fetch_function() {
    return It(this, Gr, "f");
  }
  fetch(e, t) {
    return j8(this, void 0, void 0, function* () {
      const i = pe.URLS.API.PRODUCTION_1 + It(this, ci, "f").api_version, n = (t == null ? void 0 : t.baseURL) || i, s = typeof e == "string" ? !n.endsWith("/") && !e.startsWith("/") ? new URL(`${n}/${e}`) : new URL(n + e) : e instanceof URL ? e : new URL(e.url, n), r = (t == null ? void 0 : t.headers) || (e instanceof Request ? e.headers : new Headers()) || new Headers(), a = (t == null ? void 0 : t.body) || (e instanceof Request ? e.body : void 0), u = new Headers(r);
      u.set("Accept", "*/*"), u.set("Accept-Language", `en-${It(this, ci, "f").context.client.gl || "US"}`), u.set("x-goog-visitor-id", It(this, ci, "f").context.client.visitorData || ""), u.set("x-origin", s.origin), u.set("x-youtube-client-version", It(this, ci, "f").context.client.clientVersion || ""), Dc() && (u.set("User-Agent", Jo("desktop")), u.set("origin", s.origin)), s.searchParams.set("key", It(this, ci, "f").key), s.searchParams.set("prettyPrint", "false"), s.searchParams.set("alt", "json");
      const c = u.get("Content-Type");
      let h = a;
      const p = n === i || n === pe.URLS.YT_UPLOAD;
      if (c === "application/json" && p && typeof a == "string") {
        const C = JSON.parse(a), k = Object.assign(Object.assign({}, C), {
          context: JSON.parse(JSON.stringify(It(this, ci, "f").context))
        });
        It(this, ic, "m", P_).call(this, k.context, k.client), u.set("x-youtube-client-version", k.context.client.clientVersion), delete k.client, h = JSON.stringify(k);
      }
      if (It(this, ci, "f").logged_in && p) {
        const C = It(this, ci, "f").oauth;
        if (C.validateCredentials() && (yield C.refreshIfRequired(), u.set("authorization", `Bearer ${C.credentials.access_token}`), s.searchParams.delete("key")), It(this, $s, "f")) {
          const k = Ri(It(this, $s, "f"), "PAPISID=", ";");
          k && u.set("authorization", yield Lc(k)), u.set("cookie", It(this, $s, "f"));
        }
      }
      const m = new Request(s, e instanceof Request ? e : t), b = yield It(this, Gr, "f").call(this, m, {
        body: h,
        headers: u,
        credentials: "include",
        redirect: e instanceof Request ? e.redirect : (t == null ? void 0 : t.redirect) || "follow"
      });
      if (b.ok)
        return b;
      throw new x(`Request to ${b.url} failed with status ${b.status}`, yield b.text());
    });
  }
};
l(M_, "HTTPClient");
ci = /* @__PURE__ */ new WeakMap(), $s = /* @__PURE__ */ new WeakMap(), Gr = /* @__PURE__ */ new WeakMap(), ic = /* @__PURE__ */ new WeakSet(), P_ = /* @__PURE__ */ l(function(t, i) {
  switch (i) {
    case "YTMUSIC":
      t.client.clientVersion = pe.CLIENTS.YTMUSIC.VERSION, t.client.clientName = pe.CLIENTS.YTMUSIC.NAME;
      break;
    case "ANDROID":
      t.client.clientVersion = pe.CLIENTS.ANDROID.VERSION, t.client.clientFormFactor = "SMALL_FORM_FACTOR", t.client.clientName = pe.CLIENTS.ANDROID.NAME, t.client.androidSdkVersion = pe.CLIENTS.ANDROID.SDK_VERSION;
      break;
    case "YTMUSIC_ANDROID":
      t.client.clientVersion = pe.CLIENTS.YTMUSIC_ANDROID.VERSION, t.client.clientFormFactor = "SMALL_FORM_FACTOR", t.client.clientName = pe.CLIENTS.YTMUSIC_ANDROID.NAME, t.client.androidSdkVersion = pe.CLIENTS.ANDROID.SDK_VERSION;
      break;
    case "TV_EMBEDDED":
      t.client.clientVersion = pe.CLIENTS.TV_EMBEDDED.VERSION, t.client.clientName = pe.CLIENTS.TV_EMBEDDED.NAME, t.client.clientScreen = "EMBED", t.thirdParty = { embedUrl: pe.URLS.YT_BASE };
      break;
  }
}, "_HTTPClient_adjustContext");
var Li = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, An = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, oe = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Qi, Qn, it, ze, qa, N_, nc, P5, R_, E1, L_ = class {
  constructor(e) {
    Qi.add(this), Qn.set(this, void 0), it.set(this, void 0), ze.set(this, void 0), qa.set(this, 5), An(this, it, e, "f");
  }
  init(e) {
    return Li(this, void 0, void 0, function* () {
      An(this, ze, e, "f"), this.validateCredentials() ? this.has_access_token_expired || oe(this, it, "f").emit("auth", {
        credentials: oe(this, ze, "f"),
        status: "SUCCESS"
      }) : (yield oe(this, Qi, "m", N_).call(this)) || (yield oe(this, Qi, "m", nc).call(this));
    });
  }
  cacheCredentials() {
    var e;
    return Li(this, void 0, void 0, function* () {
      const i = new TextEncoder().encode(JSON.stringify(oe(this, ze, "f")));
      yield (e = oe(this, it, "f").cache) === null || e === void 0 ? void 0 : e.set("youtubei_oauth_credentials", i.buffer);
    });
  }
  removeCache() {
    var e;
    return Li(this, void 0, void 0, function* () {
      yield (e = oe(this, it, "f").cache) === null || e === void 0 ? void 0 : e.remove("youtubei_oauth_credentials");
    });
  }
  refreshIfRequired() {
    return Li(this, void 0, void 0, function* () {
      this.has_access_token_expired && (yield oe(this, Qi, "m", R_).call(this));
    });
  }
  revokeCredentials() {
    return Li(this, void 0, void 0, function* () {
      if (!!oe(this, ze, "f"))
        return yield this.removeCache(), oe(this, it, "f").http.fetch_function(new URL(`/o/oauth2/revoke?token=${encodeURIComponent(oe(this, ze, "f").access_token)}`, pe.URLS.YT_BASE), {
          method: "post"
        });
    });
  }
  get credentials() {
    return oe(this, ze, "f");
  }
  get has_access_token_expired() {
    const e = oe(this, ze, "f") ? new Date(oe(this, ze, "f").expires).getTime() : -1 / 0;
    return new Date().getTime() > e;
  }
  validateCredentials() {
    return oe(this, ze, "f") && Reflect.has(oe(this, ze, "f"), "access_token") && Reflect.has(oe(this, ze, "f"), "refresh_token") && Reflect.has(oe(this, ze, "f"), "expires") || !1;
  }
};
l(L_, "OAuth");
Qn = /* @__PURE__ */ new WeakMap(), it = /* @__PURE__ */ new WeakMap(), ze = /* @__PURE__ */ new WeakMap(), qa = /* @__PURE__ */ new WeakMap(), Qi = /* @__PURE__ */ new WeakSet(), N_ = /* @__PURE__ */ l(function() {
  var t;
  return Li(this, void 0, void 0, function* () {
    const i = yield (t = oe(this, it, "f").cache) === null || t === void 0 ? void 0 : t.get("youtubei_oauth_credentials");
    if (!i)
      return !1;
    const n = new TextDecoder(), s = JSON.parse(n.decode(i));
    return An(this, ze, {
      access_token: s.access_token,
      refresh_token: s.refresh_token,
      expires: new Date(s.expires)
    }, "f"), oe(this, it, "f").emit("auth", {
      credentials: oe(this, ze, "f"),
      status: "SUCCESS"
    }), !0;
  });
}, "_OAuth_loadCachedCredentials"), nc = /* @__PURE__ */ l(function() {
  return Li(this, void 0, void 0, function* () {
    An(this, Qn, yield oe(this, Qi, "m", E1).call(this), "f");
    const t = {
      client_id: oe(this, Qn, "f").client_id,
      scope: pe.OAUTH.SCOPE,
      device_id: lr(),
      model_name: pe.OAUTH.MODEL_NAME
    }, n = yield (yield oe(this, it, "f").http.fetch_function(new URL("/o/oauth2/device/code", pe.URLS.YT_BASE), {
      body: JSON.stringify(t),
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      }
    })).json();
    oe(this, it, "f").emit("auth-pending", n), An(this, qa, n.interval, "f"), oe(this, Qi, "m", P5).call(this, n.device_code);
  });
}, "_OAuth_getUserCode"), P5 = /* @__PURE__ */ l(function(t) {
  const i = setInterval(() => Li(this, void 0, void 0, function* () {
    const n = Object.assign(Object.assign({}, oe(this, Qn, "f")), { code: t, grant_type: pe.OAUTH.GRANT_TYPE });
    try {
      const r = yield (yield oe(this, it, "f").http.fetch_function(new URL("/o/oauth2/token", pe.URLS.YT_BASE), {
        body: JSON.stringify(n),
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        }
      })).json();
      if (r.error) {
        switch (r.error) {
          case "access_denied":
            oe(this, it, "f").emit("auth-error", new ss("Access was denied.", { status: "ACCESS_DENIED" }));
            break;
          case "expired_token":
            oe(this, it, "f").emit("auth-error", new ss("The device code has expired, restarting auth flow.", { status: "DEVICE_CODE_EXPIRED" })), clearInterval(i), oe(this, Qi, "m", nc).call(this);
            break;
          default:
            break;
        }
        return;
      }
      const a = new Date(new Date().getTime() + r.expires_in * 1e3);
      An(this, ze, {
        access_token: r.access_token,
        refresh_token: r.refresh_token,
        expires: a
      }, "f"), oe(this, it, "f").emit("auth", {
        credentials: oe(this, ze, "f"),
        status: "SUCCESS"
      }), clearInterval(i);
    } catch (s) {
      return clearInterval(i), oe(this, it, "f").emit("auth-error", new ss("Could not obtain user code.", { status: "FAILED", error: s }));
    }
  }), oe(this, qa, "f") * 1e3);
}, "_OAuth_startPolling"), R_ = /* @__PURE__ */ l(function() {
  return Li(this, void 0, void 0, function* () {
    if (!oe(this, ze, "f"))
      return;
    An(this, Qn, yield oe(this, Qi, "m", E1).call(this), "f");
    const t = Object.assign(Object.assign({}, oe(this, Qn, "f")), { refresh_token: oe(this, ze, "f").refresh_token, grant_type: "refresh_token" }), n = yield (yield oe(this, it, "f").http.fetch_function(new URL("/o/oauth2/token", pe.URLS.YT_BASE), {
      body: JSON.stringify(t),
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      }
    })).json(), s = new Date(new Date().getTime() + n.expires_in * 1e3);
    An(this, ze, {
      access_token: n.access_token,
      refresh_token: n.refresh_token || oe(this, ze, "f").refresh_token,
      expires: s
    }, "f"), oe(this, it, "f").emit("update-credentials", {
      credentials: oe(this, ze, "f"),
      status: "SUCCESS"
    });
  });
}, "_OAuth_refreshAccessToken"), E1 = /* @__PURE__ */ l(function() {
  var t;
  return Li(this, void 0, void 0, function* () {
    const n = yield (yield oe(this, it, "f").http.fetch_function(new URL("/tv", pe.URLS.YT_BASE), { headers: pe.OAUTH.HEADERS })).text(), s = (t = pe.OAUTH.REGEX.AUTH_SCRIPT.exec(n)) === null || t === void 0 ? void 0 : t[1];
    if (!s)
      throw new ss("Could not obtain script url.", { status: "FAILED" });
    const a = (yield (yield oe(this, it, "f").http.fetch(s, { baseURL: pe.URLS.YT_BASE })).text()).replace(/\n/g, "").match(pe.OAUTH.REGEX.CLIENT_IDENTITY), u = a == null ? void 0 : a.groups;
    if (!u)
      throw new ss("Could not obtain client identity.", { status: "FAILED" });
    return u;
  });
}, "_OAuth_getClientIdentity");
var H8 = L_, Ir = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, xa = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, $n = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, za, Ka, es, Ya, sc;
(function(e) {
  e.WEB = "WEB", e.MUSIC = "WEB_REMIX", e.ANDROID = "ANDROID", e.ANDROID_MUSIC = "ANDROID_MUSIC";
})(sc || (sc = {}));
var Ml = class extends mm {
  constructor(e, t, i, n, s, r, a) {
    super(), za.set(this, void 0), Ka.set(this, void 0), es.set(this, void 0), Ya.set(this, void 0), xa(this, es, e, "f"), xa(this, Ka, t, "f"), xa(this, za, i, "f"), xa(this, Ya, n, "f"), this.http = new M_(this, s, r), this.actions = new V8(this), this.oauth = new H8(this), this.logged_in = !!s, this.cache = a;
  }
  on(e, t) {
    super.on(e, t);
  }
  once(e, t) {
    super.once(e, t);
  }
  static create(e = {}) {
    return Ir(this, void 0, void 0, function* () {
      const { context: t, api_key: i, api_version: n } = yield Ml.getSessionData(e.lang, e.device_category, e.client_type, e.timezone, e.fetch);
      return new Ml(t, i, n, yield En.create(e.cache, e.fetch), e.cookie, e.fetch, e.cache);
    });
  }
  static getSessionData(e = "en-US", t = "desktop", i = sc.WEB, n = Intl.DateTimeFormat().resolvedOptions().timeZone, s = globalThis.fetch) {
    return Ir(this, void 0, void 0, function* () {
      const r = new URL("/sw.js_data", pe.URLS.YT_BASE), a = yield s(r, {
        headers: {
          "accept-language": e,
          "user-agent": Jo("desktop"),
          accept: "*/*",
          referer: "https://www.youtube.com/sw.js",
          cookie: `PREF=tz=${n.replace("/", ".")}`
        }
      });
      if (!a.ok)
        throw new Nc(`Failed to get session data: ${a.status}`);
      const u = yield a.text(), h = JSON.parse(u.replace(/^\)\]\}'/, ""))[0][2], p = `v${h[0][0][6]}`, [[m], b] = h, C = vs(11), k = Math.floor(Date.now() / 1e3), D = Rt.encodeVisitorData(C, k);
      return { context: {
        client: {
          hl: m[0],
          gl: m[2],
          remoteHost: m[3],
          visitorData: D,
          userAgent: m[14],
          clientName: i,
          clientVersion: m[16],
          osName: m[17],
          osVersion: m[18],
          platform: t.toUpperCase(),
          clientFormFactor: "UNKNOWN_FORM_FACTOR",
          userInterfaceTheme: "USER_INTERFACE_THEME_LIGHT",
          timeZone: m[79],
          browserName: m[86],
          browserVersion: m[87],
          originalUrl: pe.URLS.API.BASE,
          deviceMake: m[11],
          deviceModel: m[12],
          utcOffsetMinutes: new Date().getTimezoneOffset()
        },
        user: {
          lockedSafetyMode: !1
        },
        request: {
          useSsl: !0
        }
      }, api_key: b, api_version: p };
    });
  }
  signIn(e) {
    return Ir(this, void 0, void 0, function* () {
      return new Promise((t, i) => Ir(this, void 0, void 0, function* () {
        const n = /* @__PURE__ */ l((s) => i(s), "error_handler");
        this.once("auth", (s) => {
          this.off("auth-error", n), s.status === "SUCCESS" && (this.logged_in = !0, t()), i(s);
        }), this.once("auth-error", n);
        try {
          yield this.oauth.init(e), this.oauth.validateCredentials() && (yield this.oauth.refreshIfRequired(), this.logged_in = !0, t());
        } catch (s) {
          i(s);
        }
      }));
    });
  }
  signOut() {
    return Ir(this, void 0, void 0, function* () {
      if (!this.logged_in)
        throw new x("You are not signed in");
      const e = yield this.oauth.revokeCredentials();
      return this.logged_in = !1, e;
    });
  }
  get key() {
    return $n(this, Ka, "f");
  }
  get api_version() {
    return $n(this, za, "f");
  }
  get client_version() {
    return $n(this, es, "f").client.clientVersion;
  }
  get client_name() {
    return $n(this, es, "f").client.clientName;
  }
  get context() {
    return $n(this, es, "f");
  }
  get player() {
    return $n(this, Ya, "f");
  }
  get lang() {
    return $n(this, es, "f").client.hl;
  }
};
l(Ml, "Session");
za = /* @__PURE__ */ new WeakMap(), Ka = /* @__PURE__ */ new WeakMap(), es = /* @__PURE__ */ new WeakMap(), Ya = /* @__PURE__ */ new WeakMap();
var M5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Pr = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Me = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ct, vn, qr, Mt, ko = class {
  constructor(e, t, i = !1) {
    Ct.set(this, void 0), vn.set(this, void 0), qr.set(this, void 0), Mt.set(this, void 0), t.on_response_received_actions || t.on_response_received_endpoints || i ? Pr(this, Ct, t, "f") : Pr(this, Ct, y.parseResponse(t), "f");
    const n = Me(this, Ct, "f").on_response_received_commands ? Me(this, Ct, "f").on_response_received_commands_memo : Me(this, Ct, "f").on_response_received_endpoints ? Me(this, Ct, "f").on_response_received_endpoints_memo : Me(this, Ct, "f").contents ? Me(this, Ct, "f").contents_memo : Me(this, Ct, "f").on_response_received_actions ? Me(this, Ct, "f").on_response_received_actions_memo : void 0;
    if (!n)
      throw new x("No memo found in feed");
    Pr(this, Mt, n, "f"), Pr(this, qr, e, "f");
  }
  static getVideosFromMemo(e) {
    return e.getType([
      b_,
      uy,
      ey,
      e_,
      Jy,
      T_
    ]);
  }
  static getPlaylistsFromMemo(e) {
    return e.getType([Zo, ly]);
  }
  get videos() {
    return ko.getVideosFromMemo(Me(this, Mt, "f"));
  }
  get posts() {
    return Me(this, Mt, "f").getType([vh, i_]);
  }
  get channels() {
    return Me(this, Mt, "f").getType([Hg, ay]);
  }
  get playlists() {
    return ko.getPlaylistsFromMemo(Me(this, Mt, "f"));
  }
  get memo() {
    return Me(this, Mt, "f");
  }
  get contents() {
    var e, t, i, n;
    const s = (t = (e = Me(this, Mt, "f").getType(Bt)) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.content, r = (i = Me(this, Mt, "f").getType(Ql)) === null || i === void 0 ? void 0 : i[0], a = (n = Me(this, Mt, "f").getType(Rg)) === null || n === void 0 ? void 0 : n[0];
    return s || r || a;
  }
  get shelves() {
    return Me(this, Mt, "f").getType([y0, u_, r_]);
  }
  getShelf(e) {
    return this.shelves.find((t) => t.title.toString() === e);
  }
  get secondary_contents() {
    if (!Me(this, Ct, "f").contents.is_node)
      return;
    const e = Me(this, Ct, "f").contents.item();
    if (!!e.is(na, Q0))
      return e.secondary_contents;
  }
  get actions() {
    return Me(this, qr, "f");
  }
  get page() {
    return Me(this, Ct, "f");
  }
  get has_continuation() {
    return (Me(this, Mt, "f").get("ContinuationItem") || []).length > 0;
  }
  getContinuationData() {
    return M5(this, void 0, void 0, function* () {
      if (Me(this, vn, "f")) {
        if (Me(this, vn, "f").length > 1)
          throw new x("There are too many continuations, you'll need to find the correct one yourself in this.page");
        if (Me(this, vn, "f").length === 0)
          throw new x("There are no continuations");
        return yield Me(this, vn, "f")[0].endpoint.call(Me(this, qr, "f"), void 0, !0);
      }
      if (Pr(this, vn, Me(this, Mt, "f").getType(sn), "f"), Me(this, vn, "f"))
        return this.getContinuationData();
    });
  }
  getContinuation() {
    return M5(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new ko(this.actions, e, !0);
    });
  }
};
l(ko, "Feed");
Ct = /* @__PURE__ */ new WeakMap(), vn = /* @__PURE__ */ new WeakMap(), qr = /* @__PURE__ */ new WeakMap(), Mt = /* @__PURE__ */ new WeakMap();
var On = ko, N5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Nl = class extends On {
  constructor(e, t, i = !1) {
    var n, s, r, a, u, c, h;
    super(e, t, i);
    const p = ((s = (n = this.page.contents) === null || n === void 0 ? void 0 : n.item().as(Q0).primary_contents) === null || s === void 0 ? void 0 : s.item().as(dt).contents.array()) || ((r = this.page.on_response_received_commands) === null || r === void 0 ? void 0 : r[0].contents), m = (a = this.page.contents) === null || a === void 0 ? void 0 : a.item().key("secondary_contents"), b = m != null && m.isParsed() ? m.parsed().item().key("contents").parsed().array() : void 0;
    this.results = (u = p.firstOfType(Hi)) === null || u === void 0 ? void 0 : u.contents;
    const C = (h = (c = this.results) === null || c === void 0 ? void 0 : c.get({ type: "HorizontalCardList" }, !0)) === null || h === void 0 ? void 0 : h.as(hy), k = b == null ? void 0 : b.firstOfType(__);
    this.refinements = this.page.refinements || [], this.estimated_results = this.page.estimated_results, this.watch_card = {
      header: (k == null ? void 0 : k.header.item()) || null,
      call_to_action: (k == null ? void 0 : k.call_to_action.item().as(x_)) || null,
      sections: (k == null ? void 0 : k.sections.array().filterType(E_)) || []
    }, this.refinement_cards = {
      header: (C == null ? void 0 : C.header.item().as(l_)) || null,
      cards: (C == null ? void 0 : C.cards.array().filterType(c_)) || zt([])
    };
  }
  selectRefinementCard(e) {
    return N5(this, void 0, void 0, function* () {
      let t;
      if (typeof e == "string") {
        if (t = this.refinement_cards.cards.get({ query: e }), !t)
          throw new x(`Refinement card "${e}" not found`, { available_cards: this.refinement_card_queries });
      } else if (e.type === "SearchRefinementCard")
        t = e;
      else
        throw new x("Invalid refinement card!");
      const i = yield t.endpoint.call(this.actions, void 0, !0);
      return new Nl(this.actions, i, !0);
    });
  }
  get refinement_card_queries() {
    return this.refinement_cards.cards.map((e) => e.query);
  }
  getContinuation() {
    return N5(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new Nl(this.actions, e, !0);
    });
  }
};
l(Nl, "Search");
var W8 = Nl, $8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, R5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ea = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, zr, Kr, vm = class extends On {
  constructor(e, t, i = !1) {
    super(e, t, i), zr.set(this, void 0), Kr.set(this, void 0), R5(this, Kr, e, "f"), R5(this, zr, this.page.contents_memo.getType(Bt), "f");
  }
  get tabs() {
    return Ea(this, zr, "f").map((e) => e.title.toString());
  }
  getTab(e) {
    return $8(this, void 0, void 0, function* () {
      const t = Ea(this, zr, "f").find((n) => n.title.toLowerCase() === e.toLowerCase());
      if (!t)
        throw new x(`Tab "${e}" not found`);
      if (t.selected)
        return this;
      const i = yield t.endpoint.call(Ea(this, Kr, "f"));
      if (!i)
        throw new x("Failed to call endpoint");
      return new vm(Ea(this, Kr, "f"), i.data, !1);
    });
  }
  get title() {
    var e, t;
    return (t = (e = this.page.contents_memo.getType(Bt)) === null || e === void 0 ? void 0 : e.find((i) => i.selected)) === null || t === void 0 ? void 0 : t.title.toString();
  }
};
l(vm, "TabbedFeed");
zr = /* @__PURE__ */ new WeakMap(), Kr = /* @__PURE__ */ new WeakMap();
var D_ = vm, Ns = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, rs = class extends D_ {
  constructor(e, t, i = !1) {
    var n;
    super(e, t, i), this.header = this.page.header.item().as(Ug);
    const s = this.page.metadata.item().as($g), r = (n = this.page.microformat) === null || n === void 0 ? void 0 : n.as(ea);
    this.metadata = Object.assign(Object.assign({}, s), r || {}), this.sponsor_button = this.header.sponsor_button, this.subscribe_button = this.header.subscribe_button;
    const a = this.page.contents.item().key("tabs").parsed().array().filterType(Bt).get({ selected: !0 });
    this.current_tab = a;
  }
  getVideos() {
    return Ns(this, void 0, void 0, function* () {
      const e = yield this.getTab("Videos");
      return new rs(this.actions, e.page, !0);
    });
  }
  getPlaylists() {
    return Ns(this, void 0, void 0, function* () {
      const e = yield this.getTab("Playlists");
      return new rs(this.actions, e.page, !0);
    });
  }
  getHome() {
    return Ns(this, void 0, void 0, function* () {
      const e = yield this.getTab("Home");
      return new rs(this.actions, e.page, !0);
    });
  }
  getCommunity() {
    return Ns(this, void 0, void 0, function* () {
      const e = yield this.getTab("Community");
      return new rs(this.actions, e.page, !0);
    });
  }
  getChannels() {
    return Ns(this, void 0, void 0, function* () {
      const e = yield this.getTab("Channels");
      return new rs(this.actions, e.page, !0);
    });
  }
  getAbout() {
    var e;
    return Ns(this, void 0, void 0, function* () {
      return (e = (yield this.getTab("About")).memo.getType(Wg)) === null || e === void 0 ? void 0 : e[0];
    });
  }
};
l(rs, "Channel");
var G8 = rs, A1 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Yr, Xa, B_ = class extends On {
  constructor(e, t, i = !1) {
    var n, s;
    super(e, t, i), Yr.add(this);
    const r = this.page.header.item().as(Yy), a = (n = this.page.sidebar) === null || n === void 0 ? void 0 : n.as(Q1).contents.array().firstOfType(Zy), u = (s = this.page.sidebar) === null || s === void 0 ? void 0 : s.as(Q1).contents.array().firstOfType(Qy);
    this.info = Object.assign(Object.assign({}, this.page.metadata.item().as(Xy)), {
      author: u == null ? void 0 : u.owner.item().as(w_).author,
      thumbnails: a == null ? void 0 : a.thumbnail_renderer.item().as(t_).thumbnail,
      total_items: A1(this, Yr, "m", Xa).call(this, 0, a),
      views: A1(this, Yr, "m", Xa).call(this, 1, a),
      last_updated: A1(this, Yr, "m", Xa).call(this, 2, a),
      can_share: r.can_share,
      can_delete: r.can_delete,
      is_editable: r.is_editable,
      privacy: r.privacy
    }), this.menu = a == null ? void 0 : a.menu, this.endpoint = a == null ? void 0 : a.endpoint;
  }
  get items() {
    return this.videos;
  }
};
l(B_, "Playlist");
Yr = /* @__PURE__ */ new WeakSet(), Xa = /* @__PURE__ */ l(function(t, i) {
  var n;
  return !i || !i.stats ? "N/A" : ((n = i.stats[t]) === null || n === void 0 ? void 0 : n.toString()) || "N/A";
}, "_Playlist_getStat");
var Rl = B_, q8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, gm = class extends On {
  constructor(e, t, i = !1) {
    var n, s;
    super(e, t, i), this.sections = this.memo.get("ItemSection"), this.feed_actions = ((s = (n = this.memo.get("BrowseFeedActions")) === null || n === void 0 ? void 0 : n[0]) === null || s === void 0 ? void 0 : s.as(Vg)) || [];
  }
  getContinuation() {
    return q8(this, void 0, void 0, function* () {
      const e = yield this.getContinuationData();
      return new gm(this.actions, e, !0);
    });
  }
};
l(gm, "History");
var O_ = gm, z8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, L5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, hs = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, rc, os, Xr, F_, V_ = class {
  constructor(e, t) {
    var i, n;
    rc.add(this), os.set(this, void 0), Xr.set(this, void 0), L5(this, os, t, "f"), L5(this, Xr, y.parseResponse(e), "f");
    const s = hs(this, Xr, "f").contents.item().as(na);
    if (!s)
      throw new x("Response did not have a TwoColumnBrowseResults.");
    const r = s.tabs.array().as(Bt).get({ selected: !0 });
    if (!r)
      throw new x("Could not find target tab.");
    const a = ((i = s.secondary_contents.item().as(ec).items.array().get({ type: "ProfileColumnStats" })) === null || i === void 0 ? void 0 : i.as(n_)) || null, u = ((n = s.secondary_contents.item().as(ec).items.array().get({ type: "ProfileColumnUserInfo" })) === null || n === void 0 ? void 0 : n.as(s_)) || null;
    if (this.profile = { stats: a, user_info: u }, !r.content)
      throw new x("Target tab did not have any content.");
    const c = r.content.as(dt).contents.array().as(Hi).map((h) => {
      var p;
      return (p = h.contents) === null || p === void 0 ? void 0 : p.firstOfType(y0);
    });
    this.sections = c.map((h) => {
      var p;
      return {
        type: h.icon_type,
        title: h.title,
        contents: ((p = h.content) === null || p === void 0 ? void 0 : p.item().items.array()) || [],
        getAll: () => hs(this, rc, "m", F_).call(this, h)
      };
    });
  }
  get history() {
    return this.sections.find((e) => e.type === "WATCH_HISTORY");
  }
  get watch_later() {
    return this.sections.find((e) => e.type === "WATCH_LATER");
  }
  get liked_videos() {
    return this.sections.find((e) => e.type === "LIKE");
  }
  get playlists() {
    return this.sections.find((e) => e.type === "PLAYLISTS");
  }
  get clips() {
    return this.sections.find((e) => e.type === "CONTENT_CUT");
  }
  get page() {
    return hs(this, Xr, "f");
  }
};
l(V_, "Library");
os = /* @__PURE__ */ new WeakMap(), Xr = /* @__PURE__ */ new WeakMap(), rc = /* @__PURE__ */ new WeakSet(), F_ = /* @__PURE__ */ l(function(t) {
  var i;
  return z8(this, void 0, void 0, function* () {
    if (!(!((i = t.menu) === null || i === void 0) && i.item().as(rn).hasKey("top_level_buttons")))
      throw new x(`The ${t.title.text} shelf doesn't have more items`);
    const n = yield t.menu.item().as(rn).top_level_buttons.get({ text: "See all" });
    if (!n)
      throw new x("Did not find target button.");
    const s = yield n.as(at).endpoint.callTest(hs(this, os, "f"), { parse: !0 });
    switch (t.icon_type) {
      case "LIKE":
      case "WATCH_LATER":
        return new Rl(hs(this, os, "f"), s, !0);
      case "WATCH_HISTORY":
        return new O_(hs(this, os, "f"), s, !0);
      case "CONTENT_CUT":
        return new On(hs(this, os, "f"), s, !0);
      default:
        throw new x("Target shelf not implemented.");
    }
  });
}, "_Library_getAll");
var K8 = V_, D5 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, k1 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, xi = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Gs, gn, Jr, ym = class {
  constructor(e, t, i = !1) {
    var n, s, r, a, u;
    Gs.set(this, void 0), gn.set(this, void 0), Jr.set(this, void 0), k1(this, Gs, i ? t : y.parseResponse(t), "f"), k1(this, gn, e, "f");
    const c = xi(this, Gs, "f").on_response_received_endpoints;
    if (!c)
      throw new x("Comments page did not have any content.");
    this.header = (s = (n = c[0].contents) === null || n === void 0 ? void 0 : n.get({ type: "CommentsHeader" })) === null || s === void 0 ? void 0 : s.as(Yg);
    const h = ((r = c[1].contents) === null || r === void 0 ? void 0 : r.filterType(Jg)) || [];
    this.contents = h.map((p) => {
      var m;
      return (m = p.comment) === null || m === void 0 || m.setActions(xi(this, gn, "f")), p.setActions(xi(this, gn, "f")), p;
    }), k1(this, Jr, (u = (a = c[1].contents) === null || a === void 0 ? void 0 : a.get({ type: "ContinuationItem" })) === null || u === void 0 ? void 0 : u.as(sn), "f");
  }
  createComment(e) {
    var t;
    return D5(this, void 0, void 0, function* () {
      if (!this.header)
        throw new x("Page header is missing.");
      const i = (t = this.header.create_renderer) === null || t === void 0 ? void 0 : t.as(Xg).submit_button.item().as(at);
      if (!i)
        throw new x("Could not find target button.");
      return yield i.endpoint.callTest(xi(this, gn, "f"), {
        commentText: e
      });
    });
  }
  getContinuation() {
    return D5(this, void 0, void 0, function* () {
      if (!xi(this, Jr, "f"))
        throw new x("Continuation not found");
      const e = yield xi(this, Jr, "f").endpoint.callTest(xi(this, gn, "f"), { parse: !0 }), t = Object.assign({}, xi(this, Gs, "f"));
      if (!t.on_response_received_endpoints || !e.on_response_received_endpoints)
        throw new x("Invalid reponse format, missing on_response_received_endpoints");
      return t.on_response_received_endpoints.pop(), t.on_response_received_endpoints.push(e.on_response_received_endpoints[0]), new ym(xi(this, gn, "f"), t, !0);
    });
  }
  get page() {
    return xi(this, Gs, "f");
  }
};
l(ym, "Comments");
Gs = /* @__PURE__ */ new WeakMap(), gn = /* @__PURE__ */ new WeakMap(), Jr = /* @__PURE__ */ new WeakMap();
var Y8 = ym, X8 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, B5 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Mr = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, qs, Zr, _m = class {
  constructor(e, t) {
    var i, n;
    qs.set(this, void 0), Zr.set(this, void 0), B5(this, Zr, e, "f"), B5(this, qs, y.parseResponse(t.data), "f"), this.header = ((n = (i = Mr(this, qs, "f").actions_memo.get("SimpleMenuHeader")) === null || i === void 0 ? void 0 : i[0]) === null || n === void 0 ? void 0 : n.as(Ey)) || null, this.contents = Mr(this, qs, "f").actions_memo.get("Notification");
  }
  getContinuation() {
    var e;
    return X8(this, void 0, void 0, function* () {
      const t = (e = Mr(this, qs, "f").actions_memo.get("ContinuationItem")) === null || e === void 0 ? void 0 : e[0].as(sn);
      if (!t)
        throw new x("Continuation not found");
      const i = yield t.endpoint.callTest(Mr(this, Zr, "f"), { parse: !1 });
      return new _m(Mr(this, Zr, "f"), i);
    });
  }
};
l(_m, "NotificationsMenu");
qs = /* @__PURE__ */ new WeakMap(), Zr = /* @__PURE__ */ new WeakMap();
var J8 = _m, Qr = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, ds = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ut = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, kn, or, tr, Io, eo, Ja, to, U_, O5, j_, F5, H_ = class extends mm {
  constructor(e) {
    var t, i;
    super(), kn.add(this), or.set(this, void 0), tr.set(this, void 0), Io.set(this, void 0), eo.set(this, void 0), Ja.set(this, 1e3), to.set(this, 5e3), this.running = !1, this.is_replay = !1, ds(this, tr, e, "f"), ds(this, or, e.actions, "f"), ds(this, Io, ((t = e.livechat) === null || t === void 0 ? void 0 : t.continuation) || void 0, "f"), this.is_replay = ((i = e.livechat) === null || i === void 0 ? void 0 : i.is_replay) || !1;
  }
  start() {
    this.running || (this.running = !0, ut(this, kn, "m", U_).call(this), ut(this, kn, "m", j_).call(this));
  }
  stop() {
    this.running = !1;
  }
  sendMessage(e) {
    return Qr(this, void 0, void 0, function* () {
      const t = yield ut(this, or, "f").livechat("live_chat/send_message", Object.assign({ text: e }, {
        video_id: ut(this, tr, "f").basic_info.id,
        channel_id: ut(this, tr, "f").basic_info.channel_id
      })), i = y.parseResponse(t.data);
      if (!i.actions)
        throw new x('Response did not have an "actions" property. The call may have failed.');
      return i.actions.array().as(gy);
    });
  }
};
l(H_, "LiveChat");
or = /* @__PURE__ */ new WeakMap(), tr = /* @__PURE__ */ new WeakMap(), Io = /* @__PURE__ */ new WeakMap(), eo = /* @__PURE__ */ new WeakMap(), Ja = /* @__PURE__ */ new WeakMap(), to = /* @__PURE__ */ new WeakMap(), kn = /* @__PURE__ */ new WeakSet(), U_ = /* @__PURE__ */ l(function e() {
  const t = setTimeout(() => {
    (() => Qr(this, void 0, void 0, function* () {
      const i = this.is_replay ? "live_chat/get_live_chat_replay" : "live_chat/get_live_chat", n = yield ut(this, or, "f").livechat(i, { ctoken: ut(this, Io, "f") }), r = y.parseResponse(n.data).continuation_contents;
      if (!(r instanceof su))
        throw new x("Continuation is not a LiveChatContinuation");
      ds(this, Io, r.continuation.token, "f"), ds(this, Ja, r.continuation.timeout_ms, "f"), r.header ? (this.initial_info = r, this.emit("start", r)) : yield ut(this, kn, "m", O5).call(this, r.actions), clearTimeout(t), this.running && ut(this, kn, "m", e).call(this);
    }))().catch((i) => Promise.reject(i));
  }, ut(this, Ja, "f"));
}, "_LiveChat_pollLivechat"), O5 = /* @__PURE__ */ l(function(t) {
  return Qr(this, void 0, void 0, function* () {
    let n = t.length < 125 ? 1 : 0;
    const s = n == 1 ? (n = 1e4 / t.length, n *= Math.random() + 0.5, n = Math.min(1e3, n), n = Math.max(80, n)) : n = 80;
    for (const r of t)
      yield ut(this, kn, "m", F5).call(this, s), this.emit("chat-update", r);
  });
}, "_LiveChat_emitSmoothedActions"), j_ = /* @__PURE__ */ l(function e() {
  const t = setTimeout(() => {
    (() => Qr(this, void 0, void 0, function* () {
      var i, n, s, r, a, u, c, h, p, m, b, C;
      const k = {
        video_id: ut(this, tr, "f").basic_info.id,
        ctoken: void 0
      };
      ut(this, eo, "f") && (k.ctoken = ut(this, eo, "f"));
      const D = yield ut(this, or, "f").livechat("updated_metadata", k), I = y.parseResponse(D.data);
      ds(this, eo, (i = I.continuation) === null || i === void 0 ? void 0 : i.token, "f"), ds(this, to, ((n = I.continuation) === null || n === void 0 ? void 0 : n.timeout_ms) || ut(this, to, "f"), "f"), this.metadata = {
        title: ((s = I.actions) === null || s === void 0 ? void 0 : s.array().firstOfType(wy)) || ((r = this.metadata) === null || r === void 0 ? void 0 : r.title),
        description: ((a = I.actions) === null || a === void 0 ? void 0 : a.array().firstOfType(by)) || ((u = this.metadata) === null || u === void 0 ? void 0 : u.description),
        views: ((c = I.actions) === null || c === void 0 ? void 0 : c.array().firstOfType(Cy)) || ((h = this.metadata) === null || h === void 0 ? void 0 : h.views),
        likes: ((p = I.actions) === null || p === void 0 ? void 0 : p.array().firstOfType(Sy)) || ((m = this.metadata) === null || m === void 0 ? void 0 : m.likes),
        date: ((b = I.actions) === null || b === void 0 ? void 0 : b.array().firstOfType(_y)) || ((C = this.metadata) === null || C === void 0 ? void 0 : C.date)
      }, this.emit("metadata-update", this.metadata), clearTimeout(t), this.running && ut(this, kn, "m", e).call(this);
    }))().catch((i) => Promise.reject(i));
  }, ut(this, to, "f"));
}, "_LiveChat_pollMetadata"), F5 = /* @__PURE__ */ l(function(t) {
  return Qr(this, void 0, void 0, function* () {
    return new Promise((i) => setTimeout(() => i(), t));
  });
}, "_LiveChat_wait");
var Z8 = H_, Ll = Symbol("changed"), zs = Symbol("classList"), pi = Symbol("CustomElements"), Aa = Symbol("content"), I1 = Symbol("dataset"), Gn = Symbol("doctype"), oc = Symbol("DOMParser"), ne = Symbol("end"), Nr = Symbol("EventTarget"), Za = Symbol("globals"), fi = Symbol("image"), gr = Symbol("mime"), Pn = Symbol("MutationObserver"), W = Symbol("next"), W_ = Symbol("ownerElement"), ct = Symbol("prev"), yt = Symbol("private"), Rs = Symbol("sheet"), Lt = Symbol("start"), P1 = Symbol("style"), Po = Symbol("upgrade"), He = Symbol("value"), $_ = {};
Yo($_, {
  DefaultHandler: () => Ho,
  DomHandler: () => Ho,
  DomUtils: () => uu,
  ElementType: () => K_,
  Parser: () => ru,
  Tokenizer: () => Sm,
  createDomStream: () => Ob,
  getFeed: () => pu,
  parseDOM: () => Hm,
  parseDocument: () => jm,
  parseFeed: () => Fb
});
var Q8 = new Uint16Array([7489, 60, 213, 305, 650, 1181, 1403, 1488, 1653, 1758, 1954, 2006, 2063, 2634, 2705, 3489, 3693, 3849, 3878, 4298, 4648, 4833, 5141, 5277, 5315, 5343, 5413, 0, 0, 0, 0, 0, 0, 5483, 5837, 6541, 7186, 7645, 8062, 8288, 8624, 8845, 9152, 9211, 9282, 10276, 10514, 11528, 11848, 12238, 12310, 12986, 13881, 14252, 14590, 14888, 14961, 15072, 15150, 2048, 69, 77, 97, 98, 99, 102, 103, 108, 109, 110, 111, 112, 114, 115, 116, 117, 92, 98, 102, 109, 115, 127, 132, 139, 144, 149, 152, 166, 179, 185, 200, 207, 108, 105, 103, 32827, 198, 16582, 80, 32827, 38, 16422, 99, 117, 116, 101, 32827, 193, 16577, 114, 101, 118, 101, 59, 16642, 256, 105, 121, 120, 125, 114, 99, 32827, 194, 16578, 59, 17424, 114, 59, 49152, 55349, 56580, 114, 97, 118, 101, 32827, 192, 16576, 112, 104, 97, 59, 17297, 97, 99, 114, 59, 16640, 100, 59, 27219, 256, 103, 112, 157, 161, 111, 110, 59, 16644, 102, 59, 49152, 55349, 56632, 112, 108, 121, 70, 117, 110, 99, 116, 105, 111, 110, 59, 24673, 105, 110, 103, 32827, 197, 16581, 256, 99, 115, 190, 195, 114, 59, 49152, 55349, 56476, 105, 103, 110, 59, 25172, 105, 108, 100, 101, 32827, 195, 16579, 109, 108, 32827, 196, 16580, 1024, 97, 99, 101, 102, 111, 114, 115, 117, 229, 251, 254, 279, 284, 290, 295, 298, 256, 99, 114, 234, 242, 107, 115, 108, 97, 115, 104, 59, 25110, 374, 246, 248, 59, 27367, 101, 100, 59, 25350, 121, 59, 17425, 384, 99, 114, 116, 261, 267, 276, 97, 117, 115, 101, 59, 25141, 110, 111, 117, 108, 108, 105, 115, 59, 24876, 97, 59, 17298, 114, 59, 49152, 55349, 56581, 112, 102, 59, 49152, 55349, 56633, 101, 118, 101, 59, 17112, 99, 242, 275, 109, 112, 101, 113, 59, 25166, 1792, 72, 79, 97, 99, 100, 101, 102, 104, 105, 108, 111, 114, 115, 117, 333, 337, 342, 384, 414, 418, 437, 439, 442, 476, 533, 627, 632, 638, 99, 121, 59, 17447, 80, 89, 32827, 169, 16553, 384, 99, 112, 121, 349, 354, 378, 117, 116, 101, 59, 16646, 256, 59, 105, 359, 360, 25298, 116, 97, 108, 68, 105, 102, 102, 101, 114, 101, 110, 116, 105, 97, 108, 68, 59, 24901, 108, 101, 121, 115, 59, 24877, 512, 97, 101, 105, 111, 393, 398, 404, 408, 114, 111, 110, 59, 16652, 100, 105, 108, 32827, 199, 16583, 114, 99, 59, 16648, 110, 105, 110, 116, 59, 25136, 111, 116, 59, 16650, 256, 100, 110, 423, 429, 105, 108, 108, 97, 59, 16568, 116, 101, 114, 68, 111, 116, 59, 16567, 242, 383, 105, 59, 17319, 114, 99, 108, 101, 512, 68, 77, 80, 84, 455, 459, 465, 470, 111, 116, 59, 25241, 105, 110, 117, 115, 59, 25238, 108, 117, 115, 59, 25237, 105, 109, 101, 115, 59, 25239, 111, 256, 99, 115, 482, 504, 107, 119, 105, 115, 101, 67, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25138, 101, 67, 117, 114, 108, 121, 256, 68, 81, 515, 527, 111, 117, 98, 108, 101, 81, 117, 111, 116, 101, 59, 24605, 117, 111, 116, 101, 59, 24601, 512, 108, 110, 112, 117, 542, 552, 583, 597, 111, 110, 256, 59, 101, 549, 550, 25143, 59, 27252, 384, 103, 105, 116, 559, 566, 570, 114, 117, 101, 110, 116, 59, 25185, 110, 116, 59, 25135, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25134, 256, 102, 114, 588, 590, 59, 24834, 111, 100, 117, 99, 116, 59, 25104, 110, 116, 101, 114, 67, 108, 111, 99, 107, 119, 105, 115, 101, 67, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 108, 59, 25139, 111, 115, 115, 59, 27183, 99, 114, 59, 49152, 55349, 56478, 112, 256, 59, 67, 644, 645, 25299, 97, 112, 59, 25165, 1408, 68, 74, 83, 90, 97, 99, 101, 102, 105, 111, 115, 672, 684, 688, 692, 696, 715, 727, 737, 742, 819, 1165, 256, 59, 111, 377, 677, 116, 114, 97, 104, 100, 59, 26897, 99, 121, 59, 17410, 99, 121, 59, 17413, 99, 121, 59, 17423, 384, 103, 114, 115, 703, 708, 711, 103, 101, 114, 59, 24609, 114, 59, 24993, 104, 118, 59, 27364, 256, 97, 121, 720, 725, 114, 111, 110, 59, 16654, 59, 17428, 108, 256, 59, 116, 733, 734, 25095, 97, 59, 17300, 114, 59, 49152, 55349, 56583, 256, 97, 102, 747, 807, 256, 99, 109, 752, 802, 114, 105, 116, 105, 99, 97, 108, 512, 65, 68, 71, 84, 768, 774, 790, 796, 99, 117, 116, 101, 59, 16564, 111, 372, 779, 781, 59, 17113, 98, 108, 101, 65, 99, 117, 116, 101, 59, 17117, 114, 97, 118, 101, 59, 16480, 105, 108, 100, 101, 59, 17116, 111, 110, 100, 59, 25284, 102, 101, 114, 101, 110, 116, 105, 97, 108, 68, 59, 24902, 1136, 829, 0, 0, 0, 834, 852, 0, 1029, 102, 59, 49152, 55349, 56635, 384, 59, 68, 69, 840, 841, 845, 16552, 111, 116, 59, 24796, 113, 117, 97, 108, 59, 25168, 98, 108, 101, 768, 67, 68, 76, 82, 85, 86, 867, 882, 898, 975, 994, 1016, 111, 110, 116, 111, 117, 114, 73, 110, 116, 101, 103, 114, 97, 236, 569, 111, 628, 889, 0, 0, 891, 187, 841, 110, 65, 114, 114, 111, 119, 59, 25043, 256, 101, 111, 903, 932, 102, 116, 384, 65, 82, 84, 912, 918, 929, 114, 114, 111, 119, 59, 25040, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 25044, 101, 229, 714, 110, 103, 256, 76, 82, 939, 964, 101, 102, 116, 256, 65, 82, 947, 953, 114, 114, 111, 119, 59, 26616, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26618, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26617, 105, 103, 104, 116, 256, 65, 84, 984, 990, 114, 114, 111, 119, 59, 25042, 101, 101, 59, 25256, 112, 577, 1001, 0, 0, 1007, 114, 114, 111, 119, 59, 25041, 111, 119, 110, 65, 114, 114, 111, 119, 59, 25045, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25125, 110, 768, 65, 66, 76, 82, 84, 97, 1042, 1066, 1072, 1118, 1151, 892, 114, 114, 111, 119, 384, 59, 66, 85, 1053, 1054, 1058, 24979, 97, 114, 59, 26899, 112, 65, 114, 114, 111, 119, 59, 25077, 114, 101, 118, 101, 59, 17169, 101, 102, 116, 722, 1082, 0, 1094, 0, 1104, 105, 103, 104, 116, 86, 101, 99, 116, 111, 114, 59, 26960, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26974, 101, 99, 116, 111, 114, 256, 59, 66, 1113, 1114, 25021, 97, 114, 59, 26966, 105, 103, 104, 116, 468, 1127, 0, 1137, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26975, 101, 99, 116, 111, 114, 256, 59, 66, 1146, 1147, 25025, 97, 114, 59, 26967, 101, 101, 256, 59, 65, 1158, 1159, 25252, 114, 114, 111, 119, 59, 24999, 256, 99, 116, 1170, 1175, 114, 59, 49152, 55349, 56479, 114, 111, 107, 59, 16656, 2048, 78, 84, 97, 99, 100, 102, 103, 108, 109, 111, 112, 113, 115, 116, 117, 120, 1213, 1216, 1220, 1227, 1246, 1250, 1255, 1262, 1269, 1313, 1327, 1334, 1362, 1373, 1376, 1381, 71, 59, 16714, 72, 32827, 208, 16592, 99, 117, 116, 101, 32827, 201, 16585, 384, 97, 105, 121, 1234, 1239, 1244, 114, 111, 110, 59, 16666, 114, 99, 32827, 202, 16586, 59, 17453, 111, 116, 59, 16662, 114, 59, 49152, 55349, 56584, 114, 97, 118, 101, 32827, 200, 16584, 101, 109, 101, 110, 116, 59, 25096, 256, 97, 112, 1274, 1278, 99, 114, 59, 16658, 116, 121, 595, 1286, 0, 0, 1298, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26107, 101, 114, 121, 83, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26027, 256, 103, 112, 1318, 1322, 111, 110, 59, 16664, 102, 59, 49152, 55349, 56636, 115, 105, 108, 111, 110, 59, 17301, 117, 256, 97, 105, 1340, 1353, 108, 256, 59, 84, 1346, 1347, 27253, 105, 108, 100, 101, 59, 25154, 108, 105, 98, 114, 105, 117, 109, 59, 25036, 256, 99, 105, 1367, 1370, 114, 59, 24880, 109, 59, 27251, 97, 59, 17303, 109, 108, 32827, 203, 16587, 256, 105, 112, 1386, 1391, 115, 116, 115, 59, 25091, 111, 110, 101, 110, 116, 105, 97, 108, 69, 59, 24903, 640, 99, 102, 105, 111, 115, 1413, 1416, 1421, 1458, 1484, 121, 59, 17444, 114, 59, 49152, 55349, 56585, 108, 108, 101, 100, 595, 1431, 0, 0, 1443, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26108, 101, 114, 121, 83, 109, 97, 108, 108, 83, 113, 117, 97, 114, 101, 59, 26026, 880, 1466, 0, 1471, 0, 0, 1476, 102, 59, 49152, 55349, 56637, 65, 108, 108, 59, 25088, 114, 105, 101, 114, 116, 114, 102, 59, 24881, 99, 242, 1483, 1536, 74, 84, 97, 98, 99, 100, 102, 103, 111, 114, 115, 116, 1512, 1516, 1519, 1530, 1536, 1554, 1558, 1563, 1565, 1571, 1644, 1650, 99, 121, 59, 17411, 32827, 62, 16446, 109, 109, 97, 256, 59, 100, 1527, 1528, 17299, 59, 17372, 114, 101, 118, 101, 59, 16670, 384, 101, 105, 121, 1543, 1548, 1552, 100, 105, 108, 59, 16674, 114, 99, 59, 16668, 59, 17427, 111, 116, 59, 16672, 114, 59, 49152, 55349, 56586, 59, 25305, 112, 102, 59, 49152, 55349, 56638, 101, 97, 116, 101, 114, 768, 69, 70, 71, 76, 83, 84, 1589, 1604, 1614, 1622, 1627, 1638, 113, 117, 97, 108, 256, 59, 76, 1598, 1599, 25189, 101, 115, 115, 59, 25307, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25191, 114, 101, 97, 116, 101, 114, 59, 27298, 101, 115, 115, 59, 25207, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 27262, 105, 108, 100, 101, 59, 25203, 99, 114, 59, 49152, 55349, 56482, 59, 25195, 1024, 65, 97, 99, 102, 105, 111, 115, 117, 1669, 1675, 1686, 1691, 1694, 1706, 1726, 1738, 82, 68, 99, 121, 59, 17450, 256, 99, 116, 1680, 1684, 101, 107, 59, 17095, 59, 16478, 105, 114, 99, 59, 16676, 114, 59, 24844, 108, 98, 101, 114, 116, 83, 112, 97, 99, 101, 59, 24843, 496, 1711, 0, 1714, 102, 59, 24845, 105, 122, 111, 110, 116, 97, 108, 76, 105, 110, 101, 59, 25856, 256, 99, 116, 1731, 1733, 242, 1705, 114, 111, 107, 59, 16678, 109, 112, 324, 1744, 1752, 111, 119, 110, 72, 117, 109, 240, 303, 113, 117, 97, 108, 59, 25167, 1792, 69, 74, 79, 97, 99, 100, 102, 103, 109, 110, 111, 115, 116, 117, 1786, 1790, 1795, 1799, 1806, 1818, 1822, 1825, 1832, 1860, 1912, 1931, 1935, 1941, 99, 121, 59, 17429, 108, 105, 103, 59, 16690, 99, 121, 59, 17409, 99, 117, 116, 101, 32827, 205, 16589, 256, 105, 121, 1811, 1816, 114, 99, 32827, 206, 16590, 59, 17432, 111, 116, 59, 16688, 114, 59, 24849, 114, 97, 118, 101, 32827, 204, 16588, 384, 59, 97, 112, 1824, 1839, 1855, 256, 99, 103, 1844, 1847, 114, 59, 16682, 105, 110, 97, 114, 121, 73, 59, 24904, 108, 105, 101, 243, 989, 500, 1865, 0, 1890, 256, 59, 101, 1869, 1870, 25132, 256, 103, 114, 1875, 1880, 114, 97, 108, 59, 25131, 115, 101, 99, 116, 105, 111, 110, 59, 25282, 105, 115, 105, 98, 108, 101, 256, 67, 84, 1900, 1906, 111, 109, 109, 97, 59, 24675, 105, 109, 101, 115, 59, 24674, 384, 103, 112, 116, 1919, 1923, 1928, 111, 110, 59, 16686, 102, 59, 49152, 55349, 56640, 97, 59, 17305, 99, 114, 59, 24848, 105, 108, 100, 101, 59, 16680, 491, 1946, 0, 1950, 99, 121, 59, 17414, 108, 32827, 207, 16591, 640, 99, 102, 111, 115, 117, 1964, 1975, 1980, 1986, 2e3, 256, 105, 121, 1969, 1973, 114, 99, 59, 16692, 59, 17433, 114, 59, 49152, 55349, 56589, 112, 102, 59, 49152, 55349, 56641, 483, 1991, 0, 1996, 114, 59, 49152, 55349, 56485, 114, 99, 121, 59, 17416, 107, 99, 121, 59, 17412, 896, 72, 74, 97, 99, 102, 111, 115, 2020, 2024, 2028, 2033, 2045, 2050, 2056, 99, 121, 59, 17445, 99, 121, 59, 17420, 112, 112, 97, 59, 17306, 256, 101, 121, 2038, 2043, 100, 105, 108, 59, 16694, 59, 17434, 114, 59, 49152, 55349, 56590, 112, 102, 59, 49152, 55349, 56642, 99, 114, 59, 49152, 55349, 56486, 1408, 74, 84, 97, 99, 101, 102, 108, 109, 111, 115, 116, 2085, 2089, 2092, 2128, 2147, 2483, 2488, 2503, 2509, 2615, 2631, 99, 121, 59, 17417, 32827, 60, 16444, 640, 99, 109, 110, 112, 114, 2103, 2108, 2113, 2116, 2125, 117, 116, 101, 59, 16697, 98, 100, 97, 59, 17307, 103, 59, 26602, 108, 97, 99, 101, 116, 114, 102, 59, 24850, 114, 59, 24990, 384, 97, 101, 121, 2135, 2140, 2145, 114, 111, 110, 59, 16701, 100, 105, 108, 59, 16699, 59, 17435, 256, 102, 115, 2152, 2416, 116, 1280, 65, 67, 68, 70, 82, 84, 85, 86, 97, 114, 2174, 2217, 2225, 2272, 2278, 2300, 2351, 2395, 912, 2410, 256, 110, 114, 2179, 2191, 103, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26600, 114, 111, 119, 384, 59, 66, 82, 2201, 2202, 2206, 24976, 97, 114, 59, 25060, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 25030, 101, 105, 108, 105, 110, 103, 59, 25352, 111, 501, 2231, 0, 2243, 98, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26598, 110, 468, 2248, 0, 2258, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26977, 101, 99, 116, 111, 114, 256, 59, 66, 2267, 2268, 25027, 97, 114, 59, 26969, 108, 111, 111, 114, 59, 25354, 105, 103, 104, 116, 256, 65, 86, 2287, 2293, 114, 114, 111, 119, 59, 24980, 101, 99, 116, 111, 114, 59, 26958, 256, 101, 114, 2305, 2327, 101, 384, 59, 65, 86, 2313, 2314, 2320, 25251, 114, 114, 111, 119, 59, 24996, 101, 99, 116, 111, 114, 59, 26970, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 2340, 2341, 2345, 25266, 97, 114, 59, 27087, 113, 117, 97, 108, 59, 25268, 112, 384, 68, 84, 86, 2359, 2370, 2380, 111, 119, 110, 86, 101, 99, 116, 111, 114, 59, 26961, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26976, 101, 99, 116, 111, 114, 256, 59, 66, 2390, 2391, 25023, 97, 114, 59, 26968, 101, 99, 116, 111, 114, 256, 59, 66, 2405, 2406, 25020, 97, 114, 59, 26962, 105, 103, 104, 116, 225, 924, 115, 768, 69, 70, 71, 76, 83, 84, 2430, 2443, 2453, 2461, 2466, 2477, 113, 117, 97, 108, 71, 114, 101, 97, 116, 101, 114, 59, 25306, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25190, 114, 101, 97, 116, 101, 114, 59, 25206, 101, 115, 115, 59, 27297, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 27261, 105, 108, 100, 101, 59, 25202, 114, 59, 49152, 55349, 56591, 256, 59, 101, 2493, 2494, 25304, 102, 116, 97, 114, 114, 111, 119, 59, 25050, 105, 100, 111, 116, 59, 16703, 384, 110, 112, 119, 2516, 2582, 2587, 103, 512, 76, 82, 108, 114, 2526, 2551, 2562, 2576, 101, 102, 116, 256, 65, 82, 2534, 2540, 114, 114, 111, 119, 59, 26613, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26615, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 26614, 101, 102, 116, 256, 97, 114, 947, 2570, 105, 103, 104, 116, 225, 959, 105, 103, 104, 116, 225, 970, 102, 59, 49152, 55349, 56643, 101, 114, 256, 76, 82, 2594, 2604, 101, 102, 116, 65, 114, 114, 111, 119, 59, 24985, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 24984, 384, 99, 104, 116, 2622, 2624, 2626, 242, 2124, 59, 25008, 114, 111, 107, 59, 16705, 59, 25194, 1024, 97, 99, 101, 102, 105, 111, 115, 117, 2650, 2653, 2656, 2679, 2684, 2693, 2699, 2702, 112, 59, 26885, 121, 59, 17436, 256, 100, 108, 2661, 2671, 105, 117, 109, 83, 112, 97, 99, 101, 59, 24671, 108, 105, 110, 116, 114, 102, 59, 24883, 114, 59, 49152, 55349, 56592, 110, 117, 115, 80, 108, 117, 115, 59, 25107, 112, 102, 59, 49152, 55349, 56644, 99, 242, 2678, 59, 17308, 1152, 74, 97, 99, 101, 102, 111, 115, 116, 117, 2723, 2727, 2733, 2752, 2836, 2841, 3473, 3479, 3486, 99, 121, 59, 17418, 99, 117, 116, 101, 59, 16707, 384, 97, 101, 121, 2740, 2745, 2750, 114, 111, 110, 59, 16711, 100, 105, 108, 59, 16709, 59, 17437, 384, 103, 115, 119, 2759, 2800, 2830, 97, 116, 105, 118, 101, 384, 77, 84, 86, 2771, 2783, 2792, 101, 100, 105, 117, 109, 83, 112, 97, 99, 101, 59, 24587, 104, 105, 256, 99, 110, 2790, 2776, 235, 2777, 101, 114, 121, 84, 104, 105, 238, 2777, 116, 101, 100, 256, 71, 76, 2808, 2822, 114, 101, 97, 116, 101, 114, 71, 114, 101, 97, 116, 101, 242, 1651, 101, 115, 115, 76, 101, 115, 243, 2632, 76, 105, 110, 101, 59, 16394, 114, 59, 49152, 55349, 56593, 512, 66, 110, 112, 116, 2850, 2856, 2871, 2874, 114, 101, 97, 107, 59, 24672, 66, 114, 101, 97, 107, 105, 110, 103, 83, 112, 97, 99, 101, 59, 16544, 102, 59, 24853, 1664, 59, 67, 68, 69, 71, 72, 76, 78, 80, 82, 83, 84, 86, 2901, 2902, 2922, 2940, 2977, 3051, 3076, 3166, 3204, 3238, 3288, 3425, 3461, 27372, 256, 111, 117, 2907, 2916, 110, 103, 114, 117, 101, 110, 116, 59, 25186, 112, 67, 97, 112, 59, 25197, 111, 117, 98, 108, 101, 86, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25126, 384, 108, 113, 120, 2947, 2954, 2971, 101, 109, 101, 110, 116, 59, 25097, 117, 97, 108, 256, 59, 84, 2962, 2963, 25184, 105, 108, 100, 101, 59, 49152, 8770, 824, 105, 115, 116, 115, 59, 25092, 114, 101, 97, 116, 101, 114, 896, 59, 69, 70, 71, 76, 83, 84, 2998, 2999, 3005, 3017, 3027, 3032, 3045, 25199, 113, 117, 97, 108, 59, 25201, 117, 108, 108, 69, 113, 117, 97, 108, 59, 49152, 8807, 824, 114, 101, 97, 116, 101, 114, 59, 49152, 8811, 824, 101, 115, 115, 59, 25209, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 49152, 10878, 824, 105, 108, 100, 101, 59, 25205, 117, 109, 112, 324, 3058, 3069, 111, 119, 110, 72, 117, 109, 112, 59, 49152, 8782, 824, 113, 117, 97, 108, 59, 49152, 8783, 824, 101, 256, 102, 115, 3082, 3111, 116, 84, 114, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 3098, 3099, 3105, 25322, 97, 114, 59, 49152, 10703, 824, 113, 117, 97, 108, 59, 25324, 115, 768, 59, 69, 71, 76, 83, 84, 3125, 3126, 3132, 3140, 3147, 3160, 25198, 113, 117, 97, 108, 59, 25200, 114, 101, 97, 116, 101, 114, 59, 25208, 101, 115, 115, 59, 49152, 8810, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 49152, 10877, 824, 105, 108, 100, 101, 59, 25204, 101, 115, 116, 101, 100, 256, 71, 76, 3176, 3193, 114, 101, 97, 116, 101, 114, 71, 114, 101, 97, 116, 101, 114, 59, 49152, 10914, 824, 101, 115, 115, 76, 101, 115, 115, 59, 49152, 10913, 824, 114, 101, 99, 101, 100, 101, 115, 384, 59, 69, 83, 3218, 3219, 3227, 25216, 113, 117, 97, 108, 59, 49152, 10927, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25312, 256, 101, 105, 3243, 3257, 118, 101, 114, 115, 101, 69, 108, 101, 109, 101, 110, 116, 59, 25100, 103, 104, 116, 84, 114, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 3275, 3276, 3282, 25323, 97, 114, 59, 49152, 10704, 824, 113, 117, 97, 108, 59, 25325, 256, 113, 117, 3293, 3340, 117, 97, 114, 101, 83, 117, 256, 98, 112, 3304, 3321, 115, 101, 116, 256, 59, 69, 3312, 3315, 49152, 8847, 824, 113, 117, 97, 108, 59, 25314, 101, 114, 115, 101, 116, 256, 59, 69, 3331, 3334, 49152, 8848, 824, 113, 117, 97, 108, 59, 25315, 384, 98, 99, 112, 3347, 3364, 3406, 115, 101, 116, 256, 59, 69, 3355, 3358, 49152, 8834, 8402, 113, 117, 97, 108, 59, 25224, 99, 101, 101, 100, 115, 512, 59, 69, 83, 84, 3378, 3379, 3387, 3398, 25217, 113, 117, 97, 108, 59, 49152, 10928, 824, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25313, 105, 108, 100, 101, 59, 49152, 8831, 824, 101, 114, 115, 101, 116, 256, 59, 69, 3416, 3419, 49152, 8835, 8402, 113, 117, 97, 108, 59, 25225, 105, 108, 100, 101, 512, 59, 69, 70, 84, 3438, 3439, 3445, 3455, 25153, 113, 117, 97, 108, 59, 25156, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25159, 105, 108, 100, 101, 59, 25161, 101, 114, 116, 105, 99, 97, 108, 66, 97, 114, 59, 25124, 99, 114, 59, 49152, 55349, 56489, 105, 108, 100, 101, 32827, 209, 16593, 59, 17309, 1792, 69, 97, 99, 100, 102, 103, 109, 111, 112, 114, 115, 116, 117, 118, 3517, 3522, 3529, 3541, 3547, 3552, 3559, 3580, 3586, 3616, 3618, 3634, 3647, 3652, 108, 105, 103, 59, 16722, 99, 117, 116, 101, 32827, 211, 16595, 256, 105, 121, 3534, 3539, 114, 99, 32827, 212, 16596, 59, 17438, 98, 108, 97, 99, 59, 16720, 114, 59, 49152, 55349, 56594, 114, 97, 118, 101, 32827, 210, 16594, 384, 97, 101, 105, 3566, 3570, 3574, 99, 114, 59, 16716, 103, 97, 59, 17321, 99, 114, 111, 110, 59, 17311, 112, 102, 59, 49152, 55349, 56646, 101, 110, 67, 117, 114, 108, 121, 256, 68, 81, 3598, 3610, 111, 117, 98, 108, 101, 81, 117, 111, 116, 101, 59, 24604, 117, 111, 116, 101, 59, 24600, 59, 27220, 256, 99, 108, 3623, 3628, 114, 59, 49152, 55349, 56490, 97, 115, 104, 32827, 216, 16600, 105, 364, 3639, 3644, 100, 101, 32827, 213, 16597, 101, 115, 59, 27191, 109, 108, 32827, 214, 16598, 101, 114, 256, 66, 80, 3659, 3680, 256, 97, 114, 3664, 3667, 114, 59, 24638, 97, 99, 256, 101, 107, 3674, 3676, 59, 25566, 101, 116, 59, 25524, 97, 114, 101, 110, 116, 104, 101, 115, 105, 115, 59, 25564, 1152, 97, 99, 102, 104, 105, 108, 111, 114, 115, 3711, 3719, 3722, 3727, 3730, 3732, 3741, 3760, 3836, 114, 116, 105, 97, 108, 68, 59, 25090, 121, 59, 17439, 114, 59, 49152, 55349, 56595, 105, 59, 17318, 59, 17312, 117, 115, 77, 105, 110, 117, 115, 59, 16561, 256, 105, 112, 3746, 3757, 110, 99, 97, 114, 101, 112, 108, 97, 110, 229, 1693, 102, 59, 24857, 512, 59, 101, 105, 111, 3769, 3770, 3808, 3812, 27323, 99, 101, 100, 101, 115, 512, 59, 69, 83, 84, 3784, 3785, 3791, 3802, 25210, 113, 117, 97, 108, 59, 27311, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25212, 105, 108, 100, 101, 59, 25214, 109, 101, 59, 24627, 256, 100, 112, 3817, 3822, 117, 99, 116, 59, 25103, 111, 114, 116, 105, 111, 110, 256, 59, 97, 549, 3833, 108, 59, 25117, 256, 99, 105, 3841, 3846, 114, 59, 49152, 55349, 56491, 59, 17320, 512, 85, 102, 111, 115, 3857, 3862, 3867, 3871, 79, 84, 32827, 34, 16418, 114, 59, 49152, 55349, 56596, 112, 102, 59, 24858, 99, 114, 59, 49152, 55349, 56492, 1536, 66, 69, 97, 99, 101, 102, 104, 105, 111, 114, 115, 117, 3902, 3907, 3911, 3936, 3955, 4007, 4010, 4013, 4246, 4265, 4276, 4286, 97, 114, 114, 59, 26896, 71, 32827, 174, 16558, 384, 99, 110, 114, 3918, 3923, 3926, 117, 116, 101, 59, 16724, 103, 59, 26603, 114, 256, 59, 116, 3932, 3933, 24992, 108, 59, 26902, 384, 97, 101, 121, 3943, 3948, 3953, 114, 111, 110, 59, 16728, 100, 105, 108, 59, 16726, 59, 17440, 256, 59, 118, 3960, 3961, 24860, 101, 114, 115, 101, 256, 69, 85, 3970, 3993, 256, 108, 113, 3975, 3982, 101, 109, 101, 110, 116, 59, 25099, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 25035, 112, 69, 113, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 26991, 114, 187, 3961, 111, 59, 17313, 103, 104, 116, 1024, 65, 67, 68, 70, 84, 85, 86, 97, 4033, 4075, 4083, 4130, 4136, 4187, 4231, 984, 256, 110, 114, 4038, 4050, 103, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26601, 114, 111, 119, 384, 59, 66, 76, 4060, 4061, 4065, 24978, 97, 114, 59, 25061, 101, 102, 116, 65, 114, 114, 111, 119, 59, 25028, 101, 105, 108, 105, 110, 103, 59, 25353, 111, 501, 4089, 0, 4101, 98, 108, 101, 66, 114, 97, 99, 107, 101, 116, 59, 26599, 110, 468, 4106, 0, 4116, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26973, 101, 99, 116, 111, 114, 256, 59, 66, 4125, 4126, 25026, 97, 114, 59, 26965, 108, 111, 111, 114, 59, 25355, 256, 101, 114, 4141, 4163, 101, 384, 59, 65, 86, 4149, 4150, 4156, 25250, 114, 114, 111, 119, 59, 24998, 101, 99, 116, 111, 114, 59, 26971, 105, 97, 110, 103, 108, 101, 384, 59, 66, 69, 4176, 4177, 4181, 25267, 97, 114, 59, 27088, 113, 117, 97, 108, 59, 25269, 112, 384, 68, 84, 86, 4195, 4206, 4216, 111, 119, 110, 86, 101, 99, 116, 111, 114, 59, 26959, 101, 101, 86, 101, 99, 116, 111, 114, 59, 26972, 101, 99, 116, 111, 114, 256, 59, 66, 4226, 4227, 25022, 97, 114, 59, 26964, 101, 99, 116, 111, 114, 256, 59, 66, 4241, 4242, 25024, 97, 114, 59, 26963, 256, 112, 117, 4251, 4254, 102, 59, 24861, 110, 100, 73, 109, 112, 108, 105, 101, 115, 59, 26992, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25051, 256, 99, 104, 4281, 4284, 114, 59, 24859, 59, 25009, 108, 101, 68, 101, 108, 97, 121, 101, 100, 59, 27124, 1664, 72, 79, 97, 99, 102, 104, 105, 109, 111, 113, 115, 116, 117, 4324, 4337, 4343, 4349, 4377, 4382, 4433, 4438, 4449, 4455, 4533, 4539, 4543, 256, 67, 99, 4329, 4334, 72, 99, 121, 59, 17449, 121, 59, 17448, 70, 84, 99, 121, 59, 17452, 99, 117, 116, 101, 59, 16730, 640, 59, 97, 101, 105, 121, 4360, 4361, 4366, 4371, 4375, 27324, 114, 111, 110, 59, 16736, 100, 105, 108, 59, 16734, 114, 99, 59, 16732, 59, 17441, 114, 59, 49152, 55349, 56598, 111, 114, 116, 512, 68, 76, 82, 85, 4394, 4404, 4414, 4425, 111, 119, 110, 65, 114, 114, 111, 119, 187, 1054, 101, 102, 116, 65, 114, 114, 111, 119, 187, 2202, 105, 103, 104, 116, 65, 114, 114, 111, 119, 187, 4061, 112, 65, 114, 114, 111, 119, 59, 24977, 103, 109, 97, 59, 17315, 97, 108, 108, 67, 105, 114, 99, 108, 101, 59, 25112, 112, 102, 59, 49152, 55349, 56650, 626, 4461, 0, 0, 4464, 116, 59, 25114, 97, 114, 101, 512, 59, 73, 83, 85, 4475, 4476, 4489, 4527, 26017, 110, 116, 101, 114, 115, 101, 99, 116, 105, 111, 110, 59, 25235, 117, 256, 98, 112, 4495, 4510, 115, 101, 116, 256, 59, 69, 4503, 4504, 25231, 113, 117, 97, 108, 59, 25233, 101, 114, 115, 101, 116, 256, 59, 69, 4520, 4521, 25232, 113, 117, 97, 108, 59, 25234, 110, 105, 111, 110, 59, 25236, 99, 114, 59, 49152, 55349, 56494, 97, 114, 59, 25286, 512, 98, 99, 109, 112, 4552, 4571, 4617, 4619, 256, 59, 115, 4557, 4558, 25296, 101, 116, 256, 59, 69, 4557, 4565, 113, 117, 97, 108, 59, 25222, 256, 99, 104, 4576, 4613, 101, 101, 100, 115, 512, 59, 69, 83, 84, 4589, 4590, 4596, 4607, 25211, 113, 117, 97, 108, 59, 27312, 108, 97, 110, 116, 69, 113, 117, 97, 108, 59, 25213, 105, 108, 100, 101, 59, 25215, 84, 104, 225, 3980, 59, 25105, 384, 59, 101, 115, 4626, 4627, 4643, 25297, 114, 115, 101, 116, 256, 59, 69, 4636, 4637, 25219, 113, 117, 97, 108, 59, 25223, 101, 116, 187, 4627, 1408, 72, 82, 83, 97, 99, 102, 104, 105, 111, 114, 115, 4670, 4676, 4681, 4693, 4702, 4721, 4726, 4767, 4802, 4808, 4817, 79, 82, 78, 32827, 222, 16606, 65, 68, 69, 59, 24866, 256, 72, 99, 4686, 4690, 99, 121, 59, 17419, 121, 59, 17446, 256, 98, 117, 4698, 4700, 59, 16393, 59, 17316, 384, 97, 101, 121, 4709, 4714, 4719, 114, 111, 110, 59, 16740, 100, 105, 108, 59, 16738, 59, 17442, 114, 59, 49152, 55349, 56599, 256, 101, 105, 4731, 4745, 498, 4736, 0, 4743, 101, 102, 111, 114, 101, 59, 25140, 97, 59, 17304, 256, 99, 110, 4750, 4760, 107, 83, 112, 97, 99, 101, 59, 49152, 8287, 8202, 83, 112, 97, 99, 101, 59, 24585, 108, 100, 101, 512, 59, 69, 70, 84, 4779, 4780, 4786, 4796, 25148, 113, 117, 97, 108, 59, 25155, 117, 108, 108, 69, 113, 117, 97, 108, 59, 25157, 105, 108, 100, 101, 59, 25160, 112, 102, 59, 49152, 55349, 56651, 105, 112, 108, 101, 68, 111, 116, 59, 24795, 256, 99, 116, 4822, 4827, 114, 59, 49152, 55349, 56495, 114, 111, 107, 59, 16742, 2785, 4855, 4878, 4890, 4902, 0, 4908, 4913, 0, 0, 0, 0, 0, 4920, 4925, 4983, 4997, 0, 5119, 5124, 5130, 5136, 256, 99, 114, 4859, 4865, 117, 116, 101, 32827, 218, 16602, 114, 256, 59, 111, 4871, 4872, 24991, 99, 105, 114, 59, 26953, 114, 483, 4883, 0, 4886, 121, 59, 17422, 118, 101, 59, 16748, 256, 105, 121, 4894, 4899, 114, 99, 32827, 219, 16603, 59, 17443, 98, 108, 97, 99, 59, 16752, 114, 59, 49152, 55349, 56600, 114, 97, 118, 101, 32827, 217, 16601, 97, 99, 114, 59, 16746, 256, 100, 105, 4929, 4969, 101, 114, 256, 66, 80, 4936, 4957, 256, 97, 114, 4941, 4944, 114, 59, 16479, 97, 99, 256, 101, 107, 4951, 4953, 59, 25567, 101, 116, 59, 25525, 97, 114, 101, 110, 116, 104, 101, 115, 105, 115, 59, 25565, 111, 110, 256, 59, 80, 4976, 4977, 25283, 108, 117, 115, 59, 25230, 256, 103, 112, 4987, 4991, 111, 110, 59, 16754, 102, 59, 49152, 55349, 56652, 1024, 65, 68, 69, 84, 97, 100, 112, 115, 5013, 5038, 5048, 5060, 1e3, 5074, 5079, 5107, 114, 114, 111, 119, 384, 59, 66, 68, 4432, 5024, 5028, 97, 114, 59, 26898, 111, 119, 110, 65, 114, 114, 111, 119, 59, 25029, 111, 119, 110, 65, 114, 114, 111, 119, 59, 24981, 113, 117, 105, 108, 105, 98, 114, 105, 117, 109, 59, 26990, 101, 101, 256, 59, 65, 5067, 5068, 25253, 114, 114, 111, 119, 59, 24997, 111, 119, 110, 225, 1011, 101, 114, 256, 76, 82, 5086, 5096, 101, 102, 116, 65, 114, 114, 111, 119, 59, 24982, 105, 103, 104, 116, 65, 114, 114, 111, 119, 59, 24983, 105, 256, 59, 108, 5113, 5114, 17362, 111, 110, 59, 17317, 105, 110, 103, 59, 16750, 99, 114, 59, 49152, 55349, 56496, 105, 108, 100, 101, 59, 16744, 109, 108, 32827, 220, 16604, 1152, 68, 98, 99, 100, 101, 102, 111, 115, 118, 5159, 5164, 5168, 5171, 5182, 5253, 5258, 5264, 5270, 97, 115, 104, 59, 25259, 97, 114, 59, 27371, 121, 59, 17426, 97, 115, 104, 256, 59, 108, 5179, 5180, 25257, 59, 27366, 256, 101, 114, 5187, 5189, 59, 25281, 384, 98, 116, 121, 5196, 5200, 5242, 97, 114, 59, 24598, 256, 59, 105, 5199, 5205, 99, 97, 108, 512, 66, 76, 83, 84, 5217, 5221, 5226, 5236, 97, 114, 59, 25123, 105, 110, 101, 59, 16508, 101, 112, 97, 114, 97, 116, 111, 114, 59, 26456, 105, 108, 100, 101, 59, 25152, 84, 104, 105, 110, 83, 112, 97, 99, 101, 59, 24586, 114, 59, 49152, 55349, 56601, 112, 102, 59, 49152, 55349, 56653, 99, 114, 59, 49152, 55349, 56497, 100, 97, 115, 104, 59, 25258, 640, 99, 101, 102, 111, 115, 5287, 5292, 5297, 5302, 5308, 105, 114, 99, 59, 16756, 100, 103, 101, 59, 25280, 114, 59, 49152, 55349, 56602, 112, 102, 59, 49152, 55349, 56654, 99, 114, 59, 49152, 55349, 56498, 512, 102, 105, 111, 115, 5323, 5328, 5330, 5336, 114, 59, 49152, 55349, 56603, 59, 17310, 112, 102, 59, 49152, 55349, 56655, 99, 114, 59, 49152, 55349, 56499, 1152, 65, 73, 85, 97, 99, 102, 111, 115, 117, 5361, 5365, 5369, 5373, 5380, 5391, 5396, 5402, 5408, 99, 121, 59, 17455, 99, 121, 59, 17415, 99, 121, 59, 17454, 99, 117, 116, 101, 32827, 221, 16605, 256, 105, 121, 5385, 5389, 114, 99, 59, 16758, 59, 17451, 114, 59, 49152, 55349, 56604, 112, 102, 59, 49152, 55349, 56656, 99, 114, 59, 49152, 55349, 56500, 109, 108, 59, 16760, 1024, 72, 97, 99, 100, 101, 102, 111, 115, 5429, 5433, 5439, 5451, 5455, 5469, 5472, 5476, 99, 121, 59, 17430, 99, 117, 116, 101, 59, 16761, 256, 97, 121, 5444, 5449, 114, 111, 110, 59, 16765, 59, 17431, 111, 116, 59, 16763, 498, 5460, 0, 5467, 111, 87, 105, 100, 116, 232, 2777, 97, 59, 17302, 114, 59, 24872, 112, 102, 59, 24868, 99, 114, 59, 49152, 55349, 56501, 3041, 5507, 5514, 5520, 0, 5552, 5558, 5567, 0, 0, 0, 0, 5574, 5595, 5611, 5727, 5741, 0, 5781, 5787, 5810, 5817, 0, 5822, 99, 117, 116, 101, 32827, 225, 16609, 114, 101, 118, 101, 59, 16643, 768, 59, 69, 100, 105, 117, 121, 5532, 5533, 5537, 5539, 5544, 5549, 25150, 59, 49152, 8766, 819, 59, 25151, 114, 99, 32827, 226, 16610, 116, 101, 32955, 180, 774, 59, 17456, 108, 105, 103, 32827, 230, 16614, 256, 59, 114, 178, 5562, 59, 49152, 55349, 56606, 114, 97, 118, 101, 32827, 224, 16608, 256, 101, 112, 5578, 5590, 256, 102, 112, 5583, 5588, 115, 121, 109, 59, 24885, 232, 5587, 104, 97, 59, 17329, 256, 97, 112, 5599, 99, 256, 99, 108, 5604, 5607, 114, 59, 16641, 103, 59, 27199, 612, 5616, 0, 0, 5642, 640, 59, 97, 100, 115, 118, 5626, 5627, 5631, 5633, 5639, 25127, 110, 100, 59, 27221, 59, 27228, 108, 111, 112, 101, 59, 27224, 59, 27226, 896, 59, 101, 108, 109, 114, 115, 122, 5656, 5657, 5659, 5662, 5695, 5711, 5721, 25120, 59, 27044, 101, 187, 5657, 115, 100, 256, 59, 97, 5669, 5670, 25121, 1121, 5680, 5682, 5684, 5686, 5688, 5690, 5692, 5694, 59, 27048, 59, 27049, 59, 27050, 59, 27051, 59, 27052, 59, 27053, 59, 27054, 59, 27055, 116, 256, 59, 118, 5701, 5702, 25119, 98, 256, 59, 100, 5708, 5709, 25278, 59, 27037, 256, 112, 116, 5716, 5719, 104, 59, 25122, 187, 185, 97, 114, 114, 59, 25468, 256, 103, 112, 5731, 5735, 111, 110, 59, 16645, 102, 59, 49152, 55349, 56658, 896, 59, 69, 97, 101, 105, 111, 112, 4801, 5755, 5757, 5762, 5764, 5767, 5770, 59, 27248, 99, 105, 114, 59, 27247, 59, 25162, 100, 59, 25163, 115, 59, 16423, 114, 111, 120, 256, 59, 101, 4801, 5778, 241, 5763, 105, 110, 103, 32827, 229, 16613, 384, 99, 116, 121, 5793, 5798, 5800, 114, 59, 49152, 55349, 56502, 59, 16426, 109, 112, 256, 59, 101, 4801, 5807, 241, 648, 105, 108, 100, 101, 32827, 227, 16611, 109, 108, 32827, 228, 16612, 256, 99, 105, 5826, 5832, 111, 110, 105, 110, 244, 626, 110, 116, 59, 27153, 2048, 78, 97, 98, 99, 100, 101, 102, 105, 107, 108, 110, 111, 112, 114, 115, 117, 5869, 5873, 5936, 5948, 5955, 5960, 6008, 6013, 6112, 6118, 6201, 6224, 5901, 6461, 6472, 6512, 111, 116, 59, 27373, 256, 99, 114, 5878, 5918, 107, 512, 99, 101, 112, 115, 5888, 5893, 5901, 5907, 111, 110, 103, 59, 25164, 112, 115, 105, 108, 111, 110, 59, 17398, 114, 105, 109, 101, 59, 24629, 105, 109, 256, 59, 101, 5914, 5915, 25149, 113, 59, 25293, 374, 5922, 5926, 101, 101, 59, 25277, 101, 100, 256, 59, 103, 5932, 5933, 25349, 101, 187, 5933, 114, 107, 256, 59, 116, 4956, 5943, 98, 114, 107, 59, 25526, 256, 111, 121, 5889, 5953, 59, 17457, 113, 117, 111, 59, 24606, 640, 99, 109, 112, 114, 116, 5971, 5979, 5985, 5988, 5992, 97, 117, 115, 256, 59, 101, 266, 265, 112, 116, 121, 118, 59, 27056, 115, 233, 5900, 110, 111, 245, 275, 384, 97, 104, 119, 5999, 6001, 6003, 59, 17330, 59, 24886, 101, 101, 110, 59, 25196, 114, 59, 49152, 55349, 56607, 103, 896, 99, 111, 115, 116, 117, 118, 119, 6029, 6045, 6067, 6081, 6101, 6107, 6110, 384, 97, 105, 117, 6036, 6038, 6042, 240, 1888, 114, 99, 59, 26095, 112, 187, 4977, 384, 100, 112, 116, 6052, 6056, 6061, 111, 116, 59, 27136, 108, 117, 115, 59, 27137, 105, 109, 101, 115, 59, 27138, 625, 6073, 0, 0, 6078, 99, 117, 112, 59, 27142, 97, 114, 59, 26117, 114, 105, 97, 110, 103, 108, 101, 256, 100, 117, 6093, 6098, 111, 119, 110, 59, 26045, 112, 59, 26035, 112, 108, 117, 115, 59, 27140, 101, 229, 5188, 229, 5293, 97, 114, 111, 119, 59, 26893, 384, 97, 107, 111, 6125, 6182, 6197, 256, 99, 110, 6130, 6179, 107, 384, 108, 115, 116, 6138, 1451, 6146, 111, 122, 101, 110, 103, 101, 59, 27115, 114, 105, 97, 110, 103, 108, 101, 512, 59, 100, 108, 114, 6162, 6163, 6168, 6173, 26036, 111, 119, 110, 59, 26046, 101, 102, 116, 59, 26050, 105, 103, 104, 116, 59, 26040, 107, 59, 25635, 433, 6187, 0, 6195, 434, 6191, 0, 6193, 59, 26002, 59, 26001, 52, 59, 26003, 99, 107, 59, 25992, 256, 101, 111, 6206, 6221, 256, 59, 113, 6211, 6214, 49152, 61, 8421, 117, 105, 118, 59, 49152, 8801, 8421, 116, 59, 25360, 512, 112, 116, 119, 120, 6233, 6238, 6247, 6252, 102, 59, 49152, 55349, 56659, 256, 59, 116, 5067, 6243, 111, 109, 187, 5068, 116, 105, 101, 59, 25288, 1536, 68, 72, 85, 86, 98, 100, 104, 109, 112, 116, 117, 118, 6277, 6294, 6314, 6331, 6359, 6363, 6380, 6399, 6405, 6410, 6416, 6433, 512, 76, 82, 108, 114, 6286, 6288, 6290, 6292, 59, 25943, 59, 25940, 59, 25942, 59, 25939, 640, 59, 68, 85, 100, 117, 6305, 6306, 6308, 6310, 6312, 25936, 59, 25958, 59, 25961, 59, 25956, 59, 25959, 512, 76, 82, 108, 114, 6323, 6325, 6327, 6329, 59, 25949, 59, 25946, 59, 25948, 59, 25945, 896, 59, 72, 76, 82, 104, 108, 114, 6346, 6347, 6349, 6351, 6353, 6355, 6357, 25937, 59, 25964, 59, 25955, 59, 25952, 59, 25963, 59, 25954, 59, 25951, 111, 120, 59, 27081, 512, 76, 82, 108, 114, 6372, 6374, 6376, 6378, 59, 25941, 59, 25938, 59, 25872, 59, 25868, 640, 59, 68, 85, 100, 117, 1725, 6391, 6393, 6395, 6397, 59, 25957, 59, 25960, 59, 25900, 59, 25908, 105, 110, 117, 115, 59, 25247, 108, 117, 115, 59, 25246, 105, 109, 101, 115, 59, 25248, 512, 76, 82, 108, 114, 6425, 6427, 6429, 6431, 59, 25947, 59, 25944, 59, 25880, 59, 25876, 896, 59, 72, 76, 82, 104, 108, 114, 6448, 6449, 6451, 6453, 6455, 6457, 6459, 25858, 59, 25962, 59, 25953, 59, 25950, 59, 25916, 59, 25892, 59, 25884, 256, 101, 118, 291, 6466, 98, 97, 114, 32827, 166, 16550, 512, 99, 101, 105, 111, 6481, 6486, 6490, 6496, 114, 59, 49152, 55349, 56503, 109, 105, 59, 24655, 109, 256, 59, 101, 5914, 5916, 108, 384, 59, 98, 104, 6504, 6505, 6507, 16476, 59, 27077, 115, 117, 98, 59, 26568, 364, 6516, 6526, 108, 256, 59, 101, 6521, 6522, 24610, 116, 187, 6522, 112, 384, 59, 69, 101, 303, 6533, 6535, 59, 27310, 256, 59, 113, 1756, 1755, 3297, 6567, 0, 6632, 6673, 6677, 6706, 0, 6711, 6736, 0, 0, 6836, 0, 0, 6849, 0, 0, 6945, 6958, 6989, 6994, 0, 7165, 0, 7180, 384, 99, 112, 114, 6573, 6578, 6621, 117, 116, 101, 59, 16647, 768, 59, 97, 98, 99, 100, 115, 6591, 6592, 6596, 6602, 6613, 6617, 25129, 110, 100, 59, 27204, 114, 99, 117, 112, 59, 27209, 256, 97, 117, 6607, 6610, 112, 59, 27211, 112, 59, 27207, 111, 116, 59, 27200, 59, 49152, 8745, 65024, 256, 101, 111, 6626, 6629, 116, 59, 24641, 238, 1683, 512, 97, 101, 105, 117, 6640, 6651, 6657, 6661, 496, 6645, 0, 6648, 115, 59, 27213, 111, 110, 59, 16653, 100, 105, 108, 32827, 231, 16615, 114, 99, 59, 16649, 112, 115, 256, 59, 115, 6668, 6669, 27212, 109, 59, 27216, 111, 116, 59, 16651, 384, 100, 109, 110, 6683, 6688, 6694, 105, 108, 32955, 184, 429, 112, 116, 121, 118, 59, 27058, 116, 33024, 162, 59, 101, 6701, 6702, 16546, 114, 228, 434, 114, 59, 49152, 55349, 56608, 384, 99, 101, 105, 6717, 6720, 6733, 121, 59, 17479, 99, 107, 256, 59, 109, 6727, 6728, 26387, 97, 114, 107, 187, 6728, 59, 17351, 114, 896, 59, 69, 99, 101, 102, 109, 115, 6751, 6752, 6754, 6763, 6820, 6826, 6830, 26059, 59, 27075, 384, 59, 101, 108, 6761, 6762, 6765, 17094, 113, 59, 25175, 101, 609, 6772, 0, 0, 6792, 114, 114, 111, 119, 256, 108, 114, 6780, 6785, 101, 102, 116, 59, 25018, 105, 103, 104, 116, 59, 25019, 640, 82, 83, 97, 99, 100, 6802, 6804, 6806, 6810, 6815, 187, 3911, 59, 25800, 115, 116, 59, 25243, 105, 114, 99, 59, 25242, 97, 115, 104, 59, 25245, 110, 105, 110, 116, 59, 27152, 105, 100, 59, 27375, 99, 105, 114, 59, 27074, 117, 98, 115, 256, 59, 117, 6843, 6844, 26211, 105, 116, 187, 6844, 748, 6855, 6868, 6906, 0, 6922, 111, 110, 256, 59, 101, 6861, 6862, 16442, 256, 59, 113, 199, 198, 621, 6873, 0, 0, 6882, 97, 256, 59, 116, 6878, 6879, 16428, 59, 16448, 384, 59, 102, 108, 6888, 6889, 6891, 25089, 238, 4448, 101, 256, 109, 120, 6897, 6902, 101, 110, 116, 187, 6889, 101, 243, 589, 487, 6910, 0, 6919, 256, 59, 100, 4795, 6914, 111, 116, 59, 27245, 110, 244, 582, 384, 102, 114, 121, 6928, 6932, 6935, 59, 49152, 55349, 56660, 111, 228, 596, 33024, 169, 59, 115, 341, 6941, 114, 59, 24855, 256, 97, 111, 6949, 6953, 114, 114, 59, 25013, 115, 115, 59, 26391, 256, 99, 117, 6962, 6967, 114, 59, 49152, 55349, 56504, 256, 98, 112, 6972, 6980, 256, 59, 101, 6977, 6978, 27343, 59, 27345, 256, 59, 101, 6985, 6986, 27344, 59, 27346, 100, 111, 116, 59, 25327, 896, 100, 101, 108, 112, 114, 118, 119, 7008, 7020, 7031, 7042, 7084, 7124, 7161, 97, 114, 114, 256, 108, 114, 7016, 7018, 59, 26936, 59, 26933, 624, 7026, 0, 0, 7029, 114, 59, 25310, 99, 59, 25311, 97, 114, 114, 256, 59, 112, 7039, 7040, 25014, 59, 26941, 768, 59, 98, 99, 100, 111, 115, 7055, 7056, 7062, 7073, 7077, 7080, 25130, 114, 99, 97, 112, 59, 27208, 256, 97, 117, 7067, 7070, 112, 59, 27206, 112, 59, 27210, 111, 116, 59, 25229, 114, 59, 27205, 59, 49152, 8746, 65024, 512, 97, 108, 114, 118, 7093, 7103, 7134, 7139, 114, 114, 256, 59, 109, 7100, 7101, 25015, 59, 26940, 121, 384, 101, 118, 119, 7111, 7124, 7128, 113, 624, 7118, 0, 0, 7122, 114, 101, 227, 7027, 117, 227, 7029, 101, 101, 59, 25294, 101, 100, 103, 101, 59, 25295, 101, 110, 32827, 164, 16548, 101, 97, 114, 114, 111, 119, 256, 108, 114, 7150, 7155, 101, 102, 116, 187, 7040, 105, 103, 104, 116, 187, 7101, 101, 228, 7133, 256, 99, 105, 7169, 7175, 111, 110, 105, 110, 244, 503, 110, 116, 59, 25137, 108, 99, 116, 121, 59, 25389, 2432, 65, 72, 97, 98, 99, 100, 101, 102, 104, 105, 106, 108, 111, 114, 115, 116, 117, 119, 122, 7224, 7227, 7231, 7261, 7273, 7285, 7306, 7326, 7340, 7351, 7419, 7423, 7437, 7547, 7569, 7595, 7611, 7622, 7629, 114, 242, 897, 97, 114, 59, 26981, 512, 103, 108, 114, 115, 7240, 7245, 7250, 7252, 103, 101, 114, 59, 24608, 101, 116, 104, 59, 24888, 242, 4403, 104, 256, 59, 118, 7258, 7259, 24592, 187, 2314, 363, 7265, 7271, 97, 114, 111, 119, 59, 26895, 97, 227, 789, 256, 97, 121, 7278, 7283, 114, 111, 110, 59, 16655, 59, 17460, 384, 59, 97, 111, 818, 7292, 7300, 256, 103, 114, 703, 7297, 114, 59, 25034, 116, 115, 101, 113, 59, 27255, 384, 103, 108, 109, 7313, 7316, 7320, 32827, 176, 16560, 116, 97, 59, 17332, 112, 116, 121, 118, 59, 27057, 256, 105, 114, 7331, 7336, 115, 104, 116, 59, 27007, 59, 49152, 55349, 56609, 97, 114, 256, 108, 114, 7347, 7349, 187, 2268, 187, 4126, 640, 97, 101, 103, 115, 118, 7362, 888, 7382, 7388, 7392, 109, 384, 59, 111, 115, 806, 7370, 7380, 110, 100, 256, 59, 115, 806, 7377, 117, 105, 116, 59, 26214, 97, 109, 109, 97, 59, 17373, 105, 110, 59, 25330, 384, 59, 105, 111, 7399, 7400, 7416, 16631, 100, 101, 33024, 247, 59, 111, 7399, 7408, 110, 116, 105, 109, 101, 115, 59, 25287, 110, 248, 7415, 99, 121, 59, 17490, 99, 623, 7430, 0, 0, 7434, 114, 110, 59, 25374, 111, 112, 59, 25357, 640, 108, 112, 116, 117, 119, 7448, 7453, 7458, 7497, 7509, 108, 97, 114, 59, 16420, 102, 59, 49152, 55349, 56661, 640, 59, 101, 109, 112, 115, 779, 7469, 7479, 7485, 7490, 113, 256, 59, 100, 850, 7475, 111, 116, 59, 25169, 105, 110, 117, 115, 59, 25144, 108, 117, 115, 59, 25108, 113, 117, 97, 114, 101, 59, 25249, 98, 108, 101, 98, 97, 114, 119, 101, 100, 103, 229, 250, 110, 384, 97, 100, 104, 4398, 7517, 7527, 111, 119, 110, 97, 114, 114, 111, 119, 243, 7299, 97, 114, 112, 111, 111, 110, 256, 108, 114, 7538, 7542, 101, 102, 244, 7348, 105, 103, 104, 244, 7350, 354, 7551, 7557, 107, 97, 114, 111, 247, 3906, 623, 7562, 0, 0, 7566, 114, 110, 59, 25375, 111, 112, 59, 25356, 384, 99, 111, 116, 7576, 7587, 7590, 256, 114, 121, 7581, 7585, 59, 49152, 55349, 56505, 59, 17493, 108, 59, 27126, 114, 111, 107, 59, 16657, 256, 100, 114, 7600, 7604, 111, 116, 59, 25329, 105, 256, 59, 102, 7610, 6166, 26047, 256, 97, 104, 7616, 7619, 114, 242, 1065, 97, 242, 4006, 97, 110, 103, 108, 101, 59, 27046, 256, 99, 105, 7634, 7637, 121, 59, 17503, 103, 114, 97, 114, 114, 59, 26623, 2304, 68, 97, 99, 100, 101, 102, 103, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 120, 7681, 7689, 7705, 7736, 1400, 7740, 7753, 7777, 7806, 7845, 7855, 7869, 7905, 7978, 7991, 8004, 8014, 8026, 256, 68, 111, 7686, 7476, 111, 244, 7305, 256, 99, 115, 7694, 7700, 117, 116, 101, 32827, 233, 16617, 116, 101, 114, 59, 27246, 512, 97, 105, 111, 121, 7714, 7719, 7729, 7734, 114, 111, 110, 59, 16667, 114, 256, 59, 99, 7725, 7726, 25174, 32827, 234, 16618, 108, 111, 110, 59, 25173, 59, 17485, 111, 116, 59, 16663, 256, 68, 114, 7745, 7749, 111, 116, 59, 25170, 59, 49152, 55349, 56610, 384, 59, 114, 115, 7760, 7761, 7767, 27290, 97, 118, 101, 32827, 232, 16616, 256, 59, 100, 7772, 7773, 27286, 111, 116, 59, 27288, 512, 59, 105, 108, 115, 7786, 7787, 7794, 7796, 27289, 110, 116, 101, 114, 115, 59, 25575, 59, 24851, 256, 59, 100, 7801, 7802, 27285, 111, 116, 59, 27287, 384, 97, 112, 115, 7813, 7817, 7831, 99, 114, 59, 16659, 116, 121, 384, 59, 115, 118, 7826, 7827, 7829, 25093, 101, 116, 187, 7827, 112, 256, 49, 59, 7837, 7844, 307, 7841, 7843, 59, 24580, 59, 24581, 24579, 256, 103, 115, 7850, 7852, 59, 16715, 112, 59, 24578, 256, 103, 112, 7860, 7864, 111, 110, 59, 16665, 102, 59, 49152, 55349, 56662, 384, 97, 108, 115, 7876, 7886, 7890, 114, 256, 59, 115, 7882, 7883, 25301, 108, 59, 27107, 117, 115, 59, 27249, 105, 384, 59, 108, 118, 7898, 7899, 7903, 17333, 111, 110, 187, 7899, 59, 17397, 512, 99, 115, 117, 118, 7914, 7923, 7947, 7971, 256, 105, 111, 7919, 7729, 114, 99, 187, 7726, 617, 7929, 0, 0, 7931, 237, 1352, 97, 110, 116, 256, 103, 108, 7938, 7942, 116, 114, 187, 7773, 101, 115, 115, 187, 7802, 384, 97, 101, 105, 7954, 7958, 7962, 108, 115, 59, 16445, 115, 116, 59, 25183, 118, 256, 59, 68, 565, 7968, 68, 59, 27256, 112, 97, 114, 115, 108, 59, 27109, 256, 68, 97, 7983, 7987, 111, 116, 59, 25171, 114, 114, 59, 26993, 384, 99, 100, 105, 7998, 8001, 7928, 114, 59, 24879, 111, 244, 850, 256, 97, 104, 8009, 8011, 59, 17335, 32827, 240, 16624, 256, 109, 114, 8019, 8023, 108, 32827, 235, 16619, 111, 59, 24748, 384, 99, 105, 112, 8033, 8036, 8039, 108, 59, 16417, 115, 244, 1390, 256, 101, 111, 8044, 8052, 99, 116, 97, 116, 105, 111, 238, 1369, 110, 101, 110, 116, 105, 97, 108, 229, 1401, 2529, 8082, 0, 8094, 0, 8097, 8103, 0, 0, 8134, 8140, 0, 8147, 0, 8166, 8170, 8192, 0, 8200, 8282, 108, 108, 105, 110, 103, 100, 111, 116, 115, 101, 241, 7748, 121, 59, 17476, 109, 97, 108, 101, 59, 26176, 384, 105, 108, 114, 8109, 8115, 8129, 108, 105, 103, 59, 32768, 64259, 617, 8121, 0, 0, 8125, 103, 59, 32768, 64256, 105, 103, 59, 32768, 64260, 59, 49152, 55349, 56611, 108, 105, 103, 59, 32768, 64257, 108, 105, 103, 59, 49152, 102, 106, 384, 97, 108, 116, 8153, 8156, 8161, 116, 59, 26221, 105, 103, 59, 32768, 64258, 110, 115, 59, 26033, 111, 102, 59, 16786, 496, 8174, 0, 8179, 102, 59, 49152, 55349, 56663, 256, 97, 107, 1471, 8183, 256, 59, 118, 8188, 8189, 25300, 59, 27353, 97, 114, 116, 105, 110, 116, 59, 27149, 256, 97, 111, 8204, 8277, 256, 99, 115, 8209, 8274, 945, 8218, 8240, 8248, 8261, 8264, 0, 8272, 946, 8226, 8229, 8231, 8234, 8236, 0, 8238, 32827, 189, 16573, 59, 24915, 32827, 188, 16572, 59, 24917, 59, 24921, 59, 24923, 435, 8244, 0, 8246, 59, 24916, 59, 24918, 692, 8254, 8257, 0, 0, 8259, 32827, 190, 16574, 59, 24919, 59, 24924, 53, 59, 24920, 438, 8268, 0, 8270, 59, 24922, 59, 24925, 56, 59, 24926, 108, 59, 24644, 119, 110, 59, 25378, 99, 114, 59, 49152, 55349, 56507, 2176, 69, 97, 98, 99, 100, 101, 102, 103, 105, 106, 108, 110, 111, 114, 115, 116, 118, 8322, 8329, 8351, 8357, 8368, 8372, 8432, 8437, 8442, 8447, 8451, 8466, 8504, 791, 8510, 8530, 8606, 256, 59, 108, 1613, 8327, 59, 27276, 384, 99, 109, 112, 8336, 8341, 8349, 117, 116, 101, 59, 16885, 109, 97, 256, 59, 100, 8348, 7386, 17331, 59, 27270, 114, 101, 118, 101, 59, 16671, 256, 105, 121, 8362, 8366, 114, 99, 59, 16669, 59, 17459, 111, 116, 59, 16673, 512, 59, 108, 113, 115, 1598, 1602, 8381, 8393, 384, 59, 113, 115, 1598, 1612, 8388, 108, 97, 110, 244, 1637, 512, 59, 99, 100, 108, 1637, 8402, 8405, 8421, 99, 59, 27305, 111, 116, 256, 59, 111, 8412, 8413, 27264, 256, 59, 108, 8418, 8419, 27266, 59, 27268, 256, 59, 101, 8426, 8429, 49152, 8923, 65024, 115, 59, 27284, 114, 59, 49152, 55349, 56612, 256, 59, 103, 1651, 1563, 109, 101, 108, 59, 24887, 99, 121, 59, 17491, 512, 59, 69, 97, 106, 1626, 8460, 8462, 8464, 59, 27282, 59, 27301, 59, 27300, 512, 69, 97, 101, 115, 8475, 8477, 8489, 8500, 59, 25193, 112, 256, 59, 112, 8483, 8484, 27274, 114, 111, 120, 187, 8484, 256, 59, 113, 8494, 8495, 27272, 256, 59, 113, 8494, 8475, 105, 109, 59, 25319, 112, 102, 59, 49152, 55349, 56664, 256, 99, 105, 8515, 8518, 114, 59, 24842, 109, 384, 59, 101, 108, 1643, 8526, 8528, 59, 27278, 59, 27280, 33536, 62, 59, 99, 100, 108, 113, 114, 1518, 8544, 8554, 8558, 8563, 8569, 256, 99, 105, 8549, 8551, 59, 27303, 114, 59, 27258, 111, 116, 59, 25303, 80, 97, 114, 59, 27029, 117, 101, 115, 116, 59, 27260, 640, 97, 100, 101, 108, 115, 8580, 8554, 8592, 1622, 8603, 496, 8585, 0, 8590, 112, 114, 111, 248, 8350, 114, 59, 27e3, 113, 256, 108, 113, 1599, 8598, 108, 101, 115, 243, 8328, 105, 237, 1643, 256, 101, 110, 8611, 8621, 114, 116, 110, 101, 113, 113, 59, 49152, 8809, 65024, 197, 8618, 1280, 65, 97, 98, 99, 101, 102, 107, 111, 115, 121, 8644, 8647, 8689, 8693, 8698, 8728, 8733, 8751, 8808, 8829, 114, 242, 928, 512, 105, 108, 109, 114, 8656, 8660, 8663, 8667, 114, 115, 240, 5252, 102, 187, 8228, 105, 108, 244, 1705, 256, 100, 114, 8672, 8676, 99, 121, 59, 17482, 384, 59, 99, 119, 2292, 8683, 8687, 105, 114, 59, 26952, 59, 25005, 97, 114, 59, 24847, 105, 114, 99, 59, 16677, 384, 97, 108, 114, 8705, 8718, 8723, 114, 116, 115, 256, 59, 117, 8713, 8714, 26213, 105, 116, 187, 8714, 108, 105, 112, 59, 24614, 99, 111, 110, 59, 25273, 114, 59, 49152, 55349, 56613, 115, 256, 101, 119, 8739, 8745, 97, 114, 111, 119, 59, 26917, 97, 114, 111, 119, 59, 26918, 640, 97, 109, 111, 112, 114, 8762, 8766, 8771, 8798, 8803, 114, 114, 59, 25087, 116, 104, 116, 59, 25147, 107, 256, 108, 114, 8777, 8787, 101, 102, 116, 97, 114, 114, 111, 119, 59, 25001, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25002, 102, 59, 49152, 55349, 56665, 98, 97, 114, 59, 24597, 384, 99, 108, 116, 8815, 8820, 8824, 114, 59, 49152, 55349, 56509, 97, 115, 232, 8692, 114, 111, 107, 59, 16679, 256, 98, 112, 8834, 8839, 117, 108, 108, 59, 24643, 104, 101, 110, 187, 7259, 2785, 8867, 0, 8874, 0, 8888, 8901, 8910, 0, 8917, 8947, 0, 0, 8952, 8994, 9063, 9058, 9087, 0, 9094, 9130, 9140, 99, 117, 116, 101, 32827, 237, 16621, 384, 59, 105, 121, 1905, 8880, 8885, 114, 99, 32827, 238, 16622, 59, 17464, 256, 99, 120, 8892, 8895, 121, 59, 17461, 99, 108, 32827, 161, 16545, 256, 102, 114, 927, 8905, 59, 49152, 55349, 56614, 114, 97, 118, 101, 32827, 236, 16620, 512, 59, 105, 110, 111, 1854, 8925, 8937, 8942, 256, 105, 110, 8930, 8934, 110, 116, 59, 27148, 116, 59, 25133, 102, 105, 110, 59, 27100, 116, 97, 59, 24873, 108, 105, 103, 59, 16691, 384, 97, 111, 112, 8958, 8986, 8989, 384, 99, 103, 116, 8965, 8968, 8983, 114, 59, 16683, 384, 101, 108, 112, 1823, 8975, 8979, 105, 110, 229, 1934, 97, 114, 244, 1824, 104, 59, 16689, 102, 59, 25271, 101, 100, 59, 16821, 640, 59, 99, 102, 111, 116, 1268, 9004, 9009, 9021, 9025, 97, 114, 101, 59, 24837, 105, 110, 256, 59, 116, 9016, 9017, 25118, 105, 101, 59, 27101, 100, 111, 244, 8985, 640, 59, 99, 101, 108, 112, 1879, 9036, 9040, 9051, 9057, 97, 108, 59, 25274, 256, 103, 114, 9045, 9049, 101, 114, 243, 5475, 227, 9037, 97, 114, 104, 107, 59, 27159, 114, 111, 100, 59, 27196, 512, 99, 103, 112, 116, 9071, 9074, 9078, 9083, 121, 59, 17489, 111, 110, 59, 16687, 102, 59, 49152, 55349, 56666, 97, 59, 17337, 117, 101, 115, 116, 32827, 191, 16575, 256, 99, 105, 9098, 9103, 114, 59, 49152, 55349, 56510, 110, 640, 59, 69, 100, 115, 118, 1268, 9115, 9117, 9121, 1267, 59, 25337, 111, 116, 59, 25333, 256, 59, 118, 9126, 9127, 25332, 59, 25331, 256, 59, 105, 1911, 9134, 108, 100, 101, 59, 16681, 491, 9144, 0, 9148, 99, 121, 59, 17494, 108, 32827, 239, 16623, 768, 99, 102, 109, 111, 115, 117, 9164, 9175, 9180, 9185, 9191, 9205, 256, 105, 121, 9169, 9173, 114, 99, 59, 16693, 59, 17465, 114, 59, 49152, 55349, 56615, 97, 116, 104, 59, 16951, 112, 102, 59, 49152, 55349, 56667, 483, 9196, 0, 9201, 114, 59, 49152, 55349, 56511, 114, 99, 121, 59, 17496, 107, 99, 121, 59, 17492, 1024, 97, 99, 102, 103, 104, 106, 111, 115, 9227, 9238, 9250, 9255, 9261, 9265, 9269, 9275, 112, 112, 97, 256, 59, 118, 9235, 9236, 17338, 59, 17392, 256, 101, 121, 9243, 9248, 100, 105, 108, 59, 16695, 59, 17466, 114, 59, 49152, 55349, 56616, 114, 101, 101, 110, 59, 16696, 99, 121, 59, 17477, 99, 121, 59, 17500, 112, 102, 59, 49152, 55349, 56668, 99, 114, 59, 49152, 55349, 56512, 2944, 65, 66, 69, 72, 97, 98, 99, 100, 101, 102, 103, 104, 106, 108, 109, 110, 111, 112, 114, 115, 116, 117, 118, 9328, 9345, 9350, 9357, 9361, 9486, 9533, 9562, 9600, 9806, 9822, 9829, 9849, 9853, 9882, 9906, 9944, 10077, 10088, 10123, 10176, 10241, 10258, 384, 97, 114, 116, 9335, 9338, 9340, 114, 242, 2502, 242, 917, 97, 105, 108, 59, 26907, 97, 114, 114, 59, 26894, 256, 59, 103, 2452, 9355, 59, 27275, 97, 114, 59, 26978, 2403, 9381, 0, 9386, 0, 9393, 0, 0, 0, 0, 0, 9397, 9402, 0, 9414, 9416, 9421, 0, 9465, 117, 116, 101, 59, 16698, 109, 112, 116, 121, 118, 59, 27060, 114, 97, 238, 2124, 98, 100, 97, 59, 17339, 103, 384, 59, 100, 108, 2190, 9409, 9411, 59, 27025, 229, 2190, 59, 27269, 117, 111, 32827, 171, 16555, 114, 1024, 59, 98, 102, 104, 108, 112, 115, 116, 2201, 9438, 9446, 9449, 9451, 9454, 9457, 9461, 256, 59, 102, 2205, 9443, 115, 59, 26911, 115, 59, 26909, 235, 8786, 112, 59, 25003, 108, 59, 26937, 105, 109, 59, 26995, 108, 59, 24994, 384, 59, 97, 101, 9471, 9472, 9476, 27307, 105, 108, 59, 26905, 256, 59, 115, 9481, 9482, 27309, 59, 49152, 10925, 65024, 384, 97, 98, 114, 9493, 9497, 9501, 114, 114, 59, 26892, 114, 107, 59, 26482, 256, 97, 107, 9506, 9516, 99, 256, 101, 107, 9512, 9514, 59, 16507, 59, 16475, 256, 101, 115, 9521, 9523, 59, 27019, 108, 256, 100, 117, 9529, 9531, 59, 27023, 59, 27021, 512, 97, 101, 117, 121, 9542, 9547, 9558, 9560, 114, 111, 110, 59, 16702, 256, 100, 105, 9552, 9556, 105, 108, 59, 16700, 236, 2224, 226, 9513, 59, 17467, 512, 99, 113, 114, 115, 9571, 9574, 9581, 9597, 97, 59, 26934, 117, 111, 256, 59, 114, 3609, 5958, 256, 100, 117, 9586, 9591, 104, 97, 114, 59, 26983, 115, 104, 97, 114, 59, 26955, 104, 59, 25010, 640, 59, 102, 103, 113, 115, 9611, 9612, 2441, 9715, 9727, 25188, 116, 640, 97, 104, 108, 114, 116, 9624, 9636, 9655, 9666, 9704, 114, 114, 111, 119, 256, 59, 116, 2201, 9633, 97, 233, 9462, 97, 114, 112, 111, 111, 110, 256, 100, 117, 9647, 9652, 111, 119, 110, 187, 1114, 112, 187, 2406, 101, 102, 116, 97, 114, 114, 111, 119, 115, 59, 25031, 105, 103, 104, 116, 384, 97, 104, 115, 9677, 9686, 9694, 114, 114, 111, 119, 256, 59, 115, 2292, 2215, 97, 114, 112, 111, 111, 110, 243, 3992, 113, 117, 105, 103, 97, 114, 114, 111, 247, 8688, 104, 114, 101, 101, 116, 105, 109, 101, 115, 59, 25291, 384, 59, 113, 115, 9611, 2451, 9722, 108, 97, 110, 244, 2476, 640, 59, 99, 100, 103, 115, 2476, 9738, 9741, 9757, 9768, 99, 59, 27304, 111, 116, 256, 59, 111, 9748, 9749, 27263, 256, 59, 114, 9754, 9755, 27265, 59, 27267, 256, 59, 101, 9762, 9765, 49152, 8922, 65024, 115, 59, 27283, 640, 97, 100, 101, 103, 115, 9779, 9785, 9789, 9801, 9803, 112, 112, 114, 111, 248, 9414, 111, 116, 59, 25302, 113, 256, 103, 113, 9795, 9797, 244, 2441, 103, 116, 242, 9356, 244, 2459, 105, 237, 2482, 384, 105, 108, 114, 9813, 2273, 9818, 115, 104, 116, 59, 27004, 59, 49152, 55349, 56617, 256, 59, 69, 2460, 9827, 59, 27281, 353, 9833, 9846, 114, 256, 100, 117, 9650, 9838, 256, 59, 108, 2405, 9843, 59, 26986, 108, 107, 59, 25988, 99, 121, 59, 17497, 640, 59, 97, 99, 104, 116, 2632, 9864, 9867, 9873, 9878, 114, 242, 9665, 111, 114, 110, 101, 242, 7432, 97, 114, 100, 59, 26987, 114, 105, 59, 26106, 256, 105, 111, 9887, 9892, 100, 111, 116, 59, 16704, 117, 115, 116, 256, 59, 97, 9900, 9901, 25520, 99, 104, 101, 187, 9901, 512, 69, 97, 101, 115, 9915, 9917, 9929, 9940, 59, 25192, 112, 256, 59, 112, 9923, 9924, 27273, 114, 111, 120, 187, 9924, 256, 59, 113, 9934, 9935, 27271, 256, 59, 113, 9934, 9915, 105, 109, 59, 25318, 1024, 97, 98, 110, 111, 112, 116, 119, 122, 9961, 9972, 9975, 10010, 10031, 10049, 10055, 10064, 256, 110, 114, 9966, 9969, 103, 59, 26604, 114, 59, 25085, 114, 235, 2241, 103, 384, 108, 109, 114, 9983, 9997, 10004, 101, 102, 116, 256, 97, 114, 2534, 9991, 105, 103, 104, 116, 225, 2546, 97, 112, 115, 116, 111, 59, 26620, 105, 103, 104, 116, 225, 2557, 112, 97, 114, 114, 111, 119, 256, 108, 114, 10021, 10025, 101, 102, 244, 9453, 105, 103, 104, 116, 59, 25004, 384, 97, 102, 108, 10038, 10041, 10045, 114, 59, 27013, 59, 49152, 55349, 56669, 117, 115, 59, 27181, 105, 109, 101, 115, 59, 27188, 353, 10059, 10063, 115, 116, 59, 25111, 225, 4942, 384, 59, 101, 102, 10071, 10072, 6144, 26058, 110, 103, 101, 187, 10072, 97, 114, 256, 59, 108, 10084, 10085, 16424, 116, 59, 27027, 640, 97, 99, 104, 109, 116, 10099, 10102, 10108, 10117, 10119, 114, 242, 2216, 111, 114, 110, 101, 242, 7564, 97, 114, 256, 59, 100, 3992, 10115, 59, 26989, 59, 24590, 114, 105, 59, 25279, 768, 97, 99, 104, 105, 113, 116, 10136, 10141, 2624, 10146, 10158, 10171, 113, 117, 111, 59, 24633, 114, 59, 49152, 55349, 56513, 109, 384, 59, 101, 103, 2482, 10154, 10156, 59, 27277, 59, 27279, 256, 98, 117, 9514, 10163, 111, 256, 59, 114, 3615, 10169, 59, 24602, 114, 111, 107, 59, 16706, 33792, 60, 59, 99, 100, 104, 105, 108, 113, 114, 2091, 10194, 9785, 10204, 10208, 10213, 10218, 10224, 256, 99, 105, 10199, 10201, 59, 27302, 114, 59, 27257, 114, 101, 229, 9714, 109, 101, 115, 59, 25289, 97, 114, 114, 59, 26998, 117, 101, 115, 116, 59, 27259, 256, 80, 105, 10229, 10233, 97, 114, 59, 27030, 384, 59, 101, 102, 10240, 2349, 6171, 26051, 114, 256, 100, 117, 10247, 10253, 115, 104, 97, 114, 59, 26954, 104, 97, 114, 59, 26982, 256, 101, 110, 10263, 10273, 114, 116, 110, 101, 113, 113, 59, 49152, 8808, 65024, 197, 10270, 1792, 68, 97, 99, 100, 101, 102, 104, 105, 108, 110, 111, 112, 115, 117, 10304, 10309, 10370, 10382, 10387, 10400, 10405, 10408, 10458, 10466, 10468, 2691, 10483, 10498, 68, 111, 116, 59, 25146, 512, 99, 108, 112, 114, 10318, 10322, 10339, 10365, 114, 32827, 175, 16559, 256, 101, 116, 10327, 10329, 59, 26178, 256, 59, 101, 10334, 10335, 26400, 115, 101, 187, 10335, 256, 59, 115, 4155, 10344, 116, 111, 512, 59, 100, 108, 117, 4155, 10355, 10359, 10363, 111, 119, 238, 1164, 101, 102, 244, 2319, 240, 5073, 107, 101, 114, 59, 26030, 256, 111, 121, 10375, 10380, 109, 109, 97, 59, 27177, 59, 17468, 97, 115, 104, 59, 24596, 97, 115, 117, 114, 101, 100, 97, 110, 103, 108, 101, 187, 5670, 114, 59, 49152, 55349, 56618, 111, 59, 24871, 384, 99, 100, 110, 10415, 10420, 10441, 114, 111, 32827, 181, 16565, 512, 59, 97, 99, 100, 5220, 10429, 10432, 10436, 115, 244, 5799, 105, 114, 59, 27376, 111, 116, 32955, 183, 437, 117, 115, 384, 59, 98, 100, 10450, 6403, 10451, 25106, 256, 59, 117, 7484, 10456, 59, 27178, 355, 10462, 10465, 112, 59, 27355, 242, 8722, 240, 2689, 256, 100, 112, 10473, 10478, 101, 108, 115, 59, 25255, 102, 59, 49152, 55349, 56670, 256, 99, 116, 10488, 10493, 114, 59, 49152, 55349, 56514, 112, 111, 115, 187, 5533, 384, 59, 108, 109, 10505, 10506, 10509, 17340, 116, 105, 109, 97, 112, 59, 25272, 3072, 71, 76, 82, 86, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 108, 109, 111, 112, 114, 115, 116, 117, 118, 119, 10562, 10579, 10622, 10633, 10648, 10714, 10729, 10773, 10778, 10840, 10845, 10883, 10901, 10916, 10920, 11012, 11015, 11076, 11135, 11182, 11316, 11367, 11388, 11497, 256, 103, 116, 10567, 10571, 59, 49152, 8921, 824, 256, 59, 118, 10576, 3023, 49152, 8811, 8402, 384, 101, 108, 116, 10586, 10610, 10614, 102, 116, 256, 97, 114, 10593, 10599, 114, 114, 111, 119, 59, 25037, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25038, 59, 49152, 8920, 824, 256, 59, 118, 10619, 3143, 49152, 8810, 8402, 105, 103, 104, 116, 97, 114, 114, 111, 119, 59, 25039, 256, 68, 100, 10638, 10643, 97, 115, 104, 59, 25263, 97, 115, 104, 59, 25262, 640, 98, 99, 110, 112, 116, 10659, 10663, 10668, 10673, 10700, 108, 97, 187, 734, 117, 116, 101, 59, 16708, 103, 59, 49152, 8736, 8402, 640, 59, 69, 105, 111, 112, 3460, 10684, 10688, 10693, 10696, 59, 49152, 10864, 824, 100, 59, 49152, 8779, 824, 115, 59, 16713, 114, 111, 248, 3460, 117, 114, 256, 59, 97, 10707, 10708, 26222, 108, 256, 59, 115, 10707, 2872, 499, 10719, 0, 10723, 112, 32955, 160, 2871, 109, 112, 256, 59, 101, 3065, 3072, 640, 97, 101, 111, 117, 121, 10740, 10750, 10755, 10768, 10771, 496, 10745, 0, 10747, 59, 27203, 111, 110, 59, 16712, 100, 105, 108, 59, 16710, 110, 103, 256, 59, 100, 3454, 10762, 111, 116, 59, 49152, 10861, 824, 112, 59, 27202, 59, 17469, 97, 115, 104, 59, 24595, 896, 59, 65, 97, 100, 113, 115, 120, 2962, 10793, 10797, 10811, 10817, 10821, 10832, 114, 114, 59, 25047, 114, 256, 104, 114, 10803, 10806, 107, 59, 26916, 256, 59, 111, 5106, 5104, 111, 116, 59, 49152, 8784, 824, 117, 105, 246, 2915, 256, 101, 105, 10826, 10830, 97, 114, 59, 26920, 237, 2968, 105, 115, 116, 256, 59, 115, 2976, 2975, 114, 59, 49152, 55349, 56619, 512, 69, 101, 115, 116, 3013, 10854, 10873, 10876, 384, 59, 113, 115, 3004, 10861, 3041, 384, 59, 113, 115, 3004, 3013, 10868, 108, 97, 110, 244, 3042, 105, 237, 3050, 256, 59, 114, 2998, 10881, 187, 2999, 384, 65, 97, 112, 10890, 10893, 10897, 114, 242, 10609, 114, 114, 59, 25006, 97, 114, 59, 27378, 384, 59, 115, 118, 3981, 10908, 3980, 256, 59, 100, 10913, 10914, 25340, 59, 25338, 99, 121, 59, 17498, 896, 65, 69, 97, 100, 101, 115, 116, 10935, 10938, 10942, 10946, 10949, 10998, 11001, 114, 242, 10598, 59, 49152, 8806, 824, 114, 114, 59, 24986, 114, 59, 24613, 512, 59, 102, 113, 115, 3131, 10958, 10979, 10991, 116, 256, 97, 114, 10964, 10969, 114, 114, 111, 247, 10945, 105, 103, 104, 116, 97, 114, 114, 111, 247, 10896, 384, 59, 113, 115, 3131, 10938, 10986, 108, 97, 110, 244, 3157, 256, 59, 115, 3157, 10996, 187, 3126, 105, 237, 3165, 256, 59, 114, 3125, 11006, 105, 256, 59, 101, 3098, 3109, 105, 228, 3472, 256, 112, 116, 11020, 11025, 102, 59, 49152, 55349, 56671, 33152, 172, 59, 105, 110, 11033, 11034, 11062, 16556, 110, 512, 59, 69, 100, 118, 2953, 11044, 11048, 11054, 59, 49152, 8953, 824, 111, 116, 59, 49152, 8949, 824, 481, 2953, 11059, 11061, 59, 25335, 59, 25334, 105, 256, 59, 118, 3256, 11068, 481, 3256, 11073, 11075, 59, 25342, 59, 25341, 384, 97, 111, 114, 11083, 11107, 11113, 114, 512, 59, 97, 115, 116, 2939, 11093, 11098, 11103, 108, 108, 101, 236, 2939, 108, 59, 49152, 11005, 8421, 59, 49152, 8706, 824, 108, 105, 110, 116, 59, 27156, 384, 59, 99, 101, 3218, 11120, 11123, 117, 229, 3237, 256, 59, 99, 3224, 11128, 256, 59, 101, 3218, 11133, 241, 3224, 512, 65, 97, 105, 116, 11144, 11147, 11165, 11175, 114, 242, 10632, 114, 114, 384, 59, 99, 119, 11156, 11157, 11161, 24987, 59, 49152, 10547, 824, 59, 49152, 8605, 824, 103, 104, 116, 97, 114, 114, 111, 119, 187, 11157, 114, 105, 256, 59, 101, 3275, 3286, 896, 99, 104, 105, 109, 112, 113, 117, 11197, 11213, 11225, 11012, 2936, 11236, 11247, 512, 59, 99, 101, 114, 3378, 11206, 3383, 11209, 117, 229, 3397, 59, 49152, 55349, 56515, 111, 114, 116, 621, 11013, 0, 0, 11222, 97, 114, 225, 11094, 109, 256, 59, 101, 3438, 11231, 256, 59, 113, 3444, 3443, 115, 117, 256, 98, 112, 11243, 11245, 229, 3320, 229, 3339, 384, 98, 99, 112, 11254, 11281, 11289, 512, 59, 69, 101, 115, 11263, 11264, 3362, 11268, 25220, 59, 49152, 10949, 824, 101, 116, 256, 59, 101, 3355, 11275, 113, 256, 59, 113, 3363, 11264, 99, 256, 59, 101, 3378, 11287, 241, 3384, 512, 59, 69, 101, 115, 11298, 11299, 3423, 11303, 25221, 59, 49152, 10950, 824, 101, 116, 256, 59, 101, 3416, 11310, 113, 256, 59, 113, 3424, 11299, 512, 103, 105, 108, 114, 11325, 11327, 11333, 11335, 236, 3031, 108, 100, 101, 32827, 241, 16625, 231, 3139, 105, 97, 110, 103, 108, 101, 256, 108, 114, 11346, 11356, 101, 102, 116, 256, 59, 101, 3098, 11354, 241, 3110, 105, 103, 104, 116, 256, 59, 101, 3275, 11365, 241, 3287, 256, 59, 109, 11372, 11373, 17341, 384, 59, 101, 115, 11380, 11381, 11385, 16419, 114, 111, 59, 24854, 112, 59, 24583, 1152, 68, 72, 97, 100, 103, 105, 108, 114, 115, 11407, 11412, 11417, 11422, 11427, 11440, 11446, 11475, 11491, 97, 115, 104, 59, 25261, 97, 114, 114, 59, 26884, 112, 59, 49152, 8781, 8402, 97, 115, 104, 59, 25260, 256, 101, 116, 11432, 11436, 59, 49152, 8805, 8402, 59, 49152, 62, 8402, 110, 102, 105, 110, 59, 27102, 384, 65, 101, 116, 11453, 11457, 11461, 114, 114, 59, 26882, 59, 49152, 8804, 8402, 256, 59, 114, 11466, 11469, 49152, 60, 8402, 105, 101, 59, 49152, 8884, 8402, 256, 65, 116, 11480, 11484, 114, 114, 59, 26883, 114, 105, 101, 59, 49152, 8885, 8402, 105, 109, 59, 49152, 8764, 8402, 384, 65, 97, 110, 11504, 11508, 11522, 114, 114, 59, 25046, 114, 256, 104, 114, 11514, 11517, 107, 59, 26915, 256, 59, 111, 5095, 5093, 101, 97, 114, 59, 26919, 4691, 6805, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 11565, 0, 11576, 11592, 11616, 11621, 11634, 11652, 6919, 0, 0, 11661, 11691, 0, 11720, 11726, 0, 11740, 11801, 11819, 11838, 11843, 256, 99, 115, 11569, 6807, 117, 116, 101, 32827, 243, 16627, 256, 105, 121, 11580, 11589, 114, 256, 59, 99, 6814, 11586, 32827, 244, 16628, 59, 17470, 640, 97, 98, 105, 111, 115, 6816, 11602, 11607, 456, 11610, 108, 97, 99, 59, 16721, 118, 59, 27192, 111, 108, 100, 59, 27068, 108, 105, 103, 59, 16723, 256, 99, 114, 11625, 11629, 105, 114, 59, 27071, 59, 49152, 55349, 56620, 879, 11641, 0, 0, 11644, 0, 11650, 110, 59, 17115, 97, 118, 101, 32827, 242, 16626, 59, 27073, 256, 98, 109, 11656, 3572, 97, 114, 59, 27061, 512, 97, 99, 105, 116, 11669, 11672, 11685, 11688, 114, 242, 6784, 256, 105, 114, 11677, 11680, 114, 59, 27070, 111, 115, 115, 59, 27067, 110, 229, 3666, 59, 27072, 384, 97, 101, 105, 11697, 11701, 11705, 99, 114, 59, 16717, 103, 97, 59, 17353, 384, 99, 100, 110, 11712, 11717, 461, 114, 111, 110, 59, 17343, 59, 27062, 112, 102, 59, 49152, 55349, 56672, 384, 97, 101, 108, 11732, 11735, 466, 114, 59, 27063, 114, 112, 59, 27065, 896, 59, 97, 100, 105, 111, 115, 118, 11754, 11755, 11758, 11784, 11789, 11792, 11798, 25128, 114, 242, 6790, 512, 59, 101, 102, 109, 11767, 11768, 11778, 11781, 27229, 114, 256, 59, 111, 11774, 11775, 24884, 102, 187, 11775, 32827, 170, 16554, 32827, 186, 16570, 103, 111, 102, 59, 25270, 114, 59, 27222, 108, 111, 112, 101, 59, 27223, 59, 27227, 384, 99, 108, 111, 11807, 11809, 11815, 242, 11777, 97, 115, 104, 32827, 248, 16632, 108, 59, 25240, 105, 364, 11823, 11828, 100, 101, 32827, 245, 16629, 101, 115, 256, 59, 97, 475, 11834, 115, 59, 27190, 109, 108, 32827, 246, 16630, 98, 97, 114, 59, 25405, 2785, 11870, 0, 11901, 0, 11904, 11933, 0, 11938, 11961, 0, 0, 11979, 3740, 0, 12051, 0, 0, 12075, 12220, 0, 12232, 114, 512, 59, 97, 115, 116, 1027, 11879, 11890, 3717, 33024, 182, 59, 108, 11885, 11886, 16566, 108, 101, 236, 1027, 617, 11896, 0, 0, 11899, 109, 59, 27379, 59, 27389, 121, 59, 17471, 114, 640, 99, 105, 109, 112, 116, 11915, 11919, 11923, 6245, 11927, 110, 116, 59, 16421, 111, 100, 59, 16430, 105, 108, 59, 24624, 101, 110, 107, 59, 24625, 114, 59, 49152, 55349, 56621, 384, 105, 109, 111, 11944, 11952, 11956, 256, 59, 118, 11949, 11950, 17350, 59, 17365, 109, 97, 244, 2678, 110, 101, 59, 26126, 384, 59, 116, 118, 11967, 11968, 11976, 17344, 99, 104, 102, 111, 114, 107, 187, 8189, 59, 17366, 256, 97, 117, 11983, 11999, 110, 256, 99, 107, 11989, 11997, 107, 256, 59, 104, 8692, 11995, 59, 24846, 246, 8692, 115, 1152, 59, 97, 98, 99, 100, 101, 109, 115, 116, 12019, 12020, 6408, 12025, 12029, 12036, 12038, 12042, 12046, 16427, 99, 105, 114, 59, 27171, 105, 114, 59, 27170, 256, 111, 117, 7488, 12034, 59, 27173, 59, 27250, 110, 32955, 177, 3741, 105, 109, 59, 27174, 119, 111, 59, 27175, 384, 105, 112, 117, 12057, 12064, 12069, 110, 116, 105, 110, 116, 59, 27157, 102, 59, 49152, 55349, 56673, 110, 100, 32827, 163, 16547, 1280, 59, 69, 97, 99, 101, 105, 110, 111, 115, 117, 3784, 12095, 12097, 12100, 12103, 12161, 12169, 12178, 12158, 12214, 59, 27315, 112, 59, 27319, 117, 229, 3801, 256, 59, 99, 3790, 12108, 768, 59, 97, 99, 101, 110, 115, 3784, 12121, 12127, 12134, 12136, 12158, 112, 112, 114, 111, 248, 12099, 117, 114, 108, 121, 101, 241, 3801, 241, 3790, 384, 97, 101, 115, 12143, 12150, 12154, 112, 112, 114, 111, 120, 59, 27321, 113, 113, 59, 27317, 105, 109, 59, 25320, 105, 237, 3807, 109, 101, 256, 59, 115, 12168, 3758, 24626, 384, 69, 97, 115, 12152, 12176, 12154, 240, 12149, 384, 100, 102, 112, 3820, 12185, 12207, 384, 97, 108, 115, 12192, 12197, 12202, 108, 97, 114, 59, 25390, 105, 110, 101, 59, 25362, 117, 114, 102, 59, 25363, 256, 59, 116, 3835, 12212, 239, 3835, 114, 101, 108, 59, 25264, 256, 99, 105, 12224, 12229, 114, 59, 49152, 55349, 56517, 59, 17352, 110, 99, 115, 112, 59, 24584, 768, 102, 105, 111, 112, 115, 117, 12250, 8930, 12255, 12261, 12267, 12273, 114, 59, 49152, 55349, 56622, 112, 102, 59, 49152, 55349, 56674, 114, 105, 109, 101, 59, 24663, 99, 114, 59, 49152, 55349, 56518, 384, 97, 101, 111, 12280, 12297, 12307, 116, 256, 101, 105, 12286, 12293, 114, 110, 105, 111, 110, 243, 1712, 110, 116, 59, 27158, 115, 116, 256, 59, 101, 12304, 12305, 16447, 241, 7961, 244, 3860, 2688, 65, 66, 72, 97, 98, 99, 100, 101, 102, 104, 105, 108, 109, 110, 111, 112, 114, 115, 116, 117, 120, 12352, 12369, 12373, 12377, 12512, 12558, 12587, 12615, 12642, 12658, 12686, 12806, 12821, 12836, 12841, 12888, 12910, 12914, 12944, 12976, 12983, 384, 97, 114, 116, 12359, 12362, 12364, 114, 242, 4275, 242, 989, 97, 105, 108, 59, 26908, 97, 114, 242, 7269, 97, 114, 59, 26980, 896, 99, 100, 101, 110, 113, 114, 116, 12392, 12405, 12408, 12415, 12431, 12436, 12492, 256, 101, 117, 12397, 12401, 59, 49152, 8765, 817, 116, 101, 59, 16725, 105, 227, 4462, 109, 112, 116, 121, 118, 59, 27059, 103, 512, 59, 100, 101, 108, 4049, 12425, 12427, 12429, 59, 27026, 59, 27045, 229, 4049, 117, 111, 32827, 187, 16571, 114, 1408, 59, 97, 98, 99, 102, 104, 108, 112, 115, 116, 119, 4060, 12460, 12463, 12471, 12473, 12476, 12478, 12480, 12483, 12487, 12490, 112, 59, 26997, 256, 59, 102, 4064, 12468, 115, 59, 26912, 59, 26931, 115, 59, 26910, 235, 8797, 240, 10030, 108, 59, 26949, 105, 109, 59, 26996, 108, 59, 24995, 59, 24989, 256, 97, 105, 12497, 12501, 105, 108, 59, 26906, 111, 256, 59, 110, 12507, 12508, 25142, 97, 108, 243, 3870, 384, 97, 98, 114, 12519, 12522, 12526, 114, 242, 6117, 114, 107, 59, 26483, 256, 97, 107, 12531, 12541, 99, 256, 101, 107, 12537, 12539, 59, 16509, 59, 16477, 256, 101, 115, 12546, 12548, 59, 27020, 108, 256, 100, 117, 12554, 12556, 59, 27022, 59, 27024, 512, 97, 101, 117, 121, 12567, 12572, 12583, 12585, 114, 111, 110, 59, 16729, 256, 100, 105, 12577, 12581, 105, 108, 59, 16727, 236, 4082, 226, 12538, 59, 17472, 512, 99, 108, 113, 115, 12596, 12599, 12605, 12612, 97, 59, 26935, 100, 104, 97, 114, 59, 26985, 117, 111, 256, 59, 114, 526, 525, 104, 59, 25011, 384, 97, 99, 103, 12622, 12639, 3908, 108, 512, 59, 105, 112, 115, 3960, 12632, 12635, 4252, 110, 229, 4283, 97, 114, 244, 4009, 116, 59, 26029, 384, 105, 108, 114, 12649, 4131, 12654, 115, 104, 116, 59, 27005, 59, 49152, 55349, 56623, 256, 97, 111, 12663, 12678, 114, 256, 100, 117, 12669, 12671, 187, 1147, 256, 59, 108, 4241, 12676, 59, 26988, 256, 59, 118, 12683, 12684, 17345, 59, 17393, 384, 103, 110, 115, 12693, 12793, 12796, 104, 116, 768, 97, 104, 108, 114, 115, 116, 12708, 12720, 12738, 12760, 12772, 12782, 114, 114, 111, 119, 256, 59, 116, 4060, 12717, 97, 233, 12488, 97, 114, 112, 111, 111, 110, 256, 100, 117, 12731, 12735, 111, 119, 238, 12670, 112, 187, 4242, 101, 102, 116, 256, 97, 104, 12746, 12752, 114, 114, 111, 119, 243, 4074, 97, 114, 112, 111, 111, 110, 243, 1361, 105, 103, 104, 116, 97, 114, 114, 111, 119, 115, 59, 25033, 113, 117, 105, 103, 97, 114, 114, 111, 247, 12491, 104, 114, 101, 101, 116, 105, 109, 101, 115, 59, 25292, 103, 59, 17114, 105, 110, 103, 100, 111, 116, 115, 101, 241, 7986, 384, 97, 104, 109, 12813, 12816, 12819, 114, 242, 4074, 97, 242, 1361, 59, 24591, 111, 117, 115, 116, 256, 59, 97, 12830, 12831, 25521, 99, 104, 101, 187, 12831, 109, 105, 100, 59, 27374, 512, 97, 98, 112, 116, 12850, 12861, 12864, 12882, 256, 110, 114, 12855, 12858, 103, 59, 26605, 114, 59, 25086, 114, 235, 4099, 384, 97, 102, 108, 12871, 12874, 12878, 114, 59, 27014, 59, 49152, 55349, 56675, 117, 115, 59, 27182, 105, 109, 101, 115, 59, 27189, 256, 97, 112, 12893, 12903, 114, 256, 59, 103, 12899, 12900, 16425, 116, 59, 27028, 111, 108, 105, 110, 116, 59, 27154, 97, 114, 242, 12771, 512, 97, 99, 104, 113, 12923, 12928, 4284, 12933, 113, 117, 111, 59, 24634, 114, 59, 49152, 55349, 56519, 256, 98, 117, 12539, 12938, 111, 256, 59, 114, 532, 531, 384, 104, 105, 114, 12951, 12955, 12960, 114, 101, 229, 12792, 109, 101, 115, 59, 25290, 105, 512, 59, 101, 102, 108, 12970, 4185, 6177, 12971, 26041, 116, 114, 105, 59, 27086, 108, 117, 104, 97, 114, 59, 26984, 59, 24862, 3425, 13013, 13019, 13023, 13100, 13112, 13169, 0, 13178, 13220, 0, 0, 13292, 13296, 0, 13352, 13384, 13402, 13485, 13489, 13514, 13553, 0, 13846, 0, 0, 13875, 99, 117, 116, 101, 59, 16731, 113, 117, 239, 10170, 1280, 59, 69, 97, 99, 101, 105, 110, 112, 115, 121, 4589, 13043, 13045, 13055, 13058, 13067, 13071, 13087, 13094, 13097, 59, 27316, 496, 13050, 0, 13052, 59, 27320, 111, 110, 59, 16737, 117, 229, 4606, 256, 59, 100, 4595, 13063, 105, 108, 59, 16735, 114, 99, 59, 16733, 384, 69, 97, 115, 13078, 13080, 13083, 59, 27318, 112, 59, 27322, 105, 109, 59, 25321, 111, 108, 105, 110, 116, 59, 27155, 105, 237, 4612, 59, 17473, 111, 116, 384, 59, 98, 101, 13108, 7495, 13109, 25285, 59, 27238, 896, 65, 97, 99, 109, 115, 116, 120, 13126, 13130, 13143, 13147, 13150, 13155, 13165, 114, 114, 59, 25048, 114, 256, 104, 114, 13136, 13138, 235, 8744, 256, 59, 111, 2614, 2612, 116, 32827, 167, 16551, 105, 59, 16443, 119, 97, 114, 59, 26921, 109, 256, 105, 110, 13161, 240, 110, 117, 243, 241, 116, 59, 26422, 114, 256, 59, 111, 13174, 8277, 49152, 55349, 56624, 512, 97, 99, 111, 121, 13186, 13190, 13201, 13216, 114, 112, 59, 26223, 256, 104, 121, 13195, 13199, 99, 121, 59, 17481, 59, 17480, 114, 116, 621, 13209, 0, 0, 13212, 105, 228, 5220, 97, 114, 97, 236, 11887, 32827, 173, 16557, 256, 103, 109, 13224, 13236, 109, 97, 384, 59, 102, 118, 13233, 13234, 13234, 17347, 59, 17346, 1024, 59, 100, 101, 103, 108, 110, 112, 114, 4779, 13253, 13257, 13262, 13270, 13278, 13281, 13286, 111, 116, 59, 27242, 256, 59, 113, 4785, 4784, 256, 59, 69, 13267, 13268, 27294, 59, 27296, 256, 59, 69, 13275, 13276, 27293, 59, 27295, 101, 59, 25158, 108, 117, 115, 59, 27172, 97, 114, 114, 59, 26994, 97, 114, 242, 4413, 512, 97, 101, 105, 116, 13304, 13320, 13327, 13335, 256, 108, 115, 13309, 13316, 108, 115, 101, 116, 109, 233, 13162, 104, 112, 59, 27187, 112, 97, 114, 115, 108, 59, 27108, 256, 100, 108, 5219, 13332, 101, 59, 25379, 256, 59, 101, 13340, 13341, 27306, 256, 59, 115, 13346, 13347, 27308, 59, 49152, 10924, 65024, 384, 102, 108, 112, 13358, 13363, 13378, 116, 99, 121, 59, 17484, 256, 59, 98, 13368, 13369, 16431, 256, 59, 97, 13374, 13375, 27076, 114, 59, 25407, 102, 59, 49152, 55349, 56676, 97, 256, 100, 114, 13389, 1026, 101, 115, 256, 59, 117, 13396, 13397, 26208, 105, 116, 187, 13397, 384, 99, 115, 117, 13408, 13433, 13471, 256, 97, 117, 13413, 13423, 112, 256, 59, 115, 4488, 13419, 59, 49152, 8851, 65024, 112, 256, 59, 115, 4532, 13429, 59, 49152, 8852, 65024, 117, 256, 98, 112, 13439, 13455, 384, 59, 101, 115, 4503, 4508, 13446, 101, 116, 256, 59, 101, 4503, 13453, 241, 4509, 384, 59, 101, 115, 4520, 4525, 13462, 101, 116, 256, 59, 101, 4520, 13469, 241, 4526, 384, 59, 97, 102, 4475, 13478, 1456, 114, 357, 13483, 1457, 187, 4476, 97, 114, 242, 4424, 512, 99, 101, 109, 116, 13497, 13502, 13506, 13509, 114, 59, 49152, 55349, 56520, 116, 109, 238, 241, 105, 236, 13333, 97, 114, 230, 4542, 256, 97, 114, 13518, 13525, 114, 256, 59, 102, 13524, 6079, 26118, 256, 97, 110, 13530, 13549, 105, 103, 104, 116, 256, 101, 112, 13539, 13546, 112, 115, 105, 108, 111, 238, 7904, 104, 233, 11951, 115, 187, 10322, 640, 98, 99, 109, 110, 112, 13563, 13662, 4617, 13707, 13710, 1152, 59, 69, 100, 101, 109, 110, 112, 114, 115, 13582, 13583, 13585, 13589, 13598, 13603, 13612, 13617, 13622, 25218, 59, 27333, 111, 116, 59, 27325, 256, 59, 100, 4570, 13594, 111, 116, 59, 27331, 117, 108, 116, 59, 27329, 256, 69, 101, 13608, 13610, 59, 27339, 59, 25226, 108, 117, 115, 59, 27327, 97, 114, 114, 59, 27001, 384, 101, 105, 117, 13629, 13650, 13653, 116, 384, 59, 101, 110, 13582, 13637, 13643, 113, 256, 59, 113, 4570, 13583, 101, 113, 256, 59, 113, 13611, 13608, 109, 59, 27335, 256, 98, 112, 13658, 13660, 59, 27349, 59, 27347, 99, 768, 59, 97, 99, 101, 110, 115, 4589, 13676, 13682, 13689, 13691, 13094, 112, 112, 114, 111, 248, 13050, 117, 114, 108, 121, 101, 241, 4606, 241, 4595, 384, 97, 101, 115, 13698, 13704, 13083, 112, 112, 114, 111, 248, 13082, 113, 241, 13079, 103, 59, 26218, 1664, 49, 50, 51, 59, 69, 100, 101, 104, 108, 109, 110, 112, 115, 13737, 13740, 13743, 4636, 13746, 13748, 13760, 13769, 13781, 13786, 13791, 13800, 13805, 32827, 185, 16569, 32827, 178, 16562, 32827, 179, 16563, 59, 27334, 256, 111, 115, 13753, 13756, 116, 59, 27326, 117, 98, 59, 27352, 256, 59, 100, 4642, 13765, 111, 116, 59, 27332, 115, 256, 111, 117, 13775, 13778, 108, 59, 26569, 98, 59, 27351, 97, 114, 114, 59, 27003, 117, 108, 116, 59, 27330, 256, 69, 101, 13796, 13798, 59, 27340, 59, 25227, 108, 117, 115, 59, 27328, 384, 101, 105, 117, 13812, 13833, 13836, 116, 384, 59, 101, 110, 4636, 13820, 13826, 113, 256, 59, 113, 4642, 13746, 101, 113, 256, 59, 113, 13799, 13796, 109, 59, 27336, 256, 98, 112, 13841, 13843, 59, 27348, 59, 27350, 384, 65, 97, 110, 13852, 13856, 13869, 114, 114, 59, 25049, 114, 256, 104, 114, 13862, 13864, 235, 8750, 256, 59, 111, 2603, 2601, 119, 97, 114, 59, 26922, 108, 105, 103, 32827, 223, 16607, 3041, 13905, 13917, 13920, 4814, 13939, 13945, 0, 13950, 14018, 0, 0, 0, 0, 0, 14043, 14083, 0, 14089, 14188, 0, 0, 0, 14215, 626, 13910, 0, 0, 13915, 103, 101, 116, 59, 25366, 59, 17348, 114, 235, 3679, 384, 97, 101, 121, 13926, 13931, 13936, 114, 111, 110, 59, 16741, 100, 105, 108, 59, 16739, 59, 17474, 108, 114, 101, 99, 59, 25365, 114, 59, 49152, 55349, 56625, 512, 101, 105, 107, 111, 13958, 13981, 14005, 14012, 498, 13963, 0, 13969, 101, 256, 52, 102, 4740, 4737, 97, 384, 59, 115, 118, 13976, 13977, 13979, 17336, 121, 109, 59, 17361, 256, 99, 110, 13986, 14002, 107, 256, 97, 115, 13992, 13998, 112, 112, 114, 111, 248, 4801, 105, 109, 187, 4780, 115, 240, 4766, 256, 97, 115, 14010, 13998, 240, 4801, 114, 110, 32827, 254, 16638, 492, 799, 14022, 8935, 101, 115, 33152, 215, 59, 98, 100, 14031, 14032, 14040, 16599, 256, 59, 97, 6415, 14037, 114, 59, 27185, 59, 27184, 384, 101, 112, 115, 14049, 14051, 14080, 225, 10829, 512, 59, 98, 99, 102, 1158, 14060, 14064, 14068, 111, 116, 59, 25398, 105, 114, 59, 27377, 256, 59, 111, 14073, 14076, 49152, 55349, 56677, 114, 107, 59, 27354, 225, 13154, 114, 105, 109, 101, 59, 24628, 384, 97, 105, 112, 14095, 14098, 14180, 100, 229, 4680, 896, 97, 100, 101, 109, 112, 115, 116, 14113, 14157, 14144, 14161, 14167, 14172, 14175, 110, 103, 108, 101, 640, 59, 100, 108, 113, 114, 14128, 14129, 14134, 14144, 14146, 26037, 111, 119, 110, 187, 7611, 101, 102, 116, 256, 59, 101, 10240, 14142, 241, 2350, 59, 25180, 105, 103, 104, 116, 256, 59, 101, 12970, 14155, 241, 4186, 111, 116, 59, 26092, 105, 110, 117, 115, 59, 27194, 108, 117, 115, 59, 27193, 98, 59, 27085, 105, 109, 101, 59, 27195, 101, 122, 105, 117, 109, 59, 25570, 384, 99, 104, 116, 14194, 14205, 14209, 256, 114, 121, 14199, 14203, 59, 49152, 55349, 56521, 59, 17478, 99, 121, 59, 17499, 114, 111, 107, 59, 16743, 256, 105, 111, 14219, 14222, 120, 244, 6007, 104, 101, 97, 100, 256, 108, 114, 14231, 14240, 101, 102, 116, 97, 114, 114, 111, 247, 2127, 105, 103, 104, 116, 97, 114, 114, 111, 119, 187, 3933, 2304, 65, 72, 97, 98, 99, 100, 102, 103, 104, 108, 109, 111, 112, 114, 115, 116, 117, 119, 14288, 14291, 14295, 14308, 14320, 14332, 14350, 14364, 14371, 14388, 14417, 14429, 14443, 14505, 14540, 14546, 14570, 14582, 114, 242, 1005, 97, 114, 59, 26979, 256, 99, 114, 14300, 14306, 117, 116, 101, 32827, 250, 16634, 242, 4432, 114, 483, 14314, 0, 14317, 121, 59, 17502, 118, 101, 59, 16749, 256, 105, 121, 14325, 14330, 114, 99, 32827, 251, 16635, 59, 17475, 384, 97, 98, 104, 14339, 14342, 14347, 114, 242, 5037, 108, 97, 99, 59, 16753, 97, 242, 5059, 256, 105, 114, 14355, 14360, 115, 104, 116, 59, 27006, 59, 49152, 55349, 56626, 114, 97, 118, 101, 32827, 249, 16633, 353, 14375, 14385, 114, 256, 108, 114, 14380, 14382, 187, 2391, 187, 4227, 108, 107, 59, 25984, 256, 99, 116, 14393, 14413, 623, 14399, 0, 0, 14410, 114, 110, 256, 59, 101, 14405, 14406, 25372, 114, 187, 14406, 111, 112, 59, 25359, 114, 105, 59, 26104, 256, 97, 108, 14422, 14426, 99, 114, 59, 16747, 32955, 168, 841, 256, 103, 112, 14434, 14438, 111, 110, 59, 16755, 102, 59, 49152, 55349, 56678, 768, 97, 100, 104, 108, 115, 117, 4427, 14456, 14461, 4978, 14481, 14496, 111, 119, 110, 225, 5043, 97, 114, 112, 111, 111, 110, 256, 108, 114, 14472, 14476, 101, 102, 244, 14381, 105, 103, 104, 244, 14383, 105, 384, 59, 104, 108, 14489, 14490, 14492, 17349, 187, 5114, 111, 110, 187, 14490, 112, 97, 114, 114, 111, 119, 115, 59, 25032, 384, 99, 105, 116, 14512, 14532, 14536, 623, 14518, 0, 0, 14529, 114, 110, 256, 59, 101, 14524, 14525, 25373, 114, 187, 14525, 111, 112, 59, 25358, 110, 103, 59, 16751, 114, 105, 59, 26105, 99, 114, 59, 49152, 55349, 56522, 384, 100, 105, 114, 14553, 14557, 14562, 111, 116, 59, 25328, 108, 100, 101, 59, 16745, 105, 256, 59, 102, 14128, 14568, 187, 6163, 256, 97, 109, 14575, 14578, 114, 242, 14504, 108, 32827, 252, 16636, 97, 110, 103, 108, 101, 59, 27047, 1920, 65, 66, 68, 97, 99, 100, 101, 102, 108, 110, 111, 112, 114, 115, 122, 14620, 14623, 14633, 14637, 14773, 14776, 14781, 14815, 14820, 14824, 14835, 14841, 14845, 14849, 14880, 114, 242, 1015, 97, 114, 256, 59, 118, 14630, 14631, 27368, 59, 27369, 97, 115, 232, 993, 256, 110, 114, 14642, 14647, 103, 114, 116, 59, 27036, 896, 101, 107, 110, 112, 114, 115, 116, 13539, 14662, 14667, 14674, 14685, 14692, 14742, 97, 112, 112, 225, 9237, 111, 116, 104, 105, 110, 231, 7830, 384, 104, 105, 114, 13547, 11976, 14681, 111, 112, 244, 12213, 256, 59, 104, 5047, 14690, 239, 12685, 256, 105, 117, 14697, 14701, 103, 109, 225, 13235, 256, 98, 112, 14706, 14724, 115, 101, 116, 110, 101, 113, 256, 59, 113, 14717, 14720, 49152, 8842, 65024, 59, 49152, 10955, 65024, 115, 101, 116, 110, 101, 113, 256, 59, 113, 14735, 14738, 49152, 8843, 65024, 59, 49152, 10956, 65024, 256, 104, 114, 14747, 14751, 101, 116, 225, 13980, 105, 97, 110, 103, 108, 101, 256, 108, 114, 14762, 14767, 101, 102, 116, 187, 2341, 105, 103, 104, 116, 187, 4177, 121, 59, 17458, 97, 115, 104, 187, 4150, 384, 101, 108, 114, 14788, 14802, 14807, 384, 59, 98, 101, 11754, 14795, 14799, 97, 114, 59, 25275, 113, 59, 25178, 108, 105, 112, 59, 25326, 256, 98, 116, 14812, 5224, 97, 242, 5225, 114, 59, 49152, 55349, 56627, 116, 114, 233, 14766, 115, 117, 256, 98, 112, 14831, 14833, 187, 3356, 187, 3417, 112, 102, 59, 49152, 55349, 56679, 114, 111, 240, 3835, 116, 114, 233, 14772, 256, 99, 117, 14854, 14859, 114, 59, 49152, 55349, 56523, 256, 98, 112, 14864, 14872, 110, 256, 69, 101, 14720, 14870, 187, 14718, 110, 256, 69, 101, 14738, 14878, 187, 14736, 105, 103, 122, 97, 103, 59, 27034, 896, 99, 101, 102, 111, 112, 114, 115, 14902, 14907, 14934, 14939, 14932, 14945, 14954, 105, 114, 99, 59, 16757, 256, 100, 105, 14912, 14929, 256, 98, 103, 14917, 14921, 97, 114, 59, 27231, 101, 256, 59, 113, 5626, 14927, 59, 25177, 101, 114, 112, 59, 24856, 114, 59, 49152, 55349, 56628, 112, 102, 59, 49152, 55349, 56680, 256, 59, 101, 5241, 14950, 97, 116, 232, 5241, 99, 114, 59, 49152, 55349, 56524, 2787, 6030, 14983, 0, 14987, 0, 14992, 15003, 0, 0, 15005, 15016, 15019, 15023, 0, 0, 15043, 15054, 0, 15064, 6108, 6111, 116, 114, 233, 6097, 114, 59, 49152, 55349, 56629, 256, 65, 97, 14996, 14999, 114, 242, 963, 114, 242, 2550, 59, 17342, 256, 65, 97, 15009, 15012, 114, 242, 952, 114, 242, 2539, 97, 240, 10003, 105, 115, 59, 25339, 384, 100, 112, 116, 6052, 15029, 15038, 256, 102, 108, 15034, 6057, 59, 49152, 55349, 56681, 105, 109, 229, 6066, 256, 65, 97, 15047, 15050, 114, 242, 974, 114, 242, 2561, 256, 99, 113, 15058, 6072, 114, 59, 49152, 55349, 56525, 256, 112, 116, 6102, 15068, 114, 233, 6100, 1024, 97, 99, 101, 102, 105, 111, 115, 117, 15088, 15101, 15112, 15116, 15121, 15125, 15131, 15137, 99, 256, 117, 121, 15094, 15099, 116, 101, 32827, 253, 16637, 59, 17487, 256, 105, 121, 15106, 15110, 114, 99, 59, 16759, 59, 17483, 110, 32827, 165, 16549, 114, 59, 49152, 55349, 56630, 99, 121, 59, 17495, 112, 102, 59, 49152, 55349, 56682, 99, 114, 59, 49152, 55349, 56526, 256, 99, 109, 15142, 15145, 121, 59, 17486, 108, 32827, 255, 16639, 1280, 97, 99, 100, 101, 102, 104, 105, 111, 115, 119, 15170, 15176, 15188, 15192, 15204, 15209, 15213, 15220, 15226, 15232, 99, 117, 116, 101, 59, 16762, 256, 97, 121, 15181, 15186, 114, 111, 110, 59, 16766, 59, 17463, 111, 116, 59, 16764, 256, 101, 116, 15197, 15201, 116, 114, 230, 5471, 97, 59, 17334, 114, 59, 49152, 55349, 56631, 99, 121, 59, 17462, 103, 114, 97, 114, 114, 59, 25053, 112, 102, 59, 49152, 55349, 56683, 99, 114, 59, 49152, 55349, 56527, 256, 106, 110, 15237, 15239, 59, 24589, 106, 59, 24588]), eC = new Uint16Array([512, 97, 103, 108, 113, 9, 21, 24, 27, 621, 15, 0, 0, 18, 112, 59, 16422, 111, 115, 59, 16423, 116, 59, 16446, 116, 59, 16444, 117, 111, 116, 59, 16418]), M1, tC = /* @__PURE__ */ new Map([
  [0, 65533],
  [128, 8364],
  [130, 8218],
  [131, 402],
  [132, 8222],
  [133, 8230],
  [134, 8224],
  [135, 8225],
  [136, 710],
  [137, 8240],
  [138, 352],
  [139, 8249],
  [140, 338],
  [142, 381],
  [145, 8216],
  [146, 8217],
  [147, 8220],
  [148, 8221],
  [149, 8226],
  [150, 8211],
  [151, 8212],
  [152, 732],
  [153, 8482],
  [154, 353],
  [155, 8250],
  [156, 339],
  [158, 382],
  [159, 376]
]), ac = (M1 = String.fromCodePoint) !== null && M1 !== void 0 ? M1 : function(e) {
  let t = "";
  return e > 65535 && (e -= 65536, t += String.fromCharCode(e >>> 10 & 1023 | 55296), e = 56320 | e & 1023), t += String.fromCharCode(e), t;
};
function bm(e) {
  var t;
  return e >= 55296 && e <= 57343 || e > 1114111 ? 65533 : (t = tC.get(e)) !== null && t !== void 0 ? t : e;
}
l(bm, "replaceCodePoint");
function G_(e) {
  return ac(bm(e));
}
l(G_, "decodeCodePoint");
var $t;
(function(e) {
  e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_F = 102] = "LOWER_F", e[e.LOWER_X = 120] = "LOWER_X", e[e.To_LOWER_BIT = 32] = "To_LOWER_BIT";
})($t || ($t = {}));
var Oi;
(function(e) {
  e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE";
})(Oi || (Oi = {}));
function iC(e) {
  return /* @__PURE__ */ l(function(i, n) {
    let s = "", r = 0, a = 0;
    for (; (a = i.indexOf("&", a)) >= 0; ) {
      if (s += i.slice(r, a), r = a, a += 1, i.charCodeAt(a) === $t.NUM) {
        let m = a + 1, b = 10, C = i.charCodeAt(m);
        (C | $t.To_LOWER_BIT) === $t.LOWER_X && (b = 16, a += 1, m += 1);
        do
          C = i.charCodeAt(++a);
        while (C >= $t.ZERO && C <= $t.NINE || b === 16 && (C | $t.To_LOWER_BIT) >= $t.LOWER_A && (C | $t.To_LOWER_BIT) <= $t.LOWER_F);
        if (m !== a) {
          const k = i.substring(m, a), D = parseInt(k, b);
          if (i.charCodeAt(a) === $t.SEMI)
            a += 1;
          else if (n)
            continue;
          s += G_(D), r = a;
        }
        continue;
      }
      let u = 0, c = 1, h = 0, p = e[h];
      for (; a < i.length && (h = wm(e, p, h + 1, i.charCodeAt(a)), !(h < 0)); a++, c++) {
        p = e[h];
        const m = p & Oi.VALUE_LENGTH;
        if (m) {
          (!n || i.charCodeAt(a) === $t.SEMI) && (u = h, c = 0);
          const b = (m >> 14) - 1;
          if (b === 0)
            break;
          h += b;
        }
      }
      if (u !== 0) {
        const m = (e[u] & Oi.VALUE_LENGTH) >> 14;
        s += m === 1 ? String.fromCharCode(e[u] & ~Oi.VALUE_LENGTH) : m === 2 ? String.fromCharCode(e[u + 1]) : String.fromCharCode(e[u + 1], e[u + 2]), r = a - c + 1;
      }
    }
    return s + i.slice(r);
  }, "decodeHTMLBinary");
}
l(iC, "getDecoder");
function wm(e, t, i, n) {
  const s = (t & Oi.BRANCH_LENGTH) >> 7, r = t & Oi.JUMP_TABLE;
  if (s === 0)
    return r !== 0 && n === r ? i : -1;
  if (r) {
    const c = n - r;
    return c < 0 || c >= s ? -1 : e[i + c] - 1;
  }
  let a = i, u = a + s - 1;
  for (; a <= u; ) {
    const c = a + u >>> 1, h = e[c];
    if (h < n)
      a = c + 1;
    else if (h > n)
      u = c - 1;
    else
      return e[c + s];
  }
  return -1;
}
l(wm, "determineBranch");
var z;
(function(e) {
  e[e.Tab = 9] = "Tab", e[e.NewLine = 10] = "NewLine", e[e.FormFeed = 12] = "FormFeed", e[e.CarriageReturn = 13] = "CarriageReturn", e[e.Space = 32] = "Space", e[e.ExclamationMark = 33] = "ExclamationMark", e[e.Num = 35] = "Num", e[e.Amp = 38] = "Amp", e[e.SingleQuote = 39] = "SingleQuote", e[e.DoubleQuote = 34] = "DoubleQuote", e[e.Dash = 45] = "Dash", e[e.Slash = 47] = "Slash", e[e.Zero = 48] = "Zero", e[e.Nine = 57] = "Nine", e[e.Semi = 59] = "Semi", e[e.Lt = 60] = "Lt", e[e.Eq = 61] = "Eq", e[e.Gt = 62] = "Gt", e[e.Questionmark = 63] = "Questionmark", e[e.UpperA = 65] = "UpperA", e[e.LowerA = 97] = "LowerA", e[e.UpperF = 70] = "UpperF", e[e.LowerF = 102] = "LowerF", e[e.UpperZ = 90] = "UpperZ", e[e.LowerZ = 122] = "LowerZ", e[e.LowerX = 120] = "LowerX", e[e.OpeningSquareBracket = 91] = "OpeningSquareBracket";
})(z || (z = {}));
var N;
(function(e) {
  e[e.Text = 1] = "Text", e[e.BeforeTagName = 2] = "BeforeTagName", e[e.InTagName = 3] = "InTagName", e[e.InSelfClosingTag = 4] = "InSelfClosingTag", e[e.BeforeClosingTagName = 5] = "BeforeClosingTagName", e[e.InClosingTagName = 6] = "InClosingTagName", e[e.AfterClosingTagName = 7] = "AfterClosingTagName", e[e.BeforeAttributeName = 8] = "BeforeAttributeName", e[e.InAttributeName = 9] = "InAttributeName", e[e.AfterAttributeName = 10] = "AfterAttributeName", e[e.BeforeAttributeValue = 11] = "BeforeAttributeValue", e[e.InAttributeValueDq = 12] = "InAttributeValueDq", e[e.InAttributeValueSq = 13] = "InAttributeValueSq", e[e.InAttributeValueNq = 14] = "InAttributeValueNq", e[e.BeforeDeclaration = 15] = "BeforeDeclaration", e[e.InDeclaration = 16] = "InDeclaration", e[e.InProcessingInstruction = 17] = "InProcessingInstruction", e[e.BeforeComment = 18] = "BeforeComment", e[e.CDATASequence = 19] = "CDATASequence", e[e.InSpecialComment = 20] = "InSpecialComment", e[e.InCommentLike = 21] = "InCommentLike", e[e.BeforeSpecialS = 22] = "BeforeSpecialS", e[e.SpecialStartSequence = 23] = "SpecialStartSequence", e[e.InSpecialTag = 24] = "InSpecialTag", e[e.BeforeEntity = 25] = "BeforeEntity", e[e.BeforeNumericEntity = 26] = "BeforeNumericEntity", e[e.InNamedEntity = 27] = "InNamedEntity", e[e.InNumericEntity = 28] = "InNumericEntity", e[e.InHexEntity = 29] = "InHexEntity";
})(N || (N = {}));
function Mi(e) {
  return e === z.Space || e === z.NewLine || e === z.Tab || e === z.FormFeed || e === z.CarriageReturn;
}
l(Mi, "isWhitespace");
function io(e) {
  return e === z.Slash || e === z.Gt || Mi(e);
}
l(io, "isEndOfTagSection");
function lc(e) {
  return e >= z.Zero && e <= z.Nine;
}
l(lc, "isNumber");
function q_(e) {
  return e >= z.LowerA && e <= z.LowerZ || e >= z.UpperA && e <= z.UpperZ;
}
l(q_, "isASCIIAlpha");
function z_(e) {
  return e >= z.UpperA && e <= z.UpperF || e >= z.LowerA && e <= z.LowerF;
}
l(z_, "isHexDigit");
var Di;
(function(e) {
  e[e.NoValue = 0] = "NoValue", e[e.Unquoted = 1] = "Unquoted", e[e.Single = 2] = "Single", e[e.Double = 3] = "Double";
})(Di || (Di = {}));
var Pt = {
  Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
  CdataEnd: new Uint8Array([93, 93, 62]),
  CommentEnd: new Uint8Array([45, 45, 62]),
  ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
  StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
  TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101])
}, Sm = class {
  constructor({ xmlMode: e = !1, decodeEntities: t = !0 }, i) {
    this.cbs = i, this.state = N.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = N.Text, this.isSpecial = !1, this.running = !0, this.offset = 0, this.sequenceIndex = 0, this.trieIndex = 0, this.trieCurrent = 0, this.entityResult = 0, this.entityExcess = 0, this.xmlMode = e, this.decodeEntities = t, this.entityTrie = e ? eC : Q8;
  }
  reset() {
    this.state = N.Text, this.buffer = "", this.sectionStart = 0, this.index = 0, this.baseState = N.Text, this.currentSequence = void 0, this.running = !0, this.offset = 0;
  }
  write(e) {
    this.offset += this.buffer.length, this.buffer = e, this.parse();
  }
  end() {
    this.running && this.finish();
  }
  pause() {
    this.running = !1;
  }
  resume() {
    this.running = !0, this.index < this.buffer.length + this.offset && this.parse();
  }
  getIndex() {
    return this.index;
  }
  getSectionStart() {
    return this.sectionStart;
  }
  stateText(e) {
    e === z.Lt || !this.decodeEntities && this.fastForwardTo(z.Lt) ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = N.BeforeTagName, this.sectionStart = this.index) : this.decodeEntities && e === z.Amp && (this.state = N.BeforeEntity);
  }
  stateSpecialStartSequence(e) {
    const t = this.sequenceIndex === this.currentSequence.length;
    if (!(t ? io(e) : (e | 32) === this.currentSequence[this.sequenceIndex]))
      this.isSpecial = !1;
    else if (!t) {
      this.sequenceIndex++;
      return;
    }
    this.sequenceIndex = 0, this.state = N.InTagName, this.stateInTagName(e);
  }
  stateInSpecialTag(e) {
    if (this.sequenceIndex === this.currentSequence.length) {
      if (e === z.Gt || Mi(e)) {
        const t = this.index - this.currentSequence.length;
        if (this.sectionStart < t) {
          const i = this.index;
          this.index = t, this.cbs.ontext(this.sectionStart, t), this.index = i;
        }
        this.isSpecial = !1, this.sectionStart = t + 2, this.stateInClosingTagName(e);
        return;
      }
      this.sequenceIndex = 0;
    }
    (e | 32) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : this.sequenceIndex === 0 ? this.currentSequence === Pt.TitleEnd ? this.decodeEntities && e === z.Amp && (this.state = N.BeforeEntity) : this.fastForwardTo(z.Lt) && (this.sequenceIndex = 1) : this.sequenceIndex = Number(e === z.Lt);
  }
  stateCDATASequence(e) {
    e === Pt.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === Pt.Cdata.length && (this.state = N.InCommentLike, this.currentSequence = Pt.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = N.InDeclaration, this.stateInDeclaration(e));
  }
  fastForwardTo(e) {
    for (; ++this.index < this.buffer.length + this.offset; )
      if (this.buffer.charCodeAt(this.index - this.offset) === e)
        return !0;
    return this.index = this.buffer.length + this.offset - 1, !1;
  }
  stateInCommentLike(e) {
    e === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === Pt.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index, 2) : this.cbs.oncomment(this.sectionStart, this.index, 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = N.Text) : this.sequenceIndex === 0 ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : e !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0);
  }
  isTagStartChar(e) {
    return this.xmlMode ? !io(e) : q_(e);
  }
  startSpecial(e, t) {
    this.isSpecial = !0, this.currentSequence = e, this.sequenceIndex = t, this.state = N.SpecialStartSequence;
  }
  stateBeforeTagName(e) {
    if (e === z.ExclamationMark)
      this.state = N.BeforeDeclaration, this.sectionStart = this.index + 1;
    else if (e === z.Questionmark)
      this.state = N.InProcessingInstruction, this.sectionStart = this.index + 1;
    else if (this.isTagStartChar(e)) {
      const t = e | 32;
      this.sectionStart = this.index, !this.xmlMode && t === Pt.TitleEnd[2] ? this.startSpecial(Pt.TitleEnd, 3) : this.state = !this.xmlMode && t === Pt.ScriptEnd[2] ? N.BeforeSpecialS : N.InTagName;
    } else
      e === z.Slash ? this.state = N.BeforeClosingTagName : (this.state = N.Text, this.stateText(e));
  }
  stateInTagName(e) {
    io(e) && (this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = N.BeforeAttributeName, this.stateBeforeAttributeName(e));
  }
  stateBeforeClosingTagName(e) {
    Mi(e) || (e === z.Gt ? this.state = N.Text : (this.state = this.isTagStartChar(e) ? N.InClosingTagName : N.InSpecialComment, this.sectionStart = this.index));
  }
  stateInClosingTagName(e) {
    (e === z.Gt || Mi(e)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = N.AfterClosingTagName, this.stateAfterClosingTagName(e));
  }
  stateAfterClosingTagName(e) {
    (e === z.Gt || this.fastForwardTo(z.Gt)) && (this.state = N.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeAttributeName(e) {
    e === z.Gt ? (this.cbs.onopentagend(this.index), this.isSpecial ? (this.state = N.InSpecialTag, this.sequenceIndex = 0) : this.state = N.Text, this.baseState = this.state, this.sectionStart = this.index + 1) : e === z.Slash ? this.state = N.InSelfClosingTag : Mi(e) || (this.state = N.InAttributeName, this.sectionStart = this.index);
  }
  stateInSelfClosingTag(e) {
    e === z.Gt ? (this.cbs.onselfclosingtag(this.index), this.state = N.Text, this.baseState = N.Text, this.sectionStart = this.index + 1, this.isSpecial = !1) : Mi(e) || (this.state = N.BeforeAttributeName, this.stateBeforeAttributeName(e));
  }
  stateInAttributeName(e) {
    (e === z.Eq || io(e)) && (this.cbs.onattribname(this.sectionStart, this.index), this.sectionStart = -1, this.state = N.AfterAttributeName, this.stateAfterAttributeName(e));
  }
  stateAfterAttributeName(e) {
    e === z.Eq ? this.state = N.BeforeAttributeValue : e === z.Slash || e === z.Gt ? (this.cbs.onattribend(Di.NoValue, this.index), this.state = N.BeforeAttributeName, this.stateBeforeAttributeName(e)) : Mi(e) || (this.cbs.onattribend(Di.NoValue, this.index), this.state = N.InAttributeName, this.sectionStart = this.index);
  }
  stateBeforeAttributeValue(e) {
    e === z.DoubleQuote ? (this.state = N.InAttributeValueDq, this.sectionStart = this.index + 1) : e === z.SingleQuote ? (this.state = N.InAttributeValueSq, this.sectionStart = this.index + 1) : Mi(e) || (this.sectionStart = this.index, this.state = N.InAttributeValueNq, this.stateInAttributeValueNoQuotes(e));
  }
  handleInAttributeValue(e, t) {
    e === t || !this.decodeEntities && this.fastForwardTo(t) ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(t === z.DoubleQuote ? Di.Double : Di.Single, this.index), this.state = N.BeforeAttributeName) : this.decodeEntities && e === z.Amp && (this.baseState = this.state, this.state = N.BeforeEntity);
  }
  stateInAttributeValueDoubleQuotes(e) {
    this.handleInAttributeValue(e, z.DoubleQuote);
  }
  stateInAttributeValueSingleQuotes(e) {
    this.handleInAttributeValue(e, z.SingleQuote);
  }
  stateInAttributeValueNoQuotes(e) {
    Mi(e) || e === z.Gt ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(Di.Unquoted, this.index), this.state = N.BeforeAttributeName, this.stateBeforeAttributeName(e)) : this.decodeEntities && e === z.Amp && (this.baseState = this.state, this.state = N.BeforeEntity);
  }
  stateBeforeDeclaration(e) {
    e === z.OpeningSquareBracket ? (this.state = N.CDATASequence, this.sequenceIndex = 0) : this.state = e === z.Dash ? N.BeforeComment : N.InDeclaration;
  }
  stateInDeclaration(e) {
    (e === z.Gt || this.fastForwardTo(z.Gt)) && (this.cbs.ondeclaration(this.sectionStart, this.index), this.state = N.Text, this.sectionStart = this.index + 1);
  }
  stateInProcessingInstruction(e) {
    (e === z.Gt || this.fastForwardTo(z.Gt)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = N.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeComment(e) {
    e === z.Dash ? (this.state = N.InCommentLike, this.currentSequence = Pt.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = N.InDeclaration;
  }
  stateInSpecialComment(e) {
    (e === z.Gt || this.fastForwardTo(z.Gt)) && (this.cbs.oncomment(this.sectionStart, this.index, 0), this.state = N.Text, this.sectionStart = this.index + 1);
  }
  stateBeforeSpecialS(e) {
    const t = e | 32;
    t === Pt.ScriptEnd[3] ? this.startSpecial(Pt.ScriptEnd, 4) : t === Pt.StyleEnd[3] ? this.startSpecial(Pt.StyleEnd, 4) : (this.state = N.InTagName, this.stateInTagName(e));
  }
  stateBeforeEntity(e) {
    this.entityExcess = 1, this.entityResult = 0, e === z.Num ? this.state = N.BeforeNumericEntity : e === z.Amp || (this.trieIndex = 0, this.trieCurrent = this.entityTrie[0], this.state = N.InNamedEntity, this.stateInNamedEntity(e));
  }
  stateInNamedEntity(e) {
    if (this.entityExcess += 1, this.trieIndex = wm(this.entityTrie, this.trieCurrent, this.trieIndex + 1, e), this.trieIndex < 0) {
      this.emitNamedEntity(), this.index--;
      return;
    }
    this.trieCurrent = this.entityTrie[this.trieIndex];
    const t = this.trieCurrent & Oi.VALUE_LENGTH;
    if (t) {
      const i = (t >> 14) - 1;
      if (!this.allowLegacyEntity() && e !== z.Semi)
        this.trieIndex += i;
      else {
        const n = this.index - this.entityExcess + 1;
        n > this.sectionStart && this.emitPartial(this.sectionStart, n), this.entityResult = this.trieIndex, this.trieIndex += i, this.entityExcess = 0, this.sectionStart = this.index + 1, i === 0 && this.emitNamedEntity();
      }
    }
  }
  emitNamedEntity() {
    if (this.state = this.baseState, this.entityResult === 0)
      return;
    switch ((this.entityTrie[this.entityResult] & Oi.VALUE_LENGTH) >> 14) {
      case 1:
        this.emitCodePoint(this.entityTrie[this.entityResult] & ~Oi.VALUE_LENGTH);
        break;
      case 2:
        this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
        break;
      case 3:
        this.emitCodePoint(this.entityTrie[this.entityResult + 1]), this.emitCodePoint(this.entityTrie[this.entityResult + 2]);
    }
  }
  stateBeforeNumericEntity(e) {
    (e | 32) === z.LowerX ? (this.entityExcess++, this.state = N.InHexEntity) : (this.state = N.InNumericEntity, this.stateInNumericEntity(e));
  }
  emitNumericEntity(e) {
    const t = this.index - this.entityExcess - 1;
    t + 2 + Number(this.state === N.InHexEntity) !== this.index && (t > this.sectionStart && this.emitPartial(this.sectionStart, t), this.sectionStart = this.index + Number(e), this.emitCodePoint(bm(this.entityResult))), this.state = this.baseState;
  }
  stateInNumericEntity(e) {
    e === z.Semi ? this.emitNumericEntity(!0) : lc(e) ? (this.entityResult = this.entityResult * 10 + (e - z.Zero), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
  }
  stateInHexEntity(e) {
    e === z.Semi ? this.emitNumericEntity(!0) : lc(e) ? (this.entityResult = this.entityResult * 16 + (e - z.Zero), this.entityExcess++) : z_(e) ? (this.entityResult = this.entityResult * 16 + ((e | 32) - z.LowerA + 10), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--);
  }
  allowLegacyEntity() {
    return !this.xmlMode && (this.baseState === N.Text || this.baseState === N.InSpecialTag);
  }
  cleanup() {
    this.running && this.sectionStart !== this.index && (this.state === N.Text || this.state === N.InSpecialTag && this.sequenceIndex === 0 ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : (this.state === N.InAttributeValueDq || this.state === N.InAttributeValueSq || this.state === N.InAttributeValueNq) && (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index));
  }
  shouldContinue() {
    return this.index < this.buffer.length + this.offset && this.running;
  }
  parse() {
    for (; this.shouldContinue(); ) {
      const e = this.buffer.charCodeAt(this.index - this.offset);
      this.state === N.Text ? this.stateText(e) : this.state === N.SpecialStartSequence ? this.stateSpecialStartSequence(e) : this.state === N.InSpecialTag ? this.stateInSpecialTag(e) : this.state === N.CDATASequence ? this.stateCDATASequence(e) : this.state === N.InAttributeValueDq ? this.stateInAttributeValueDoubleQuotes(e) : this.state === N.InAttributeName ? this.stateInAttributeName(e) : this.state === N.InCommentLike ? this.stateInCommentLike(e) : this.state === N.InSpecialComment ? this.stateInSpecialComment(e) : this.state === N.BeforeAttributeName ? this.stateBeforeAttributeName(e) : this.state === N.InTagName ? this.stateInTagName(e) : this.state === N.InClosingTagName ? this.stateInClosingTagName(e) : this.state === N.BeforeTagName ? this.stateBeforeTagName(e) : this.state === N.AfterAttributeName ? this.stateAfterAttributeName(e) : this.state === N.InAttributeValueSq ? this.stateInAttributeValueSingleQuotes(e) : this.state === N.BeforeAttributeValue ? this.stateBeforeAttributeValue(e) : this.state === N.BeforeClosingTagName ? this.stateBeforeClosingTagName(e) : this.state === N.AfterClosingTagName ? this.stateAfterClosingTagName(e) : this.state === N.BeforeSpecialS ? this.stateBeforeSpecialS(e) : this.state === N.InAttributeValueNq ? this.stateInAttributeValueNoQuotes(e) : this.state === N.InSelfClosingTag ? this.stateInSelfClosingTag(e) : this.state === N.InDeclaration ? this.stateInDeclaration(e) : this.state === N.BeforeDeclaration ? this.stateBeforeDeclaration(e) : this.state === N.BeforeComment ? this.stateBeforeComment(e) : this.state === N.InProcessingInstruction ? this.stateInProcessingInstruction(e) : this.state === N.InNamedEntity ? this.stateInNamedEntity(e) : this.state === N.BeforeEntity ? this.stateBeforeEntity(e) : this.state === N.InHexEntity ? this.stateInHexEntity(e) : this.state === N.InNumericEntity ? this.stateInNumericEntity(e) : this.stateBeforeNumericEntity(e), this.index++;
    }
    this.cleanup();
  }
  finish() {
    this.state === N.InNamedEntity && this.emitNamedEntity(), this.sectionStart < this.index && this.handleTrailingData(), this.cbs.onend();
  }
  handleTrailingData() {
    const e = this.buffer.length + this.offset;
    this.state === N.InCommentLike ? this.currentSequence === Pt.CdataEnd ? this.cbs.oncdata(this.sectionStart, e, 0) : this.cbs.oncomment(this.sectionStart, e, 0) : this.state === N.InNumericEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === N.InHexEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === N.InTagName || this.state === N.BeforeAttributeName || this.state === N.BeforeAttributeValue || this.state === N.AfterAttributeName || this.state === N.InAttributeName || this.state === N.InAttributeValueSq || this.state === N.InAttributeValueDq || this.state === N.InAttributeValueNq || this.state === N.InClosingTagName || this.cbs.ontext(this.sectionStart, e);
  }
  emitPartial(e, t) {
    this.baseState !== N.Text && this.baseState !== N.InSpecialTag ? this.cbs.onattribdata(e, t) : this.cbs.ontext(e, t);
  }
  emitCodePoint(e) {
    this.baseState !== N.Text && this.baseState !== N.InSpecialTag ? this.cbs.onattribentity(e) : this.cbs.ontextentity(e);
  }
};
l(Sm, "Tokenizer");
var Ls = /* @__PURE__ */ new Set([
  "input",
  "option",
  "optgroup",
  "select",
  "button",
  "datalist",
  "textarea"
]), Le = /* @__PURE__ */ new Set(["p"]), V5 = /* @__PURE__ */ new Set(["thead", "tbody"]), U5 = /* @__PURE__ */ new Set(["dd", "dt"]), j5 = /* @__PURE__ */ new Set(["rt", "rp"]), nC = /* @__PURE__ */ new Map([
  ["tr", /* @__PURE__ */ new Set(["tr", "th", "td"])],
  ["th", /* @__PURE__ */ new Set(["th"])],
  ["td", /* @__PURE__ */ new Set(["thead", "th", "td"])],
  ["body", /* @__PURE__ */ new Set(["head", "link", "script"])],
  ["li", /* @__PURE__ */ new Set(["li"])],
  ["p", Le],
  ["h1", Le],
  ["h2", Le],
  ["h3", Le],
  ["h4", Le],
  ["h5", Le],
  ["h6", Le],
  ["select", Ls],
  ["input", Ls],
  ["output", Ls],
  ["button", Ls],
  ["datalist", Ls],
  ["textarea", Ls],
  ["option", /* @__PURE__ */ new Set(["option"])],
  ["optgroup", /* @__PURE__ */ new Set(["optgroup", "option"])],
  ["dd", U5],
  ["dt", U5],
  ["address", Le],
  ["article", Le],
  ["aside", Le],
  ["blockquote", Le],
  ["details", Le],
  ["div", Le],
  ["dl", Le],
  ["fieldset", Le],
  ["figcaption", Le],
  ["figure", Le],
  ["footer", Le],
  ["form", Le],
  ["header", Le],
  ["hr", Le],
  ["main", Le],
  ["nav", Le],
  ["ol", Le],
  ["pre", Le],
  ["section", Le],
  ["table", Le],
  ["ul", Le],
  ["rt", j5],
  ["rp", j5],
  ["tbody", V5],
  ["tfoot", V5]
]), sC = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]), H5 = /* @__PURE__ */ new Set(["math", "svg"]), W5 = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignobject",
  "desc",
  "title"
]), rC = /\s|\//, ru = class {
  constructor(e, t = {}) {
    var i, n, s, r, a;
    this.options = t, this.startIndex = 0, this.endIndex = 0, this.openTagStart = 0, this.tagname = "", this.attribname = "", this.attribvalue = "", this.attribs = null, this.stack = [], this.foreignContext = [], this.buffers = [], this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1, this.cbs = e != null ? e : {}, this.lowerCaseTagNames = (i = t.lowerCaseTags) !== null && i !== void 0 ? i : !t.xmlMode, this.lowerCaseAttributeNames = (n = t.lowerCaseAttributeNames) !== null && n !== void 0 ? n : !t.xmlMode, this.tokenizer = new ((s = t.Tokenizer) !== null && s !== void 0 ? s : Sm)(this.options, this), (a = (r = this.cbs).onparserinit) === null || a === void 0 || a.call(r, this);
  }
  ontext(e, t) {
    var i, n;
    const s = this.getSlice(e, t);
    this.endIndex = t - 1, (n = (i = this.cbs).ontext) === null || n === void 0 || n.call(i, s), this.startIndex = t;
  }
  ontextentity(e) {
    var t, i;
    const n = this.tokenizer.getSectionStart();
    this.endIndex = n - 1, (i = (t = this.cbs).ontext) === null || i === void 0 || i.call(t, ac(e)), this.startIndex = n;
  }
  isVoidElement(e) {
    return !this.options.xmlMode && sC.has(e);
  }
  onopentagname(e, t) {
    this.endIndex = t;
    let i = this.getSlice(e, t);
    this.lowerCaseTagNames && (i = i.toLowerCase()), this.emitOpenTag(i);
  }
  emitOpenTag(e) {
    var t, i, n, s;
    this.openTagStart = this.startIndex, this.tagname = e;
    const r = !this.options.xmlMode && nC.get(e);
    if (r)
      for (; this.stack.length > 0 && r.has(this.stack[this.stack.length - 1]); ) {
        const a = this.stack.pop();
        (i = (t = this.cbs).onclosetag) === null || i === void 0 || i.call(t, a, !0);
      }
    this.isVoidElement(e) || (this.stack.push(e), H5.has(e) ? this.foreignContext.push(!0) : W5.has(e) && this.foreignContext.push(!1)), (s = (n = this.cbs).onopentagname) === null || s === void 0 || s.call(n, e), this.cbs.onopentag && (this.attribs = {});
  }
  endOpenTag(e) {
    var t, i;
    this.startIndex = this.openTagStart, this.attribs && ((i = (t = this.cbs).onopentag) === null || i === void 0 || i.call(t, this.tagname, this.attribs, e), this.attribs = null), this.cbs.onclosetag && this.isVoidElement(this.tagname) && this.cbs.onclosetag(this.tagname, !0), this.tagname = "";
  }
  onopentagend(e) {
    this.endIndex = e, this.endOpenTag(!1), this.startIndex = e + 1;
  }
  onclosetag(e, t) {
    var i, n, s, r, a, u;
    this.endIndex = t;
    let c = this.getSlice(e, t);
    if (this.lowerCaseTagNames && (c = c.toLowerCase()), (H5.has(c) || W5.has(c)) && this.foreignContext.pop(), this.isVoidElement(c))
      !this.options.xmlMode && c === "br" && ((n = (i = this.cbs).onopentagname) === null || n === void 0 || n.call(i, "br"), (r = (s = this.cbs).onopentag) === null || r === void 0 || r.call(s, "br", {}, !0), (u = (a = this.cbs).onclosetag) === null || u === void 0 || u.call(a, "br", !1));
    else {
      const h = this.stack.lastIndexOf(c);
      if (h !== -1)
        if (this.cbs.onclosetag) {
          let p = this.stack.length - h;
          for (; p--; )
            this.cbs.onclosetag(this.stack.pop(), p !== 0);
        } else
          this.stack.length = h;
      else
        !this.options.xmlMode && c === "p" && (this.emitOpenTag("p"), this.closeCurrentTag(!0));
    }
    this.startIndex = t + 1;
  }
  onselfclosingtag(e) {
    this.endIndex = e, this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1] ? (this.closeCurrentTag(!1), this.startIndex = e + 1) : this.onopentagend(e);
  }
  closeCurrentTag(e) {
    var t, i;
    const n = this.tagname;
    this.endOpenTag(e), this.stack[this.stack.length - 1] === n && ((i = (t = this.cbs).onclosetag) === null || i === void 0 || i.call(t, n, !e), this.stack.pop());
  }
  onattribname(e, t) {
    this.startIndex = e;
    const i = this.getSlice(e, t);
    this.attribname = this.lowerCaseAttributeNames ? i.toLowerCase() : i;
  }
  onattribdata(e, t) {
    this.attribvalue += this.getSlice(e, t);
  }
  onattribentity(e) {
    this.attribvalue += ac(e);
  }
  onattribend(e, t) {
    var i, n;
    this.endIndex = t, (n = (i = this.cbs).onattribute) === null || n === void 0 || n.call(i, this.attribname, this.attribvalue, e === Di.Double ? '"' : e === Di.Single ? "'" : e === Di.NoValue ? void 0 : null), this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname) && (this.attribs[this.attribname] = this.attribvalue), this.attribvalue = "";
  }
  getInstructionName(e) {
    const t = e.search(rC);
    let i = t < 0 ? e : e.substr(0, t);
    return this.lowerCaseTagNames && (i = i.toLowerCase()), i;
  }
  ondeclaration(e, t) {
    this.endIndex = t;
    const i = this.getSlice(e, t);
    if (this.cbs.onprocessinginstruction) {
      const n = this.getInstructionName(i);
      this.cbs.onprocessinginstruction(`!${n}`, `!${i}`);
    }
    this.startIndex = t + 1;
  }
  onprocessinginstruction(e, t) {
    this.endIndex = t;
    const i = this.getSlice(e, t);
    if (this.cbs.onprocessinginstruction) {
      const n = this.getInstructionName(i);
      this.cbs.onprocessinginstruction(`?${n}`, `?${i}`);
    }
    this.startIndex = t + 1;
  }
  oncomment(e, t, i) {
    var n, s, r, a;
    this.endIndex = t, (s = (n = this.cbs).oncomment) === null || s === void 0 || s.call(n, this.getSlice(e, t - i)), (a = (r = this.cbs).oncommentend) === null || a === void 0 || a.call(r), this.startIndex = t + 1;
  }
  oncdata(e, t, i) {
    var n, s, r, a, u, c, h, p, m, b;
    this.endIndex = t;
    const C = this.getSlice(e, t - i);
    this.options.xmlMode || this.options.recognizeCDATA ? ((s = (n = this.cbs).oncdatastart) === null || s === void 0 || s.call(n), (a = (r = this.cbs).ontext) === null || a === void 0 || a.call(r, C), (c = (u = this.cbs).oncdataend) === null || c === void 0 || c.call(u)) : ((p = (h = this.cbs).oncomment) === null || p === void 0 || p.call(h, `[CDATA[${C}]]`), (b = (m = this.cbs).oncommentend) === null || b === void 0 || b.call(m)), this.startIndex = t + 1;
  }
  onend() {
    var e, t;
    if (this.cbs.onclosetag) {
      this.endIndex = this.startIndex;
      for (let i = this.stack.length; i > 0; this.cbs.onclosetag(this.stack[--i], !0))
        ;
    }
    (t = (e = this.cbs).onend) === null || t === void 0 || t.call(e);
  }
  reset() {
    var e, t, i, n;
    (t = (e = this.cbs).onreset) === null || t === void 0 || t.call(e), this.tokenizer.reset(), this.tagname = "", this.attribname = "", this.attribs = null, this.stack.length = 0, this.startIndex = 0, this.endIndex = 0, (n = (i = this.cbs).onparserinit) === null || n === void 0 || n.call(i, this), this.buffers.length = 0, this.bufferOffset = 0, this.writeIndex = 0, this.ended = !1;
  }
  parseComplete(e) {
    this.reset(), this.end(e);
  }
  getSlice(e, t) {
    for (; e - this.bufferOffset >= this.buffers[0].length; )
      this.shiftBuffer();
    let i = this.buffers[0].slice(e - this.bufferOffset, t - this.bufferOffset);
    for (; t - this.bufferOffset > this.buffers[0].length; )
      this.shiftBuffer(), i += this.buffers[0].slice(0, t - this.bufferOffset);
    return i;
  }
  shiftBuffer() {
    this.bufferOffset += this.buffers[0].length, this.writeIndex--, this.buffers.shift();
  }
  write(e) {
    var t, i;
    if (this.ended) {
      (i = (t = this.cbs).onerror) === null || i === void 0 || i.call(t, new Error(".write() after done!"));
      return;
    }
    this.buffers.push(e), this.tokenizer.running && (this.tokenizer.write(e), this.writeIndex++);
  }
  end(e) {
    var t, i;
    if (this.ended) {
      (i = (t = this.cbs).onerror) === null || i === void 0 || i.call(t, Error(".end() after done!"));
      return;
    }
    e && this.write(e), this.ended = !0, this.tokenizer.end();
  }
  pause() {
    this.tokenizer.pause();
  }
  resume() {
    for (this.tokenizer.resume(); this.tokenizer.running && this.writeIndex < this.buffers.length; )
      this.tokenizer.write(this.buffers[this.writeIndex++]);
    this.ended && this.tokenizer.end();
  }
  parseChunk(e) {
    this.write(e);
  }
  done(e) {
    this.end(e);
  }
};
l(ru, "Parser");
var K_ = {};
Yo(K_, {
  CDATA: () => ib,
  Comment: () => Z_,
  Directive: () => J_,
  Doctype: () => nb,
  ElementType: () => ke,
  Root: () => Y_,
  Script: () => Q_,
  Style: () => eb,
  Tag: () => tb,
  Text: () => X_,
  isTag: () => Cm
});
var ke;
(function(e) {
  e.Root = "root", e.Text = "text", e.Directive = "directive", e.Comment = "comment", e.Script = "script", e.Style = "style", e.Tag = "tag", e.CDATA = "cdata", e.Doctype = "doctype";
})(ke || (ke = {}));
function Cm(e) {
  return e.type === ke.Tag || e.type === ke.Script || e.type === ke.Style;
}
l(Cm, "isTag");
var Y_ = ke.Root, X_ = ke.Text, J_ = ke.Directive, Z_ = ke.Comment, Q_ = ke.Script, eb = ke.Style, tb = ke.Tag, ib = ke.CDATA, nb = ke.Doctype, Tm = class {
  constructor() {
    this.parent = null, this.prev = null, this.next = null, this.startIndex = null, this.endIndex = null;
  }
  get parentNode() {
    return this.parent;
  }
  set parentNode(e) {
    this.parent = e;
  }
  get previousSibling() {
    return this.prev;
  }
  set previousSibling(e) {
    this.prev = e;
  }
  get nextSibling() {
    return this.next;
  }
  set nextSibling(e) {
    this.next = e;
  }
  cloneNode(e = !1) {
    return Pm(this, e);
  }
};
l(Tm, "Node");
var ou = class extends Tm {
  constructor(e) {
    super(), this.data = e;
  }
  get nodeValue() {
    return this.data;
  }
  set nodeValue(e) {
    this.data = e;
  }
};
l(ou, "DataNode");
var Dl = class extends ou {
  constructor() {
    super(...arguments), this.type = ke.Text;
  }
  get nodeType() {
    return 3;
  }
};
l(Dl, "Text");
var xm = class extends ou {
  constructor() {
    super(...arguments), this.type = ke.Comment;
  }
  get nodeType() {
    return 8;
  }
};
l(xm, "Comment");
var Em = class extends ou {
  constructor(e, t) {
    super(t), this.name = e, this.type = ke.Directive;
  }
  get nodeType() {
    return 1;
  }
};
l(Em, "ProcessingInstruction");
var au = class extends Tm {
  constructor(e) {
    super(), this.children = e;
  }
  get firstChild() {
    var e;
    return (e = this.children[0]) !== null && e !== void 0 ? e : null;
  }
  get lastChild() {
    return this.children.length > 0 ? this.children[this.children.length - 1] : null;
  }
  get childNodes() {
    return this.children;
  }
  set childNodes(e) {
    this.children = e;
  }
};
l(au, "NodeWithChildren");
var Am = class extends au {
  constructor() {
    super(...arguments), this.type = ke.CDATA;
  }
  get nodeType() {
    return 4;
  }
};
l(Am, "CDATA");
var Bl = class extends au {
  constructor() {
    super(...arguments), this.type = ke.Root;
  }
  get nodeType() {
    return 9;
  }
};
l(Bl, "Document");
var km = class extends au {
  constructor(e, t, i = [], n = e === "script" ? ke.Script : e === "style" ? ke.Style : ke.Tag) {
    super(i), this.name = e, this.attribs = t, this.type = n;
  }
  get nodeType() {
    return 1;
  }
  get tagName() {
    return this.name;
  }
  set tagName(e) {
    this.name = e;
  }
  get attributes() {
    return Object.keys(this.attribs).map((e) => {
      var t, i;
      return {
        name: e,
        value: this.attribs[e],
        namespace: (t = this["x-attribsNamespace"]) === null || t === void 0 ? void 0 : t[e],
        prefix: (i = this["x-attribsPrefix"]) === null || i === void 0 ? void 0 : i[e]
      };
    });
  }
};
l(km, "Element");
function Et(e) {
  return Cm(e);
}
l(Et, "isTag");
function ra(e) {
  return e.type === ke.CDATA;
}
l(ra, "isCDATA");
function Fn(e) {
  return e.type === ke.Text;
}
l(Fn, "isText");
function lu(e) {
  return e.type === ke.Comment;
}
l(lu, "isComment");
function sb(e) {
  return e.type === ke.Directive;
}
l(sb, "isDirective");
function Im(e) {
  return e.type === ke.Root;
}
l(Im, "isDocument");
function on(e) {
  return Object.prototype.hasOwnProperty.call(e, "children");
}
l(on, "hasChildren");
function Pm(e, t = !1) {
  let i;
  if (Fn(e))
    i = new Dl(e.data);
  else if (lu(e))
    i = new xm(e.data);
  else if (Et(e)) {
    const n = t ? Qa(e.children) : [], s = new km(e.name, So({}, e.attribs), n);
    n.forEach((r) => r.parent = s), e.namespace != null && (s.namespace = e.namespace), e["x-attribsNamespace"] && (s["x-attribsNamespace"] = So({}, e["x-attribsNamespace"])), e["x-attribsPrefix"] && (s["x-attribsPrefix"] = So({}, e["x-attribsPrefix"])), i = s;
  } else if (ra(e)) {
    const n = t ? Qa(e.children) : [], s = new Am(n);
    n.forEach((r) => r.parent = s), i = s;
  } else if (Im(e)) {
    const n = t ? Qa(e.children) : [], s = new Bl(n);
    n.forEach((r) => r.parent = s), e["x-mode"] && (s["x-mode"] = e["x-mode"]), i = s;
  } else if (sb(e)) {
    const n = new Em(e.name, e.data);
    e["x-name"] != null && (n["x-name"] = e["x-name"], n["x-publicId"] = e["x-publicId"], n["x-systemId"] = e["x-systemId"]), i = n;
  } else
    throw new Error(`Not implemented yet: ${e.type}`);
  return i.startIndex = e.startIndex, i.endIndex = e.endIndex, e.sourceCodeLocation != null && (i.sourceCodeLocation = e.sourceCodeLocation), i;
}
l(Pm, "cloneNode");
function Qa(e) {
  const t = e.map((i) => Pm(i, !0));
  for (let i = 1; i < t.length; i++)
    t[i].prev = t[i - 1], t[i - 1].next = t[i];
  return t;
}
l(Qa, "cloneChildren");
var $5 = {
  withStartIndices: !1,
  withEndIndices: !1,
  xmlMode: !1
}, Ho = class {
  constructor(e, t, i) {
    this.dom = [], this.root = new Bl(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null, typeof t == "function" && (i = t, t = $5), typeof e == "object" && (t = e, e = void 0), this.callback = e != null ? e : null, this.options = t != null ? t : $5, this.elementCB = i != null ? i : null;
  }
  onparserinit(e) {
    this.parser = e;
  }
  onreset() {
    this.dom = [], this.root = new Bl(this.dom), this.done = !1, this.tagStack = [this.root], this.lastNode = null, this.parser = null;
  }
  onend() {
    this.done || (this.done = !0, this.parser = null, this.handleCallback(null));
  }
  onerror(e) {
    this.handleCallback(e);
  }
  onclosetag() {
    this.lastNode = null;
    const e = this.tagStack.pop();
    this.options.withEndIndices && (e.endIndex = this.parser.endIndex), this.elementCB && this.elementCB(e);
  }
  onopentag(e, t) {
    const i = this.options.xmlMode ? ke.Tag : void 0, n = new km(e, t, void 0, i);
    this.addNode(n), this.tagStack.push(n);
  }
  ontext(e) {
    const { lastNode: t } = this;
    if (t && t.type === ke.Text)
      t.data += e, this.options.withEndIndices && (t.endIndex = this.parser.endIndex);
    else {
      const i = new Dl(e);
      this.addNode(i), this.lastNode = i;
    }
  }
  oncomment(e) {
    if (this.lastNode && this.lastNode.type === ke.Comment) {
      this.lastNode.data += e;
      return;
    }
    const t = new xm(e);
    this.addNode(t), this.lastNode = t;
  }
  oncommentend() {
    this.lastNode = null;
  }
  oncdatastart() {
    const e = new Dl(""), t = new Am([e]);
    this.addNode(t), e.parent = t, this.lastNode = e;
  }
  oncdataend() {
    this.lastNode = null;
  }
  onprocessinginstruction(e, t) {
    const i = new Em(e, t);
    this.addNode(i);
  }
  handleCallback(e) {
    if (typeof this.callback == "function")
      this.callback(e, this.dom);
    else if (e)
      throw e;
  }
  addNode(e) {
    const t = this.tagStack[this.tagStack.length - 1], i = t.children[t.children.length - 1];
    this.options.withStartIndices && (e.startIndex = this.parser.startIndex), this.options.withEndIndices && (e.endIndex = this.parser.endIndex), t.children.push(e), i && (e.prev = i, i.next = e), e.parent = t, this.lastNode = null;
  }
};
l(Ho, "DomHandler");
var uu = {};
Yo(uu, {
  DocumentPosition: () => ii,
  append: () => Sb,
  appendChild: () => wb,
  compareDocumentPosition: () => Vm,
  existsOne: () => Bm,
  filter: () => oa,
  find: () => hu,
  findAll: () => Eb,
  findOne: () => du,
  findOneChild: () => xb,
  getAttributeValue: () => mb,
  getChildren: () => Lm,
  getElementById: () => Pb,
  getElements: () => Ib,
  getElementsByTagName: () => Cs,
  getElementsByTagType: () => Mb,
  getFeed: () => pu,
  getInnerHTML: () => pb,
  getName: () => gb,
  getOuterHTML: () => Rm,
  getParent: () => Dm,
  getSiblings: () => fb,
  getText: () => Mo,
  hasAttrib: () => vb,
  hasChildren: () => on,
  innerText: () => Ol,
  isCDATA: () => ra,
  isComment: () => lu,
  isDocument: () => Im,
  isTag: () => Et,
  isText: () => Fn,
  nextElementSibling: () => yb,
  prepend: () => Tb,
  prependChild: () => Cb,
  prevElementSibling: () => _b,
  removeElement: () => yr,
  removeSubsets: () => Nb,
  replaceElement: () => bb,
  testElement: () => kb,
  textContent: () => Wo,
  uniqueSort: () => Rb
});
var G5 = /["&'<>$\x80-\uFFFF]/g, oC = /* @__PURE__ */ new Map([
  [34, "&quot;"],
  [38, "&amp;"],
  [39, "&apos;"],
  [60, "&lt;"],
  [62, "&gt;"]
]), aC = String.prototype.codePointAt != null ? (e, t) => e.codePointAt(t) : (e, t) => (e.charCodeAt(t) & 64512) === 55296 ? (e.charCodeAt(t) - 55296) * 1024 + e.charCodeAt(t + 1) - 56320 + 65536 : e.charCodeAt(t);
function Mm(e) {
  let t = "", i = 0, n;
  for (; (n = G5.exec(e)) !== null; ) {
    const s = n.index, r = e.charCodeAt(s), a = oC.get(r);
    a !== void 0 ? (t += e.substring(i, s) + a, i = s + 1) : (t += `${e.substring(i, s)}&#x${aC(e, s).toString(16)};`, i = G5.lastIndex += Number((r & 64512) === 55296));
  }
  return t + e.substr(i);
}
l(Mm, "encodeXML");
function Nm(e, t) {
  return /* @__PURE__ */ l(function(n) {
    let s, r = 0, a = "";
    for (; s = e.exec(n); )
      r !== s.index && (a += n.substring(r, s.index)), a += t.get(s[0].charCodeAt(0)), r = s.index + 1;
    return a + n.substring(r);
  }, "escape");
}
l(Nm, "getEscaper");
var lC = Nm(/["&\u00A0]/g, /* @__PURE__ */ new Map([
  [34, "&quot;"],
  [38, "&amp;"],
  [160, "&nbsp;"]
])), uC = Nm(/[&<>\u00A0]/g, /* @__PURE__ */ new Map([
  [38, "&amp;"],
  [60, "&lt;"],
  [62, "&gt;"],
  [160, "&nbsp;"]
])), q5;
(function(e) {
  e[e.XML = 0] = "XML", e[e.HTML = 1] = "HTML";
})(q5 || (q5 = {}));
var z5;
(function(e) {
  e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict";
})(z5 || (z5 = {}));
var K5;
(function(e) {
  e[e.UTF8 = 0] = "UTF8", e[e.ASCII = 1] = "ASCII", e[e.Extensive = 2] = "Extensive", e[e.Attribute = 3] = "Attribute", e[e.Text = 4] = "Text";
})(K5 || (K5 = {}));
var cC = new Map([
  "altGlyph",
  "altGlyphDef",
  "altGlyphItem",
  "animateColor",
  "animateMotion",
  "animateTransform",
  "clipPath",
  "feBlend",
  "feColorMatrix",
  "feComponentTransfer",
  "feComposite",
  "feConvolveMatrix",
  "feDiffuseLighting",
  "feDisplacementMap",
  "feDistantLight",
  "feDropShadow",
  "feFlood",
  "feFuncA",
  "feFuncB",
  "feFuncG",
  "feFuncR",
  "feGaussianBlur",
  "feImage",
  "feMerge",
  "feMergeNode",
  "feMorphology",
  "feOffset",
  "fePointLight",
  "feSpecularLighting",
  "feSpotLight",
  "feTile",
  "feTurbulence",
  "foreignObject",
  "glyphRef",
  "linearGradient",
  "radialGradient",
  "textPath"
].map((e) => [e.toLowerCase(), e])), hC = new Map([
  "definitionURL",
  "attributeName",
  "attributeType",
  "baseFrequency",
  "baseProfile",
  "calcMode",
  "clipPathUnits",
  "diffuseConstant",
  "edgeMode",
  "filterUnits",
  "glyphRef",
  "gradientTransform",
  "gradientUnits",
  "kernelMatrix",
  "kernelUnitLength",
  "keyPoints",
  "keySplines",
  "keyTimes",
  "lengthAdjust",
  "limitingConeAngle",
  "markerHeight",
  "markerUnits",
  "markerWidth",
  "maskContentUnits",
  "maskUnits",
  "numOctaves",
  "pathLength",
  "patternContentUnits",
  "patternTransform",
  "patternUnits",
  "pointsAtX",
  "pointsAtY",
  "pointsAtZ",
  "preserveAlpha",
  "preserveAspectRatio",
  "primitiveUnits",
  "refX",
  "refY",
  "repeatCount",
  "repeatDur",
  "requiredExtensions",
  "requiredFeatures",
  "specularConstant",
  "specularExponent",
  "spreadMethod",
  "startOffset",
  "stdDeviation",
  "stitchTiles",
  "surfaceScale",
  "systemLanguage",
  "tableValues",
  "targetX",
  "targetY",
  "textLength",
  "viewBox",
  "viewTarget",
  "xChannelSelector",
  "yChannelSelector",
  "zoomAndPan"
].map((e) => [e.toLowerCase(), e])), dC = /* @__PURE__ */ new Set([
  "style",
  "script",
  "xmp",
  "iframe",
  "noembed",
  "noframes",
  "plaintext",
  "noscript"
]);
function rb(e) {
  return e.replace(/"/g, "&quot;");
}
l(rb, "replaceQuotes");
function ob(e, t) {
  var i;
  if (!e)
    return;
  const n = ((i = t.encodeEntities) !== null && i !== void 0 ? i : t.decodeEntities) === !1 ? rb : t.xmlMode || t.encodeEntities !== "utf8" ? Mm : lC;
  return Object.keys(e).map((s) => {
    var r, a;
    const u = (r = e[s]) !== null && r !== void 0 ? r : "";
    return t.xmlMode === "foreign" && (s = (a = hC.get(s)) !== null && a !== void 0 ? a : s), !t.emptyAttrs && !t.xmlMode && u === "" ? s : `${s}="${n(u)}"`;
  }).join(" ");
}
l(ob, "formatAttributes");
var Y5 = /* @__PURE__ */ new Set([
  "area",
  "base",
  "basefont",
  "br",
  "col",
  "command",
  "embed",
  "frame",
  "hr",
  "img",
  "input",
  "isindex",
  "keygen",
  "link",
  "meta",
  "param",
  "source",
  "track",
  "wbr"
]);
function cu(e, t = {}) {
  const i = "length" in e ? e : [e];
  let n = "";
  for (let s = 0; s < i.length; s++)
    n += ab(i[s], t);
  return n;
}
l(cu, "render");
var pC = cu;
function ab(e, t) {
  switch (e.type) {
    case Y_:
      return cu(e.children, t);
    case nb:
    case J_:
      return ub(e);
    case Z_:
      return db(e);
    case ib:
      return hb(e);
    case Q_:
    case eb:
    case tb:
      return lb(e, t);
    case X_:
      return cb(e, t);
  }
}
l(ab, "renderNode");
var fC = /* @__PURE__ */ new Set([
  "mi",
  "mo",
  "mn",
  "ms",
  "mtext",
  "annotation-xml",
  "foreignObject",
  "desc",
  "title"
]), mC = /* @__PURE__ */ new Set(["svg", "math"]);
function lb(e, t) {
  var i;
  t.xmlMode === "foreign" && (e.name = (i = cC.get(e.name)) !== null && i !== void 0 ? i : e.name, e.parent && fC.has(e.parent.name) && (t = y5(So({}, t), { xmlMode: !1 }))), !t.xmlMode && mC.has(e.name) && (t = y5(So({}, t), { xmlMode: "foreign" }));
  let n = `<${e.name}`;
  const s = ob(e.attribs, t);
  return s && (n += ` ${s}`), e.children.length === 0 && (t.xmlMode ? t.selfClosingTags !== !1 : t.selfClosingTags && Y5.has(e.name)) ? (t.xmlMode || (n += " "), n += "/>") : (n += ">", e.children.length > 0 && (n += cu(e.children, t)), (t.xmlMode || !Y5.has(e.name)) && (n += `</${e.name}>`)), n;
}
l(lb, "renderTag");
function ub(e) {
  return `<${e.data}>`;
}
l(ub, "renderDirective");
function cb(e, t) {
  var i;
  let n = e.data || "";
  return ((i = t.encodeEntities) !== null && i !== void 0 ? i : t.decodeEntities) !== !1 && !(!t.xmlMode && e.parent && dC.has(e.parent.name)) && (n = t.xmlMode || t.encodeEntities !== "utf8" ? Mm(n) : uC(n)), n;
}
l(cb, "renderText");
function hb(e) {
  return `<![CDATA[${e.children[0].data}]]>`;
}
l(hb, "renderCdata");
function db(e) {
  return `<!--${e.data}-->`;
}
l(db, "renderComment");
function Rm(e, t) {
  return pC(e, t);
}
l(Rm, "getOuterHTML");
function pb(e, t) {
  return on(e) ? e.children.map((i) => Rm(i, t)).join("") : "";
}
l(pb, "getInnerHTML");
function Mo(e) {
  return Array.isArray(e) ? e.map(Mo).join("") : Et(e) ? e.name === "br" ? `
` : Mo(e.children) : ra(e) ? Mo(e.children) : Fn(e) ? e.data : "";
}
l(Mo, "getText");
function Wo(e) {
  return Array.isArray(e) ? e.map(Wo).join("") : on(e) && !lu(e) ? Wo(e.children) : Fn(e) ? e.data : "";
}
l(Wo, "textContent");
function Ol(e) {
  return Array.isArray(e) ? e.map(Ol).join("") : on(e) && (e.type === ke.Tag || ra(e)) ? Ol(e.children) : Fn(e) ? e.data : "";
}
l(Ol, "innerText");
function Lm(e) {
  return on(e) ? e.children : [];
}
l(Lm, "getChildren");
function Dm(e) {
  return e.parent || null;
}
l(Dm, "getParent");
function fb(e) {
  const t = Dm(e);
  if (t != null)
    return Lm(t);
  const i = [e];
  let { prev: n, next: s } = e;
  for (; n != null; )
    i.unshift(n), { prev: n } = n;
  for (; s != null; )
    i.push(s), { next: s } = s;
  return i;
}
l(fb, "getSiblings");
function mb(e, t) {
  var i;
  return (i = e.attribs) === null || i === void 0 ? void 0 : i[t];
}
l(mb, "getAttributeValue");
function vb(e, t) {
  return e.attribs != null && Object.prototype.hasOwnProperty.call(e.attribs, t) && e.attribs[t] != null;
}
l(vb, "hasAttrib");
function gb(e) {
  return e.name;
}
l(gb, "getName");
function yb(e) {
  let { next: t } = e;
  for (; t !== null && !Et(t); )
    ({ next: t } = t);
  return t;
}
l(yb, "nextElementSibling");
function _b(e) {
  let { prev: t } = e;
  for (; t !== null && !Et(t); )
    ({ prev: t } = t);
  return t;
}
l(_b, "prevElementSibling");
function yr(e) {
  if (e.prev && (e.prev.next = e.next), e.next && (e.next.prev = e.prev), e.parent) {
    const t = e.parent.children;
    t.splice(t.lastIndexOf(e), 1);
  }
}
l(yr, "removeElement");
function bb(e, t) {
  const i = t.prev = e.prev;
  i && (i.next = t);
  const n = t.next = e.next;
  n && (n.prev = t);
  const s = t.parent = e.parent;
  if (s) {
    const r = s.children;
    r[r.lastIndexOf(e)] = t, e.parent = null;
  }
}
l(bb, "replaceElement");
function wb(e, t) {
  if (yr(t), t.next = null, t.parent = e, e.children.push(t) > 1) {
    const i = e.children[e.children.length - 2];
    i.next = t, t.prev = i;
  } else
    t.prev = null;
}
l(wb, "appendChild");
function Sb(e, t) {
  yr(t);
  const { parent: i } = e, n = e.next;
  if (t.next = n, t.prev = e, e.next = t, t.parent = i, n) {
    if (n.prev = t, i) {
      const s = i.children;
      s.splice(s.lastIndexOf(n), 0, t);
    }
  } else
    i && i.children.push(t);
}
l(Sb, "append");
function Cb(e, t) {
  if (yr(t), t.parent = e, t.prev = null, e.children.unshift(t) !== 1) {
    const i = e.children[1];
    i.prev = t, t.next = i;
  } else
    t.next = null;
}
l(Cb, "prependChild");
function Tb(e, t) {
  yr(t);
  const { parent: i } = e;
  if (i) {
    const n = i.children;
    n.splice(n.indexOf(e), 0, t);
  }
  e.prev && (e.prev.next = t), t.parent = i, t.prev = e.prev, t.next = e, e.prev = t;
}
l(Tb, "prepend");
function oa(e, t, i = !0, n = 1 / 0) {
  return Array.isArray(t) || (t = [t]), hu(e, t, i, n);
}
l(oa, "filter");
function hu(e, t, i, n) {
  const s = [];
  for (const r of t) {
    if (e(r) && (s.push(r), --n <= 0))
      break;
    if (i && on(r) && r.children.length > 0) {
      const a = hu(e, r.children, i, n);
      if (s.push(...a), n -= a.length, n <= 0)
        break;
    }
  }
  return s;
}
l(hu, "find");
function xb(e, t) {
  return t.find(e);
}
l(xb, "findOneChild");
function du(e, t, i = !0) {
  let n = null;
  for (let s = 0; s < t.length && !n; s++) {
    const r = t[s];
    if (Et(r))
      e(r) ? n = r : i && r.children.length > 0 && (n = du(e, r.children, !0));
    else
      continue;
  }
  return n;
}
l(du, "findOne");
function Bm(e, t) {
  return t.some((i) => Et(i) && (e(i) || i.children.length > 0 && Bm(e, i.children)));
}
l(Bm, "existsOne");
function Eb(e, t) {
  var i;
  const n = [], s = t.filter(Et);
  let r;
  for (; r = s.shift(); ) {
    const a = (i = r.children) === null || i === void 0 ? void 0 : i.filter(Et);
    a && a.length > 0 && s.unshift(...a), e(r) && n.push(r);
  }
  return n;
}
l(Eb, "findAll");
var Fl = {
  tag_name(e) {
    return typeof e == "function" ? (t) => Et(t) && e(t.name) : e === "*" ? Et : (t) => Et(t) && t.name === e;
  },
  tag_type(e) {
    return typeof e == "function" ? (t) => e(t.type) : (t) => t.type === e;
  },
  tag_contains(e) {
    return typeof e == "function" ? (t) => Fn(t) && e(t.data) : (t) => Fn(t) && t.data === e;
  }
};
function Om(e, t) {
  return typeof t == "function" ? (i) => Et(i) && t(i.attribs[e]) : (i) => Et(i) && i.attribs[e] === t;
}
l(Om, "getAttribCheck");
function Ab(e, t) {
  return (i) => e(i) || t(i);
}
l(Ab, "combineFuncs");
function Fm(e) {
  const t = Object.keys(e).map((i) => {
    const n = e[i];
    return Object.prototype.hasOwnProperty.call(Fl, i) ? Fl[i](n) : Om(i, n);
  });
  return t.length === 0 ? null : t.reduce(Ab);
}
l(Fm, "compileTest");
function kb(e, t) {
  const i = Fm(e);
  return i ? i(t) : !0;
}
l(kb, "testElement");
function Ib(e, t, i, n = 1 / 0) {
  const s = Fm(e);
  return s ? oa(s, t, i, n) : [];
}
l(Ib, "getElements");
function Pb(e, t, i = !0) {
  return Array.isArray(t) || (t = [t]), du(Om("id", e), t, i);
}
l(Pb, "getElementById");
function Cs(e, t, i = !0, n = 1 / 0) {
  return oa(Fl.tag_name(e), t, i, n);
}
l(Cs, "getElementsByTagName");
function Mb(e, t, i = !0, n = 1 / 0) {
  return oa(Fl.tag_type(e), t, i, n);
}
l(Mb, "getElementsByTagType");
function Nb(e) {
  let t = e.length;
  for (; --t >= 0; ) {
    const i = e[t];
    if (t > 0 && e.lastIndexOf(i, t - 1) >= 0) {
      e.splice(t, 1);
      continue;
    }
    for (let n = i.parent; n; n = n.parent)
      if (e.includes(n)) {
        e.splice(t, 1);
        break;
      }
  }
  return e;
}
l(Nb, "removeSubsets");
var ii;
(function(e) {
  e[e.DISCONNECTED = 1] = "DISCONNECTED", e[e.PRECEDING = 2] = "PRECEDING", e[e.FOLLOWING = 4] = "FOLLOWING", e[e.CONTAINS = 8] = "CONTAINS", e[e.CONTAINED_BY = 16] = "CONTAINED_BY";
})(ii || (ii = {}));
function Vm(e, t) {
  const i = [], n = [];
  if (e === t)
    return 0;
  let s = on(e) ? e : e.parent;
  for (; s; )
    i.unshift(s), s = s.parent;
  for (s = on(t) ? t : t.parent; s; )
    n.unshift(s), s = s.parent;
  const r = Math.min(i.length, n.length);
  let a = 0;
  for (; a < r && i[a] === n[a]; )
    a++;
  if (a === 0)
    return ii.DISCONNECTED;
  const u = i[a - 1], c = u.children, h = i[a], p = n[a];
  return c.indexOf(h) > c.indexOf(p) ? u === t ? ii.FOLLOWING | ii.CONTAINED_BY : ii.FOLLOWING : u === e ? ii.PRECEDING | ii.CONTAINS : ii.PRECEDING;
}
l(Vm, "compareDocumentPosition");
function Rb(e) {
  return e = e.filter((t, i, n) => !n.includes(t, i + 1)), e.sort((t, i) => {
    const n = Vm(t, i);
    return n & ii.PRECEDING ? -1 : n & ii.FOLLOWING ? 1 : 0;
  }), e;
}
l(Rb, "uniqueSort");
function pu(e) {
  const t = $o(Bb, e);
  return t ? t.name === "feed" ? Lb(t) : Db(t) : null;
}
l(pu, "getFeed");
function Lb(e) {
  var t;
  const i = e.children, n = {
    type: "atom",
    items: Cs("entry", i).map((a) => {
      var u;
      const { children: c } = a, h = { media: Um(c) };
      Tt(h, "id", "id", c), Tt(h, "title", "title", c);
      const p = (u = $o("link", c)) === null || u === void 0 ? void 0 : u.attribs.href;
      p && (h.link = p);
      const m = Mn("summary", c) || Mn("content", c);
      m && (h.description = m);
      const b = Mn("updated", c);
      return b && (h.pubDate = new Date(b)), h;
    })
  };
  Tt(n, "id", "id", i), Tt(n, "title", "title", i);
  const s = (t = $o("link", i)) === null || t === void 0 ? void 0 : t.attribs.href;
  s && (n.link = s), Tt(n, "description", "subtitle", i);
  const r = Mn("updated", i);
  return r && (n.updated = new Date(r)), Tt(n, "author", "email", i, !0), n;
}
l(Lb, "getAtomFeed");
function Db(e) {
  var t, i;
  const n = (i = (t = $o("channel", e.children)) === null || t === void 0 ? void 0 : t.children) !== null && i !== void 0 ? i : [], s = {
    type: e.name.substr(0, 3),
    id: "",
    items: Cs("item", e.children).map((a) => {
      const { children: u } = a, c = { media: Um(u) };
      Tt(c, "id", "guid", u), Tt(c, "title", "title", u), Tt(c, "link", "link", u), Tt(c, "description", "description", u);
      const h = Mn("pubDate", u);
      return h && (c.pubDate = new Date(h)), c;
    })
  };
  Tt(s, "title", "title", n), Tt(s, "link", "link", n), Tt(s, "description", "description", n);
  const r = Mn("lastBuildDate", n);
  return r && (s.updated = new Date(r)), Tt(s, "author", "managingEditor", n, !0), s;
}
l(Db, "getRssFeed");
var vC = ["url", "type", "lang"], gC = [
  "fileSize",
  "bitrate",
  "framerate",
  "samplingrate",
  "channels",
  "duration",
  "height",
  "width"
];
function Um(e) {
  return Cs("media:content", e).map((t) => {
    const { attribs: i } = t, n = {
      medium: i.medium,
      isDefault: !!i.isDefault
    };
    for (const s of vC)
      i[s] && (n[s] = i[s]);
    for (const s of gC)
      i[s] && (n[s] = parseInt(i[s], 10));
    return i.expression && (n.expression = i.expression), n;
  });
}
l(Um, "getMediaElements");
function $o(e, t) {
  return Cs(e, t, !0, 1)[0];
}
l($o, "getOneElement");
function Mn(e, t, i = !1) {
  return Wo(Cs(e, t, i, 1)).trim();
}
l(Mn, "fetch");
function Tt(e, t, i, n, s = !1) {
  const r = Mn(i, n, s);
  r && (e[t] = r);
}
l(Tt, "addConditionally");
function Bb(e) {
  return e === "rss" || e === "feed" || e === "rdf:RDF";
}
l(Bb, "isValidFeed");
function jm(e, t) {
  const i = new Ho(void 0, t);
  return new ru(i, t).end(e), i.root;
}
l(jm, "parseDocument");
function Hm(e, t) {
  return jm(e, t).children;
}
l(Hm, "parseDOM");
function Ob(e, t, i) {
  const n = new Ho(e, t, i);
  return new ru(n, t);
}
l(Ob, "createDomStream");
function Fb(e, t = { xmlMode: !0 }) {
  return pu(Hm(e, t));
}
l(Fb, "parseFeed");
var Vn = -1, Re = 1, ft = 2, _t = 3, an = 8, In = 9, hr = 10, Dn = 11, yC = /* @__PURE__ */ new Set(["ARTICLE", "ASIDE", "BLOCKQUOTE", "BODY", "BR", "BUTTON", "CANVAS", "CAPTION", "COL", "COLGROUP", "DD", "DIV", "DL", "DT", "EMBED", "FIELDSET", "FIGCAPTION", "FIGURE", "FOOTER", "FORM", "H1", "H2", "H3", "H4", "H5", "H6", "LI", "UL", "OL", "P"]), _C = -1, bC = 1, wC = 4, SC = 128, CC = 1, X5 = 2, J5 = 4, TC = 8, xC = 16, EC = 32, Vl = "http://www.w3.org/2000/svg", {
  assign: AC,
  create: kC,
  defineProperties: IC,
  entries: PC,
  getOwnPropertyDescriptors: _E,
  keys: MC,
  setPrototypeOf: Vt
} = Object, No = String, Kt = /* @__PURE__ */ l((e) => e.nodeType === Re ? e[ne] : e, "getEnd"), aa = /* @__PURE__ */ l(({ ownerDocument: e }) => e[gr].ignoreCase, "ignoreCase"), _i = /* @__PURE__ */ l((e, t) => {
  e[W] = t, t[ct] = e;
}, "knownAdjacent"), Vb = /* @__PURE__ */ l((e, t, i) => {
  _i(e, t), _i(Kt(t), i);
}, "knownBoundaries"), NC = /* @__PURE__ */ l((e, t, i, n) => {
  _i(e, t), _i(Kt(i), n);
}, "knownSegment"), fu = /* @__PURE__ */ l((e, t, i) => {
  _i(e, t), _i(t, i);
}, "knownSiblings"), uc = /* @__PURE__ */ l(({ localName: e, ownerDocument: t }) => t[gr].ignoreCase ? e.toUpperCase() : e, "localCase"), Ub = /* @__PURE__ */ l((e, t) => {
  e && (e[W] = t), t && (t[ct] = e);
}, "setAdjacent"), Nn = /* @__PURE__ */ new WeakMap(), mu = !1, Ul = /* @__PURE__ */ new WeakMap(), bs = /* @__PURE__ */ new WeakMap(), vu = /* @__PURE__ */ l((e, t, i, n) => {
  mu && bs.has(e) && e.attributeChangedCallback && e.constructor.observedAttributes.includes(t) && e.attributeChangedCallback(t, i, n);
}, "attributeChangedCallback"), jb = /* @__PURE__ */ l((e, t) => (i) => {
  if (bs.has(i)) {
    const n = bs.get(i);
    n.connected !== t && i.isConnected === t && (n.connected = t, e in i && i[e]());
  }
}, "createTrigger"), Z5 = jb("connectedCallback", !0), cc = /* @__PURE__ */ l((e) => {
  if (mu) {
    Z5(e), Nn.has(e) && (e = Nn.get(e).shadowRoot);
    let { [W]: t, [ne]: i } = e;
    for (; t !== i; )
      t.nodeType === Re && Z5(t), t = t[W];
  }
}, "connectedCallback"), Q5 = jb("disconnectedCallback", !1), RC = /* @__PURE__ */ l((e) => {
  if (mu) {
    Q5(e), Nn.has(e) && (e = Nn.get(e).shadowRoot);
    let { [W]: t, [ne]: i } = e;
    for (; t !== i; )
      t.nodeType === Re && Q5(t), t = t[W];
  }
}, "disconnectedCallback"), Hb = class {
  constructor(e) {
    this.ownerDocument = e, this.registry = /* @__PURE__ */ new Map(), this.waiting = /* @__PURE__ */ new Map(), this.active = !1;
  }
  define(e, t, i = {}) {
    const { ownerDocument: n, registry: s, waiting: r } = this;
    if (s.has(e))
      throw new Error("unable to redefine " + e);
    if (Ul.has(t))
      throw new Error("unable to redefine the same class: " + t);
    this.active = mu = !0;
    const { extends: a } = i;
    Ul.set(t, {
      ownerDocument: n,
      options: { is: a ? e : "" },
      localName: a || e
    });
    const u = a ? (c) => c.localName === a && c.getAttribute("is") === e : (c) => c.localName === e;
    if (s.set(e, { Class: t, check: u }), r.has(e)) {
      for (const c of r.get(e))
        c(t);
      r.delete(e);
    }
    n.querySelectorAll(a ? `${a}[is="${e}"]` : e).forEach(this.upgrade, this);
  }
  upgrade(e) {
    if (bs.has(e))
      return;
    const { ownerDocument: t, registry: i } = this, n = e.getAttribute("is") || e.localName;
    if (i.has(n)) {
      const { Class: s, check: r } = i.get(n);
      if (r(e)) {
        const { attributes: a, isConnected: u } = e;
        for (const h of a)
          e.removeAttributeNode(h);
        const c = PC(e);
        for (const [h] of c)
          delete e[h];
        Vt(e, s.prototype), t[Po] = { element: e, values: c }, new s(t, n), bs.set(e, { connected: u });
        for (const h of a)
          e.setAttributeNode(h);
        u && e.connectedCallback && e.connectedCallback();
      }
    }
  }
  whenDefined(e) {
    const { registry: t, waiting: i } = this;
    return new Promise((n) => {
      t.has(e) ? n(t.get(e).Class) : (i.has(e) || i.set(e, []), i.get(e).push(n));
    });
  }
  get(e) {
    const t = this.registry.get(e);
    return t && t.Class;
  }
};
l(Hb, "CustomElementRegistry");
var { Parser: LC } = $_, Ds = /* @__PURE__ */ l((e, t, i) => {
  const n = e[ne];
  return t.parentNode = e, Vb(n[ct], t, n), i && t.nodeType === Re && cc(t), t;
}, "append"), DC = /* @__PURE__ */ l((e, t, i, n, s) => {
  i[He] = n, i.ownerElement = e, fu(t[ct], i, t), i.name === "class" && (e.className = n), s && vu(e, i.name, null, n);
}, "attribute"), Wb = /* @__PURE__ */ l((e, t, i) => {
  const { active: n, registry: s } = e[pi];
  let r = e, a = null;
  const u = new LC({
    onprocessinginstruction(c, h) {
      c.toLowerCase() === "!doctype" && (e.doctype = h.slice(c.length).trim());
    },
    onopentag(c, h) {
      let p = !0;
      if (t) {
        if (a)
          r = Ds(r, e.createElementNS(Vl, c), n), r.ownerSVGElement = a, p = !1;
        else if (c === "svg" || c === "SVG")
          a = e.createElementNS(Vl, c), r = Ds(r, a, n), p = !1;
        else if (n) {
          const b = c.includes("-") ? c : h.is || "";
          if (b && s.has(b)) {
            const { Class: C } = s.get(b);
            r = Ds(r, new C(), n), delete h.is, p = !1;
          }
        }
      }
      p && (r = Ds(r, e.createElement(c), !1));
      let m = r[ne];
      for (const b of MC(h))
        DC(r, m, e.createAttribute(b), h[b], n);
    },
    oncomment(c) {
      Ds(r, e.createComment(c), n);
    },
    ontext(c) {
      Ds(r, e.createTextNode(c), n);
    },
    onclosetag() {
      t && r === a && (a = null), r = r.parentNode;
    }
  }, {
    lowerCaseAttributeNames: !1,
    decodeEntities: !0,
    xmlMode: !t
  });
  return u.write(i), u.end(), e;
}, "parseFromString"), jl = /* @__PURE__ */ new Map(), At = /* @__PURE__ */ l((e, t) => {
  for (const i of [].concat(e))
    jl.set(i, t), jl.set(i.toUpperCase(), t);
}, "registerHTMLClass"), BC = Wi($3(), 1), $b = /* @__PURE__ */ l(({ [W]: e, [ne]: t }, i) => {
  for (; e !== t; ) {
    switch (e.nodeType) {
      case ft:
        Gb(e, i);
        break;
      case _t:
      case an:
        qb(e, i);
        break;
      case Re:
        Kb(e, i), e = Kt(e);
        break;
      case hr:
        zb(e, i);
        break;
    }
    e = e[W];
  }
  const n = i.length - 1, s = i[n];
  typeof s == "number" && s < 0 ? i[n] += Vn : i.push(Vn);
}, "loopSegment"), Gb = /* @__PURE__ */ l((e, t) => {
  t.push(ft, e.name);
  const i = e[He].trim();
  i && t.push(i);
}, "attrAsJSON"), qb = /* @__PURE__ */ l((e, t) => {
  const i = e[He];
  i.trim() && t.push(e.nodeType, i);
}, "characterDataAsJSON"), OC = /* @__PURE__ */ l((e, t) => {
  t.push(e.nodeType), $b(e, t);
}, "nonElementAsJSON"), zb = /* @__PURE__ */ l(({ name: e, publicId: t, systemId: i }, n) => {
  n.push(hr, e), t && n.push(t), i && n.push(i);
}, "documentTypeAsJSON"), Kb = /* @__PURE__ */ l((e, t) => {
  t.push(Re, e.localName), $b(e, t);
}, "elementAsJSON"), Yb = /* @__PURE__ */ l((e, t, i, n, s, r) => ({ type: e, target: t, addedNodes: i, removedNodes: n, attributeName: s, oldValue: r }), "createRecord"), e2 = /* @__PURE__ */ l((e, t, i, n, s, r) => {
  if (!n || n.includes(i)) {
    const { callback: a, records: u, scheduled: c } = e;
    u.push(Yb("attributes", t, [], [], i, s ? r : void 0)), c || (e.scheduled = !0, Promise.resolve().then(() => {
      e.scheduled = !1, a(u.splice(0), e);
    }));
  }
}, "queueAttribute"), Wm = /* @__PURE__ */ l((e, t, i) => {
  const { ownerDocument: n } = e, { active: s, observers: r } = n[Pn];
  if (s) {
    for (const a of r)
      for (const [
        u,
        {
          childList: c,
          subtree: h,
          attributes: p,
          attributeFilter: m,
          attributeOldValue: b
        }
      ] of a.nodes)
        if (c) {
          if (h && (u === n || u.contains(e)) || !h && u.children.includes(e)) {
            e2(a, e, t, m, b, i);
            break;
          }
        } else if (p && u === e) {
          e2(a, e, t, m, b, i);
          break;
        }
  }
}, "attributeChangedCallback"), Ro = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i } = e, { active: n, observers: s } = i[Pn];
  if (n) {
    for (const r of s)
      for (const [a, { subtree: u, childList: c, characterData: h }] of r.nodes)
        if (c && (t && (a === t || u && a.contains(t)) || !t && (u && (a === i || a.contains(e)) || !u && a[h ? "childNodes" : "children"].includes(e)))) {
          const { callback: p, records: m, scheduled: b } = r;
          m.push(Yb("childList", a, t ? [] : [e], t ? [e] : [])), b || (r.scheduled = !0, Promise.resolve().then(() => {
            r.scheduled = !1, p(m.splice(0), r);
          }));
          break;
        }
  }
}, "moCallback"), Xb = class {
  constructor(e) {
    const t = /* @__PURE__ */ new Set();
    this.observers = t, this.active = !1, this.class = /* @__PURE__ */ l(class {
      constructor(n) {
        this.callback = n, this.nodes = /* @__PURE__ */ new Map(), this.records = [], this.scheduled = !1;
      }
      disconnect() {
        this.records.splice(0), this.nodes.clear(), t.delete(this), e[Pn].active = !!t.size;
      }
      observe(n, s = {
        subtree: !1,
        childList: !1,
        attributes: !1,
        attributeFilter: null,
        attributeOldValue: !1,
        characterData: !1
      }) {
        ("attributeOldValue" in s || "attributeFilter" in s) && (s.attributes = !0), s.childList = !!s.childList, s.subtree = !!s.subtree, this.nodes.set(n, s), t.add(this), e[Pn].active = !0;
      }
      takeRecords() {
        return this.records.splice(0);
      }
    }, "MutationObserver");
  }
};
l(Xb, "MutationObserverClass");
var FC = /* @__PURE__ */ new Set([
  "allowfullscreen",
  "allowpaymentrequest",
  "async",
  "autofocus",
  "autoplay",
  "checked",
  "class",
  "contenteditable",
  "controls",
  "default",
  "defer",
  "disabled",
  "draggable",
  "formnovalidate",
  "hidden",
  "id",
  "ismap",
  "itemscope",
  "loop",
  "multiple",
  "muted",
  "nomodule",
  "novalidate",
  "open",
  "playsinline",
  "readonly",
  "required",
  "reversed",
  "selected",
  "style",
  "truespeed"
]), hc = /* @__PURE__ */ l((e, t) => {
  const { [He]: i, name: n } = t;
  t.ownerElement = e, fu(e, t, e[W]), n === "class" && (e.className = i), Wm(e, n, null), vu(e, n, null, i);
}, "setAttribute"), t2 = /* @__PURE__ */ l((e, t) => {
  const { [He]: i, name: n } = t;
  _i(t[ct], t[W]), t.ownerElement = t[ct] = t[W] = null, n === "class" && (e[zs] = null), Wm(e, n, i), vu(e, n, i, null);
}, "removeAttribute"), Fe = {
  get(e, t) {
    return e.hasAttribute(t);
  },
  set(e, t, i) {
    i ? e.setAttribute(t, "") : e.removeAttribute(t);
  }
}, Rn = {
  get(e, t) {
    return parseFloat(e.getAttribute(t) || 0);
  },
  set(e, t, i) {
    e.setAttribute(t, i);
  }
}, Y = {
  get(e, t) {
    return e.getAttribute(t) || "";
  },
  set(e, t, i) {
    e.setAttribute(t, i);
  }
}, el = /* @__PURE__ */ new WeakMap();
function Jb(e, t) {
  return typeof t == "function" ? t.call(e.target, e) : t.handleEvent(e), e._stopImmediatePropagationFlag;
}
l(Jb, "dispatch");
function Zb({ currentTarget: e, target: t }) {
  const i = el.get(e);
  if (i && i.has(this.type)) {
    const n = i.get(this.type);
    e === t ? this.eventPhase = this.AT_TARGET : this.eventPhase = this.BUBBLING_PHASE, this.currentTarget = e, this.target = t;
    for (const [s, r] of n)
      if (r && r.once && n.delete(s), Jb(this, s))
        break;
    return delete this.currentTarget, delete this.target, this.cancelBubble;
  }
}
l(Zb, "invokeListeners");
var gu = class {
  constructor() {
    el.set(this, /* @__PURE__ */ new Map());
  }
  _getParent() {
    return null;
  }
  addEventListener(e, t, i) {
    const n = el.get(this);
    n.has(e) || n.set(e, /* @__PURE__ */ new Map()), n.get(e).set(t, i);
  }
  removeEventListener(e, t) {
    const i = el.get(this);
    if (i.has(e)) {
      const n = i.get(e);
      n.delete(t) && !n.size && i.delete(e);
    }
  }
  dispatchEvent(e) {
    let t = this;
    for (e.eventPhase = e.CAPTURING_PHASE; t; )
      t.dispatchEvent && e._path.push({ currentTarget: t, target: this }), t = e.bubbles && t._getParent && t._getParent();
    return e._path.some(Zb, e), e._path = [], e.eventPhase = e.NONE, !e.defaultPrevented;
  }
};
l(gu, "DOMEventTarget");
var gi = class extends Array {
  item(e) {
    return e < this.length ? this[e] : null;
  }
};
l(gi, "NodeList");
var i2 = /* @__PURE__ */ l(({ parentNode: e }) => {
  let t = 0;
  for (; e; )
    t++, e = e.parentNode;
  return t;
}, "getParentNodeCount"), Hn = class extends gu {
  static get ELEMENT_NODE() {
    return Re;
  }
  static get ATTRIBUTE_NODE() {
    return ft;
  }
  static get TEXT_NODE() {
    return _t;
  }
  static get COMMENT_NODE() {
    return an;
  }
  static get DOCUMENT_NODE() {
    return In;
  }
  static get DOCUMENT_FRAGMENT_NODE() {
    return Dn;
  }
  static get DOCUMENT_TYPE_NODE() {
    return hr;
  }
  constructor(e, t, i) {
    super(), this.ownerDocument = e, this.localName = t, this.nodeType = i, this.parentNode = null, this[W] = null, this[ct] = null;
  }
  get ELEMENT_NODE() {
    return Re;
  }
  get ATTRIBUTE_NODE() {
    return ft;
  }
  get TEXT_NODE() {
    return _t;
  }
  get COMMENT_NODE() {
    return an;
  }
  get DOCUMENT_NODE() {
    return In;
  }
  get DOCUMENT_FRAGMENT_NODE() {
    return Dn;
  }
  get DOCUMENT_TYPE_NODE() {
    return hr;
  }
  get baseURI() {
    const e = this.nodeType === In ? this : this.ownerDocument;
    if (e) {
      const t = e.querySelector("base");
      if (t)
        return t.getAttribute("href");
      const { location: i } = e.defaultView;
      if (i)
        return i.href;
    }
    return null;
  }
  get isConnected() {
    return !1;
  }
  get nodeName() {
    return this.localName;
  }
  get parentElement() {
    return null;
  }
  get previousSibling() {
    return null;
  }
  get previousElementSibling() {
    return null;
  }
  get nextSibling() {
    return null;
  }
  get nextElementSibling() {
    return null;
  }
  get childNodes() {
    return new gi();
  }
  get firstChild() {
    return null;
  }
  get lastChild() {
    return null;
  }
  get nodeValue() {
    return null;
  }
  set nodeValue(e) {
  }
  get textContent() {
    return null;
  }
  set textContent(e) {
  }
  normalize() {
  }
  cloneNode() {
    return null;
  }
  contains() {
    return !1;
  }
  insertBefore(e, t) {
    return e;
  }
  appendChild(e) {
    return e;
  }
  replaceChild(e, t) {
    return t;
  }
  removeChild(e) {
    return e;
  }
  toString() {
    return "";
  }
  hasChildNodes() {
    return !!this.lastChild;
  }
  isSameNode(e) {
    return this === e;
  }
  compareDocumentPosition(e) {
    let t = 0;
    if (this !== e) {
      let i = i2(this), n = i2(e);
      if (i < n)
        t += J5, this.contains(e) && (t += xC);
      else if (n < i)
        t += X5, e.contains(this) && (t += TC);
      else if (i && n) {
        const { childNodes: s } = this.parentNode;
        s.indexOf(this) < s.indexOf(e) ? t += J5 : t += X5;
      }
      (!i || !n) && (t += EC, t += CC);
    }
    return t;
  }
  isEqualNode(e) {
    if (this === e)
      return !0;
    if (this.nodeType === e.nodeType) {
      switch (this.nodeType) {
        case In:
        case Dn: {
          const t = this.childNodes, i = e.childNodes;
          return t.length === i.length && t.every((n, s) => n.isEqualNode(i[s]));
        }
      }
      return this.toString() === e.toString();
    }
    return !1;
  }
  _getParent() {
    return this.parentNode;
  }
  getRootNode() {
    let e = this;
    for (; e.parentNode; )
      e = e.parentNode;
    return e.nodeType === In ? e.documentElement : e;
  }
};
l(Hn, "Node");
var VC = /"/g, Ts = class extends Hn {
  constructor(e, t, i = "") {
    super(e, "#attribute", ft), this.ownerElement = null, this.name = No(t), this[He] = No(i), this[Ll] = !1;
  }
  get value() {
    return this[He];
  }
  set value(e) {
    const { [He]: t, name: i, ownerElement: n } = this;
    this[He] = No(e), this[Ll] = !0, n && (Wm(n, i, t), vu(n, i, t, this[He]));
  }
  cloneNode() {
    const { ownerDocument: e, name: t, [He]: i } = this;
    return new Ts(e, t, i);
  }
  toString() {
    const { name: e, [He]: t } = this;
    return FC.has(e) && !t ? e : `${e}="${t.replace(VC, "&quot;")}"`;
  }
  toJSON() {
    const e = [];
    return Gb(this, e), e;
  }
};
l(Ts, "Attr");
var Qb = /* @__PURE__ */ l(({ ownerDocument: e, parentNode: t }) => {
  for (; t; ) {
    if (t === e)
      return !0;
    t = t.parentNode || t.host;
  }
  return !1;
}, "isConnected"), e4 = /* @__PURE__ */ l(({ parentNode: e }) => {
  if (e)
    switch (e.nodeType) {
      case In:
      case Dn:
        return null;
    }
  return e;
}, "parentElement"), Go = /* @__PURE__ */ l(({ [ct]: e }) => {
  switch (e ? e.nodeType : 0) {
    case Vn:
      return e[Lt];
    case _t:
    case an:
      return e;
  }
  return null;
}, "previousSibling"), ms = /* @__PURE__ */ l((e) => {
  const t = Kt(e)[W];
  return t && (t.nodeType === Vn ? null : t);
}, "nextSibling"), $m = /* @__PURE__ */ l((e) => {
  let t = ms(e);
  for (; t && t.nodeType !== Re; )
    t = ms(t);
  return t;
}, "nextElementSibling"), t4 = /* @__PURE__ */ l((e) => {
  let t = Go(e);
  for (; t && t.nodeType !== Re; )
    t = Go(t);
  return t;
}, "previousElementSibling"), Gm = /* @__PURE__ */ l((e, t) => {
  const i = e.createDocumentFragment();
  return i.append(...t), i;
}, "asFragment"), i4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && n.insertBefore(Gm(i, t), e);
}, "before"), n4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && n.insertBefore(Gm(i, t), Kt(e)[W]);
}, "after"), s4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i, parentNode: n } = e;
  n && (n.insertBefore(Gm(i, t), e), e.remove());
}, "replaceWith"), r4 = /* @__PURE__ */ l((e, t, i) => {
  const { parentNode: n, nodeType: s } = t;
  (e || i) && (Ub(e, i), t[ct] = null, Kt(t)[W] = null), n && (t.parentNode = null, Ro(t, n), s === Re && RC(t));
}, "remove"), la = class extends Hn {
  constructor(e, t, i, n) {
    super(e, t, i), this[He] = No(n);
  }
  get isConnected() {
    return Qb(this);
  }
  get parentElement() {
    return e4(this);
  }
  get previousSibling() {
    return Go(this);
  }
  get nextSibling() {
    return ms(this);
  }
  get previousElementSibling() {
    return t4(this);
  }
  get nextElementSibling() {
    return $m(this);
  }
  before(...e) {
    i4(this, e);
  }
  after(...e) {
    n4(this, e);
  }
  replaceWith(...e) {
    s4(this, e);
  }
  remove() {
    r4(this[ct], this, this[W]);
  }
  get data() {
    return this[He];
  }
  set data(e) {
    this[He] = No(e), Ro(this, this.parentNode);
  }
  get nodeValue() {
    return this.data;
  }
  set nodeValue(e) {
    this.data = e;
  }
  get textContent() {
    return this.data;
  }
  set textContent(e) {
    this.data = e;
  }
  get length() {
    return this.data.length;
  }
  substringData(e, t) {
    return this.data.substr(e, t);
  }
  appendData(e) {
    this.data += e;
  }
  insertData(e, t) {
    const { data: i } = this;
    this.data = i.slice(0, e) + t + i.slice(e);
  }
  deleteData(e, t) {
    const { data: i } = this;
    this.data = i.slice(0, e) + i.slice(e + t);
  }
  replaceData(e, t, i) {
    const { data: n } = this;
    this.data = n.slice(0, e) + i + n.slice(e + t);
  }
  toJSON() {
    const e = [];
    return qb(this, e), e;
  }
};
l(la, "CharacterData");
var ua = class extends la {
  constructor(e, t = "") {
    super(e, "#comment", an, t);
  }
  cloneNode() {
    const { ownerDocument: e, [He]: t } = this;
    return new ua(e, t);
  }
  toString() {
    return `<!--${this[He]}-->`;
  }
};
l(ua, "Comment");
Wi(fr(), 1);
var re;
(function(e) {
  e.Attribute = "attribute", e.Pseudo = "pseudo", e.PseudoElement = "pseudo-element", e.Tag = "tag", e.Universal = "universal", e.Adjacent = "adjacent", e.Child = "child", e.Descendant = "descendant", e.Parent = "parent", e.Sibling = "sibling", e.ColumnCombinator = "column-combinator";
})(re || (re = {}));
var ot;
(function(e) {
  e.Any = "any", e.Element = "element", e.End = "end", e.Equals = "equals", e.Exists = "exists", e.Hyphen = "hyphen", e.Not = "not", e.Start = "start";
})(ot || (ot = {}));
var n2 = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/, UC = /\\([\da-f]{1,6}\s?|(\s)|.)/gi, jC = /* @__PURE__ */ new Map([
  [126, ot.Element],
  [94, ot.Start],
  [36, ot.End],
  [42, ot.Any],
  [33, ot.Not],
  [124, ot.Hyphen]
]), HC = /* @__PURE__ */ new Set([
  "has",
  "not",
  "matches",
  "is",
  "where",
  "host",
  "host-context"
]);
function o4(e) {
  switch (e.type) {
    case re.Adjacent:
    case re.Child:
    case re.Descendant:
    case re.Parent:
    case re.Sibling:
    case re.ColumnCombinator:
      return !0;
    default:
      return !1;
  }
}
l(o4, "isTraversal");
var WC = /* @__PURE__ */ new Set(["contains", "icontains"]);
function a4(e, t, i) {
  const n = parseInt(t, 16) - 65536;
  return n !== n || i ? t : n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, n & 1023 | 56320);
}
l(a4, "funescape");
function Ks(e) {
  return e.replace(UC, a4);
}
l(Ks, "unescapeCSS");
function tl(e) {
  return e === 39 || e === 34;
}
l(tl, "isQuote");
function dc(e) {
  return e === 32 || e === 9 || e === 10 || e === 12 || e === 13;
}
l(dc, "isWhitespace");
function qm(e) {
  const t = [], i = zm(t, `${e}`, 0);
  if (i < e.length)
    throw new Error(`Unmatched selector: ${e.slice(i)}`);
  return t;
}
l(qm, "parse");
function zm(e, t, i) {
  let n = [];
  function s(b) {
    const C = t.slice(i + b).match(n2);
    if (!C)
      throw new Error(`Expected name, found ${t.slice(i)}`);
    const [k] = C;
    return i += b + k.length, Ks(k);
  }
  l(s, "getName");
  function r(b) {
    for (i += b; i < t.length && dc(t.charCodeAt(i)); )
      i++;
  }
  l(r, "stripWhitespace");
  function a() {
    i += 1;
    const b = i;
    let C = 1;
    for (; C > 0 && i < t.length; i++)
      t.charCodeAt(i) === 40 && !u(i) ? C++ : t.charCodeAt(i) === 41 && !u(i) && C--;
    if (C)
      throw new Error("Parenthesis not matched");
    return Ks(t.slice(b, i - 1));
  }
  l(a, "readValueWithParenthesis");
  function u(b) {
    let C = 0;
    for (; t.charCodeAt(--b) === 92; )
      C++;
    return (C & 1) === 1;
  }
  l(u, "isEscaped");
  function c() {
    if (n.length > 0 && o4(n[n.length - 1]))
      throw new Error("Did not expect successive traversals.");
  }
  l(c, "ensureNotTraversal");
  function h(b) {
    if (n.length > 0 && n[n.length - 1].type === re.Descendant) {
      n[n.length - 1].type = b;
      return;
    }
    c(), n.push({ type: b });
  }
  l(h, "addTraversal");
  function p(b, C) {
    n.push({
      type: re.Attribute,
      name: b,
      action: C,
      value: s(1),
      namespace: null,
      ignoreCase: "quirks"
    });
  }
  l(p, "addSpecialAttribute");
  function m() {
    if (n.length && n[n.length - 1].type === re.Descendant && n.pop(), n.length === 0)
      throw new Error("Empty sub-selector");
    e.push(n);
  }
  if (l(m, "finalizeSubselector"), r(0), t.length === i)
    return i;
  e:
    for (; i < t.length; ) {
      const b = t.charCodeAt(i);
      switch (b) {
        case 32:
        case 9:
        case 10:
        case 12:
        case 13: {
          (n.length === 0 || n[0].type !== re.Descendant) && (c(), n.push({ type: re.Descendant })), r(1);
          break;
        }
        case 62: {
          h(re.Child), r(1);
          break;
        }
        case 60: {
          h(re.Parent), r(1);
          break;
        }
        case 126: {
          h(re.Sibling), r(1);
          break;
        }
        case 43: {
          h(re.Adjacent), r(1);
          break;
        }
        case 46: {
          p("class", ot.Element);
          break;
        }
        case 35: {
          p("id", ot.Equals);
          break;
        }
        case 91: {
          r(1);
          let C, k = null;
          t.charCodeAt(i) === 124 ? C = s(1) : t.startsWith("*|", i) ? (k = "*", C = s(2)) : (C = s(0), t.charCodeAt(i) === 124 && t.charCodeAt(i + 1) !== 61 && (k = C, C = s(1))), r(0);
          let D = ot.Exists;
          const I = jC.get(t.charCodeAt(i));
          if (I) {
            if (D = I, t.charCodeAt(i + 1) !== 61)
              throw new Error("Expected `=`");
            r(2);
          } else
            t.charCodeAt(i) === 61 && (D = ot.Equals, r(1));
          let $ = "", O = null;
          if (D !== "exists") {
            if (tl(t.charCodeAt(i))) {
              const M = t.charCodeAt(i);
              let v = i + 1;
              for (; v < t.length && (t.charCodeAt(v) !== M || u(v)); )
                v += 1;
              if (t.charCodeAt(v) !== M)
                throw new Error("Attribute value didn't end");
              $ = Ks(t.slice(i + 1, v)), i = v + 1;
            } else {
              const M = i;
              for (; i < t.length && (!dc(t.charCodeAt(i)) && t.charCodeAt(i) !== 93 || u(i)); )
                i += 1;
              $ = Ks(t.slice(M, i));
            }
            r(0);
            const K = t.charCodeAt(i) | 32;
            K === 115 ? (O = !1, r(1)) : K === 105 && (O = !0, r(1));
          }
          if (t.charCodeAt(i) !== 93)
            throw new Error("Attribute selector didn't terminate");
          i += 1;
          const F = {
            type: re.Attribute,
            name: C,
            action: D,
            value: $,
            namespace: k,
            ignoreCase: O
          };
          n.push(F);
          break;
        }
        case 58: {
          if (t.charCodeAt(i + 1) === 58) {
            n.push({
              type: re.PseudoElement,
              name: s(2).toLowerCase(),
              data: t.charCodeAt(i) === 40 ? a() : null
            });
            continue;
          }
          const C = s(1).toLowerCase();
          let k = null;
          if (t.charCodeAt(i) === 40)
            if (HC.has(C)) {
              if (tl(t.charCodeAt(i + 1)))
                throw new Error(`Pseudo-selector ${C} cannot be quoted`);
              if (k = [], i = zm(k, t, i + 1), t.charCodeAt(i) !== 41)
                throw new Error(`Missing closing parenthesis in :${C} (${t})`);
              i += 1;
            } else {
              if (k = a(), WC.has(C)) {
                const D = k.charCodeAt(0);
                D === k.charCodeAt(k.length - 1) && tl(D) && (k = k.slice(1, -1));
              }
              k = Ks(k);
            }
          n.push({ type: re.Pseudo, name: C, data: k });
          break;
        }
        case 44: {
          m(), n = [], r(1);
          break;
        }
        default: {
          if (t.startsWith("/*", i)) {
            const D = t.indexOf("*/", i + 2);
            if (D < 0)
              throw new Error("Comment was not terminated");
            i = D + 2, n.length === 0 && r(0);
            break;
          }
          let C = null, k;
          if (b === 42)
            i += 1, k = "*";
          else if (b === 124) {
            if (k = "", t.charCodeAt(i + 1) === 124) {
              h(re.ColumnCombinator), r(2);
              break;
            }
          } else if (n2.test(t.slice(i)))
            k = s(0);
          else
            break e;
          t.charCodeAt(i) === 124 && t.charCodeAt(i + 1) !== 124 && (C = k, t.charCodeAt(i + 1) === 42 ? (k = "*", i += 2) : k = s(1)), n.push(k === "*" ? { type: re.Universal, namespace: C } : { type: re.Tag, name: k, namespace: C });
        }
      }
    }
  return m(), i;
}
l(zm, "parseSelector");
var Ln = Wi(fr(), 1), l4 = /* @__PURE__ */ new Map([
  [re.Universal, 50],
  [re.Tag, 30],
  [re.Attribute, 1],
  [re.Pseudo, 0]
]);
function yu(e) {
  return !l4.has(e.type);
}
l(yu, "isTraversal");
var $C = /* @__PURE__ */ new Map([
  [ot.Exists, 10],
  [ot.Equals, 8],
  [ot.Not, 7],
  [ot.Start, 6],
  [ot.End, 6],
  [ot.Any, 5]
]);
function u4(e) {
  const t = e.map(Km);
  for (let i = 1; i < e.length; i++) {
    const n = t[i];
    if (!(n < 0))
      for (let s = i - 1; s >= 0 && n < t[s]; s--) {
        const r = e[s + 1];
        e[s + 1] = e[s], e[s] = r, t[s + 1] = t[s], t[s] = n;
      }
  }
}
l(u4, "sortByProcedure");
function Km(e) {
  var t, i;
  let n = (t = l4.get(e.type)) !== null && t !== void 0 ? t : -1;
  return e.type === re.Attribute ? (n = (i = $C.get(e.action)) !== null && i !== void 0 ? i : 4, e.action === ot.Equals && e.name === "id" && (n = 9), e.ignoreCase && (n >>= 1)) : e.type === re.Pseudo && (e.data ? e.name === "has" || e.name === "contains" ? n = 0 : Array.isArray(e.data) ? (n = Math.min(...e.data.map((s) => Math.min(...s.map(Km)))), n < 0 && (n = 0)) : n = 2 : n = 3), n;
}
l(Km, "getProcedure");
var ka = Wi(fr(), 1), GC = /[-[\]{}()*+?.,\\^$|#\s]/g;
function pc(e) {
  return e.replace(GC, "\\$&");
}
l(pc, "escapeRegex");
var qC = /* @__PURE__ */ new Set([
  "accept",
  "accept-charset",
  "align",
  "alink",
  "axis",
  "bgcolor",
  "charset",
  "checked",
  "clear",
  "codetype",
  "color",
  "compact",
  "declare",
  "defer",
  "dir",
  "direction",
  "disabled",
  "enctype",
  "face",
  "frame",
  "hreflang",
  "http-equiv",
  "lang",
  "language",
  "link",
  "media",
  "method",
  "multiple",
  "nohref",
  "noresize",
  "noshade",
  "nowrap",
  "readonly",
  "rel",
  "rev",
  "rules",
  "scope",
  "scrolling",
  "selected",
  "shape",
  "target",
  "text",
  "type",
  "valign",
  "valuetype",
  "vlink"
]);
function yn(e, t) {
  return typeof e.ignoreCase == "boolean" ? e.ignoreCase : e.ignoreCase === "quirks" ? !!t.quirksMode : !t.xmlMode && qC.has(e.name);
}
l(yn, "shouldIgnoreCase");
var zC = {
  equals(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    return yn(t, i) ? (r = r.toLowerCase(), (a) => {
      const u = n.getAttributeValue(a, s);
      return u != null && u.length === r.length && u.toLowerCase() === r && e(a);
    }) : (a) => n.getAttributeValue(a, s) === r && e(a);
  },
  hyphen(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = r.length;
    return yn(t, i) ? (r = r.toLowerCase(), /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && (h.length === a || h.charAt(a) === "-") && h.substr(0, a).toLowerCase() === r && e(c);
    }, "hyphenIC")) : /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && (h.length === a || h.charAt(a) === "-") && h.substr(0, a) === r && e(c);
    }, "hyphen");
  },
  element(e, t, i) {
    const { adapter: n } = i, { name: s, value: r } = t;
    if (/\s/.test(r))
      return ka.default.falseFunc;
    const a = new RegExp(`(?:^|\\s)${pc(r)}(?:$|\\s)`, yn(t, i) ? "i" : "");
    return /* @__PURE__ */ l(function(c) {
      const h = n.getAttributeValue(c, s);
      return h != null && h.length >= r.length && a.test(h) && e(c);
    }, "element");
  },
  exists(e, { name: t }, { adapter: i }) {
    return (n) => i.hasAttrib(n, t) && e(n);
  },
  start(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = r.length;
    return a === 0 ? ka.default.falseFunc : yn(t, i) ? (r = r.toLowerCase(), (u) => {
      const c = n.getAttributeValue(u, s);
      return c != null && c.length >= a && c.substr(0, a).toLowerCase() === r && e(u);
    }) : (u) => {
      var c;
      return !!(!((c = n.getAttributeValue(u, s)) === null || c === void 0) && c.startsWith(r)) && e(u);
    };
  },
  end(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    const a = -r.length;
    return a === 0 ? ka.default.falseFunc : yn(t, i) ? (r = r.toLowerCase(), (u) => {
      var c;
      return ((c = n.getAttributeValue(u, s)) === null || c === void 0 ? void 0 : c.substr(a).toLowerCase()) === r && e(u);
    }) : (u) => {
      var c;
      return !!(!((c = n.getAttributeValue(u, s)) === null || c === void 0) && c.endsWith(r)) && e(u);
    };
  },
  any(e, t, i) {
    const { adapter: n } = i, { name: s, value: r } = t;
    if (r === "")
      return ka.default.falseFunc;
    if (yn(t, i)) {
      const a = new RegExp(pc(r), "i");
      return /* @__PURE__ */ l(function(c) {
        const h = n.getAttributeValue(c, s);
        return h != null && h.length >= r.length && a.test(h) && e(c);
      }, "anyIC");
    }
    return (a) => {
      var u;
      return !!(!((u = n.getAttributeValue(a, s)) === null || u === void 0) && u.includes(r)) && e(a);
    };
  },
  not(e, t, i) {
    const { adapter: n } = i, { name: s } = t;
    let { value: r } = t;
    return r === "" ? (a) => !!n.getAttributeValue(a, s) && e(a) : yn(t, i) ? (r = r.toLowerCase(), (a) => {
      const u = n.getAttributeValue(a, s);
      return (u == null || u.length !== r.length || u.toLowerCase() !== r) && e(a);
    }) : (a) => n.getAttributeValue(a, s) !== r && e(a);
  }
}, KC = /* @__PURE__ */ new Set([9, 10, 12, 13, 32]), s2 = "0".charCodeAt(0), YC = "9".charCodeAt(0);
function c4(e) {
  if (e = e.trim().toLowerCase(), e === "even")
    return [2, 0];
  if (e === "odd")
    return [2, 1];
  let t = 0, i = 0, n = r(), s = a();
  if (t < e.length && e.charAt(t) === "n" && (t++, i = n * (s != null ? s : 1), u(), t < e.length ? (n = r(), u(), s = a()) : n = s = 0), s === null || t < e.length)
    throw new Error(`n-th rule couldn't be parsed ('${e}')`);
  return [i, n * s];
  function r() {
    return e.charAt(t) === "-" ? (t++, -1) : (e.charAt(t) === "+" && t++, 1);
  }
  function a() {
    const c = t;
    let h = 0;
    for (; t < e.length && e.charCodeAt(t) >= s2 && e.charCodeAt(t) <= YC; )
      h = h * 10 + (e.charCodeAt(t) - s2), t++;
    return t === c ? null : h;
  }
  function u() {
    for (; t < e.length && KC.has(e.charCodeAt(t)); )
      t++;
  }
}
l(c4, "parse");
var r2 = Wi(fr(), 1);
function h4(e) {
  const t = e[0], i = e[1] - 1;
  if (i < 0 && t <= 0)
    return r2.default.falseFunc;
  if (t === -1)
    return (r) => r <= i;
  if (t === 0)
    return (r) => r === i;
  if (t === 1)
    return i < 0 ? r2.default.trueFunc : (r) => r >= i;
  const n = Math.abs(t), s = (i % n + n) % n;
  return t > 1 ? (r) => r >= i && r % n === s : (r) => r <= i && r % n === s;
}
l(h4, "compile");
function no(e) {
  return h4(c4(e));
}
l(no, "nthCheck");
var Ht = Wi(fr(), 1);
function so(e, t) {
  return (i) => {
    const n = t.getParent(i);
    return n != null && t.isTag(n) && e(i);
  };
}
l(so, "getChildFunc");
var fc = {
  contains(e, t, { adapter: i }) {
    return /* @__PURE__ */ l(function(s) {
      return e(s) && i.getText(s).includes(t);
    }, "contains");
  },
  icontains(e, t, { adapter: i }) {
    const n = t.toLowerCase();
    return /* @__PURE__ */ l(function(r) {
      return e(r) && i.getText(r).toLowerCase().includes(n);
    }, "icontains");
  },
  "nth-child"(e, t, { adapter: i, equals: n }) {
    const s = no(t);
    return s === Ht.default.falseFunc ? Ht.default.falseFunc : s === Ht.default.trueFunc ? so(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = 0; h < u.length && !n(a, u[h]); h++)
        i.isTag(u[h]) && c++;
      return s(c) && e(a);
    }, "nthChild");
  },
  "nth-last-child"(e, t, { adapter: i, equals: n }) {
    const s = no(t);
    return s === Ht.default.falseFunc ? Ht.default.falseFunc : s === Ht.default.trueFunc ? so(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = u.length - 1; h >= 0 && !n(a, u[h]); h--)
        i.isTag(u[h]) && c++;
      return s(c) && e(a);
    }, "nthLastChild");
  },
  "nth-of-type"(e, t, { adapter: i, equals: n }) {
    const s = no(t);
    return s === Ht.default.falseFunc ? Ht.default.falseFunc : s === Ht.default.trueFunc ? so(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = 0; h < u.length; h++) {
        const p = u[h];
        if (n(a, p))
          break;
        i.isTag(p) && i.getName(p) === i.getName(a) && c++;
      }
      return s(c) && e(a);
    }, "nthOfType");
  },
  "nth-last-of-type"(e, t, { adapter: i, equals: n }) {
    const s = no(t);
    return s === Ht.default.falseFunc ? Ht.default.falseFunc : s === Ht.default.trueFunc ? so(e, i) : /* @__PURE__ */ l(function(a) {
      const u = i.getSiblings(a);
      let c = 0;
      for (let h = u.length - 1; h >= 0; h--) {
        const p = u[h];
        if (n(a, p))
          break;
        i.isTag(p) && i.getName(p) === i.getName(a) && c++;
      }
      return s(c) && e(a);
    }, "nthLastOfType");
  },
  root(e, t, { adapter: i }) {
    return (n) => {
      const s = i.getParent(n);
      return (s == null || !i.isTag(s)) && e(n);
    };
  },
  scope(e, t, i, n) {
    const { equals: s } = i;
    return !n || n.length === 0 ? fc.root(e, t, i) : n.length === 1 ? (r) => s(n[0], r) && e(r) : (r) => n.includes(r) && e(r);
  },
  hover: il("isHovered"),
  visited: il("isVisited"),
  active: il("isActive")
};
function il(e) {
  return /* @__PURE__ */ l(function(i, n, { adapter: s }) {
    const r = s[e];
    return typeof r != "function" ? Ht.default.falseFunc : /* @__PURE__ */ l(function(u) {
      return r(u) && i(u);
    }, "active");
  }, "dynamicPseudo");
}
l(il, "dynamicStatePseudo");
var o2 = {
  empty(e, { adapter: t }) {
    return !t.getChildren(e).some((i) => t.isTag(i) || t.getText(i) !== "");
  },
  "first-child"(e, { adapter: t, equals: i }) {
    if (t.prevElementSibling)
      return t.prevElementSibling(e) == null;
    const n = t.getSiblings(e).find((s) => t.isTag(s));
    return n != null && i(e, n);
  },
  "last-child"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e);
    for (let s = n.length - 1; s >= 0; s--) {
      if (i(e, n[s]))
        return !0;
      if (t.isTag(n[s]))
        break;
    }
    return !1;
  },
  "first-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e), s = t.getName(e);
    for (let r = 0; r < n.length; r++) {
      const a = n[r];
      if (i(e, a))
        return !0;
      if (t.isTag(a) && t.getName(a) === s)
        break;
    }
    return !1;
  },
  "last-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getSiblings(e), s = t.getName(e);
    for (let r = n.length - 1; r >= 0; r--) {
      const a = n[r];
      if (i(e, a))
        return !0;
      if (t.isTag(a) && t.getName(a) === s)
        break;
    }
    return !1;
  },
  "only-of-type"(e, { adapter: t, equals: i }) {
    const n = t.getName(e);
    return t.getSiblings(e).every((s) => i(e, s) || !t.isTag(s) || t.getName(s) !== n);
  },
  "only-child"(e, { adapter: t, equals: i }) {
    return t.getSiblings(e).every((n) => i(e, n) || !t.isTag(n));
  }
};
function mc(e, t, i, n) {
  if (i === null) {
    if (e.length > n)
      throw new Error(`Pseudo-class :${t} requires an argument`);
  } else if (e.length === n)
    throw new Error(`Pseudo-class :${t} doesn't have any arguments`);
}
l(mc, "verifyPseudoArgs");
var XC = {
  "any-link": ":is(a, area, link)[href]",
  link: ":any-link:not(:visited)",
  disabled: `:is(
        :is(button, input, select, textarea, optgroup, option)[disabled],
        optgroup[disabled] > option,
        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)
    )`,
  enabled: ":not(:disabled)",
  checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)",
  required: ":is(input, select, textarea)[required]",
  optional: ":is(input, select, textarea):not([required])",
  selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)",
  checkbox: "[type=checkbox]",
  file: "[type=file]",
  password: "[type=password]",
  radio: "[type=radio]",
  reset: "[type=reset]",
  image: "[type=image]",
  submit: "[type=submit]",
  parent: ":not(:empty)",
  header: ":is(h1, h2, h3, h4, h5, h6)",
  button: ":is(button, input[type=button])",
  input: ":is(input, textarea, select, button)",
  text: "input:is(:not([type!='']), [type=text])"
}, mi = Wi(fr(), 1), d4 = {};
function Ym(e, t) {
  return e === mi.default.falseFunc ? mi.default.falseFunc : (i) => t.isTag(i) && e(i);
}
l(Ym, "ensureIsTag");
function Xm(e, t) {
  const i = t.getSiblings(e);
  if (i.length <= 1)
    return [];
  const n = i.indexOf(e);
  return n < 0 || n === i.length - 1 ? [] : i.slice(n + 1).filter(t.isTag);
}
l(Xm, "getNextSiblings");
function Hl(e) {
  return {
    xmlMode: !!e.xmlMode,
    lowerCaseAttributeNames: !!e.lowerCaseAttributeNames,
    lowerCaseTags: !!e.lowerCaseTags,
    quirksMode: !!e.quirksMode,
    cacheResults: !!e.cacheResults,
    pseudos: e.pseudos,
    adapter: e.adapter,
    equals: e.equals
  };
}
l(Hl, "copyOptions");
var N1 = /* @__PURE__ */ l((e, t, i, n, s) => {
  const r = s(t, Hl(i), n);
  return r === mi.default.trueFunc ? e : r === mi.default.falseFunc ? mi.default.falseFunc : (a) => r(a) && e(a);
}, "is"), R1 = {
  is: N1,
  matches: N1,
  where: N1,
  not(e, t, i, n, s) {
    const r = s(t, Hl(i), n);
    return r === mi.default.falseFunc ? e : r === mi.default.trueFunc ? mi.default.falseFunc : (a) => !r(a) && e(a);
  },
  has(e, t, i, n, s) {
    const { adapter: r } = i, a = Hl(i);
    a.relativeSelector = !0;
    const u = t.some((p) => p.some(yu)) ? [d4] : void 0, c = s(t, a, u);
    if (c === mi.default.falseFunc)
      return mi.default.falseFunc;
    const h = Ym(c, r);
    if (u && c !== mi.default.trueFunc) {
      const { shouldTestNextSiblings: p = !1 } = c;
      return (m) => {
        if (!e(m))
          return !1;
        u[0] = m;
        const b = r.getChildren(m), C = p ? [...b, ...Xm(m, r)] : b;
        return r.existsOne(h, C);
      };
    }
    return (p) => e(p) && r.existsOne(h, r.getChildren(p));
  }
};
function p4(e, t, i, n, s) {
  var r;
  const { name: a, data: u } = t;
  if (Array.isArray(u)) {
    if (!(a in R1))
      throw new Error(`Unknown pseudo-class :${a}(${u})`);
    return R1[a](e, u, i, n, s);
  }
  const c = (r = i.pseudos) === null || r === void 0 ? void 0 : r[a], h = typeof c == "string" ? c : XC[a];
  if (typeof h == "string") {
    if (u != null)
      throw new Error(`Pseudo ${a} doesn't have any arguments`);
    const p = qm(h);
    return R1.is(e, p, i, n, s);
  }
  if (typeof c == "function")
    return mc(c, a, u, 1), (p) => c(p, u) && e(p);
  if (a in fc)
    return fc[a](e, u, i, n);
  if (a in o2) {
    const p = o2[a];
    return mc(p, a, u, 2), (m) => p(m, i, u) && e(m);
  }
  throw new Error(`Unknown pseudo-class :${a}`);
}
l(p4, "compilePseudoSelector");
function nl(e, t) {
  const i = t.getParent(e);
  return i && t.isTag(i) ? i : null;
}
l(nl, "getElementParent");
function f4(e, t, i, n, s) {
  const { adapter: r, equals: a } = i;
  switch (t.type) {
    case re.PseudoElement:
      throw new Error("Pseudo-elements are not supported by css-select");
    case re.ColumnCombinator:
      throw new Error("Column combinators are not yet supported by css-select");
    case re.Attribute: {
      if (t.namespace != null)
        throw new Error("Namespaced attributes are not yet supported by css-select");
      return (!i.xmlMode || i.lowerCaseAttributeNames) && (t.name = t.name.toLowerCase()), zC[t.action](e, t, i);
    }
    case re.Pseudo:
      return p4(e, t, i, n, s);
    case re.Tag: {
      if (t.namespace != null)
        throw new Error("Namespaced tag names are not yet supported by css-select");
      let { name: u } = t;
      return (!i.xmlMode || i.lowerCaseTags) && (u = u.toLowerCase()), /* @__PURE__ */ l(function(h) {
        return r.getName(h) === u && e(h);
      }, "tag");
    }
    case re.Descendant: {
      if (i.cacheResults === !1 || typeof WeakSet > "u")
        return /* @__PURE__ */ l(function(h) {
          let p = h;
          for (; p = nl(p, r); )
            if (e(p))
              return !0;
          return !1;
        }, "descendant");
      const u = /* @__PURE__ */ new WeakSet();
      return /* @__PURE__ */ l(function(h) {
        let p = h;
        for (; p = nl(p, r); )
          if (!u.has(p)) {
            if (r.isTag(p) && e(p))
              return !0;
            u.add(p);
          }
        return !1;
      }, "cachedDescendant");
    }
    case "_flexibleDescendant":
      return /* @__PURE__ */ l(function(c) {
        let h = c;
        do
          if (e(h))
            return !0;
        while (h = nl(h, r));
        return !1;
      }, "flexibleDescendant");
    case re.Parent:
      return /* @__PURE__ */ l(function(c) {
        return r.getChildren(c).some((h) => r.isTag(h) && e(h));
      }, "parent");
    case re.Child:
      return /* @__PURE__ */ l(function(c) {
        const h = r.getParent(c);
        return h != null && r.isTag(h) && e(h);
      }, "child");
    case re.Sibling:
      return /* @__PURE__ */ l(function(c) {
        const h = r.getSiblings(c);
        for (let p = 0; p < h.length; p++) {
          const m = h[p];
          if (a(c, m))
            break;
          if (r.isTag(m) && e(m))
            return !0;
        }
        return !1;
      }, "sibling");
    case re.Adjacent:
      return r.prevElementSibling ? /* @__PURE__ */ l(function(c) {
        const h = r.prevElementSibling(c);
        return h != null && e(h);
      }, "adjacent") : /* @__PURE__ */ l(function(c) {
        const h = r.getSiblings(c);
        let p;
        for (let m = 0; m < h.length; m++) {
          const b = h[m];
          if (a(c, b))
            break;
          r.isTag(b) && (p = b);
        }
        return !!p && e(p);
      }, "adjacent");
    case re.Universal: {
      if (t.namespace != null && t.namespace !== "*")
        throw new Error("Namespaced universal selectors are not yet supported by css-select");
      return e;
    }
  }
}
l(f4, "compileGeneralSelector");
function Jm(e, t, i) {
  const n = Zm(e, t, i);
  return Ym(n, t.adapter);
}
l(Jm, "compile");
function Zm(e, t, i) {
  const n = typeof e == "string" ? qm(e) : e;
  return ev(n, t, i);
}
l(Zm, "compileUnsafe");
function Qm(e) {
  return e.type === re.Pseudo && (e.name === "scope" || Array.isArray(e.data) && e.data.some((t) => t.some(Qm)));
}
l(Qm, "includesScopePseudo");
var JC = { type: re.Descendant }, ZC = {
  type: "_flexibleDescendant"
}, QC = {
  type: re.Pseudo,
  name: "scope",
  data: null
};
function m4(e, { adapter: t }, i) {
  const n = !!(i != null && i.every((s) => {
    const r = t.isTag(s) && t.getParent(s);
    return s === d4 || r && t.isTag(r);
  }));
  for (const s of e) {
    if (!(s.length > 0 && yu(s[0]) && s[0].type !== re.Descendant))
      if (n && !s.some(Qm))
        s.unshift(JC);
      else
        continue;
    s.unshift(QC);
  }
}
l(m4, "absolutize");
function ev(e, t, i) {
  var n;
  e.forEach(u4), i = (n = t.context) !== null && n !== void 0 ? n : i;
  const s = Array.isArray(i), r = i && (Array.isArray(i) ? i : [i]);
  if (t.relativeSelector !== !1)
    m4(e, t, r);
  else if (e.some((c) => c.length > 0 && yu(c[0])))
    throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled");
  let a = !1;
  const u = e.map((c) => {
    if (c.length >= 2) {
      const [h, p] = c;
      h.type !== re.Pseudo || h.name !== "scope" || (s && p.type === re.Descendant ? c[1] = ZC : (p.type === re.Adjacent || p.type === re.Sibling) && (a = !0));
    }
    return v4(c, t, r);
  }).reduce(g4, Ln.default.falseFunc);
  return u.shouldTestNextSiblings = a, u;
}
l(ev, "compileToken");
function v4(e, t, i) {
  var n;
  return e.reduce((s, r) => s === Ln.default.falseFunc ? Ln.default.falseFunc : f4(s, r, t, i, ev), (n = t.rootFunc) !== null && n !== void 0 ? n : Ln.default.trueFunc);
}
l(v4, "compileRules");
function g4(e, t) {
  return t === Ln.default.falseFunc || e === Ln.default.trueFunc ? e : e === Ln.default.falseFunc || t === Ln.default.trueFunc ? t : /* @__PURE__ */ l(function(n) {
    return e(n) || t(n);
  }, "combine");
}
l(g4, "reduceRules");
var y4 = /* @__PURE__ */ l((e, t) => e === t, "defaultEquals"), eT = {
  adapter: uu,
  equals: y4
};
function _u(e) {
  var t, i, n, s;
  const r = e != null ? e : eT;
  return (t = r.adapter) !== null && t !== void 0 || (r.adapter = uu), (i = r.equals) !== null && i !== void 0 || (r.equals = (s = (n = r.adapter) === null || n === void 0 ? void 0 : n.equals) !== null && s !== void 0 ? s : y4), r;
}
l(_u, "convertOptionFormats");
function _4(e) {
  return /* @__PURE__ */ l(function(i, n, s) {
    const r = _u(n);
    return e(i, r, s);
  }, "addAdapter");
}
l(_4, "wrapCompile");
var tT = _4(Jm);
function iT(e) {
  return /* @__PURE__ */ l(function(i, n, s) {
    const r = _u(s);
    typeof i != "function" && (i = Zm(i, r, n));
    const a = b4(n, r.adapter, i.shouldTestNextSiblings);
    return e(i, a, r);
  }, "select");
}
l(iT, "getSelectorFunc");
function b4(e, t, i = !1) {
  return i && (e = w4(e, t)), Array.isArray(e) ? t.removeSubsets(e) : t.getChildren(e);
}
l(b4, "prepareContext");
function w4(e, t) {
  const i = Array.isArray(e) ? e.slice(0) : [e], n = i.length;
  for (let s = 0; s < n; s++) {
    const r = Xm(i[s], t);
    i.push(...r);
  }
  return i;
}
l(w4, "appendNextSiblings");
function S4(e, t, i) {
  const n = _u(i);
  return (typeof t == "function" ? t : Jm(t, n))(e);
}
l(S4, "is");
var { isArray: nT } = Array, bu = /* @__PURE__ */ l(({ nodeType: e }) => e === Re, "isTag"), C4 = /* @__PURE__ */ l((e, t) => t.some((i) => bu(i) && (e(i) || C4(e, _r(i)))), "existsOne"), sT = /* @__PURE__ */ l((e, t) => t === "class" ? e.classList.value : e.getAttribute(t), "getAttributeValue"), _r = /* @__PURE__ */ l(({ childNodes: e }) => e, "getChildren"), rT = /* @__PURE__ */ l((e) => {
  const { localName: t } = e;
  return aa(e) ? t.toLowerCase() : t;
}, "getName"), oT = /* @__PURE__ */ l(({ parentNode: e }) => e, "getParent"), aT = /* @__PURE__ */ l((e) => {
  const { parentNode: t } = e;
  return t ? _r(t) : e;
}, "getSiblings"), vc = /* @__PURE__ */ l((e) => nT(e) ? e.map(vc).join("") : bu(e) ? vc(_r(e)) : e.nodeType === _t ? e.data : "", "getText"), lT = /* @__PURE__ */ l((e, t) => e.hasAttribute(t), "hasAttrib"), uT = /* @__PURE__ */ l((e) => {
  let { length: t } = e;
  for (; t--; ) {
    const i = e[t];
    if (t && -1 < e.lastIndexOf(i, t - 1)) {
      e.splice(t, 1);
      continue;
    }
    for (let { parentNode: n } = i; n; n = n.parentNode)
      if (e.includes(n)) {
        e.splice(t, 1);
        break;
      }
  }
  return e;
}, "removeSubsets"), T4 = /* @__PURE__ */ l((e, t) => {
  const i = [];
  for (const n of t)
    bu(n) && (e(n) && i.push(n), i.push(...T4(e, _r(n))));
  return i;
}, "findAll"), x4 = /* @__PURE__ */ l((e, t) => {
  for (let i of t)
    if (e(i) || (i = x4(e, _r(i))))
      return i;
  return null;
}, "findOne"), E4 = {
  isTag: bu,
  existsOne: C4,
  getAttributeValue: sT,
  getChildren: _r,
  getName: rT,
  getParent: oT,
  getSiblings: aT,
  getText: vc,
  hasAttrib: lT,
  removeSubsets: uT,
  findAll: T4,
  findOne: x4
}, gc = /* @__PURE__ */ l((e, t) => tT(t, {
  context: t.includes(":scope") ? e : void 0,
  xmlMode: !aa(e),
  adapter: E4
}), "prepareMatch"), cT = /* @__PURE__ */ l((e, t) => S4(e, t, {
  strict: !0,
  context: t.includes(":scope") ? e : void 0,
  xmlMode: !aa(e),
  adapter: E4
}), "matches"), { replace: hT } = "", dT = /[<>&\xA0]/g, pT = {
  "\xA0": "&nbsp;",
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;"
}, fT = /* @__PURE__ */ l((e) => pT[e], "pe"), mT = /* @__PURE__ */ l((e) => hT.call(e, dT, fT), "escape"), xs = class extends la {
  constructor(e, t = "") {
    super(e, "#text", _t, t);
  }
  get wholeText() {
    const e = [];
    let { previousSibling: t, nextSibling: i } = this;
    for (; t && t.nodeType === _t; ) {
      e.unshift(t[He]);
      t = t.previousSibling;
    }
    for (e.push(this[He]); i && i.nodeType === _t; ) {
      e.push(i[He]);
      i = i.nextSibling;
    }
    return e.join("");
  }
  cloneNode() {
    const { ownerDocument: e, [He]: t } = this;
    return new xs(e, t);
  }
  toString() {
    return mT(this[He]);
  }
};
l(xs, "Text");
var vT = /* @__PURE__ */ l((e) => e instanceof Hn, "isNode"), L1 = /* @__PURE__ */ l((e, t, i) => {
  const { ownerDocument: n } = e;
  for (const s of i)
    e.insertBefore(vT(s) ? s : new xs(n, s), t);
}, "insert"), tv = class extends Hn {
  constructor(e, t, i) {
    super(e, t, i), this[yt] = null, this[W] = this[ne] = {
      [W]: null,
      [ct]: this,
      [Lt]: this,
      nodeType: Vn,
      ownerDocument: this.ownerDocument,
      parentNode: null
    };
  }
  get childNodes() {
    const e = new gi();
    let { firstChild: t } = this;
    for (; t; )
      e.push(t), t = ms(t);
    return e;
  }
  get children() {
    const e = new gi();
    let { firstElementChild: t } = this;
    for (; t; )
      e.push(t), t = $m(t);
    return e;
  }
  get firstChild() {
    let { [W]: e, [ne]: t } = this;
    for (; e.nodeType === ft; )
      e = e[W];
    return e === t ? null : e;
  }
  get firstElementChild() {
    let { firstChild: e } = this;
    for (; e; ) {
      if (e.nodeType === Re)
        return e;
      e = ms(e);
    }
    return null;
  }
  get lastChild() {
    const e = this[ne][ct];
    switch (e.nodeType) {
      case Vn:
        return e[Lt];
      case ft:
        return null;
    }
    return e === this ? null : e;
  }
  get lastElementChild() {
    let { lastChild: e } = this;
    for (; e; ) {
      if (e.nodeType === Re)
        return e;
      e = Go(e);
    }
    return null;
  }
  get childElementCount() {
    return this.children.length;
  }
  prepend(...e) {
    L1(this, this.firstChild, e);
  }
  append(...e) {
    L1(this, this[ne], e);
  }
  replaceChildren(...e) {
    let { [W]: t, [ne]: i } = this;
    for (; t !== i && t.nodeType === ft; )
      t = t[W];
    for (; t !== i; ) {
      const n = Kt(t)[W];
      t.remove(), t = n;
    }
    e.length && L1(this, i, e);
  }
  getElementsByClassName(e) {
    const t = new gi();
    let { [W]: i, [ne]: n } = this;
    for (; i !== n; )
      i.nodeType === Re && i.hasAttribute("class") && i.classList.has(e) && t.push(i), i = i[W];
    return t;
  }
  getElementsByTagName(e) {
    const t = new gi();
    let { [W]: i, [ne]: n } = this;
    for (; i !== n; )
      i.nodeType === Re && (i.localName === e || uc(i) === e) && t.push(i), i = i[W];
    return t;
  }
  querySelector(e) {
    const t = gc(this, e);
    let { [W]: i, [ne]: n } = this;
    for (; i !== n; ) {
      if (i.nodeType === Re && t(i))
        return i;
      i = i[W];
    }
    return null;
  }
  querySelectorAll(e) {
    const t = gc(this, e), i = new gi();
    let { [W]: n, [ne]: s } = this;
    for (; n !== s; )
      n.nodeType === Re && t(n) && i.push(n), n = n[W];
    return i;
  }
  appendChild(e) {
    return this.insertBefore(e, this[ne]);
  }
  contains(e) {
    let t = e;
    for (; t && t !== this; )
      t = t.parentNode;
    return t === this;
  }
  insertBefore(e, t = null) {
    if (e === t)
      return e;
    if (e === this)
      throw new Error("unable to append a node to itself");
    const i = t || this[ne];
    switch (e.nodeType) {
      case Re:
        e.remove(), e.parentNode = this, Vb(i[ct], e, i), Ro(e, null), cc(e);
        break;
      case Dn: {
        let { [yt]: n, firstChild: s, lastChild: r } = e;
        if (s) {
          NC(i[ct], s, r, i), _i(e, e[ne]), n && n.replaceChildren();
          do
            s.parentNode = this, Ro(s, null), s.nodeType === Re && cc(s);
          while (s !== r && (s = ms(s)));
        }
        break;
      }
      case _t:
      case an:
        e.remove();
      default:
        e.parentNode = this, fu(i[ct], e, i), Ro(e, null);
        break;
    }
    return e;
  }
  normalize() {
    let { [W]: e, [ne]: t } = this;
    for (; e !== t; ) {
      const { [W]: i, [ct]: n, nodeType: s } = e;
      s === _t && (e[He] ? n && n.nodeType === _t && (n.textContent += e.textContent, e.remove()) : e.remove()), e = i;
    }
  }
  removeChild(e) {
    if (e.parentNode !== this)
      throw new Error("node is not a child");
    return e.remove(), e;
  }
  replaceChild(e, t) {
    const i = Kt(t)[W];
    return t.remove(), this.insertBefore(e, i), t;
  }
};
l(tv, "ParentNode");
var wu = class extends tv {
  getElementById(e) {
    let { [W]: t, [ne]: i } = this;
    for (; t !== i; ) {
      if (t.nodeType === Re && t.id === e)
        return t;
      t = t[W];
    }
    return null;
  }
  cloneNode(e) {
    const { ownerDocument: t, constructor: i } = this, n = new i(t);
    if (e) {
      const { [ne]: s } = n;
      for (const r of this.childNodes)
        n.insertBefore(r.cloneNode(e), s);
    }
    return n;
  }
  toString() {
    const { childNodes: e, localName: t } = this;
    return `<${t}>${e.join("")}</${t}>`;
  }
  toJSON() {
    const e = [];
    return OC(this, e), e;
  }
};
l(wu, "NonElementParentNode");
var Su = class extends wu {
  constructor(e) {
    super(e, "#document-fragment", Dn);
  }
};
l(Su, "DocumentFragment");
var dr = class extends Hn {
  constructor(e, t, i = "", n = "") {
    super(e, "#document-type", hr), this.name = t, this.publicId = i, this.systemId = n;
  }
  cloneNode() {
    const { ownerDocument: e, name: t, publicId: i, systemId: n } = this;
    return new dr(e, t, i, n);
  }
  toString() {
    const { name: e, publicId: t, systemId: i } = this, n = 0 < t.length, s = [e];
    return n && s.push("PUBLIC", `"${t}"`), i.length && (n || s.push("SYSTEM"), s.push(`"${i}"`)), `<!DOCTYPE ${s.join(" ")}>`;
  }
  toJSON() {
    const e = [];
    return zb(this, e), e;
  }
};
l(dr, "DocumentType");
var A4 = /* @__PURE__ */ l((e) => e.childNodes.join(""), "getInnerHtml"), k4 = /* @__PURE__ */ l((e, t) => {
  const { ownerDocument: i } = e, { constructor: n } = i, s = new n();
  s[pi] = i[pi];
  const { childNodes: r } = Wb(s, aa(e), t);
  e.replaceChildren(...r);
}, "setInnerHtml"), sl = /* @__PURE__ */ l((e) => e.replace(/(([A-Z0-9])([A-Z0-9][a-z]))|(([a-z])([A-Z]))/g, "$2$5-$3$6").toLowerCase(), "default"), rl = /* @__PURE__ */ new WeakMap(), D1 = /* @__PURE__ */ l((e) => `data-${sl(e)}`, "key"), gT = /* @__PURE__ */ l((e) => e.slice(5).replace(/-([a-z])/g, (t, i) => i.toUpperCase()), "prop"), yT = {
  get(e, t) {
    if (t in e)
      return rl.get(e).getAttribute(D1(t));
  },
  set(e, t, i) {
    return e[t] = i, rl.get(e).setAttribute(D1(t), i), !0;
  },
  deleteProperty(e, t) {
    return t in e && rl.get(e).removeAttribute(D1(t)), delete e[t];
  }
}, iv = class {
  constructor(e) {
    for (const { name: t, value: i } of e.attributes)
      /^data-/.test(t) && (this[gT(t)] = i);
    return rl.set(this, e), new Proxy(this, yT);
  }
};
l(iv, "DOMStringMap");
Vt(iv.prototype, null);
var { add: _T } = Set.prototype, a2 = /* @__PURE__ */ l((e, t) => {
  for (const i of t)
    i && _T.call(e, i);
}, "addTokens"), Rr = /* @__PURE__ */ l(({ [W_]: e, value: t }) => {
  const i = e.getAttributeNode("class");
  i ? i.value = t : hc(e, new Ts(e.ownerDocument, "class", t));
}, "update"), I4 = class extends Set {
  constructor(e) {
    super(), this[W_] = e;
    const t = e.getAttributeNode("class");
    t && a2(this, t.value.split(/\s+/));
  }
  get length() {
    return this.size;
  }
  get value() {
    return [...this].join(" ");
  }
  add(...e) {
    a2(this, e), Rr(this);
  }
  contains(e) {
    return this.has(e);
  }
  remove(...e) {
    for (const t of e)
      this.delete(t);
    Rr(this);
  }
  toggle(e, t) {
    if (this.has(e)) {
      if (t)
        return !0;
      this.delete(e), Rr(this);
    } else if (t || arguments.length === 1)
      return super.add(e), Rr(this), !0;
    return !1;
  }
  replace(e, t) {
    return this.has(e) ? (this.delete(e), super.add(t), Rr(this), !0) : !1;
  }
  supports() {
    return !0;
  }
};
l(I4, "DOMTokenList");
var Wl = /* @__PURE__ */ new WeakMap(), yc = /* @__PURE__ */ l((e) => [...e.keys()].filter((t) => t !== yt), "getKeys"), _c = /* @__PURE__ */ l((e) => {
  const t = Wl.get(e).getAttributeNode("style");
  if ((!t || t[Ll] || e.get(yt) !== t) && (e.clear(), t)) {
    e.set(yt, t);
    for (const i of t[He].split(/\s*;\s*/)) {
      let [n, ...s] = i.split(":");
      if (s.length > 0) {
        n = n.trim();
        const r = s.join(":").trim();
        n && r && e.set(n, r);
      }
    }
  }
  return t;
}, "updateKeys"), Ia = {
  get(e, t) {
    return t in bT ? e[t] : (_c(e), t === "length" ? yc(e).length : /^\d+$/.test(t) ? yc(e)[t] : e.get(sl(t)));
  },
  set(e, t, i) {
    if (t === "cssText")
      e[t] = i;
    else {
      let n = _c(e);
      if (i == null ? e.delete(sl(t)) : e.set(sl(t), i), !n) {
        const s = Wl.get(e);
        n = s.ownerDocument.createAttribute("style"), s.setAttributeNode(n), e.set(yt, n);
      }
      n[Ll] = !1, n[He] = e.toString();
    }
    return !0;
  }
}, nv = class extends Map {
  constructor(e) {
    return super(), Wl.set(this, e), new Proxy(this, Ia);
  }
  get cssText() {
    return this.toString();
  }
  set cssText(e) {
    Wl.get(this).setAttribute("style", e);
  }
  getPropertyValue(e) {
    const t = this[yt];
    return Ia.get(t, e);
  }
  setProperty(e, t) {
    const i = this[yt];
    Ia.set(i, e, t);
  }
  removeProperty(e) {
    const t = this[yt];
    Ia.set(t, e, null);
  }
  [Symbol.iterator]() {
    const e = yc(this[yt]), { length: t } = e;
    let i = 0;
    return {
      next() {
        const n = i === t;
        return { done: n, value: n ? null : e[i++] };
      }
    };
  }
  get [yt]() {
    return this;
  }
  toString() {
    const e = this[yt];
    _c(e);
    const t = [];
    return e.forEach(P4, t), t.join(";");
  }
};
l(nv, "CSSStyleDeclaration");
var { prototype: bT } = nv;
function P4(e, t) {
  t !== yt && this.push(`${t}:${e}`);
}
l(P4, "push");
var l2 = 3, u2 = 2, c2 = 1, h2 = 0, Un = class {
  static get BUBBLING_PHASE() {
    return l2;
  }
  static get AT_TARGET() {
    return u2;
  }
  static get CAPTURING_PHASE() {
    return c2;
  }
  static get NONE() {
    return h2;
  }
  constructor(e, t = {}) {
    this.type = e, this.bubbles = !!t.bubbles, this.cancelBubble = !1, this._stopImmediatePropagationFlag = !1, this.cancelable = !!t.cancelable, this.eventPhase = this.NONE, this.timeStamp = Date.now(), this.defaultPrevented = !1, this.originalTarget = null, this.returnValue = null, this.srcElement = null, this.target = null, this._path = [];
  }
  get BUBBLING_PHASE() {
    return l2;
  }
  get AT_TARGET() {
    return u2;
  }
  get CAPTURING_PHASE() {
    return c2;
  }
  get NONE() {
    return h2;
  }
  preventDefault() {
    this.defaultPrevented = !0;
  }
  composedPath() {
    return this._path;
  }
  stopPropagation() {
    this.cancelBubble = !0;
  }
  stopImmediatePropagation() {
    this.stopPropagation(), this._stopImmediatePropagationFlag = !0;
  }
};
l(Un, "GlobalEvent");
var sv = class extends Array {
  constructor(e) {
    super(), this.ownerElement = e;
  }
  getNamedItem(e) {
    return this.ownerElement.getAttributeNode(e);
  }
  setNamedItem(e) {
    this.ownerElement.setAttributeNode(e), this.unshift(e);
  }
  removeNamedItem(e) {
    const t = this.getNamedItem(e);
    this.ownerElement.removeAttribute(e), this.splice(this.indexOf(t), 1);
  }
  item(e) {
    return e < this.length ? this[e] : null;
  }
  getNamedItemNS(e, t) {
    return this.getNamedItem(t);
  }
  setNamedItemNS(e, t) {
    return this.setNamedItem(t);
  }
  removeNamedItemNS(e, t) {
    return this.removeNamedItem(t);
  }
};
l(sv, "NamedNodeMap");
var Cu = class extends wu {
  constructor(e) {
    super(e.ownerDocument, "#shadow-root", Dn), this.host = e;
  }
  get innerHTML() {
    return A4(this);
  }
  set innerHTML(e) {
    k4(this, e);
  }
};
l(Cu, "ShadowRoot");
var wT = {
  get(e, t) {
    return t in e ? e[t] : e.find(({ name: i }) => i === t);
  }
}, d2 = /* @__PURE__ */ l((e, t, i) => {
  if ("ownerSVGElement" in t) {
    const n = e.createElementNS(Vl, i);
    return n.ownerSVGElement = t.ownerSVGElement, n;
  }
  return e.createElement(i);
}, "create"), ST = /* @__PURE__ */ l(({ localName: e, ownerDocument: t }) => t[gr].voidElements.test(e), "isVoid"), br = class extends tv {
  constructor(e, t) {
    super(e, t, Re), this[zs] = null, this[I1] = null, this[P1] = null;
  }
  get isConnected() {
    return Qb(this);
  }
  get parentElement() {
    return e4(this);
  }
  get previousSibling() {
    return Go(this);
  }
  get nextSibling() {
    return ms(this);
  }
  get previousElementSibling() {
    return t4(this);
  }
  get nextElementSibling() {
    return $m(this);
  }
  before(...e) {
    i4(this, e);
  }
  after(...e) {
    n4(this, e);
  }
  replaceWith(...e) {
    s4(this, e);
  }
  remove() {
    r4(this[ct], this, this[ne][W]);
  }
  get id() {
    return Y.get(this, "id");
  }
  set id(e) {
    Y.set(this, "id", e);
  }
  get className() {
    return this.classList.value;
  }
  set className(e) {
    const { classList: t } = this;
    t.clear(), t.add(...e.split(/\s+/));
  }
  get nodeName() {
    return uc(this);
  }
  get tagName() {
    return uc(this);
  }
  get classList() {
    return this[zs] || (this[zs] = new I4(this));
  }
  get dataset() {
    return this[I1] || (this[I1] = new iv(this));
  }
  get nonce() {
    return Y.get(this, "nonce");
  }
  set nonce(e) {
    Y.set(this, "nonce", e);
  }
  get style() {
    return this[P1] || (this[P1] = new nv(this));
  }
  get tabIndex() {
    return Rn.get(this, "tabindex") || -1;
  }
  set tabIndex(e) {
    Rn.set(this, "tabindex", e);
  }
  get innerText() {
    const e = [];
    let { [W]: t, [ne]: i } = this;
    for (; t !== i; )
      t.nodeType === _t ? e.push(t.textContent.replace(/\s+/g, " ")) : e.length && t[W] != i && yC.has(t.tagName) && e.push(`
`), t = t[W];
    return e.join("");
  }
  get textContent() {
    const e = [];
    let { [W]: t, [ne]: i } = this;
    for (; t !== i; )
      t.nodeType === _t && e.push(t.textContent), t = t[W];
    return e.join("");
  }
  set textContent(e) {
    this.replaceChildren(), e && this.appendChild(new xs(this.ownerDocument, e));
  }
  get innerHTML() {
    return A4(this);
  }
  set innerHTML(e) {
    k4(this, e);
  }
  get outerHTML() {
    return this.toString();
  }
  set outerHTML(e) {
    const t = this.ownerDocument.createElement("");
    t.innerHTML = e, this.replaceWith(...t.childNodes);
  }
  get attributes() {
    const e = new sv(this);
    let t = this[W];
    for (; t.nodeType === ft; )
      e.push(t), t = t[W];
    return new Proxy(e, wT);
  }
  focus() {
    this.dispatchEvent(new Un("focus"));
  }
  getAttribute(e) {
    if (e === "class")
      return this.className;
    const t = this.getAttributeNode(e);
    return t && t.value;
  }
  getAttributeNode(e) {
    let t = this[W];
    for (; t.nodeType === ft; ) {
      if (t.name === e)
        return t;
      t = t[W];
    }
    return null;
  }
  getAttributeNames() {
    const e = new gi();
    let t = this[W];
    for (; t.nodeType === ft; )
      e.push(t.name), t = t[W];
    return e;
  }
  hasAttribute(e) {
    return !!this.getAttributeNode(e);
  }
  hasAttributes() {
    return this[W].nodeType === ft;
  }
  removeAttribute(e) {
    e === "class" && this[zs] && this[zs].clear();
    let t = this[W];
    for (; t.nodeType === ft; ) {
      if (t.name === e) {
        t2(this, t);
        return;
      }
      t = t[W];
    }
  }
  removeAttributeNode(e) {
    let t = this[W];
    for (; t.nodeType === ft; ) {
      if (t === e) {
        t2(this, t);
        return;
      }
      t = t[W];
    }
  }
  setAttribute(e, t) {
    if (e === "class")
      this.className = t;
    else {
      const i = this.getAttributeNode(e);
      i ? i.value = t : hc(this, new Ts(this.ownerDocument, e, t));
    }
  }
  setAttributeNode(e) {
    const { name: t } = e, i = this.getAttributeNode(t);
    if (i !== e) {
      i && this.removeAttributeNode(i);
      const { ownerElement: n } = e;
      n && n.removeAttributeNode(e), hc(this, e);
    }
    return i;
  }
  toggleAttribute(e, t) {
    return this.hasAttribute(e) ? t ? !0 : (this.removeAttribute(e), !1) : t || arguments.length === 1 ? (this.setAttribute(e, ""), !0) : !1;
  }
  get shadowRoot() {
    if (Nn.has(this)) {
      const { mode: e, shadowRoot: t } = Nn.get(this);
      if (e === "open")
        return t;
    }
    return null;
  }
  attachShadow(e) {
    if (Nn.has(this))
      throw new Error("operation not supported");
    const t = new Cu(this);
    return t.append(...this.childNodes), Nn.set(this, {
      mode: e.mode,
      shadowRoot: t
    }), t;
  }
  matches(e) {
    return cT(this, e);
  }
  closest(e) {
    let t = this;
    const i = gc(t, e);
    for (; t && !i(t); )
      t = t.parentElement;
    return t;
  }
  insertAdjacentElement(e, t) {
    const { parentElement: i } = this;
    switch (e) {
      case "beforebegin":
        if (i) {
          i.insertBefore(t, this);
          break;
        }
        return null;
      case "afterbegin":
        this.insertBefore(t, this.firstChild);
        break;
      case "beforeend":
        this.insertBefore(t, null);
        break;
      case "afterend":
        if (i) {
          i.insertBefore(t, this.nextSibling);
          break;
        }
        return null;
    }
    return t;
  }
  insertAdjacentHTML(e, t) {
    const i = this.ownerDocument.createElement("template");
    i.innerHTML = t, this.insertAdjacentElement(e, i.content);
  }
  insertAdjacentText(e, t) {
    const i = this.ownerDocument.createTextNode(t);
    this.insertAdjacentElement(e, i);
  }
  cloneNode(e = !1) {
    const { ownerDocument: t, localName: i } = this, n = /* @__PURE__ */ l((h) => {
      h.parentNode = r, _i(a, h), a = h;
    }, "addNext"), s = d2(t, this, i);
    let r = s, a = s, { [W]: u, [ne]: c } = this;
    for (; u !== c && (e || u.nodeType === ft); ) {
      switch (u.nodeType) {
        case Vn:
          _i(a, r[ne]), a = r[ne], r = r.parentNode;
          break;
        case Re: {
          const h = d2(t, u, u.localName);
          n(h), r = h;
          break;
        }
        case ft:
        case _t:
        case an:
          n(u.cloneNode(e));
          break;
      }
      u = u[W];
    }
    return _i(a, s[ne]), s;
  }
  toString() {
    const e = [], { [ne]: t } = this;
    let i = { [W]: this }, n = !1;
    do
      switch (i = i[W], i.nodeType) {
        case ft: {
          const s = " " + i;
          switch (s) {
            case " id":
            case " class":
            case " style":
              break;
            default:
              e.push(s);
          }
          break;
        }
        case Vn: {
          const s = i[Lt];
          n ? ("ownerSVGElement" in s ? e.push(" />") : ST(s) ? e.push(aa(s) ? ">" : " />") : e.push(`></${s.localName}>`), n = !1) : e.push(`</${s.localName}>`);
          break;
        }
        case Re:
          n && e.push(">"), i.toString !== this.toString ? (e.push(i.toString()), i = i[ne], n = !1) : (e.push(`<${i.localName}`), n = !0);
          break;
        case _t:
        case an:
          e.push((n ? ">" : "") + i), n = !1;
          break;
      }
    while (i !== t);
    return e.join("");
  }
  toJSON() {
    const e = [];
    return Kb(this, e), e;
  }
  getAttributeNS(e, t) {
    return this.getAttribute(t);
  }
  getElementsByTagNameNS(e, t) {
    return this.getElementsByTagName(t);
  }
  hasAttributeNS(e, t) {
    return this.hasAttribute(t);
  }
  removeAttributeNS(e, t) {
    this.removeAttribute(t);
  }
  setAttributeNS(e, t, i) {
    this.setAttribute(t, i);
  }
  setAttributeNodeNS(e) {
    return this.setAttributeNode(e);
  }
};
l(br, "Element");
var B1 = /* @__PURE__ */ new WeakMap(), CT = {
  get(e, t) {
    return e[t];
  },
  set(e, t, i) {
    return e[t] = i, !0;
  }
}, Tu = class extends br {
  constructor(e, t, i = null) {
    super(e, t), this.ownerSVGElement = i;
  }
  get className() {
    return B1.has(this) || B1.set(this, new Proxy({ baseVal: "", animVal: "" }, CT)), B1.get(this);
  }
  set className(e) {
    const { classList: t } = this;
    t.clear(), t.add(...e.split(/\s+/));
  }
  getAttribute(e) {
    return e === "class" ? [...this.classList].join(" ") : super.getAttribute(e);
  }
  setAttribute(e, t) {
    if (e === "class")
      this.className = t;
    else if (e === "style") {
      const { className: i } = this;
      i.baseVal = i.animVal = t;
    }
    super.setAttribute(e, t);
  }
};
l(Tu, "SVGElement");
var oi = /* @__PURE__ */ l(() => {
  throw new TypeError("Illegal constructor");
}, "illegalConstructor");
function xu() {
  oi();
}
l(xu, "Attr");
Vt(xu, Ts);
xu.prototype = Ts.prototype;
function Eu() {
  oi();
}
l(Eu, "CharacterData");
Vt(Eu, la);
Eu.prototype = la.prototype;
function Au() {
  oi();
}
l(Au, "Comment");
Vt(Au, ua);
Au.prototype = ua.prototype;
function ku() {
  oi();
}
l(ku, "DocumentFragment");
Vt(ku, Su);
ku.prototype = Su.prototype;
function Iu() {
  oi();
}
l(Iu, "DocumentType");
Vt(Iu, dr);
Iu.prototype = dr.prototype;
function Pu() {
  oi();
}
l(Pu, "Element");
Vt(Pu, br);
Pu.prototype = br.prototype;
function Mu() {
  oi();
}
l(Mu, "Node");
Vt(Mu, Hn);
Mu.prototype = Hn.prototype;
function Nu() {
  oi();
}
l(Nu, "ShadowRoot");
Vt(Nu, Cu);
Nu.prototype = Cu.prototype;
function Ru() {
  oi();
}
l(Ru, "Text");
Vt(Ru, xs);
Ru.prototype = xs.prototype;
function Lu() {
  oi();
}
l(Lu, "SVGElement");
Vt(Lu, Tu);
Lu.prototype = Tu.prototype;
var TT = {
  Attr: xu,
  CharacterData: Eu,
  Comment: Au,
  DocumentFragment: ku,
  DocumentType: Iu,
  Element: Pu,
  Node: Mu,
  ShadowRoot: Nu,
  Text: Ru,
  SVGElement: Lu
}, Lr = /* @__PURE__ */ new WeakMap(), E = {
  get(e, t) {
    return Lr.has(e) && Lr.get(e)[t] || null;
  },
  set(e, t, i) {
    Lr.has(e) || Lr.set(e, {});
    const n = Lr.get(e), s = t.slice(2);
    n[t] && e.removeEventListener(s, n[t], !1), (n[t] = i) && e.addEventListener(s, i, !1);
  }
}, G = class extends br {
  static get observedAttributes() {
    return [];
  }
  constructor(e = null, t = "") {
    super(e, t);
    const i = !e;
    let n;
    if (i) {
      const { constructor: s } = this;
      if (!Ul.has(s))
        throw new Error("unable to initialize this Custom Element");
      ({ ownerDocument: e, localName: t, options: n } = Ul.get(s));
    }
    if (e[Po]) {
      const { element: s, values: r } = e[Po];
      e[Po] = null;
      for (const [a, u] of r)
        s[a] = u;
      return s;
    }
    i && (this.ownerDocument = this[ne].ownerDocument = e, this.localName = t, bs.set(this, { connected: !1 }), n.is && this.setAttribute("is", n.is));
  }
  blur() {
    this.dispatchEvent(new Un("blur"));
  }
  click() {
    this.dispatchEvent(new Un("click"));
  }
  get accessKeyLabel() {
    const { accessKey: e } = this;
    return e && `Alt+Shift+${e}`;
  }
  get isContentEditable() {
    return this.hasAttribute("contenteditable");
  }
  get contentEditable() {
    return Fe.get(this, "contenteditable");
  }
  set contentEditable(e) {
    Fe.set(this, "contenteditable", e);
  }
  get draggable() {
    return Fe.get(this, "draggable");
  }
  set draggable(e) {
    Fe.set(this, "draggable", e);
  }
  get hidden() {
    return Fe.get(this, "hidden");
  }
  set hidden(e) {
    Fe.set(this, "hidden", e);
  }
  get spellcheck() {
    return Fe.get(this, "spellcheck");
  }
  set spellcheck(e) {
    Fe.set(this, "spellcheck", e);
  }
  get accessKey() {
    return Y.get(this, "accesskey");
  }
  set accessKey(e) {
    Y.set(this, "accesskey", e);
  }
  get dir() {
    return Y.get(this, "dir");
  }
  set dir(e) {
    Y.set(this, "dir", e);
  }
  get lang() {
    return Y.get(this, "lang");
  }
  set lang(e) {
    Y.set(this, "lang", e);
  }
  get title() {
    return Y.get(this, "title");
  }
  set title(e) {
    Y.set(this, "title", e);
  }
  get onabort() {
    return E.get(this, "onabort");
  }
  set onabort(e) {
    E.set(this, "onabort", e);
  }
  get onblur() {
    return E.get(this, "onblur");
  }
  set onblur(e) {
    E.set(this, "onblur", e);
  }
  get oncancel() {
    return E.get(this, "oncancel");
  }
  set oncancel(e) {
    E.set(this, "oncancel", e);
  }
  get oncanplay() {
    return E.get(this, "oncanplay");
  }
  set oncanplay(e) {
    E.set(this, "oncanplay", e);
  }
  get oncanplaythrough() {
    return E.get(this, "oncanplaythrough");
  }
  set oncanplaythrough(e) {
    E.set(this, "oncanplaythrough", e);
  }
  get onchange() {
    return E.get(this, "onchange");
  }
  set onchange(e) {
    E.set(this, "onchange", e);
  }
  get onclick() {
    return E.get(this, "onclick");
  }
  set onclick(e) {
    E.set(this, "onclick", e);
  }
  get onclose() {
    return E.get(this, "onclose");
  }
  set onclose(e) {
    E.set(this, "onclose", e);
  }
  get oncontextmenu() {
    return E.get(this, "oncontextmenu");
  }
  set oncontextmenu(e) {
    E.set(this, "oncontextmenu", e);
  }
  get oncuechange() {
    return E.get(this, "oncuechange");
  }
  set oncuechange(e) {
    E.set(this, "oncuechange", e);
  }
  get ondblclick() {
    return E.get(this, "ondblclick");
  }
  set ondblclick(e) {
    E.set(this, "ondblclick", e);
  }
  get ondrag() {
    return E.get(this, "ondrag");
  }
  set ondrag(e) {
    E.set(this, "ondrag", e);
  }
  get ondragend() {
    return E.get(this, "ondragend");
  }
  set ondragend(e) {
    E.set(this, "ondragend", e);
  }
  get ondragenter() {
    return E.get(this, "ondragenter");
  }
  set ondragenter(e) {
    E.set(this, "ondragenter", e);
  }
  get ondragleave() {
    return E.get(this, "ondragleave");
  }
  set ondragleave(e) {
    E.set(this, "ondragleave", e);
  }
  get ondragover() {
    return E.get(this, "ondragover");
  }
  set ondragover(e) {
    E.set(this, "ondragover", e);
  }
  get ondragstart() {
    return E.get(this, "ondragstart");
  }
  set ondragstart(e) {
    E.set(this, "ondragstart", e);
  }
  get ondrop() {
    return E.get(this, "ondrop");
  }
  set ondrop(e) {
    E.set(this, "ondrop", e);
  }
  get ondurationchange() {
    return E.get(this, "ondurationchange");
  }
  set ondurationchange(e) {
    E.set(this, "ondurationchange", e);
  }
  get onemptied() {
    return E.get(this, "onemptied");
  }
  set onemptied(e) {
    E.set(this, "onemptied", e);
  }
  get onended() {
    return E.get(this, "onended");
  }
  set onended(e) {
    E.set(this, "onended", e);
  }
  get onerror() {
    return E.get(this, "onerror");
  }
  set onerror(e) {
    E.set(this, "onerror", e);
  }
  get onfocus() {
    return E.get(this, "onfocus");
  }
  set onfocus(e) {
    E.set(this, "onfocus", e);
  }
  get oninput() {
    return E.get(this, "oninput");
  }
  set oninput(e) {
    E.set(this, "oninput", e);
  }
  get oninvalid() {
    return E.get(this, "oninvalid");
  }
  set oninvalid(e) {
    E.set(this, "oninvalid", e);
  }
  get onkeydown() {
    return E.get(this, "onkeydown");
  }
  set onkeydown(e) {
    E.set(this, "onkeydown", e);
  }
  get onkeypress() {
    return E.get(this, "onkeypress");
  }
  set onkeypress(e) {
    E.set(this, "onkeypress", e);
  }
  get onkeyup() {
    return E.get(this, "onkeyup");
  }
  set onkeyup(e) {
    E.set(this, "onkeyup", e);
  }
  get onload() {
    return E.get(this, "onload");
  }
  set onload(e) {
    E.set(this, "onload", e);
  }
  get onloadeddata() {
    return E.get(this, "onloadeddata");
  }
  set onloadeddata(e) {
    E.set(this, "onloadeddata", e);
  }
  get onloadedmetadata() {
    return E.get(this, "onloadedmetadata");
  }
  set onloadedmetadata(e) {
    E.set(this, "onloadedmetadata", e);
  }
  get onloadstart() {
    return E.get(this, "onloadstart");
  }
  set onloadstart(e) {
    E.set(this, "onloadstart", e);
  }
  get onmousedown() {
    return E.get(this, "onmousedown");
  }
  set onmousedown(e) {
    E.set(this, "onmousedown", e);
  }
  get onmouseenter() {
    return E.get(this, "onmouseenter");
  }
  set onmouseenter(e) {
    E.set(this, "onmouseenter", e);
  }
  get onmouseleave() {
    return E.get(this, "onmouseleave");
  }
  set onmouseleave(e) {
    E.set(this, "onmouseleave", e);
  }
  get onmousemove() {
    return E.get(this, "onmousemove");
  }
  set onmousemove(e) {
    E.set(this, "onmousemove", e);
  }
  get onmouseout() {
    return E.get(this, "onmouseout");
  }
  set onmouseout(e) {
    E.set(this, "onmouseout", e);
  }
  get onmouseover() {
    return E.get(this, "onmouseover");
  }
  set onmouseover(e) {
    E.set(this, "onmouseover", e);
  }
  get onmouseup() {
    return E.get(this, "onmouseup");
  }
  set onmouseup(e) {
    E.set(this, "onmouseup", e);
  }
  get onmousewheel() {
    return E.get(this, "onmousewheel");
  }
  set onmousewheel(e) {
    E.set(this, "onmousewheel", e);
  }
  get onpause() {
    return E.get(this, "onpause");
  }
  set onpause(e) {
    E.set(this, "onpause", e);
  }
  get onplay() {
    return E.get(this, "onplay");
  }
  set onplay(e) {
    E.set(this, "onplay", e);
  }
  get onplaying() {
    return E.get(this, "onplaying");
  }
  set onplaying(e) {
    E.set(this, "onplaying", e);
  }
  get onprogress() {
    return E.get(this, "onprogress");
  }
  set onprogress(e) {
    E.set(this, "onprogress", e);
  }
  get onratechange() {
    return E.get(this, "onratechange");
  }
  set onratechange(e) {
    E.set(this, "onratechange", e);
  }
  get onreset() {
    return E.get(this, "onreset");
  }
  set onreset(e) {
    E.set(this, "onreset", e);
  }
  get onresize() {
    return E.get(this, "onresize");
  }
  set onresize(e) {
    E.set(this, "onresize", e);
  }
  get onscroll() {
    return E.get(this, "onscroll");
  }
  set onscroll(e) {
    E.set(this, "onscroll", e);
  }
  get onseeked() {
    return E.get(this, "onseeked");
  }
  set onseeked(e) {
    E.set(this, "onseeked", e);
  }
  get onseeking() {
    return E.get(this, "onseeking");
  }
  set onseeking(e) {
    E.set(this, "onseeking", e);
  }
  get onselect() {
    return E.get(this, "onselect");
  }
  set onselect(e) {
    E.set(this, "onselect", e);
  }
  get onshow() {
    return E.get(this, "onshow");
  }
  set onshow(e) {
    E.set(this, "onshow", e);
  }
  get onstalled() {
    return E.get(this, "onstalled");
  }
  set onstalled(e) {
    E.set(this, "onstalled", e);
  }
  get onsubmit() {
    return E.get(this, "onsubmit");
  }
  set onsubmit(e) {
    E.set(this, "onsubmit", e);
  }
  get onsuspend() {
    return E.get(this, "onsuspend");
  }
  set onsuspend(e) {
    E.set(this, "onsuspend", e);
  }
  get ontimeupdate() {
    return E.get(this, "ontimeupdate");
  }
  set ontimeupdate(e) {
    E.set(this, "ontimeupdate", e);
  }
  get ontoggle() {
    return E.get(this, "ontoggle");
  }
  set ontoggle(e) {
    E.set(this, "ontoggle", e);
  }
  get onvolumechange() {
    return E.get(this, "onvolumechange");
  }
  set onvolumechange(e) {
    E.set(this, "onvolumechange", e);
  }
  get onwaiting() {
    return E.get(this, "onwaiting");
  }
  set onwaiting(e) {
    E.set(this, "onwaiting", e);
  }
  get onauxclick() {
    return E.get(this, "onauxclick");
  }
  set onauxclick(e) {
    E.set(this, "onauxclick", e);
  }
  get ongotpointercapture() {
    return E.get(this, "ongotpointercapture");
  }
  set ongotpointercapture(e) {
    E.set(this, "ongotpointercapture", e);
  }
  get onlostpointercapture() {
    return E.get(this, "onlostpointercapture");
  }
  set onlostpointercapture(e) {
    E.set(this, "onlostpointercapture", e);
  }
  get onpointercancel() {
    return E.get(this, "onpointercancel");
  }
  set onpointercancel(e) {
    E.set(this, "onpointercancel", e);
  }
  get onpointerdown() {
    return E.get(this, "onpointerdown");
  }
  set onpointerdown(e) {
    E.set(this, "onpointerdown", e);
  }
  get onpointerenter() {
    return E.get(this, "onpointerenter");
  }
  set onpointerenter(e) {
    E.set(this, "onpointerenter", e);
  }
  get onpointerleave() {
    return E.get(this, "onpointerleave");
  }
  set onpointerleave(e) {
    E.set(this, "onpointerleave", e);
  }
  get onpointermove() {
    return E.get(this, "onpointermove");
  }
  set onpointermove(e) {
    E.set(this, "onpointermove", e);
  }
  get onpointerout() {
    return E.get(this, "onpointerout");
  }
  set onpointerout(e) {
    E.set(this, "onpointerout", e);
  }
  get onpointerover() {
    return E.get(this, "onpointerover");
  }
  set onpointerover(e) {
    E.set(this, "onpointerover", e);
  }
  get onpointerup() {
    return E.get(this, "onpointerup");
  }
  set onpointerup(e) {
    E.set(this, "onpointerup", e);
  }
};
l(G, "HTMLElement");
var M4 = "template", rv = class extends G {
  constructor(e) {
    super(e, M4);
    const t = this.ownerDocument.createDocumentFragment();
    (this[Aa] = t)[yt] = this;
  }
  get content() {
    if (this.hasChildNodes() && !this[Aa].hasChildNodes())
      for (const e of this.childNodes)
        this[Aa].appendChild(e.cloneNode(!0));
    return this[Aa];
  }
};
l(rv, "HTMLTemplateElement");
At(M4, rv);
var N4 = class extends G {
  constructor(e, t = "html") {
    super(e, t);
  }
};
l(N4, "HTMLHtmlElement");
var { toString: xT } = G.prototype, ca = class extends G {
  get innerHTML() {
    return this.textContent;
  }
  set innerHTML(e) {
    this.textContent = e;
  }
  toString() {
    return xT.call(this.cloneNode()).replace(/></, `>${this.textContent}<`);
  }
};
l(ca, "TextElement");
var R4 = "script", ov = class extends ca {
  constructor(e, t = R4) {
    super(e, t);
  }
  get type() {
    return Y.get(this, "type");
  }
  set type(e) {
    Y.set(this, "type", e);
  }
  get src() {
    return Y.get(this, "src");
  }
  set src(e) {
    Y.set(this, "src", e);
  }
  get defer() {
    return Fe.get(this, "defer");
  }
  set defer(e) {
    Fe.set(this, "defer", e);
  }
  get crossOrigin() {
    return Y.get(this, "crossorigin");
  }
  set crossOrigin(e) {
    Y.set(this, "crossorigin", e);
  }
  get nomodule() {
    return Fe.get(this, "nomodule");
  }
  set nomodule(e) {
    Fe.set(this, "nomodule", e);
  }
  get referrerPolicy() {
    return Y.get(this, "referrerpolicy");
  }
  set referrerPolicy(e) {
    Y.set(this, "referrerpolicy", e);
  }
  get nonce() {
    return Y.get(this, "nonce");
  }
  set nonce(e) {
    Y.set(this, "nonce", e);
  }
  get async() {
    return Fe.get(this, "async");
  }
  set async(e) {
    Fe.set(this, "async", e);
  }
};
l(ov, "HTMLScriptElement");
At(R4, ov);
var L4 = class extends G {
  constructor(e, t = "frame") {
    super(e, t);
  }
};
l(L4, "HTMLFrameElement");
var D4 = "iframe", av = class extends G {
  constructor(e, t = D4) {
    super(e, t);
  }
  get src() {
    return Y.get(this, "src");
  }
  set src(e) {
    Y.set(this, "src", e);
  }
};
l(av, "HTMLIFrameElement");
At(D4, av);
var B4 = class extends G {
  constructor(e, t = "object") {
    super(e, t);
  }
};
l(B4, "HTMLObjectElement");
var O4 = class extends G {
  constructor(e, t = "head") {
    super(e, t);
  }
};
l(O4, "HTMLHeadElement");
var F4 = class extends G {
  constructor(e, t = "body") {
    super(e, t);
  }
};
l(F4, "HTMLBodyElement");
var ET = Wi(q3(), 1), V4 = "style", lv = class extends ca {
  constructor(e, t = V4) {
    super(e, t), this[Rs] = null;
  }
  get sheet() {
    const e = this[Rs];
    return e !== null ? e : this[Rs] = (0, ET.parse)(this.textContent);
  }
  get innerHTML() {
    return super.innerHTML || "";
  }
  set innerHTML(e) {
    super.textContent = e, this[Rs] = null;
  }
  get innerText() {
    return super.innerText || "";
  }
  set innerText(e) {
    super.textContent = e, this[Rs] = null;
  }
  get textContent() {
    return super.textContent || "";
  }
  set textContent(e) {
    super.textContent = e, this[Rs] = null;
  }
};
l(lv, "HTMLStyleElement");
At(V4, lv);
var U4 = class extends G {
  constructor(e, t = "time") {
    super(e, t);
  }
};
l(U4, "HTMLTimeElement");
var j4 = class extends G {
  constructor(e, t = "fieldset") {
    super(e, t);
  }
};
l(j4, "HTMLFieldSetElement");
var H4 = class extends G {
  constructor(e, t = "embed") {
    super(e, t);
  }
};
l(H4, "HTMLEmbedElement");
var W4 = class extends G {
  constructor(e, t = "hr") {
    super(e, t);
  }
};
l(W4, "HTMLHRElement");
var $4 = class extends G {
  constructor(e, t = "progress") {
    super(e, t);
  }
};
l($4, "HTMLProgressElement");
var G4 = class extends G {
  constructor(e, t = "p") {
    super(e, t);
  }
};
l(G4, "HTMLParagraphElement");
var q4 = class extends G {
  constructor(e, t = "table") {
    super(e, t);
  }
};
l(q4, "HTMLTableElement");
var z4 = class extends G {
  constructor(e, t = "frameset") {
    super(e, t);
  }
};
l(z4, "HTMLFrameSetElement");
var K4 = class extends G {
  constructor(e, t = "li") {
    super(e, t);
  }
};
l(K4, "HTMLLIElement");
var Y4 = class extends G {
  constructor(e, t = "base") {
    super(e, t);
  }
};
l(Y4, "HTMLBaseElement");
var X4 = class extends G {
  constructor(e, t = "datalist") {
    super(e, t);
  }
};
l(X4, "HTMLDataListElement");
var J4 = "input", uv = class extends G {
  constructor(e, t = J4) {
    super(e, t);
  }
  get autofocus() {
    return Fe.get(this, "autofocus") || -1;
  }
  set autofocus(e) {
    Fe.set(this, "autofocus", e);
  }
  get disabled() {
    return Fe.get(this, "disabled");
  }
  set disabled(e) {
    Fe.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get placeholder() {
    return this.getAttribute("placeholder");
  }
  set placeholder(e) {
    this.setAttribute("placeholder", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
};
l(uv, "HTMLInputElement");
At(J4, uv);
var Z4 = class extends G {
  constructor(e, t = "param") {
    super(e, t);
  }
};
l(Z4, "HTMLParamElement");
var Q4 = class extends G {
  constructor(e, t = "media") {
    super(e, t);
  }
};
l(Q4, "HTMLMediaElement");
var e6 = class extends G {
  constructor(e, t = "audio") {
    super(e, t);
  }
};
l(e6, "HTMLAudioElement");
var t6 = "h1", cv = class extends G {
  constructor(e, t = t6) {
    super(e, t);
  }
};
l(cv, "HTMLHeadingElement");
At([t6, "h2", "h3", "h4", "h5", "h6"], cv);
var i6 = class extends G {
  constructor(e, t = "dir") {
    super(e, t);
  }
};
l(i6, "HTMLDirectoryElement");
var n6 = class extends G {
  constructor(e, t = "quote") {
    super(e, t);
  }
};
l(n6, "HTMLQuoteElement");
var AT = Wi(z3(), 1), { createCanvas: kT } = AT.default, s6 = "canvas", hv = class extends G {
  constructor(e, t = s6) {
    super(e, t), this[fi] = kT(300, 150);
  }
  get width() {
    return this[fi].width;
  }
  set width(e) {
    Rn.set(this, "width", e), this[fi].width = e;
  }
  get height() {
    return this[fi].height;
  }
  set height(e) {
    Rn.set(this, "height", e), this[fi].height = e;
  }
  getContext(e) {
    return this[fi].getContext(e);
  }
  toDataURL(...e) {
    return this[fi].toDataURL(...e);
  }
};
l(hv, "HTMLCanvasElement");
At(s6, hv);
var r6 = class extends G {
  constructor(e, t = "legend") {
    super(e, t);
  }
};
l(r6, "HTMLLegendElement");
var o6 = class extends G {
  constructor(e, t = "option") {
    super(e, t);
  }
};
l(o6, "HTMLOptionElement");
var a6 = class extends G {
  constructor(e, t = "span") {
    super(e, t);
  }
};
l(a6, "HTMLSpanElement");
var l6 = class extends G {
  constructor(e, t = "meter") {
    super(e, t);
  }
};
l(l6, "HTMLMeterElement");
var u6 = class extends G {
  constructor(e, t = "video") {
    super(e, t);
  }
};
l(u6, "HTMLVideoElement");
var c6 = class extends G {
  constructor(e, t = "td") {
    super(e, t);
  }
};
l(c6, "HTMLTableCellElement");
var h6 = "title", dv = class extends ca {
  constructor(e, t = h6) {
    super(e, t);
  }
};
l(dv, "HTMLTitleElement");
At(h6, dv);
var d6 = class extends G {
  constructor(e, t = "output") {
    super(e, t);
  }
};
l(d6, "HTMLOutputElement");
var p6 = class extends G {
  constructor(e, t = "tr") {
    super(e, t);
  }
};
l(p6, "HTMLTableRowElement");
var f6 = class extends G {
  constructor(e, t = "data") {
    super(e, t);
  }
};
l(f6, "HTMLDataElement");
var m6 = class extends G {
  constructor(e, t = "menu") {
    super(e, t);
  }
};
l(m6, "HTMLMenuElement");
var v6 = "select", pv = class extends G {
  constructor(e, t = v6) {
    super(e, t);
  }
  get options() {
    let e = new gi(), { firstElementChild: t } = this;
    for (; t; )
      t.tagName === "OPTGROUP" ? e.push(...t.children) : e.push(t), t = t.nextElementSibling;
    return e;
  }
  get disabled() {
    return Fe.get(this, "disabled");
  }
  set disabled(e) {
    Fe.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
};
l(pv, "HTMLSelectElement");
At(v6, pv);
var g6 = class extends G {
  constructor(e, t = "br") {
    super(e, t);
  }
};
l(g6, "HTMLBRElement");
var y6 = "button", fv = class extends G {
  constructor(e, t = y6) {
    super(e, t);
  }
  get disabled() {
    return Fe.get(this, "disabled");
  }
  set disabled(e) {
    Fe.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
};
l(fv, "HTMLButtonElement");
At(y6, fv);
var _6 = class extends G {
  constructor(e, t = "map") {
    super(e, t);
  }
};
l(_6, "HTMLMapElement");
var b6 = class extends G {
  constructor(e, t = "optgroup") {
    super(e, t);
  }
};
l(b6, "HTMLOptGroupElement");
var w6 = class extends G {
  constructor(e, t = "dl") {
    super(e, t);
  }
};
l(w6, "HTMLDListElement");
var S6 = "textarea", mv = class extends ca {
  constructor(e, t = S6) {
    super(e, t);
  }
  get disabled() {
    return Fe.get(this, "disabled");
  }
  set disabled(e) {
    Fe.set(this, "disabled", e);
  }
  get name() {
    return this.getAttribute("name");
  }
  set name(e) {
    this.setAttribute("name", e);
  }
  get placeholder() {
    return this.getAttribute("placeholder");
  }
  set placeholder(e) {
    this.setAttribute("placeholder", e);
  }
  get type() {
    return this.getAttribute("type");
  }
  set type(e) {
    this.setAttribute("type", e);
  }
  get value() {
    return this.textContent;
  }
  set value(e) {
    this.textContent = e;
  }
};
l(mv, "HTMLTextAreaElement");
At(S6, mv);
var C6 = class extends G {
  constructor(e, t = "font") {
    super(e, t);
  }
};
l(C6, "HTMLFontElement");
var T6 = class extends G {
  constructor(e, t = "div") {
    super(e, t);
  }
};
l(T6, "HTMLDivElement");
var x6 = "link", vv = class extends G {
  constructor(e, t = x6) {
    super(e, t);
  }
  get disabled() {
    return Fe.get(this, "disabled");
  }
  set disabled(e) {
    Fe.set(this, "disabled", e);
  }
  get href() {
    return Y.get(this, "href");
  }
  set href(e) {
    Y.set(this, "href", e);
  }
  get hreflang() {
    return Y.get(this, "hreflang");
  }
  set hreflang(e) {
    Y.set(this, "hreflang", e);
  }
  get media() {
    return Y.get(this, "media");
  }
  set media(e) {
    Y.set(this, "media", e);
  }
  get rel() {
    return Y.get(this, "rel");
  }
  set rel(e) {
    Y.set(this, "rel", e);
  }
  get type() {
    return Y.get(this, "type");
  }
  set type(e) {
    Y.set(this, "type", e);
  }
};
l(vv, "HTMLLinkElement");
At(x6, vv);
var E6 = class extends G {
  constructor(e, t = "slot") {
    super(e, t);
  }
};
l(E6, "HTMLSlotElement");
var A6 = class extends G {
  constructor(e, t = "form") {
    super(e, t);
  }
};
l(A6, "HTMLFormElement");
var k6 = "img", Du = class extends G {
  constructor(e, t = k6) {
    super(e, t);
  }
  get alt() {
    return Y.get(this, "alt");
  }
  set alt(e) {
    Y.set(this, "alt", e);
  }
  get sizes() {
    return Y.get(this, "sizes");
  }
  set sizes(e) {
    Y.set(this, "sizes", e);
  }
  get src() {
    return Y.get(this, "src");
  }
  set src(e) {
    Y.set(this, "src", e);
  }
  get srcset() {
    return Y.get(this, "srcset");
  }
  set srcset(e) {
    Y.set(this, "srcset", e);
  }
  get title() {
    return Y.get(this, "title");
  }
  set title(e) {
    Y.set(this, "title", e);
  }
  get width() {
    return Rn.get(this, "width");
  }
  set width(e) {
    Rn.set(this, "width", e);
  }
  get height() {
    return Rn.get(this, "height");
  }
  set height(e) {
    Rn.set(this, "height", e);
  }
};
l(Du, "HTMLImageElement");
At(k6, Du);
var I6 = class extends G {
  constructor(e, t = "pre") {
    super(e, t);
  }
};
l(I6, "HTMLPreElement");
var P6 = class extends G {
  constructor(e, t = "ul") {
    super(e, t);
  }
};
l(P6, "HTMLUListElement");
var M6 = class extends G {
  constructor(e, t = "meta") {
    super(e, t);
  }
};
l(M6, "HTMLMetaElement");
var N6 = class extends G {
  constructor(e, t = "picture") {
    super(e, t);
  }
};
l(N6, "HTMLPictureElement");
var R6 = class extends G {
  constructor(e, t = "area") {
    super(e, t);
  }
};
l(R6, "HTMLAreaElement");
var L6 = class extends G {
  constructor(e, t = "ol") {
    super(e, t);
  }
};
l(L6, "HTMLOListElement");
var D6 = class extends G {
  constructor(e, t = "caption") {
    super(e, t);
  }
};
l(D6, "HTMLTableCaptionElement");
var B6 = "a", gv = class extends G {
  constructor(e, t = B6) {
    super(e, t);
  }
  get href() {
    return encodeURI(Y.get(this, "href"));
  }
  set href(e) {
    Y.set(this, "href", decodeURI(e));
  }
  get download() {
    return encodeURI(Y.get(this, "download"));
  }
  set download(e) {
    Y.set(this, "download", decodeURI(e));
  }
  get target() {
    return Y.get(this, "target");
  }
  set target(e) {
    Y.set(this, "target", e);
  }
  get type() {
    return Y.get(this, "type");
  }
  set type(e) {
    Y.set(this, "type", e);
  }
};
l(gv, "HTMLAnchorElement");
At(B6, gv);
var O6 = class extends G {
  constructor(e, t = "label") {
    super(e, t);
  }
};
l(O6, "HTMLLabelElement");
var F6 = class extends G {
  constructor(e, t = "unknown") {
    super(e, t);
  }
};
l(F6, "HTMLUnknownElement");
var V6 = class extends G {
  constructor(e, t = "mod") {
    super(e, t);
  }
};
l(V6, "HTMLModElement");
var U6 = class extends G {
  constructor(e, t = "details") {
    super(e, t);
  }
};
l(U6, "HTMLDetailsElement");
var j6 = "source", yv = class extends G {
  constructor(e, t = j6) {
    super(e, t);
  }
  get src() {
    return Y.get(this, "src");
  }
  set src(e) {
    Y.set(this, "src", e);
  }
  get srcset() {
    return Y.get(this, "srcset");
  }
  set srcset(e) {
    Y.set(this, "srcset", e);
  }
  get sizes() {
    return Y.get(this, "sizes");
  }
  set sizes(e) {
    Y.set(this, "sizes", e);
  }
  get type() {
    return Y.get(this, "type");
  }
  set type(e) {
    Y.set(this, "type", e);
  }
};
l(yv, "HTMLSourceElement");
At(j6, yv);
var H6 = class extends G {
  constructor(e, t = "track") {
    super(e, t);
  }
};
l(H6, "HTMLTrackElement");
var W6 = class extends G {
  constructor(e, t = "marquee") {
    super(e, t);
  }
};
l(W6, "HTMLMarqueeElement");
var IT = {
  HTMLElement: G,
  HTMLTemplateElement: rv,
  HTMLHtmlElement: N4,
  HTMLScriptElement: ov,
  HTMLFrameElement: L4,
  HTMLIFrameElement: av,
  HTMLObjectElement: B4,
  HTMLHeadElement: O4,
  HTMLBodyElement: F4,
  HTMLStyleElement: lv,
  HTMLTimeElement: U4,
  HTMLFieldSetElement: j4,
  HTMLEmbedElement: H4,
  HTMLHRElement: W4,
  HTMLProgressElement: $4,
  HTMLParagraphElement: G4,
  HTMLTableElement: q4,
  HTMLFrameSetElement: z4,
  HTMLLIElement: K4,
  HTMLBaseElement: Y4,
  HTMLDataListElement: X4,
  HTMLInputElement: uv,
  HTMLParamElement: Z4,
  HTMLMediaElement: Q4,
  HTMLAudioElement: e6,
  HTMLHeadingElement: cv,
  HTMLDirectoryElement: i6,
  HTMLQuoteElement: n6,
  HTMLCanvasElement: hv,
  HTMLLegendElement: r6,
  HTMLOptionElement: o6,
  HTMLSpanElement: a6,
  HTMLMeterElement: l6,
  HTMLVideoElement: u6,
  HTMLTableCellElement: c6,
  HTMLTitleElement: dv,
  HTMLOutputElement: d6,
  HTMLTableRowElement: p6,
  HTMLDataElement: f6,
  HTMLMenuElement: m6,
  HTMLSelectElement: pv,
  HTMLBRElement: g6,
  HTMLButtonElement: fv,
  HTMLMapElement: _6,
  HTMLOptGroupElement: b6,
  HTMLDListElement: w6,
  HTMLTextAreaElement: mv,
  HTMLFontElement: C6,
  HTMLDivElement: T6,
  HTMLLinkElement: vv,
  HTMLSlotElement: E6,
  HTMLFormElement: A6,
  HTMLImageElement: Du,
  HTMLPreElement: I6,
  HTMLUListElement: P6,
  HTMLMetaElement: M6,
  HTMLPictureElement: N6,
  HTMLAreaElement: R6,
  HTMLOListElement: L6,
  HTMLTableCaptionElement: D6,
  HTMLAnchorElement: gv,
  HTMLLabelElement: O6,
  HTMLUnknownElement: F6,
  HTMLModElement: V6,
  HTMLDetailsElement: U6,
  HTMLSourceElement: yv,
  HTMLTrackElement: H6,
  HTMLMarqueeElement: W6
}, Pa = { test: () => !0 }, PT = {
  "text/html": {
    docType: "<!DOCTYPE html>",
    ignoreCase: !0,
    voidElements: /^(?:area|base|br|col|embed|hr|img|input|keygen|link|menuitem|meta|param|source|track|wbr)$/i
  },
  "image/svg+xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: Pa
  },
  "text/xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: Pa
  },
  "application/xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: Pa
  },
  "application/xhtml+xml": {
    docType: '<?xml version="1.0" encoding="utf-8"?>',
    ignoreCase: !1,
    voidElements: Pa
  }
}, $6 = typeof CustomEvent == "function" ? CustomEvent : /* @__PURE__ */ l(class extends Un {
  constructor(t, i = {}) {
    super(t, i), this.detail = i.detail;
  }
}, "CustomEvent"), G6 = class extends Un {
  constructor(e, t = {}) {
    super(e, t), this.inputType = t.inputType, this.data = t.data, this.dataTransfer = t.dataTransfer, this.isComposing = t.isComposing || !1, this.ranges = t.ranges;
  }
};
l(G6, "InputEvent");
var MT = /* @__PURE__ */ l((e) => /* @__PURE__ */ l(class extends Du {
  constructor(i, n) {
    switch (super(e), arguments.length) {
      case 1:
        this.height = i, this.width = i;
        break;
      case 2:
        this.height = n, this.width = i;
        break;
    }
  }
}, "Image"), "ImageClass"), p2 = /* @__PURE__ */ l(({ [Lt]: e, [ne]: t }, i = null) => {
  Ub(e[ct], t[W]);
  do {
    const n = Kt(e), s = n === t ? n : n[W];
    i ? i.insertBefore(e, i[ne]) : e.remove(), e = s;
  } while (e !== t);
}, "deleteContents"), _v = class {
  constructor() {
    this[Lt] = null, this[ne] = null, this.commonAncestorContainer = null;
  }
  insertNode(e) {
    this[ne].parentNode.insertBefore(e, this[Lt]);
  }
  selectNode(e) {
    this[Lt] = e, this[ne] = Kt(e);
  }
  surroundContents(e) {
    e.replaceChildren(this.extractContents());
  }
  setStartBefore(e) {
    this[Lt] = e;
  }
  setStartAfter(e) {
    this[Lt] = e.nextSibling;
  }
  setEndBefore(e) {
    this[ne] = Kt(e.previousSibling);
  }
  setEndAfter(e) {
    this[ne] = Kt(e);
  }
  cloneContents() {
    let { [Lt]: e, [ne]: t } = this;
    const i = e.ownerDocument.createDocumentFragment();
    for (; e !== t; )
      i.insertBefore(e.cloneNode(!0), i[ne]), e = Kt(e), e !== t && (e = e[W]);
    return i;
  }
  deleteContents() {
    p2(this);
  }
  extractContents() {
    const e = this[Lt].ownerDocument.createDocumentFragment();
    return p2(this, e), e;
  }
  createContextualFragment(e) {
    const t = this.commonAncestorContainer.createElement("template");
    return t.innerHTML = e, this.selectNode(t.content), t.content;
  }
  cloneRange() {
    const e = new _v();
    return e[Lt] = this[Lt], e[ne] = this[ne], e;
  }
};
l(_v, "Range");
var NT = /* @__PURE__ */ l(({ nodeType: e }, t) => {
  switch (e) {
    case Re:
      return t & bC;
    case _t:
      return t & wC;
    case an:
      return t & SC;
  }
  return 0;
}, "isOK"), q6 = class {
  constructor(e, t = _C) {
    this.root = e, this.currentNode = e, this.whatToShow = t;
    let { [W]: i, [ne]: n } = e;
    if (e.nodeType === In) {
      const { documentElement: r } = e;
      i = r, n = r[ne];
    }
    const s = [];
    for (; i !== n; )
      NT(i, t) && s.push(i), i = i[W];
    this[yt] = { i: 0, nodes: s };
  }
  nextNode() {
    const e = this[yt];
    return this.currentNode = e.i < e.nodes.length ? e.nodes[e.i++] : null, this.currentNode;
  }
};
l(q6, "TreeWalker");
var f2 = /* @__PURE__ */ l((e, t, i) => {
  let { [W]: n, [ne]: s } = t;
  return e.call({ ownerDocument: t, [W]: n, [ne]: s }, i);
}, "query"), z6 = AC({}, TT, IT, {
  CustomEvent: $6,
  Event: Un,
  EventTarget: gu,
  InputEvent: G6,
  NamedNodeMap: sv,
  NodeList: gi
}), Ma = /* @__PURE__ */ new WeakMap(), jn = class extends wu {
  constructor(e) {
    super(null, "#document", In), this[pi] = { active: !1, registry: null }, this[Pn] = { active: !1, class: null }, this[gr] = PT[e], this[Gn] = null, this[oc] = null, this[Za] = null, this[fi] = null, this[Po] = null;
  }
  get defaultView() {
    return Ma.has(this) || Ma.set(this, new Proxy(globalThis, {
      set: (e, t, i) => {
        switch (t) {
          case "addEventListener":
          case "removeEventListener":
          case "dispatchEvent":
            this[Nr][t] = i;
            break;
          default:
            e[t] = i;
            break;
        }
        return !0;
      },
      get: (e, t) => {
        switch (t) {
          case "addEventListener":
          case "removeEventListener":
          case "dispatchEvent":
            if (!this[Nr]) {
              const i = this[Nr] = new gu();
              i.dispatchEvent = i.dispatchEvent.bind(i), i.addEventListener = i.addEventListener.bind(i), i.removeEventListener = i.removeEventListener.bind(i);
            }
            return this[Nr][t];
          case "document":
            return this;
          case "navigator":
            return {
              userAgent: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.150 Safari/537.36"
            };
          case "window":
            return Ma.get(this);
          case "customElements":
            return this[pi].registry || (this[pi] = new Hb(this)), this[pi];
          case "performance":
            return BC.performance;
          case "DOMParser":
            return this[oc];
          case "Image":
            return this[fi] || (this[fi] = MT(this)), this[fi];
          case "MutationObserver":
            return this[Pn].class || (this[Pn] = new Xb(this)), this[Pn].class;
        }
        return this[Za] && this[Za][t] || z6[t] || e[t];
      }
    })), Ma.get(this);
  }
  get doctype() {
    const e = this[Gn];
    if (e)
      return e;
    const { firstChild: t } = this;
    return t && t.nodeType === hr ? this[Gn] = t : null;
  }
  set doctype(e) {
    if (/^([a-z:]+)(\s+system|\s+public(\s+"([^"]+)")?)?(\s+"([^"]+)")?/i.test(e)) {
      const { $1: t, $4: i, $6: n } = RegExp;
      this[Gn] = new dr(this, t, i, n), fu(this, this[Gn], this[W]);
    }
  }
  get documentElement() {
    return this.firstElementChild;
  }
  get isConnected() {
    return !0;
  }
  _getParent() {
    return this[Nr];
  }
  createAttribute(e) {
    return new Ts(this, e);
  }
  createComment(e) {
    return new ua(this, e);
  }
  createDocumentFragment() {
    return new Su(this);
  }
  createDocumentType(e, t, i) {
    return new dr(this, e, t, i);
  }
  createElement(e) {
    return new br(this, e);
  }
  createRange() {
    const e = new _v();
    return e.commonAncestorContainer = this, e;
  }
  createTextNode(e) {
    return new xs(this, e);
  }
  createTreeWalker(e, t = -1) {
    return new q6(e, t);
  }
  createNodeIterator(e, t = -1) {
    return this.createTreeWalker(e, t);
  }
  createEvent(e) {
    const t = kC(e === "Event" ? new Un("") : new $6(""));
    return t.initEvent = t.initCustomEvent = (i, n = !1, s = !1, r) => {
      IC(t, {
        type: { value: i },
        canBubble: { value: n },
        cancelable: { value: s },
        detail: { value: r }
      });
    }, t;
  }
  cloneNode(e = !1) {
    const {
      constructor: t,
      [pi]: i,
      [Gn]: n
    } = this, s = new t();
    if (s[pi] = i, e) {
      const r = s[ne], { childNodes: a } = this;
      for (let { length: u } = a, c = 0; c < u; c++)
        s.insertBefore(a[c].cloneNode(!0), r);
      n && (s[Gn] = a[0]);
    }
    return s;
  }
  importNode(e) {
    const t = 1 < arguments.length && !!arguments[1], i = e.cloneNode(t), { [pi]: n } = this, { active: s } = n, r = /* @__PURE__ */ l((a) => {
      const { ownerDocument: u, nodeType: c } = a;
      a.ownerDocument = this, s && u !== this && c === Re && n.upgrade(a);
    }, "upgrade");
    if (r(i), t)
      switch (i.nodeType) {
        case Re:
        case Dn: {
          let { [W]: a, [ne]: u } = i;
          for (; a !== u; )
            a.nodeType === Re && r(a), a = a[W];
          break;
        }
      }
    return i;
  }
  toString() {
    return this.childNodes.join("");
  }
  querySelector(e) {
    return f2(super.querySelector, this, e);
  }
  querySelectorAll(e) {
    return f2(super.querySelectorAll, this, e);
  }
  getElementsByTagNameNS(e, t) {
    return this.getElementsByTagName(t);
  }
  createAttributeNS(e, t) {
    return this.createAttribute(t);
  }
  createElementNS(e, t, i) {
    return e === Vl ? new Tu(this, t, null) : this.createElement(t, i);
  }
};
l(jn, "Document");
Vt(z6.Document = /* @__PURE__ */ l(function() {
  oi();
}, "Document"), jn).prototype = jn.prototype;
var RT = /* @__PURE__ */ l((e, t, i, n) => {
  if (!t && jl.has(i)) {
    const a = jl.get(i);
    return new a(e, i);
  }
  const { [pi]: { active: s, registry: r } } = e;
  if (s) {
    const a = t ? n.is : i;
    if (r.has(a)) {
      const { Class: u } = r.get(a), c = new u(e, i);
      return bs.set(c, { connected: !1 }), c;
    }
  }
  return new G(e, i);
}, "createHTMLElement"), K6 = class extends jn {
  constructor() {
    super("text/html");
  }
  get all() {
    const e = new gi();
    let { [W]: t, [ne]: i } = this;
    for (; t !== i; ) {
      switch (t.nodeType) {
        case Re:
          e.push(t);
          break;
      }
      t = t[W];
    }
    return e;
  }
  get head() {
    const { documentElement: e } = this;
    let { firstElementChild: t } = e;
    return (!t || t.tagName !== "HEAD") && (t = this.createElement("head"), e.prepend(t)), t;
  }
  get body() {
    const { head: e } = this;
    let { nextElementSibling: t } = e;
    return (!t || t.tagName !== "BODY") && (t = this.createElement("body"), e.after(t)), t;
  }
  get title() {
    const { head: e } = this;
    let t = e.getElementsByTagName("title").shift();
    return t ? t.textContent : "";
  }
  set title(e) {
    const { head: t } = this;
    let i = t.getElementsByTagName("title").shift();
    i ? i.textContent = e : t.insertBefore(this.createElement("title"), t.firstChild).textContent = e;
  }
  createElement(e, t) {
    const i = !!(t && t.is), n = RT(this, i, e, t);
    return i && n.setAttribute("is", t.is), n;
  }
};
l(K6, "HTMLDocument");
var Y6 = class extends jn {
  constructor() {
    super("image/svg+xml");
  }
  toString() {
    return this[gr].docType + super.toString();
  }
};
l(Y6, "SVGDocument");
var X6 = class extends jn {
  constructor() {
    super("text/xml");
  }
  toString() {
    return this[gr].docType + super.toString();
  }
};
l(X6, "XMLDocument");
var bv = class {
  parseFromString(e, t, i = null) {
    let n = !1, s;
    return t === "text/html" ? (n = !0, s = new K6()) : t === "image/svg+xml" ? s = new Y6() : s = new X6(), s[oc] = bv, i && (s[Za] = i), e ? Wb(s, n, e) : s;
  }
};
l(bv, "DOMParser");
function J6() {
  oi();
}
l(J6, "Document");
Vt(J6, jn).prototype = jn.prototype;
var Ei = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, qn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, we = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, LT = function(e) {
  if (!Symbol.asyncIterator)
    throw new TypeError("Symbol.asyncIterator is not defined.");
  var t = e[Symbol.asyncIterator], i;
  return t ? t.call(e) : (e = typeof __values == "function" ? __values(e) : e[Symbol.iterator](), i = {}, n("next"), n("throw"), n("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function n(r) {
    i[r] = e[r] && function(a) {
      return new Promise(function(u, c) {
        a = e[r](a), s(u, c, a.done, a.value);
      });
    };
  }
  function s(r, a, u, c) {
    Promise.resolve(c).then(function(h) {
      r({ value: h, done: u });
    }, a);
  }
}, vt, ol, Qt, ar, Ji, ro, oo, ei, Z6, m2, v2, Q6 = class {
  constructor(e, t, i, n) {
    var s, r, a, u, c, h, p, m, b, C, k, D, I, $, O, F, K, M, v, H, ce, ae, Q, Xe, J, ee, ve, Je, Ce, nt, De;
    vt.add(this), ol.set(this, void 0), Qt.set(this, void 0), ar.set(this, void 0), Ji.set(this, void 0), ro.set(this, void 0), oo.set(this, void 0), qn(this, Qt, t, "f"), qn(this, ar, i, "f"), qn(this, Ji, n, "f");
    const he = y.parseResponse(e[0].data), wt = !((s = e == null ? void 0 : e[1]) === null || s === void 0) && s.data ? y.parseResponse(e[1].data) : void 0;
    if (qn(this, ol, [he, wt], "f"), ((r = he.playability_status) === null || r === void 0 ? void 0 : r.status) === "ERROR")
      throw new x("This video is unavailable", he.playability_status);
    if (he.microformat && !(!((a = he.microformat) === null || a === void 0) && a.is(Hr, ea)))
      throw new x("Invalid microformat", he.microformat);
    this.basic_info = Object.assign(Object.assign(Object.assign({}, he.video_details), {
      embed: !((u = he.microformat) === null || u === void 0) && u.is(Hr) ? (c = he.microformat) === null || c === void 0 ? void 0 : c.embed : null,
      channel: !((h = he.microformat) === null || h === void 0) && h.is(Hr) ? (p = he.microformat) === null || p === void 0 ? void 0 : p.channel : null,
      is_unlisted: (m = he.microformat) === null || m === void 0 ? void 0 : m.is_unlisted,
      is_family_safe: (b = he.microformat) === null || b === void 0 ? void 0 : b.is_family_safe,
      has_ypc_metadata: !((C = he.microformat) === null || C === void 0) && C.is(Hr) ? (k = he.microformat) === null || k === void 0 ? void 0 : k.has_ypc_metadata : null
    }), { like_count: void 0, is_liked: void 0, is_disliked: void 0 }), this.streaming_data = he.streaming_data, this.playability_status = he.playability_status, this.annotations = he.annotations, this.storyboards = he.storyboards, this.endscreen = he.endscreen, this.captions = he.captions, this.cards = he.cards, qn(this, oo, he.playback_tracking, "f");
    const Ut = wt == null ? void 0 : wt.contents.item().as(y_), ai = Ut == null ? void 0 : Ut.results, ln = Ut == null ? void 0 : Ut.secondary_results;
    if (ai && ln) {
      this.primary_info = (D = ai.get({ type: "VideoPrimaryInfo" })) === null || D === void 0 ? void 0 : D.as(S_), this.secondary_info = (I = ai.get({ type: "VideoSecondaryInfo" })) === null || I === void 0 ? void 0 : I.as(C_), this.merchandise = ($ = ai.get({ type: "MerchandiseShelf" })) === null || $ === void 0 ? void 0 : $.as(Ay), this.related_chip_cloud = (F = (O = ln.get({ type: "RelatedChipCloud" })) === null || O === void 0 ? void 0 : O.as(o_)) === null || F === void 0 ? void 0 : F.content.item().as(Oh), this.watch_next_feed = (M = (K = ln.get({ type: "ItemSection" })) === null || K === void 0 ? void 0 : K.as(Hi)) === null || M === void 0 ? void 0 : M.contents, this.watch_next_feed && Array.isArray(this.watch_next_feed) && qn(this, ro, (v = this.watch_next_feed.pop()) === null || v === void 0 ? void 0 : v.as(sn), "f"), this.player_overlays = wt == null ? void 0 : wt.player_overlays.item().as(Nf);
      const kt = (ce = (H = this.primary_info) === null || H === void 0 ? void 0 : H.menu) === null || ce === void 0 ? void 0 : ce.top_level_buttons.firstOfType(Wr);
      this.basic_info.like_count = (Q = (ae = kt == null ? void 0 : kt.like_button) === null || ae === void 0 ? void 0 : ae.as(gt)) === null || Q === void 0 ? void 0 : Q.like_count, this.basic_info.is_liked = (J = (Xe = kt == null ? void 0 : kt.like_button) === null || Xe === void 0 ? void 0 : Xe.as(gt)) === null || J === void 0 ? void 0 : J.is_toggled, this.basic_info.is_disliked = (ve = (ee = kt == null ? void 0 : kt.dislike_button) === null || ee === void 0 ? void 0 : ee.as(gt)) === null || ve === void 0 ? void 0 : ve.is_toggled;
      const Es = (Je = ai.get({ target_id: "comments-entry-point" })) === null || Je === void 0 ? void 0 : Je.as(Hi);
      this.comments_entry_point_header = (nt = (Ce = Es == null ? void 0 : Es.contents) === null || Ce === void 0 ? void 0 : Ce.get({ type: "CommentsEntryPointHeader" })) === null || nt === void 0 ? void 0 : nt.as(Kg), this.livechat = (De = wt == null ? void 0 : wt.contents_memo.getType(vy)) === null || De === void 0 ? void 0 : De[0];
    }
  }
  selectFilter(e) {
    var t, i, n, s;
    return Ei(this, void 0, void 0, function* () {
      if (!this.filters.includes(e))
        throw new x("Invalid filter", { available_filters: this.filters });
      const r = (i = (t = this.related_chip_cloud) === null || t === void 0 ? void 0 : t.chips) === null || i === void 0 ? void 0 : i.get({ text: e });
      if (r != null && r.is_selected)
        return this;
      const a = yield (n = r == null ? void 0 : r.endpoint) === null || n === void 0 ? void 0 : n.call(we(this, Qt, "f"), void 0, !0), u = (s = a == null ? void 0 : a.on_response_received_endpoints) === null || s === void 0 ? void 0 : s.get({ target_id: "watch-next-feed" });
      return this.watch_next_feed = u == null ? void 0 : u.contents, this;
    });
  }
  addToWatchHistory() {
    return Ei(this, void 0, void 0, function* () {
      if (!we(this, oo, "f"))
        throw new x("Playback tracking not available");
      const e = {
        cpn: we(this, Ji, "f"),
        fmt: 251,
        rtn: 0,
        rt: 0
      }, t = we(this, oo, "f").videostats_playback_url.replace("https://s.", "https://www.");
      return yield we(this, Qt, "f").stats(t, {
        client_name: pe.CLIENTS.WEB.NAME,
        client_version: pe.CLIENTS.WEB.VERSION
      }, e);
    });
  }
  getWatchNextContinuation() {
    var e, t, i, n;
    return Ei(this, void 0, void 0, function* () {
      const s = yield (e = we(this, ro, "f")) === null || e === void 0 ? void 0 : e.endpoint.call(we(this, Qt, "f"), void 0, !0), r = (t = s == null ? void 0 : s.on_response_received_endpoints) === null || t === void 0 ? void 0 : t.get({ type: "appendContinuationItemsAction" });
      if (!r)
        throw new x("Continuation not found");
      return this.watch_next_feed = r == null ? void 0 : r.contents, qn(this, ro, (n = (i = this.watch_next_feed) === null || i === void 0 ? void 0 : i.pop()) === null || n === void 0 ? void 0 : n.as(sn), "f"), this;
    });
  }
  like() {
    var e, t, i;
    return Ei(this, void 0, void 0, function* () {
      const n = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(Wr), s = (i = n == null ? void 0 : n.like_button) === null || i === void 0 ? void 0 : i.as(gt);
      if (!s)
        throw new x("Like button not found", { video_id: this.basic_info.id });
      if (s.is_toggled)
        throw new x("This video is already liked", { video_id: this.basic_info.id });
      return yield s.endpoint.call(we(this, Qt, "f"));
    });
  }
  dislike() {
    var e, t, i;
    return Ei(this, void 0, void 0, function* () {
      const n = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(Wr), s = (i = n == null ? void 0 : n.dislike_button) === null || i === void 0 ? void 0 : i.as(gt);
      if (!s)
        throw new x("Dislike button not found", { video_id: this.basic_info.id });
      if (s.is_toggled)
        throw new x("This video is already disliked", { video_id: this.basic_info.id });
      return yield s.endpoint.call(we(this, Qt, "f"));
    });
  }
  removeLike() {
    var e, t, i, n;
    return Ei(this, void 0, void 0, function* () {
      let s;
      const r = (t = (e = this.primary_info) === null || e === void 0 ? void 0 : e.menu) === null || t === void 0 ? void 0 : t.top_level_buttons.firstOfType(Wr), a = (i = r == null ? void 0 : r.like_button) === null || i === void 0 ? void 0 : i.as(gt), u = (n = r == null ? void 0 : r.dislike_button) === null || n === void 0 ? void 0 : n.as(gt);
      if (a != null && a.is_toggled ? s = a : u != null && u.is_toggled && (s = u), !s)
        throw new x("This video is not liked/disliked", { video_id: this.basic_info.id });
      return yield s.toggled_endpoint.call(we(this, Qt, "f"));
    });
  }
  getLiveChat() {
    if (!this.livechat)
      throw new x("Live Chat is not available", { video_id: this.basic_info.id });
    return new Z8(this);
  }
  get filters() {
    var e, t;
    return ((t = (e = this.related_chip_cloud) === null || e === void 0 ? void 0 : e.chips) === null || t === void 0 ? void 0 : t.map((i) => i.text.toString())) || [];
  }
  get actions() {
    return we(this, Qt, "f");
  }
  get cpn() {
    return we(this, Ji, "f");
  }
  get page() {
    return we(this, ol, "f");
  }
  get music_tracks() {
    return [];
  }
  chooseFormat(e) {
    if (!this.streaming_data)
      throw new x("Streaming data not available", { video_id: this.basic_info.id });
    const t = [
      ...this.streaming_data.formats || [],
      ...this.streaming_data.adaptive_formats || []
    ], i = e.type ? e.type.includes("audio") : !0, n = e.type ? e.type.includes("video") : !0, s = e.quality || "360p";
    let r = -1;
    const a = ["best", "bestefficiency"].includes(s), u = s !== "best";
    let c = t.filter((h) => i && !h.has_audio || n && !h.has_video || e.format !== "any" && !h.mime_type.includes(e.format || "mp4") || !a && h.quality_label !== s ? !1 : (r < h.width && (r = h.width), !0));
    if (!c.length)
      throw new x("No matching formats found", {
        options: e
      });
    if (a && n && (c = c.filter((h) => h.width === r)), i && !n) {
      const h = c.filter((p) => !p.has_video);
      h.length > 0 && (c = h);
    }
    return u ? c.sort((h, p) => h.bitrate - p.bitrate) : c.sort((h, p) => p.bitrate - h.bitrate), c[0];
  }
  toDash(e = (t) => t) {
    if (!this.streaming_data)
      throw new x("Streaming data not available", { video_id: this.basic_info.id });
    const { adaptive_formats: t } = this.streaming_data, i = t[0].approx_duration_ms / 1e3, n = new bv().parseFromString("", "text/xml"), s = n.createElement("Period");
    return n.appendChild(we(this, vt, "m", ei).call(this, n, "MPD", {
      xmlns: "urn:mpeg:dash:schema:mpd:2011",
      minBufferTime: "PT1.500S",
      profiles: "urn:mpeg:dash:profile:isoff-main:2011",
      type: "static",
      mediaPresentationDuration: `PT${i}S`,
      "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
      "xsi:schemaLocation": "urn:mpeg:dash:schema:mpd:2011 http://standards.iso.org/ittf/PubliclyAvailableStandards/MPEG-DASH_schema_files/DASH-MPD.xsd"
    }, [
      s
    ])), we(this, vt, "m", Z6).call(this, n, s, t, e), `${n}`;
  }
  download(e = {}) {
    var t, i;
    return Ei(this, void 0, void 0, function* () {
      if (((t = this.playability_status) === null || t === void 0 ? void 0 : t.status) === "UNPLAYABLE")
        throw new x("Video is unplayable", { video: this, error_type: "UNPLAYABLE" });
      if (((i = this.playability_status) === null || i === void 0 ? void 0 : i.status) === "LOGIN_REQUIRED")
        throw new x("Video is login required", { video: this, error_type: "LOGIN_REQUIRED" });
      if (!this.streaming_data)
        throw new x("Streaming data not available.", { video: this, error_type: "NO_STREAMING_DATA" });
      const n = Object.assign({ quality: "360p", type: "video+audio", format: "mp4", range: void 0 }, e), s = this.chooseFormat(n), r = s.decipher(we(this, ar, "f"));
      if (n.type === "video+audio" && !e.range) {
        const b = yield we(this, Qt, "f").session.http.fetch_function(`${r}&cpn=${we(this, Ji, "f")}`, {
          method: "GET",
          headers: pe.STREAM_HEADERS,
          redirect: "follow"
        });
        if (!b.ok)
          throw new x("The server responded with a non 2xx status code", { video: this, error_type: "FETCH_FAILED", response: b });
        const C = b.body;
        if (!C)
          throw new x("Could not get ReadableStream from fetch Response.", { video: this, error_type: "FETCH_FAILED", response: b });
        return C;
      }
      const a = 1048576 * 10;
      let u = e.range ? e.range.start : 0, c = e.range ? e.range.end : a, h = !1, p;
      return new ReadableStream({
        start() {
        },
        pull: (b) => Ei(this, void 0, void 0, function* () {
          if (h) {
            b.close();
            return;
          }
          return (c >= s.content_length || e.range) && (h = !0), new Promise((C, k) => Ei(this, void 0, void 0, function* () {
            var D, I;
            try {
              p = new AbortController();
              const F = yield we(this, Qt, "f").session.http.fetch_function(`${r}&cpn=${we(this, Ji, "f")}&range=${u}-${c || ""}`, {
                method: "GET",
                headers: Object.assign({}, pe.STREAM_HEADERS),
                signal: p.signal
              }), K = F.body;
              if (!K)
                throw new x("Could not get ReadableStream from fetch Response.", { video: this, error_type: "FETCH_FAILED", response: F });
              try {
                for (var $ = LT(Bc(K)), O; O = yield $.next(), !O.done; ) {
                  const M = O.value;
                  b.enqueue(M);
                }
              } catch (M) {
                D = { error: M };
              } finally {
                try {
                  O && !O.done && (I = $.return) && (yield I.call($));
                } finally {
                  if (D)
                    throw D.error;
                }
              }
              u = c + 1, c += a, C();
              return;
            } catch (F) {
              k(F);
            }
          }));
        }),
        cancel(b) {
          return Ei(this, void 0, void 0, function* () {
            p.abort(b);
          });
        }
      }, {
        highWaterMark: 1,
        size(b) {
          return b.byteLength;
        }
      });
    });
  }
};
l(Q6, "VideoInfo");
ol = /* @__PURE__ */ new WeakMap(), Qt = /* @__PURE__ */ new WeakMap(), ar = /* @__PURE__ */ new WeakMap(), Ji = /* @__PURE__ */ new WeakMap(), ro = /* @__PURE__ */ new WeakMap(), oo = /* @__PURE__ */ new WeakMap(), vt = /* @__PURE__ */ new WeakSet(), ei = /* @__PURE__ */ l(function(t, i, n, s = []) {
  const r = t.createElement(i);
  for (const [a, u] of Object.entries(n))
    r.setAttribute(a, u);
  for (const a of s)
    typeof a > "u" || r.appendChild(a);
  return r;
}, "_VideoInfo_el"), Z6 = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = [], a = [[]];
  n.forEach((u) => {
    if (!u.index_range || !u.init_range)
      return;
    const c = u.mime_type, h = r.indexOf(c);
    h > -1 ? a[h].push(u) : (r.push(c), a.push([]), a[r.length - 1].push(u));
  });
  for (let u = 0; u < r.length; u++) {
    const c = we(this, vt, "m", ei).call(this, t, "AdaptationSet", {
      id: `${u}`,
      mimeType: r[u].split(";")[0],
      startWithSAP: "1",
      subsegmentAlignment: "true"
    });
    i.appendChild(c), a[u].forEach((h) => {
      h.has_video ? we(this, vt, "m", m2).call(this, t, c, h, s) : we(this, vt, "m", v2).call(this, t, c, h, s);
    });
  }
}, "_VideoInfo_generateAdaptationSet"), m2 = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = Ri(n.mime_type, 'codecs="', '"');
  if (!n.index_range || !n.init_range)
    throw new x("Index and init ranges not available", { format: n });
  const a = new URL(n.decipher(we(this, ar, "f")));
  a.searchParams.set("cpn", we(this, Ji, "f")), i.appendChild(we(this, vt, "m", ei).call(this, t, "Representation", {
    id: n.itag,
    codecs: r,
    bandwidth: n.bitrate,
    width: n.width,
    height: n.height,
    maxPlayoutRate: "1",
    frameRate: n.fps
  }, [
    we(this, vt, "m", ei).call(this, t, "BaseURL", {}, [
      t.createTextNode(s(a).toString())
    ]),
    we(this, vt, "m", ei).call(this, t, "SegmentBase", {
      indexRange: `${n.index_range.start}-${n.index_range.end}`
    }, [
      we(this, vt, "m", ei).call(this, t, "Initialization", {
        range: `${n.init_range.start}-${n.init_range.end}`
      })
    ])
  ]));
}, "_VideoInfo_generateRepresentationVideo"), v2 = /* @__PURE__ */ l(function(t, i, n, s) {
  const r = Ri(n.mime_type, 'codecs="', '"');
  if (!n.index_range || !n.init_range)
    throw new x("Index and init ranges not available", { format: n });
  const a = new URL(n.decipher(we(this, ar, "f")));
  a.searchParams.set("cpn", we(this, Ji, "f")), i.appendChild(we(this, vt, "m", ei).call(this, t, "Representation", {
    id: n.itag,
    codecs: r,
    bandwidth: n.bitrate
  }, [
    we(this, vt, "m", ei).call(this, t, "AudioChannelConfiguration", {
      schemeIdUri: "urn:mpeg:dash:23003:3:audio_channel_configuration:2011",
      value: n.audio_channels || "2"
    }),
    we(this, vt, "m", ei).call(this, t, "BaseURL", {}, [
      t.createTextNode(s(a).toString())
    ]),
    we(this, vt, "m", ei).call(this, t, "SegmentBase", {
      indexRange: `${n.index_range.start}-${n.index_range.end}`
    }, [
      we(this, vt, "m", ei).call(this, t, "Initialization", {
        range: `${n.init_range.start}-${n.init_range.end}`
      })
    ])
  ]));
}, "_VideoInfo_generateRepresentationAudio");
var g2 = Q6, Dr = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Na = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, zn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, al, Ys, ll, ao, ew = class {
  constructor(e, t, i) {
    var n, s, r, a, u, c, h, p;
    al.set(this, void 0), Ys.set(this, void 0), ll.set(this, void 0), ao.set(this, void 0), Na(this, Ys, t, "f");
    const m = y.parseResponse(e[0].data), b = !((n = e == null ? void 0 : e[1]) === null || n === void 0) && n.data ? y.parseResponse(e[1].data) : void 0;
    if (Na(this, al, [m, b], "f"), Na(this, ll, i, "f"), ((s = m.playability_status) === null || s === void 0 ? void 0 : s.status) === "ERROR")
      throw new x("This video is unavailable", m.playability_status);
    if (!(!((r = m.microformat) === null || r === void 0) && r.is(ea)))
      throw new x("Invalid microformat", m.microformat);
    if (this.basic_info = Object.assign(Object.assign({}, m.video_details), {
      description: (a = m.microformat) === null || a === void 0 ? void 0 : a.description,
      is_unlisted: (u = m.microformat) === null || u === void 0 ? void 0 : u.is_unlisted,
      is_family_safe: (c = m.microformat) === null || c === void 0 ? void 0 : c.is_family_safe,
      url_canonical: (h = m.microformat) === null || h === void 0 ? void 0 : h.url_canonical,
      tags: (p = m.microformat) === null || p === void 0 ? void 0 : p.tags
    }), this.streaming_data = m.streaming_data, this.playability_status = m.playability_status, this.storyboards = m.storyboards, this.endscreen = m.endscreen, Na(this, ao, m.playback_tracking, "f"), b) {
      const k = b.contents.item().as(xo).contents.item().as(Eo).contents.item().as(Ao);
      this.tabs = k.tabs.array().as(Bt), this.current_video_endpoint = b.current_video_endpoint, this.player_overlays = b.player_overlays.item().as(Nf);
    }
  }
  getTab(e) {
    return Dr(this, void 0, void 0, function* () {
      if (!this.tabs)
        throw new x("Could not find any tab");
      const t = this.tabs.get({ title: e });
      if (!t)
        throw new x(`Tab "${e}" not found`, { available_tabs: this.available_tabs });
      if (t.content)
        return t.content;
      const i = yield t.endpoint.callTest(zn(this, Ys, "f"), { client: "YTMUSIC", parse: !0 });
      return i.contents.item().key("type").string() === "Message" ? i.contents.item().as(Qo) : i.contents.item().as(dt).contents.array();
    });
  }
  getUpNext(e = !0) {
    var t, i;
    return Dr(this, void 0, void 0, function* () {
      const n = yield this.getTab("Up next");
      if (!n || !n.content)
        throw new x("Music queue was empty, the video id is probably invalid.", n);
      const s = n.content.as(ys);
      if (!s.playlist_id && e) {
        const r = s.contents.firstOfType(dh);
        if (!r)
          throw new x("Automix item not found");
        const a = yield (t = r.playlist_video) === null || t === void 0 ? void 0 : t.endpoint.callTest(zn(this, Ys, "f"), {
          videoId: this.basic_info.id,
          client: "YTMUSIC",
          parse: !0
        });
        if (!a)
          throw new x("Could not fetch automix");
        return (i = a.contents_memo.getType(ys)) === null || i === void 0 ? void 0 : i[0];
      }
      return s;
    });
  }
  getRelated() {
    return Dr(this, void 0, void 0, function* () {
      return yield this.getTab("Related");
    });
  }
  getLyrics() {
    return Dr(this, void 0, void 0, function* () {
      return (yield this.getTab("Lyrics")).firstOfType(kl);
    });
  }
  addToWatchHistory() {
    return Dr(this, void 0, void 0, function* () {
      if (!zn(this, ao, "f"))
        throw new x("Playback tracking not available");
      const e = {
        cpn: zn(this, ll, "f"),
        fmt: 251,
        rtn: 0,
        rt: 0
      }, t = zn(this, ao, "f").videostats_playback_url.replace("https://s.", "https://music.");
      return yield zn(this, Ys, "f").stats(t, {
        client_name: pe.CLIENTS.YTMUSIC.NAME,
        client_version: pe.CLIENTS.YTMUSIC.VERSION
      }, e);
    });
  }
  get available_tabs() {
    return this.tabs ? this.tabs.map((e) => e.title) : [];
  }
  get page() {
    return zn(this, al, "f");
  }
};
l(ew, "TrackInfo");
al = /* @__PURE__ */ new WeakMap(), Ys = /* @__PURE__ */ new WeakMap(), ll = /* @__PURE__ */ new WeakMap(), ao = /* @__PURE__ */ new WeakMap();
var y2 = ew, O1 = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ra = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ai = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, lo, _n, ts, $l = class {
  constructor(e, t, i = {}) {
    var n, s, r, a, u, c, h;
    lo.set(this, void 0), _n.set(this, void 0), ts.set(this, void 0), Ra(this, _n, t, "f"), Ra(this, lo, i.is_continuation ? e : y.parseResponse(e.data), "f");
    const p = Ai(this, lo, "f").contents.item().as(g_).tabs.get({ selected: !0 });
    if (!p)
      throw new x("Could not find target tab.");
    const m = (n = p.content) === null || n === void 0 ? void 0 : n.as(dt);
    if (!m)
      throw new x("Target tab did not have any content.");
    this.header = m.hasKey("header") ? (s = m.header) === null || s === void 0 ? void 0 : s.item().as(Oh) : null;
    const b = m.contents.array().as(cs, Hi), C = b.firstOfType(Hi);
    this.did_you_mean = ((r = C == null ? void 0 : C.contents) === null || r === void 0 ? void 0 : r.firstOfType(iy)) || null, this.showing_results_for = ((a = C == null ? void 0 : C.contents) === null || a === void 0 ? void 0 : a.firstOfType(f_)) || null, this.message = ((u = C == null ? void 0 : C.contents) === null || u === void 0 ? void 0 : u.firstOfType(Qo)) || null, i.is_continuation || i.is_filtered ? (this.results = (c = b.firstOfType(cs)) === null || c === void 0 ? void 0 : c.contents, Ra(this, ts, (h = b.firstOfType(cs)) === null || h === void 0 ? void 0 : h.continuation, "f")) : this.sections = b.filterType(cs);
  }
  getMore(e) {
    return O1(this, void 0, void 0, function* () {
      if (!e || !e.endpoint)
        throw new x("Cannot retrieve more items for this shelf because it does not have an endpoint.");
      const t = yield e.endpoint.call(Ai(this, _n, "f"), "YTMUSIC", !0);
      if (!t)
        throw new x("Endpoint did not return any data");
      return new $l(t, Ai(this, _n, "f"), { is_continuation: !0 });
    });
  }
  getContinuation() {
    var e, t, i;
    return O1(this, void 0, void 0, function* () {
      if (!Ai(this, ts, "f"))
        throw new x("Continuation not found.");
      const s = (yield Ai(this, _n, "f").search({ ctoken: Ai(this, ts, "f"), client: "YTMUSIC" })).data.continuationContents.musicShelfContinuation;
      return this.results = y.parse(s.contents).array().as(ta), Ra(this, ts, (i = (t = (e = s == null ? void 0 : s.continuations) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.nextContinuationData) === null || i === void 0 ? void 0 : i.continuation, "f"), this;
    });
  }
  selectFilter(e) {
    var t, i, n, s;
    return O1(this, void 0, void 0, function* () {
      if (!(!((t = this.filters) === null || t === void 0) && t.includes(e)))
        throw new x("Invalid filter", { available_filters: this.filters });
      const r = (n = (i = this.header) === null || i === void 0 ? void 0 : i.chips) === null || n === void 0 ? void 0 : n.as(jo).get({ text: e });
      if (r != null && r.is_selected)
        return this;
      const a = yield (s = r == null ? void 0 : r.endpoint) === null || s === void 0 ? void 0 : s.call(Ai(this, _n, "f"), "YTMUSIC", !0);
      if (!a)
        throw new x("Endpoint did not return any data");
      return new $l(a, Ai(this, _n, "f"), { is_continuation: !0 });
    });
  }
  get has_continuation() {
    return !!Ai(this, ts, "f");
  }
  get filters() {
    var e, t;
    return ((t = (e = this.header) === null || e === void 0 ? void 0 : e.chips) === null || t === void 0 ? void 0 : t.as(jo).map((i) => i.text)) || null;
  }
  get songs() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Songs");
  }
  get videos() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Videos");
  }
  get albums() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Albums");
  }
  get artists() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Artists");
  }
  get playlists() {
    var e;
    return (e = this.sections) === null || e === void 0 ? void 0 : e.find((t) => t.title.toString() === "Community playlists");
  }
  get page() {
    return Ai(this, lo, "f");
  }
};
l($l, "Search");
lo = /* @__PURE__ */ new WeakMap(), _n = /* @__PURE__ */ new WeakMap(), ts = /* @__PURE__ */ new WeakMap();
var DT = $l, BT = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, La = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ki = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, bn, uo, is, wv = class {
  constructor(e, t) {
    var i, n, s;
    bn.set(this, void 0), uo.set(this, void 0), is.set(this, void 0), La(this, uo, t, "f"), La(this, bn, y.parseResponse(e.data), "f");
    const r = ki(this, bn, "f").contents.item().as(ia).tabs.get({ selected: !0 });
    if (!r)
      throw new x("Could not get Home tab.");
    if (r.key("content").isNull()) {
      if (!ki(this, bn, "f").continuation_contents)
        throw new x("Continuation did not have any content.");
      La(this, is, ki(this, bn, "f").continuation_contents.as(_s).continuation, "f"), this.sections = (i = ki(this, bn, "f").continuation_contents.as(_s).contents) === null || i === void 0 ? void 0 : i.as(cr);
      return;
    }
    La(this, is, (n = r.content) === null || n === void 0 ? void 0 : n.as(dt).continuation, "f"), this.sections = (s = r.content) === null || s === void 0 ? void 0 : s.as(dt).contents.array().as(cr);
  }
  getContinuation() {
    return BT(this, void 0, void 0, function* () {
      if (!ki(this, is, "f"))
        throw new x("Continuation not found.");
      const e = yield ki(this, uo, "f").browse(ki(this, is, "f"), { is_ctoken: !0, client: "YTMUSIC" });
      return new wv(e, ki(this, uo, "f"));
    });
  }
  get has_continuation() {
    return !!ki(this, is, "f");
  }
  get page() {
    return ki(this, bn, "f");
  }
};
l(wv, "HomeFeed");
bn = /* @__PURE__ */ new WeakMap(), uo = /* @__PURE__ */ new WeakMap(), is = /* @__PURE__ */ new WeakMap();
var OT = wv, FT = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, _2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, co, tw = class {
  constructor(e) {
    var t, i;
    co.set(this, void 0), FT(this, co, y.parseResponse(e.data), "f");
    const n = _2(this, co, "f").contents.item().as(ia).tabs.get({ selected: !0 });
    if (!n)
      throw new x("Could not find target tab.");
    const s = (t = n.content) === null || t === void 0 ? void 0 : t.as(dt);
    if (!s)
      throw new x("Target tab did not have any content.");
    this.top_buttons = ((i = s.contents.array().firstOfType(oy)) === null || i === void 0 ? void 0 : i.items.array().as(Qp)) || [], this.sections = s.contents.array().getAll({ type: "MusicCarouselShelf" });
  }
  get page() {
    return _2(this, co, "f");
  }
};
l(tw, "Explore");
co = /* @__PURE__ */ new WeakMap();
var VT = tw, qt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Bn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, le = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, $e, en, wn, Gl, as, iw, Xs, Yi, ul, ho, bc, po, cl, hl, nw, dl, UT = {
  history: "FEmusic_history",
  playlists: "FEmusic_liked_playlists",
  albums: "FEmusic_liked_albums",
  songs: "FEmusic_liked_videos",
  artists: "FEmusic_library_corpus_track_artists",
  subscriptions: "FEmusic_library_corpus_artists"
}, sw = {
  recently_added: "Recently added",
  a_z: "A to Z",
  z_a: "Z to A"
}, rw = {};
for (const [e, t] of Object.entries(sw))
  rw[t] = e;
var ow = class {
  constructor(e) {
    $e.add(this), en.set(this, void 0), Bn(this, en, e, "f");
  }
  getPlaylists(e) {
    return qt(this, void 0, void 0, function* () {
      const t = yield le(this, $e, "m", as).call(this, le(this, $e, "m", wn).call(this, "playlists"), (n) => n.item_type === "playlist"), i = (e == null ? void 0 : e.sort_by) || null;
      return i ? le(this, $e, "m", Xs).call(this, t, i) : t;
    });
  }
  getAlbums(e) {
    return qt(this, void 0, void 0, function* () {
      const t = yield le(this, $e, "m", as).call(this, le(this, $e, "m", wn).call(this, "albums"), (n) => n.item_type === "album"), i = (e == null ? void 0 : e.sort_by) || null;
      return i ? le(this, $e, "m", Xs).call(this, t, i) : t;
    });
  }
  getArtists(e) {
    return qt(this, void 0, void 0, function* () {
      const t = yield le(this, $e, "m", as).call(this, le(this, $e, "m", wn).call(this, "artists"), (n) => n.item_type === "library_artist"), i = (e == null ? void 0 : e.sort_by) || null;
      return i ? le(this, $e, "m", Xs).call(this, t, i) : t;
    });
  }
  getSongs(e) {
    var t;
    return qt(this, void 0, void 0, function* () {
      const i = yield le(this, $e, "m", as).call(this, le(this, $e, "m", wn).call(this, "songs"), (a) => a.item_type === "song" || a.item_type === "video"), n = (e == null ? void 0 : e.sort_by) || null, s = n === "random", r = s ? (t = i.all_items.find((a) => a.item_type === "endpoint" && a.title.toString() === "Shuffle all")) === null || t === void 0 ? void 0 : t.endpoint : null;
      if (s) {
        if (!r) {
          if (i.items.length <= 1)
            return i;
          throw new x("Unable to obtain endpoint for sort_by value 'random'");
        }
        return le(this, $e, "m", iw).call(this, r);
      }
      return n ? le(this, $e, "m", Xs).call(this, i, n) : i;
    });
  }
  getSubscriptions(e) {
    return qt(this, void 0, void 0, function* () {
      const t = yield le(this, $e, "m", as).call(this, le(this, $e, "m", wn).call(this, "subscriptions")), i = (e == null ? void 0 : e.sort_by) || null;
      return i ? le(this, $e, "m", Xs).call(this, t, i) : t;
    });
  }
  getRecentActivity(e) {
    var t, i, n;
    return qt(this, void 0, void 0, function* () {
      if (!!(e != null && e.all)) {
        const h = yield le(this, $e, "m", Gl).call(this, le(this, $e, "m", wn).call(this, "history")), p = (t = h.contents_memo.get("SectionList")) === null || t === void 0 ? void 0 : t[0].as(dt), m = ((i = p == null ? void 0 : p.contents) === null || i === void 0 ? void 0 : i.array()) || [], b = p != null && p.continuation ? {
          type: "browse",
          token: p == null ? void 0 : p.continuation
        } : null;
        return new Cv(m, b, h, le(this, en, "f"));
      }
      const r = yield le(this, $e, "m", Gl).call(this, le(this, $e, "m", wn).call(this, "songs")), u = (((n = r.contents_memo.get("SectionList")) === null || n === void 0 ? void 0 : n[0].as(dt).contents.array()) || []).find((h) => {
        var p, m;
        return ((p = h.header) === null || p === void 0 ? void 0 : p.type) === "MusicCarouselShelfBasicHeader" && ((m = h.header) === null || m === void 0 ? void 0 : m.title.toString()) === "Recent activity";
      }), c = (u == null ? void 0 : u.contents) || [];
      return new qo(c, null, null, r, le(this, en, "f"), { sort_by: null });
    });
  }
};
l(ow, "Library");
en = /* @__PURE__ */ new WeakMap(), $e = /* @__PURE__ */ new WeakSet(), wn = /* @__PURE__ */ l(function(t) {
  return UT[t];
}, "_Library_getBrowseId"), Gl = /* @__PURE__ */ l(function(t, i = {}) {
  return qt(this, void 0, void 0, function* () {
    const n = yield le(this, en, "f").browse(t, Object.assign(Object.assign({}, i), { client: "YTMUSIC" }));
    return y.parseResponse(n.data);
  });
}, "_Library_fetchPage"), as = /* @__PURE__ */ l(function(t, i = null, n = {}) {
  var s, r;
  return qt(this, void 0, void 0, function* () {
    const a = /* @__PURE__ */ l((b) => {
      var C;
      switch (b == null ? void 0 : b.type) {
        case "Grid":
          return (C = b.contents) === null || C === void 0 ? void 0 : C.array();
        case "MusicShelf":
          return b.contents;
        default:
          return [];
      }
    }, "getItemsFromDataNode"), u = yield le(this, $e, "m", Gl).call(this, t, n), h = (((s = u.contents_memo.get("SectionList")) === null || s === void 0 ? void 0 : s[0].as(dt).contents.array()) || []).find((b) => {
      var C;
      return ((C = b.header) === null || C === void 0 ? void 0 : C.type) === "ItemSectionTabbedHeader";
    }), p = (r = h == null ? void 0 : h.contents) === null || r === void 0 ? void 0 : r[0], m = p != null && p.continuation ? {
      type: "browse",
      token: p == null ? void 0 : p.continuation
    } : null;
    return new qo(a(p) || [], i, m, u, le(this, en, "f"));
  });
}, "_Library_fetchAndParseTabContents"), iw = /* @__PURE__ */ l(function(t) {
  var i;
  return qt(this, void 0, void 0, function* () {
    const n = {
      playlist_id: t.payload.playlistId,
      params: t.payload.params
    }, s = yield le(this, en, "f").next(Object.assign(Object.assign({}, n), { client: "YTMUSIC" })), r = y.parseResponse(s.data), a = (i = r.contents_memo.get("PlaylistPanel")) === null || i === void 0 ? void 0 : i[0].as(ys), u = (a == null ? void 0 : a.contents) || [], c = a != null && a.continuation ? {
      type: "next",
      token: a == null ? void 0 : a.continuation,
      payload: n
    } : null, h = /* @__PURE__ */ l((p) => p.type === "PlaylistPanelVideo", "filter");
    return new qo(u, h, c, r, le(this, en, "f"), { sort_by: "random" });
  });
}, "_Library_fetchAndParseShuffledSongs"), Xs = /* @__PURE__ */ l(function(t, i) {
  var n, s, r;
  return qt(this, void 0, void 0, function* () {
    const a = t.page, u = (s = (n = a == null ? void 0 : a.contents_memo.get("DropdownItem")) === null || n === void 0 ? void 0 : n.find((h) => h.as(Uo).label === sw[i])) === null || s === void 0 ? void 0 : s.as(Uo);
    if (!(!((r = u == null ? void 0 : u.endpoint) === null || r === void 0) && r.browse)) {
      if (t.items.length <= 1)
        return t;
      throw new x(`Unable to obtain browse endpoint for sort_by value '${i}'`);
    }
    if (u != null && u.selected)
      return t;
    const c = { params: u.endpoint.browse.params };
    return le(this, $e, "m", as).call(this, u.endpoint.browse.id, t.filter, c);
  });
}, "_Library_applySortBy");
var Sv = class {
  constructor(e, t, i) {
    Yi.set(this, void 0), ul.set(this, void 0), ho.set(this, void 0), Bn(this, Yi, e, "f"), Bn(this, ul, t, "f"), Bn(this, ho, i, "f"), this.has_continuation = !!e;
  }
  getContinuation() {
    return qt(this, void 0, void 0, function* () {
      if (!le(this, Yi, "f"))
        throw new x("Continuation not found.");
      let e;
      const t = le(this, Yi, "f").payload || {};
      switch (le(this, Yi, "f").type) {
        case "next":
          e = le(this, ho, "f").next(Object.assign(Object.assign({}, t), { ctoken: le(this, Yi, "f").token, client: "YTMUSIC" }));
          break;
        default:
          e = le(this, ho, "f").browse(le(this, Yi, "f").token, Object.assign(Object.assign({}, t), { is_ctoken: !0, client: "YTMUSIC" }));
      }
      const i = yield e, n = y.parseResponse(i.data);
      if (!n.continuation_contents)
        throw new x("No continuation data found.");
      return this.parseContinuationContents(n, le(this, Yi, "f"));
    });
  }
  get page() {
    return le(this, ul, "f");
  }
};
l(Sv, "LibraryResultsBase");
Yi = /* @__PURE__ */ new WeakMap(), ul = /* @__PURE__ */ new WeakMap(), ho = /* @__PURE__ */ new WeakMap();
var qo = class extends Sv {
  constructor(e, t, i, n, s, r) {
    super(i, n, s), bc.add(this), po.set(this, void 0), cl.set(this, void 0), hl.set(this, void 0), Bn(this, po, t, "f"), Bn(this, cl, s, "f"), Bn(this, hl, e, "f"), this.items = t ? e.filter(t) : e, this.sort_by = (r == null ? void 0 : r.sort_by) !== void 0 ? r.sort_by : le(this, bc, "m", nw).call(this);
  }
  parseContinuationContents(e, t) {
    var i;
    return qt(this, void 0, void 0, function* () {
      const n = (i = e.continuation_contents) === null || i === void 0 ? void 0 : i.as(sa, tu, iu), s = n != null && n.continuation ? Object.assign(Object.assign({}, t), { token: n == null ? void 0 : n.continuation }) : null;
      return new qo((n == null ? void 0 : n.contents) || [], le(this, po, "f"), s, e, le(this, cl, "f"), { sort_by: this.sort_by });
    });
  }
  get all_items() {
    return le(this, hl, "f");
  }
  get filter() {
    return le(this, po, "f");
  }
};
l(qo, "LibraryItemList");
po = /* @__PURE__ */ new WeakMap(), cl = /* @__PURE__ */ new WeakMap(), hl = /* @__PURE__ */ new WeakMap(), bc = /* @__PURE__ */ new WeakSet(), nw = /* @__PURE__ */ l(function() {
  var t, i;
  const n = ((i = (t = this.page) === null || t === void 0 ? void 0 : t.contents_memo.get("DropdownItem")) === null || i === void 0 ? void 0 : i.filter((s) => s.as(Uo).selected)) || [];
  for (const s of n) {
    const r = rw[s.label];
    if (r)
      return r;
  }
  return null;
}, "_LibraryItemList_getSortBy");
var Cv = class extends Sv {
  constructor(e, t, i, n) {
    super(t, i, n), dl.set(this, void 0), Bn(this, dl, n, "f"), this.sections = e;
  }
  parseContinuationContents(e, t) {
    var i;
    return qt(this, void 0, void 0, function* () {
      const n = (i = e.continuation_contents) === null || i === void 0 ? void 0 : i.as(_s), s = n != null && n.continuation ? Object.assign(Object.assign({}, t), { token: n == null ? void 0 : n.continuation }) : null;
      return new Cv((n == null ? void 0 : n.contents) || [], s, e, le(this, dl, "f"));
    });
  }
};
l(Cv, "LibrarySectionList");
dl = /* @__PURE__ */ new WeakMap();
var jT = ow, HT = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, b2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Da = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Js, pl, aw = class {
  constructor(e, t) {
    Js.set(this, void 0), pl.set(this, void 0), b2(this, Js, y.parseResponse(e.data), "f"), b2(this, pl, t, "f"), this.header = this.page.header.item().as(Uy, jy, lf);
    const i = Da(this, Js, "f").contents_memo.get("MusicShelf") || [], n = Da(this, Js, "f").contents_memo.get("MusicCarouselShelf") || [];
    this.sections = [...i, ...n];
  }
  getAllSongs() {
    var e, t;
    return HT(this, void 0, void 0, function* () {
      const i = this.sections.filter((a) => a.type === "MusicShelf");
      if (!i.length)
        throw new x("Could not find any node of type MusicShelf.");
      const n = i.find((a) => a.title.toString() === "Songs");
      if (!n)
        throw new x("Could not find target shelf (Songs).");
      if (!n.endpoint)
        throw new x("Target shelf (Songs) did not have an endpoint.");
      return ((t = (e = (yield n.endpoint.call(Da(this, pl, "f"), "YTMUSIC", !0)).contents_memo.get("MusicPlaylistShelf")) === null || e === void 0 ? void 0 : e[0]) === null || t === void 0 ? void 0 : t.as(Pl)) || null;
    });
  }
  get page() {
    return Da(this, Js, "f");
  }
};
l(aw, "Artist");
Js = /* @__PURE__ */ new WeakMap(), pl = /* @__PURE__ */ new WeakMap();
var WT = aw, w2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Br = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Sn, wc, lw = class {
  constructor(e, t) {
    var i, n;
    Sn.set(this, void 0), wc.set(this, void 0), w2(this, Sn, y.parseResponse(e.data), "f"), w2(this, wc, t, "f"), this.header = Br(this, Sn, "f").header.item().as(Il), this.url = ((i = Br(this, Sn, "f").microformat) === null || i === void 0 ? void 0 : i.as(ea).url_canonical) || null, this.contents = (n = Br(this, Sn, "f").contents_memo.get("MusicShelf")) === null || n === void 0 ? void 0 : n[0].as(cs).contents, this.sections = Br(this, Sn, "f").contents_memo.get("MusicCarouselShelf") || [];
  }
  get page() {
    return Br(this, Sn, "f");
  }
};
l(lw, "Album");
Sn = /* @__PURE__ */ new WeakMap(), wc = /* @__PURE__ */ new WeakMap();
var $T = lw, fl = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, hn = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Qe = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Sc, Wt, ls, ns, fo, Zs, uw, Tv = class {
  constructor(e, t) {
    var i, n, s, r, a, u, c, h;
    if (Sc.add(this), Wt.set(this, void 0), ls.set(this, void 0), ns.set(this, void 0), fo.set(this, void 0), Zs.set(this, void 0), hn(this, ls, t, "f"), hn(this, Wt, y.parseResponse(e.data), "f"), hn(this, fo, ((n = (i = Qe(this, Wt, "f").contents_memo.getType(cs)) === null || i === void 0 ? void 0 : i.find((p) => p.title.toString() === "Suggestions")) === null || n === void 0 ? void 0 : n.continuation) || null, "f"), hn(this, Zs, null, "f"), Qe(this, Wt, "f").continuation_contents) {
      const p = (s = Qe(this, Wt, "f").continuation_contents) === null || s === void 0 ? void 0 : s.as(eu);
      this.items = p.contents, hn(this, ns, p.continuation, "f");
    } else
      ((r = Qe(this, Wt, "f").header) === null || r === void 0 ? void 0 : r.item().type) === "MusicEditablePlaylistDetailHeader" ? this.header = (a = Qe(this, Wt, "f").header) === null || a === void 0 ? void 0 : a.item().as(Vy).header.item().as(Il) : this.header = ((u = Qe(this, Wt, "f").header) === null || u === void 0 ? void 0 : u.item().as(Il)) || null, this.items = (c = Qe(this, Wt, "f").contents_memo.getType(Pl)) === null || c === void 0 ? void 0 : c[0].contents, hn(this, ns, ((h = Qe(this, Wt, "f").contents_memo.getType(Pl)) === null || h === void 0 ? void 0 : h[0].continuation) || null, "f");
  }
  get page() {
    return Qe(this, Wt, "f");
  }
  get has_continuation() {
    return !!Qe(this, ns, "f");
  }
  getContinuation() {
    return fl(this, void 0, void 0, function* () {
      if (!Qe(this, ns, "f"))
        throw new x("Continuation not found.");
      const e = yield Qe(this, ls, "f").browse(Qe(this, ns, "f"), { is_ctoken: !0, client: "YTMUSIC" });
      return new Tv(e, Qe(this, ls, "f"));
    });
  }
  getRelated() {
    var e, t, i;
    return fl(this, void 0, void 0, function* () {
      let n = (e = Qe(this, Wt, "f").contents_memo.get("SectionList")) === null || e === void 0 ? void 0 : e[0].as(dt).continuation;
      for (; n; ) {
        const s = yield Qe(this, ls, "f").browse(n, { is_ctoken: !0, client: "YTMUSIC" }), a = (t = y.parseResponse(s.data).continuation_contents) === null || t === void 0 ? void 0 : t.as(_s), u = (i = a == null ? void 0 : a.contents) === null || i === void 0 ? void 0 : i.as(cr), c = u == null ? void 0 : u.filter((h) => {
          var p;
          return ((p = h.header) === null || p === void 0 ? void 0 : p.title.toString()) === "Related playlists";
        })[0];
        if (c)
          return c.contents || [];
        n = a == null ? void 0 : a.continuation;
      }
      return [];
    });
  }
  getSuggestions(e = !0) {
    return fl(this, void 0, void 0, function* () {
      const n = yield e || !Qe(this, Zs, "f") ? Qe(this, Sc, "m", uw).call(this, Qe(this, fo, "f")) : Promise.resolve(null);
      return n && (hn(this, Zs, n.items, "f"), hn(this, fo, n.continuation, "f")), (n == null ? void 0 : n.items) || Qe(this, Zs, "f");
    });
  }
};
l(Tv, "Playlist");
Wt = /* @__PURE__ */ new WeakMap(), ls = /* @__PURE__ */ new WeakMap(), ns = /* @__PURE__ */ new WeakMap(), fo = /* @__PURE__ */ new WeakMap(), Zs = /* @__PURE__ */ new WeakMap(), Sc = /* @__PURE__ */ new WeakSet(), uw = /* @__PURE__ */ l(function(t) {
  var i;
  return fl(this, void 0, void 0, function* () {
    if (t) {
      const n = yield Qe(this, ls, "f").browse(t, { is_ctoken: !0, client: "YTMUSIC" }), r = (i = y.parseResponse(n.data).continuation_contents) === null || i === void 0 ? void 0 : i.as(sa);
      return {
        items: (r == null ? void 0 : r.contents) || [],
        continuation: (r == null ? void 0 : r.continuation) || null
      };
    }
    return {
      items: [],
      continuation: null
    };
  });
}, "_Playlist_fetchSuggestions");
var cw = Tv, GT = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, S2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Kn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Cn, mo, hw = class {
  constructor(e, t) {
    var i, n, s;
    Cn.set(this, void 0), mo.set(this, void 0), S2(this, Cn, y.parseResponse(e.data), "f"), S2(this, mo, t, "f");
    const r = Kn(this, Cn, "f").header.item();
    this.header = r.is(Z1) ? (n = (i = Kn(this, Cn, "f").header.item().as(Z1).element) === null || i === void 0 ? void 0 : i.model) === null || n === void 0 ? void 0 : n.item().as(J1) : Kn(this, Cn, "f").header.item().as(lf);
    const a = Kn(this, Cn, "f").contents.item().as(ia).tabs.firstOfType(Bt);
    if (!a)
      throw new x("Target tab not found");
    this.sections = (s = a.content) === null || s === void 0 ? void 0 : s.as(dt).contents.array().as(Hi, cr, Qo);
  }
  getPlaylist() {
    return GT(this, void 0, void 0, function* () {
      if (!this.header)
        throw new x("Header not found");
      if (!this.header.is(J1))
        throw new x("Recap playlist not available, check back later.");
      const t = yield this.header.panels[0].text_on_tap_endpoint.callTest(Kn(this, mo, "f"), { client: "YTMUSIC" });
      return new cw(t, Kn(this, mo, "f"));
    });
  }
  get page() {
    return Kn(this, Cn, "f");
  }
};
l(hw, "Recap");
Cn = /* @__PURE__ */ new WeakMap(), mo = /* @__PURE__ */ new WeakMap();
var qT = hw, Gt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, C2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ie = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, ml, Lo, Pe, dw, pw, fw = class {
  constructor(e) {
    ml.add(this), Lo.set(this, void 0), Pe.set(this, void 0), C2(this, Lo, e, "f"), C2(this, Pe, e.actions, "f");
  }
  getInfo(e) {
    if (e instanceof Gp)
      return Ie(this, ml, "m", pw).call(this, e);
    if (typeof e == "string")
      return Ie(this, ml, "m", dw).call(this, e);
    throw new x("Invalid target, expected either a video id or a valid MusicTwoRowItem", e);
  }
  search(e, t = {}) {
    return Gt(this, void 0, void 0, function* () {
      Be({ query: e });
      const i = yield Ie(this, Pe, "f").search({ query: e, filters: t, client: "YTMUSIC" });
      return new DT(i, Ie(this, Pe, "f"), { is_filtered: Reflect.has(t, "type") && t.type !== "all" });
    });
  }
  getHomeFeed() {
    return Gt(this, void 0, void 0, function* () {
      const e = yield Ie(this, Pe, "f").browse("FEmusic_home", { client: "YTMUSIC" });
      return new OT(e, Ie(this, Pe, "f"));
    });
  }
  getExplore() {
    return Gt(this, void 0, void 0, function* () {
      const e = yield Ie(this, Pe, "f").browse("FEmusic_explore", { client: "YTMUSIC" });
      return new VT(e);
    });
  }
  getLibrary() {
    return new jT(Ie(this, Pe, "f"));
  }
  getArtist(e) {
    return Gt(this, void 0, void 0, function* () {
      if (Be({ artist_id: e }), !e.startsWith("UC") && !e.startsWith("FEmusic_library_privately_owned_artist"))
        throw new x("Invalid artist id", e);
      const t = yield Ie(this, Pe, "f").browse(e, { client: "YTMUSIC" });
      return new WT(t, Ie(this, Pe, "f"));
    });
  }
  getAlbum(e) {
    return Gt(this, void 0, void 0, function* () {
      if (Be({ album_id: e }), !e.startsWith("MPR") && !e.startsWith("FEmusic_library_privately_owned_release"))
        throw new x("Invalid album id", e);
      const t = yield Ie(this, Pe, "f").browse(e, { client: "YTMUSIC" });
      return new $T(t, Ie(this, Pe, "f"));
    });
  }
  getPlaylist(e) {
    return Gt(this, void 0, void 0, function* () {
      Be({ playlist_id: e }), e.startsWith("VL") || (e = `VL${e}`);
      const t = yield Ie(this, Pe, "f").browse(e, { client: "YTMUSIC" });
      return new cw(t, Ie(this, Pe, "f"));
    });
  }
  getUpNext(e, t = !0) {
    var i, n, s;
    return Gt(this, void 0, void 0, function* () {
      Be({ video_id: e });
      const u = (yield Ie(this, Pe, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(xo).contents.item().as(Eo).contents.item().as(Ao).tabs.array().as(Bt).get({ title: "Up next" });
      if (!u)
        throw new x("Could not find target tab.");
      const c = (i = u.content) === null || i === void 0 ? void 0 : i.as(gf);
      if (!c || !c.content)
        throw new x("Music queue was empty, the given id is probably invalid.", c);
      const h = c.content.as(ys);
      if (!h.playlist_id && t) {
        const p = h.contents.firstOfType(dh);
        if (!p)
          throw new x("Automix item not found");
        const m = yield (n = p.playlist_video) === null || n === void 0 ? void 0 : n.endpoint.callTest(Ie(this, Pe, "f"), {
          videoId: e,
          client: "YTMUSIC",
          parse: !0
        });
        if (!m)
          throw new x("Could not fetch automix");
        return (s = m.contents_memo.getType(ys)) === null || s === void 0 ? void 0 : s[0];
      }
      return h;
    });
  }
  getRelated(e) {
    return Gt(this, void 0, void 0, function* () {
      Be({ video_id: e });
      const n = (yield Ie(this, Pe, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(xo).contents.item().as(Eo).contents.item().as(Ao).tabs.array().as(Bt).get({ title: "Related" });
      if (!n)
        throw new x("Could not find target tab.");
      const s = yield n.endpoint.call(Ie(this, Pe, "f"), "YTMUSIC", !0);
      if (!s)
        throw new x("Could not retrieve tab contents, the given id may be invalid or is not a song.");
      return s.contents.item().as(dt).contents.array().as(cr, kl);
    });
  }
  getLyrics(e) {
    return Gt(this, void 0, void 0, function* () {
      Be({ video_id: e });
      const n = (yield Ie(this, Pe, "f").execute("/next", {
        videoId: e,
        client: "YTMUSIC",
        parse: !0
      })).contents.item().as(xo).contents.item().as(Eo).contents.item().as(Ao).tabs.array().as(Bt).get({ title: "Lyrics" });
      if (!n)
        throw new x("Could not find target tab.");
      const s = yield n.endpoint.call(Ie(this, Pe, "f"), "YTMUSIC", !0);
      if (!s)
        throw new x("Could not retrieve tab contents, the given id may be invalid or is not a song.");
      if (s.contents.item().key("type").string() === "Message")
        throw new x(s.contents.item().as(Qo).text, e);
      return s.contents.item().as(dt).contents.array().firstOfType(kl);
    });
  }
  getRecap() {
    return Gt(this, void 0, void 0, function* () {
      const e = yield Ie(this, Pe, "f").execute("/browse", {
        browseId: "FEmusic_listening_review",
        client: "YTMUSIC_ANDROID"
      });
      return new qT(e, Ie(this, Pe, "f"));
    });
  }
  getSearchSuggestions(e) {
    var t;
    return Gt(this, void 0, void 0, function* () {
      const n = (t = (yield Ie(this, Pe, "f").execute("/music/get_search_suggestions", {
        parse: !0,
        input: e,
        client: "YTMUSIC"
      })).contents_memo.getType(h_)) === null || t === void 0 ? void 0 : t[0];
      return n.contents.is_array ? n == null ? void 0 : n.contents.array() : zt([]);
    });
  }
};
l(fw, "Music");
Lo = /* @__PURE__ */ new WeakMap(), Pe = /* @__PURE__ */ new WeakMap(), ml = /* @__PURE__ */ new WeakSet(), dw = /* @__PURE__ */ l(function(t) {
  return Gt(this, void 0, void 0, function* () {
    const i = vs(16), n = Ie(this, Pe, "f").execute("/player", {
      cpn: i,
      client: "YTMUSIC",
      videoId: t,
      playbackContext: {
        contentPlaybackContext: {
          signatureTimestamp: Ie(this, Lo, "f").player.sts
        }
      }
    }), s = Ie(this, Pe, "f").execute("/next", {
      client: "YTMUSIC",
      videoId: t
    }), r = yield Promise.all([n, s]);
    return new y2(r, Ie(this, Pe, "f"), i);
  });
}, "_Music_fetchInfoFromVideoId"), pw = /* @__PURE__ */ l(function(t) {
  return Gt(this, void 0, void 0, function* () {
    if (!t)
      throw new x("List item cannot be undefined");
    if (!t.endpoint)
      throw new Error("This item does not have an endpoint.");
    const i = vs(16), n = t.endpoint.callTest(Ie(this, Pe, "f"), {
      cpn: i,
      client: "YTMUSIC",
      playbackContext: {
        contentPlaybackContext: {
          signatureTimestamp: Ie(this, Lo, "f").player.sts
        }
      }
    }), s = t.endpoint.callTest(Ie(this, Pe, "f"), {
      client: "YTMUSIC",
      enablePersistentPlaylistPanel: !0,
      override_endpoint: "/next"
    }), r = yield Promise.all([n, s]);
    return new y2(r, Ie(this, Pe, "f"), i);
  });
}, "_Music_fetchInfoFromListItem");
var zT = fw, vl = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, T2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, dn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Tn, gl, yl, _l, bl, Cc = class {
  constructor(e = !1, t) {
    Tn.add(this), gl.set(this, void 0), yl.set(this, void 0), T2(this, gl, t || Cc.default_persistent_directory, "f"), T2(this, yl, e, "f");
  }
  static get temp_directory() {
    switch (vi()) {
      case "deno":
        const e = Reflect.get(globalThis, "Deno");
        return `${e.env.get("TMPDIR") || e.env.get("TMP") || e.env.get("TEMP") || "/tmp"}/youtubei.js`;
      case "node":
        return `${Reflect.get(module, "require")("os").tmpdir()}/youtubei.js`;
      default:
        return "";
    }
  }
  static get default_persistent_directory() {
    switch (vi()) {
      case "deno":
        return `${Reflect.get(globalThis, "Deno").cwd()}/.cache/youtubei.js`;
      case "node":
        return Reflect.get(module, "require")("path").resolve(__dirname, "..", "..", ".cache", "youtubei.js");
      default:
        return "";
    }
  }
  get cache_dir() {
    return dn(this, yl, "f") ? dn(this, gl, "f") : Cc.temp_directory;
  }
  get(e) {
    return vl(this, void 0, void 0, function* () {
      switch (yield dn(this, Tn, "m", _l).call(this), vi()) {
        case "deno": {
          const t = `${this.cache_dir}/${e}`, i = Reflect.get(globalThis, "Deno");
          try {
            if ((yield i.stat(t)).isFile)
              return (yield i.readFile(t)).buffer;
            throw new Error("An unexpected file was found in place of the cache key");
          } catch (n) {
            if (n instanceof i.errors.NotFound)
              return;
            throw n;
          }
        }
        case "node": {
          const t = Reflect.get(module, "require")("fs/promises"), i = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
          try {
            if ((yield t.stat(i)).isFile())
              return (yield t.readFile(i)).buffer;
            throw new Error("An unexpected file was found in place of the cache key");
          } catch (n) {
            if ((n == null ? void 0 : n.code) === "ENOENT")
              return;
            throw n;
          }
        }
        case "browser": {
          const t = yield dn(this, Tn, "m", bl).call(this);
          return t ? new Promise((i, n) => {
            const s = t.transaction("kv-store", "readonly").objectStore("kv-store").get(e);
            s.onerror = n, s.onsuccess = function() {
              var r;
              const a = (r = this.result) === null || r === void 0 ? void 0 : r.v;
              i(a ? a.buffer : void 0);
            };
          }) : void 0;
        }
      }
    });
  }
  set(e, t) {
    return vl(this, void 0, void 0, function* () {
      switch (yield dn(this, Tn, "m", _l).call(this), vi()) {
        case "deno":
          {
            const i = Reflect.get(globalThis, "Deno"), n = `${this.cache_dir}/${e}`;
            yield i.writeFile(n, new Uint8Array(t));
          }
          break;
        case "node":
          {
            const i = Reflect.get(module, "require")("fs/promises"), n = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
            yield i.writeFile(n, new Uint8Array(t));
          }
          break;
        case "browser": {
          const i = yield dn(this, Tn, "m", bl).call(this);
          return i ? new Promise((n, s) => {
            const r = i.transaction("kv-store", "readwrite").objectStore("kv-store").put({ k: e, v: t });
            r.onerror = s, r.onsuccess = () => n();
          }) : void 0;
        }
      }
    });
  }
  remove(e) {
    return vl(this, void 0, void 0, function* () {
      switch (yield dn(this, Tn, "m", _l).call(this), vi()) {
        case "deno":
          {
            const t = `${this.cache_dir}/${e}`, i = Reflect.get(globalThis, "Deno");
            try {
              yield i.remove(t);
            } catch (n) {
              if (n instanceof i.errors.NotFound)
                return;
              throw n;
            }
          }
          break;
        case "node":
          {
            const t = Reflect.get(module, "require")("fs/promises"), i = Reflect.get(module, "require")("path").resolve(this.cache_dir, e);
            try {
              yield t.unlink(i);
            } catch (n) {
              if ((n == null ? void 0 : n.code) === "ENOENT")
                return;
              throw n;
            }
          }
          break;
        case "browser": {
          const t = yield dn(this, Tn, "m", bl).call(this);
          return t ? new Promise((i, n) => {
            const s = t.transaction("kv-store", "readwrite").objectStore("kv-store").delete(e);
            s.onerror = n, s.onsuccess = () => i();
          }) : void 0;
        }
      }
    });
  }
};
l(Cc, "UniversalCache");
gl = /* @__PURE__ */ new WeakMap(), yl = /* @__PURE__ */ new WeakMap(), Tn = /* @__PURE__ */ new WeakSet(), _l = /* @__PURE__ */ l(function() {
  return vl(this, void 0, void 0, function* () {
    const t = this.cache_dir;
    switch (vi()) {
      case "deno":
        const i = Reflect.get(globalThis, "Deno");
        try {
          if (!(yield i.stat(t)).isDirectory)
            throw new Error("An unexpected file was found in place of the cache directory");
        } catch (s) {
          if (s instanceof i.errors.NotFound)
            yield i.mkdir(t, { recursive: !0 });
          else
            throw s;
        }
        break;
      case "node":
        const n = Reflect.get(module, "require")("fs/promises");
        try {
          if (!(yield n.stat(t)).isDirectory())
            throw new Error("An unexpected file was found in place of the cache directory");
        } catch (s) {
          if ((s == null ? void 0 : s.code) === "ENOENT")
            yield n.mkdir(t, { recursive: !0 });
          else
            throw s;
        }
        break;
    }
  });
}, "_UniversalCache_createCache"), bl = /* @__PURE__ */ l(function() {
  const t = Reflect.get(globalThis, "indexedDB") || Reflect.get(globalThis, "webkitIndexedDB") || Reflect.get(globalThis, "mozIndexedDB") || Reflect.get(globalThis, "msIndexedDB");
  return t ? new Promise((i, n) => {
    const s = t.open("youtubei.js", 1);
    s.onsuccess = function() {
      i(this.result);
    }, s.onerror = function(r) {
      n("indexedDB request error"), console.error(r);
    }, s.onupgradeneeded = function() {
      const r = this.result.createObjectStore("kv-store", {
        keyPath: "k"
      });
      r.transaction.oncomplete = function() {
        i(this.db);
      };
    };
  }) : console.log("IndexedDB is not supported. No cache will be used.");
}, "_UniversalCache_getBrowserDB");
var Do = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, KT = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, ps = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, vo, fs, mw, vw, gw, yw = class {
  constructor(e) {
    vo.add(this), fs.set(this, void 0), KT(this, fs, e, "f");
  }
  setThumbnail(e, t) {
    return Do(this, void 0, void 0, function* () {
      if (!e || !t)
        throw new di("One or more parameters are missing.");
      const i = Rt.encodeCustomThumbnailPayload(e, t);
      return yield ps(this, fs, "f").actions.execute("/video_manager/metadata_update", {
        protobuf: !0,
        serialized_data: i
      });
    });
  }
  upload(e, t = {}) {
    return Do(this, void 0, void 0, function* () {
      const i = yield ps(this, vo, "m", mw).call(this), n = yield ps(this, vo, "m", vw).call(this, i.upload_url, e);
      if (n.status !== "STATUS_SUCCESS")
        throw new x("Could not process video.");
      return yield ps(this, vo, "m", gw).call(this, i, n, t);
    });
  }
};
l(yw, "Studio");
fs = /* @__PURE__ */ new WeakMap(), vo = /* @__PURE__ */ new WeakSet(), mw = /* @__PURE__ */ l(function() {
  return Do(this, void 0, void 0, function* () {
    const t = `innertube_android:${lr()}:0:v=3,api=1,cf=3`, i = {
      frontendUploadId: t,
      deviceDisplayName: "Pixel 6 Pro",
      fileId: `goog-edited-video://generated?videoFileUri=content://media/external/video/media/${lr()}`,
      mp4MoovAtomRelocationStatus: "UNSUPPORTED",
      transcodeResult: "DISABLED",
      connectionType: "WIFI"
    }, n = yield ps(this, fs, "f").http.fetch("/upload/youtubei", {
      baseURL: l9.URLS.YT_UPLOAD,
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-goog-upload-command": "start",
        "x-goog-upload-protocol": "resumable"
      },
      body: JSON.stringify(i)
    });
    if (!n.ok)
      throw new x("Could not get initial upload data");
    return {
      frontend_upload_id: t,
      upload_id: n.headers.get("x-guploader-uploadid"),
      upload_url: n.headers.get("x-goog-upload-url"),
      scotty_resource_id: n.headers.get("x-goog-upload-header-scotty-resource-id"),
      chunk_granularity: n.headers.get("x-goog-upload-chunk-granularity")
    };
  });
}, "_Studio_getInitialUploadData"), vw = /* @__PURE__ */ l(function(t, i) {
  return Do(this, void 0, void 0, function* () {
    const n = yield ps(this, fs, "f").http.fetch_function(t, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "x-goog-upload-command": "upload, finalize",
        "x-goog-upload-file-name": `file-${Date.now()}`,
        "x-goog-upload-offset": "0"
      },
      body: i
    });
    if (!n.ok)
      throw new x("Could not upload video");
    return yield n.json();
  });
}, "_Studio_uploadVideo"), gw = /* @__PURE__ */ l(function(t, i, n) {
  return Do(this, void 0, void 0, function* () {
    const s = {
      resourceId: {
        scottyResourceId: {
          id: i.scottyResourceId
        }
      },
      frontendUploadId: t.frontend_upload_id,
      initialMetadata: {
        title: {
          newTitle: n.title || new Date().toDateString()
        },
        description: {
          newDescription: n.description || "",
          shouldSegment: !0
        },
        privacy: {
          newPrivacy: n.privacy || "PRIVATE"
        },
        draftState: {
          isDraft: n.is_draft || !1
        }
      }
    };
    return yield ps(this, fs, "f").actions.execute("/upload/createvideo", Object.assign({ client: "ANDROID" }, s));
  });
}, "_Studio_setVideoMetadata");
var YT = yw, XT = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, x2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, go, _w = class {
  constructor(e) {
    var t, i;
    go.set(this, void 0), XT(this, go, y.parseResponse(e.data), "f"), this.sections = (i = (t = x2(this, go, "f").contents_memo) === null || t === void 0 ? void 0 : t.get("Element")) === null || i === void 0 ? void 0 : i.map((n) => {
      var s;
      return (s = n.as(od).model) === null || s === void 0 ? void 0 : s.item();
    });
  }
  get page() {
    return x2(this, go, "f");
  }
};
l(_w, "Analytics");
go = /* @__PURE__ */ new WeakMap();
var JT = _w, ZT = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, E2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, yo, bw = class {
  constructor(e) {
    var t;
    yo.set(this, void 0), ZT(this, yo, y.parseResponse(e.data), "f");
    const i = E2(this, yo, "f").contents.item().as(ia).tabs.get({ selected: !0 });
    if (!i)
      throw new x("Could not find target tab.");
    this.contents = (t = i.content) === null || t === void 0 ? void 0 : t.as(dt).contents.array().as(Hi);
  }
  get page() {
    return E2(this, yo, "f");
  }
};
l(bw, "TimeWatched");
yo = /* @__PURE__ */ new WeakMap();
var QT = bw, ex = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, A2 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, _o, ww = class {
  constructor(e) {
    _o.set(this, void 0), ex(this, _o, y.parseResponse(e.data), "f");
    const t = A2(this, _o, "f").contents.array().as(Ng)[0];
    this.contents = t.contents, this.footers = t.footers;
  }
  get page() {
    return A2(this, _o, "f");
  }
};
l(ww, "AccountInfo");
_o = /* @__PURE__ */ new WeakMap();
var tx = ww, ix = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, k2 = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Ba = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, bo, wo, xv = class {
  constructor(e, t) {
    var i, n, s, r, a;
    bo.set(this, void 0), wo.set(this, void 0), k2(this, wo, e, "f"), k2(this, bo, y.parseResponse(t.data), "f"), this.sidebar = (i = Ba(this, bo, "f").sidebar) === null || i === void 0 ? void 0 : i.as(p_);
    const u = Ba(this, bo, "f").contents.item().as(na).tabs.array().as(Bt).get({ selected: !0 });
    if (!u)
      throw new x("Target tab not found");
    const c = (n = u.content) === null || n === void 0 ? void 0 : n.as(dt).contents.array().as(Hi);
    this.introduction = (a = (r = (s = c == null ? void 0 : c.shift()) === null || s === void 0 ? void 0 : s.contents) === null || r === void 0 ? void 0 : r.get({ type: "PageIntroduction" })) === null || a === void 0 ? void 0 : a.as(Hy), this.sections = c == null ? void 0 : c.map((h) => {
      var p;
      return {
        title: ((p = h.header) === null || p === void 0 ? void 0 : p.title.toString()) || null,
        contents: h.contents
      };
    });
  }
  selectSidebarItem(e) {
    return ix(this, void 0, void 0, function* () {
      if (!this.sidebar)
        throw new x("Sidebar not available");
      const t = this.sidebar.items.get({ title: e });
      if (!t)
        throw new x(`Item "${e}" not found`, { available_items: this.sidebar_items });
      const i = yield t.endpoint.callTest(Ba(this, wo, "f"), { parse: !1 });
      return new xv(Ba(this, wo, "f"), i);
    });
  }
  getSettingOption(e) {
    var t;
    if (!this.sections)
      throw new x("Sections not available");
    for (const i of this.sections)
      if (!!i.contents)
        for (const n of i.contents) {
          const s = n.as(Ga).options;
          if (s) {
            for (const r of s)
              if (r.is(f0) && ((t = r.title) === null || t === void 0 ? void 0 : t.toString()) === e)
                return r;
          }
        }
    throw new x(`Option "${e}" not found`, { available_options: this.setting_options });
  }
  get setting_options() {
    if (!this.sections)
      throw new x("Sections not available");
    let e = [];
    for (const t of this.sections)
      if (!!t.contents)
        for (const i of t.contents)
          i.as(Ga).options && (e = e.concat(i.as(Ga).options));
    return e.map((t) => {
      var i;
      return (i = t.title) === null || i === void 0 ? void 0 : i.toString();
    }).filter((t) => t);
  }
  get sidebar_items() {
    if (!this.sidebar)
      throw new x("Sidebar not available");
    return this.sidebar.items.map((e) => e.title.toString());
  }
};
l(xv, "Settings");
bo = /* @__PURE__ */ new WeakMap(), wo = /* @__PURE__ */ new WeakMap();
var nx = xv, Oa = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, sx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Yn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, Ii, Sw = class {
  constructor(e) {
    Ii.set(this, void 0), sx(this, Ii, e, "f"), this.channel = {
      editName: (t) => Yn(this, Ii, "f").channel("channel/edit_name", { new_name: t }),
      editDescription: (t) => Yn(this, Ii, "f").channel("channel/edit_description", { new_description: t }),
      getBasicAnalytics: () => this.getAnalytics()
    };
  }
  getInfo() {
    return Oa(this, void 0, void 0, function* () {
      const e = yield Yn(this, Ii, "f").execute("/account/accounts_list", { client: "ANDROID" });
      return new tx(e);
    });
  }
  getTimeWatched() {
    return Oa(this, void 0, void 0, function* () {
      const e = yield Yn(this, Ii, "f").execute("/browse", {
        browseId: "SPtime_watched",
        client: "ANDROID"
      });
      return new QT(e);
    });
  }
  getSettings() {
    return Oa(this, void 0, void 0, function* () {
      const e = yield Yn(this, Ii, "f").execute("/browse", {
        browseId: "SPaccount_overview"
      });
      return new nx(Yn(this, Ii, "f"), e);
    });
  }
  getAnalytics() {
    var e;
    return Oa(this, void 0, void 0, function* () {
      const t = yield this.getInfo(), i = Rt.encodeChannelAnalyticsParams((e = t.footers) === null || e === void 0 ? void 0 : e.endpoint.payload.browseId), n = yield Yn(this, Ii, "f").browse("FEanalytics_screen", { params: i, client: "ANDROID" });
      return new JT(n);
    });
  }
};
l(Sw, "AccountManager");
Ii = /* @__PURE__ */ new WeakMap();
var rx = Sw, Xn = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, ox = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, qi = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, ti, Cw = class {
  constructor(e) {
    ti.set(this, void 0), ox(this, ti, e, "f");
  }
  create(e, t) {
    return Xn(this, void 0, void 0, function* () {
      Be({ title: e, video_ids: t });
      const i = yield qi(this, ti, "f").execute("/playlist/create", { title: e, ids: t, parse: !1 });
      return {
        success: i.success,
        status_code: i.status_code,
        playlist_id: i.data.playlistId,
        data: i.data
      };
    });
  }
  delete(e) {
    return Xn(this, void 0, void 0, function* () {
      Be({ playlist_id: e });
      const t = yield qi(this, ti, "f").execute("playlist/delete", { playlistId: e });
      return {
        playlist_id: e,
        success: t.success,
        status_code: t.status_code,
        data: t.data
      };
    });
  }
  addVideos(e, t) {
    return Xn(this, void 0, void 0, function* () {
      Be({ playlist_id: e, video_ids: t });
      const i = yield qi(this, ti, "f").execute("/browse/edit_playlist", {
        playlistId: e,
        actions: t.map((n) => ({
          action: "ACTION_ADD_VIDEO",
          addedVideoId: n
        })),
        parse: !1
      });
      return {
        playlist_id: e,
        action_result: i.data.actions
      };
    });
  }
  removeVideos(e, t) {
    return Xn(this, void 0, void 0, function* () {
      Be({ playlist_id: e, video_ids: t });
      const i = yield qi(this, ti, "f").execute("/browse", { browseId: `VL${e}`, parse: !0 }), n = new Rl(qi(this, ti, "f"), i, !0);
      if (!n.info.is_editable)
        throw new x("This playlist cannot be edited.", e);
      const s = {
        playlistId: e,
        actions: []
      }, r = /* @__PURE__ */ l((u) => Xn(this, void 0, void 0, function* () {
        if (u.videos.filter((h) => t.includes(h.key("id").string())).forEach((h) => s.actions.push({
          action: "ACTION_REMOVE_VIDEO",
          setVideoId: h.key("set_video_id").string()
        })), s.actions.length < t.length) {
          const h = yield u.getContinuation();
          return r(h);
        }
      }), "getSetVideoIds");
      if (yield r(n), !s.actions.length)
        throw new x("Given video ids were not found in this playlist.", t);
      const a = yield qi(this, ti, "f").execute("/browse/edit_playlist", Object.assign(Object.assign({}, s), { parse: !1 }));
      return {
        playlist_id: e,
        action_result: a.data.actions
      };
    });
  }
  moveVideo(e, t, i) {
    return Xn(this, void 0, void 0, function* () {
      Be({ playlist_id: e, moved_video_id: t, predecessor_video_id: i });
      const n = yield qi(this, ti, "f").execute("/browse", { browseId: `VL${e}`, parse: !0 }), s = new Rl(qi(this, ti, "f"), n, !0);
      if (!s.info.is_editable)
        throw new x("This playlist cannot be edited.", e);
      const r = {
        playlistId: e,
        actions: []
      };
      let a, u;
      const c = /* @__PURE__ */ l((p) => Xn(this, void 0, void 0, function* () {
        const m = p.videos.find((C) => t === C.key("id").string()), b = p.videos.find((C) => i === C.key("id").string());
        if (a = a || (m == null ? void 0 : m.key("set_video_id").string()), u = u || (b == null ? void 0 : b.key("set_video_id").string()), !a || !u) {
          const C = yield p.getContinuation();
          return c(C);
        }
      }), "getSetVideoIds");
      yield c(s), r.actions.push({
        action: "ACTION_MOVE_VIDEO_AFTER",
        setVideoId: a,
        movedSetVideoIdPredecessor: u
      });
      const h = yield qi(this, ti, "f").execute("/browse/edit_playlist", Object.assign(Object.assign({}, r), { parse: !1 }));
      return {
        playlist_id: e,
        action_result: h.data.actions
      };
    });
  }
};
l(Cw, "PlaylistManager");
ti = /* @__PURE__ */ new WeakMap();
var ax = Cw, pn = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, lx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, fn = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, hi, Tw = class {
  constructor(e) {
    hi.set(this, void 0), lx(this, hi, e, "f");
  }
  like(e) {
    return pn(this, void 0, void 0, function* () {
      return Be({ video_id: e }), yield fn(this, hi, "f").engage("like/like", { video_id: e });
    });
  }
  dislike(e) {
    return pn(this, void 0, void 0, function* () {
      return Be({ video_id: e }), yield fn(this, hi, "f").engage("like/dislike", { video_id: e });
    });
  }
  removeLike(e) {
    return pn(this, void 0, void 0, function* () {
      return Be({ video_id: e }), yield fn(this, hi, "f").engage("like/removelike", { video_id: e });
    });
  }
  subscribe(e) {
    return pn(this, void 0, void 0, function* () {
      return Be({ channel_id: e }), yield fn(this, hi, "f").engage("subscription/subscribe", { channel_id: e });
    });
  }
  unsubscribe(e) {
    return pn(this, void 0, void 0, function* () {
      return Be({ channel_id: e }), yield fn(this, hi, "f").engage("subscription/unsubscribe", { channel_id: e });
    });
  }
  comment(e, t) {
    return pn(this, void 0, void 0, function* () {
      return Be({ video_id: e, text: t }), yield fn(this, hi, "f").engage("comment/create_comment", { video_id: e, text: t });
    });
  }
  translate(e, t, i = {}) {
    return pn(this, void 0, void 0, function* () {
      Be({ text: e, target_language: t });
      const n = yield yield fn(this, hi, "f").engage("comment/perform_comment_action", {
        video_id: i.video_id,
        comment_id: i.comment_id,
        target_language: t,
        comment_action: "translate",
        text: e
      }), s = n.data.frameworkUpdates.entityBatchUpdate.mutations[0].payload.commentEntityPayload;
      return {
        success: n.success,
        status_code: n.status_code,
        translated_content: s.translatedContent.content,
        data: n.data
      };
    });
  }
  setNotificationPreferences(e, t) {
    return pn(this, void 0, void 0, function* () {
      return Be({ channel_id: e, type: t }), yield fn(this, hi, "f").notifications("modify_channel_preference", { channel_id: e, pref: t || "NONE" });
    });
  }
};
l(Tw, "InteractionManager");
hi = /* @__PURE__ */ new WeakMap();
var ux = Tw, cx = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, F1 = function(e, t, i, n) {
  if (i === "a" && !n)
    throw new TypeError("Private accessor was defined without a getter");
  if (typeof t == "function" ? e !== t || !n : !t.has(e))
    throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return i === "m" ? n : i === "a" ? n.call(e) : n ? n.value : t.get(e);
}, hx = function(e, t, i, n, s) {
  if (n === "m")
    throw new TypeError("Private method is not writable");
  if (n === "a" && !s)
    throw new TypeError("Private accessor was defined without a setter");
  if (typeof t == "function" ? e !== t || !s : !t.has(e))
    throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return n === "a" ? s.call(e, i) : s ? s.value = i : t.set(e, i), i;
}, Qs, xw = class extends On {
  constructor(e, t, i = !1) {
    super(e, t, i), Qs.set(this, void 0);
  }
  get filter_chips() {
    var e, t;
    if (F1(this, Qs, "f"))
      return F1(this, Qs, "f") || [];
    if (((e = this.memo.getType(X1)) === null || e === void 0 ? void 0 : e.length) > 1)
      throw new x("There are too many feed filter chipbars, you'll need to find the correct one yourself in this.page");
    if (((t = this.memo.getType(X1)) === null || t === void 0 ? void 0 : t.length) === 0)
      throw new x("There are no feed filter chipbars");
    return hx(this, Qs, this.memo.getType(jo), "f"), F1(this, Qs, "f") || [];
  }
  get filters() {
    return this.filter_chips.map((e) => e.text.toString()) || [];
  }
  getFilteredFeed(e) {
    var t;
    return cx(this, void 0, void 0, function* () {
      let i;
      if (typeof e == "string") {
        if (!this.filters.includes(e))
          throw new x("Filter not found", {
            available_filters: this.filters
          });
        i = this.filter_chips.find((s) => s.text.toString() === e);
      } else if (e.type === "ChipCloudChip")
        i = e;
      else
        throw new x("Invalid filter");
      if (!i)
        throw new x("Filter not found");
      if (i.is_selected)
        return this;
      const n = yield (t = i.endpoint) === null || t === void 0 ? void 0 : t.call(this.actions, void 0, !0);
      return new On(this.actions, n, !0);
    });
  }
};
l(xw, "FilterableFeed");
Qs = /* @__PURE__ */ new WeakMap();
var dx = xw, pt = function(e, t, i, n) {
  function s(r) {
    return r instanceof i ? r : new i(function(a) {
      a(r);
    });
  }
  return l(s, "adopt"), new (i || (i = Promise))(function(r, a) {
    function u(p) {
      try {
        h(n.next(p));
      } catch (m) {
        a(m);
      }
    }
    l(u, "fulfilled");
    function c(p) {
      try {
        h(n.throw(p));
      } catch (m) {
        a(m);
      }
    }
    l(c, "rejected");
    function h(p) {
      p.done ? r(p.value) : s(p.value).then(u, c);
    }
    l(h, "step"), h((n = n.apply(e, t || [])).next());
  });
}, Ev = class {
  constructor(e) {
    this.session = e, this.account = new rx(this.session.actions), this.playlist = new ax(this.session.actions), this.interact = new ux(this.session.actions), this.music = new zT(this.session), this.studio = new YT(this.session), this.actions = this.session.actions;
  }
  static create(e = {}) {
    return pt(this, void 0, void 0, function* () {
      return new Ev(yield Ml.create(e));
    });
  }
  getInfo(e, t) {
    return pt(this, void 0, void 0, function* () {
      const i = vs(16), n = yield this.actions.getVideoInfo(e, i, t), s = this.actions.next({ video_id: e }), r = yield Promise.all([n, s]);
      return new g2(r, this.actions, this.session.player, i);
    });
  }
  getBasicInfo(e, t) {
    return pt(this, void 0, void 0, function* () {
      const i = vs(16), n = yield this.actions.getVideoInfo(e, i, t);
      return new g2([n], this.actions, this.session.player, i);
    });
  }
  search(e, t = {}) {
    return pt(this, void 0, void 0, function* () {
      Be({ query: e });
      const i = yield this.actions.search({ query: e, filters: t });
      return new W8(this.actions, i.data);
    });
  }
  getSearchSuggestions(e) {
    return pt(this, void 0, void 0, function* () {
      Be({ query: e });
      const t = new URL(`${pe.URLS.YT_SUGGESTIONS}search`);
      t.searchParams.set("q", e), t.searchParams.set("hl", this.session.context.client.hl), t.searchParams.set("gl", this.session.context.client.gl), t.searchParams.set("ds", "yt"), t.searchParams.set("client", "youtube"), t.searchParams.set("xssi", "t"), t.searchParams.set("oe", "UTF");
      const n = yield (yield this.session.http.fetch(t)).text();
      return JSON.parse(n.replace(")]}'", ""))[1].map((a) => a[0]);
    });
  }
  getComments(e, t) {
    return pt(this, void 0, void 0, function* () {
      Be({ video_id: e });
      const i = Rt.encodeCommentsSectionParams(e, {
        sort_by: t || "TOP_COMMENTS"
      }), n = yield this.actions.next({ ctoken: i });
      return new Y8(this.actions, n.data);
    });
  }
  getHomeFeed() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEwhat_to_watch");
      return new dx(this.actions, e.data);
    });
  }
  getLibrary() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FElibrary");
      return new K8(e.data, this.actions);
    });
  }
  getHistory() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEhistory");
      return new O_(this.actions, e.data);
    });
  }
  getTrending() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEtrending");
      return new D_(this.actions, e.data);
    });
  }
  getSubscriptionsFeed() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.browse("FEsubscriptions");
      return new On(this.actions, e.data);
    });
  }
  getChannel(e) {
    return pt(this, void 0, void 0, function* () {
      Be({ id: e });
      const t = yield this.actions.browse(e);
      return new G8(this.actions, t.data);
    });
  }
  getNotifications() {
    return pt(this, void 0, void 0, function* () {
      const e = yield this.actions.notifications("get_notification_menu");
      return new J8(this.actions, e);
    });
  }
  getUnseenNotificationsCount() {
    return pt(this, void 0, void 0, function* () {
      return (yield this.actions.notifications("get_unseen_count")).data.unseenCount;
    });
  }
  getPlaylist(e) {
    return pt(this, void 0, void 0, function* () {
      Be({ id: e });
      const t = yield this.actions.browse(`VL${e.replace(/VL/g, "")}`);
      return new Rl(this.actions, t.data);
    });
  }
  getStreamingData(e, t = {}) {
    return pt(this, void 0, void 0, function* () {
      return (yield this.getBasicInfo(e)).chooseFormat(t);
    });
  }
  download(e, t) {
    return pt(this, void 0, void 0, function* () {
      return (yield this.getBasicInfo(e, t == null ? void 0 : t.client)).download(t);
    });
  }
  call(e, t) {
    return e.callTest(this.actions, t);
  }
};
l(Ev, "Innertube");
var px = Ev;
const Bu = px.create({
  cookie: document.cookie,
  fetch: (...e) => fetch(...e)
});
async function fx() {
  const t = await (await Bu).getLibrary();
  return (await Promise.all(t.playlists.contents.map(gx))).filter((n) => n.title != "Favorites");
}
async function mx(e) {
  await (await Bu).playlist.addVideos("WL", [e]);
}
async function vx(e) {
  await (await Bu).playlist.removeVideos("WL", [e]);
}
async function gx(e) {
  const t = await Bu;
  return {
    author: Ew(e.author),
    id: e.id,
    title: e.title.text,
    videos: (await t.getPlaylist(e.id)).items.map(yx).reverse()
  };
}
function yx(e) {
  return {
    author: Ew(e.author),
    duration: e.duration.text,
    id: e.id,
    thumbnail: e.thumbnails[0],
    title: e.title.text
  };
}
function Ew(e) {
  return {
    id: e.id,
    name: e.name,
    url: e.url
  };
}
function _x(e) {
  ws(e, "svelte-wei49c", "div.svelte-wei49c{display:grid;grid-template-columns:1fr;grid-template-rows:auto 1fr;height:100%}");
}
const bx = (e) => ({ selected: e & 1 }), I2 = (e) => ({ selected: e[0] }), wx = (e) => ({ selected: e & 1 }), P2 = (e) => ({
  select: e[1],
  selected: e[0]
});
function Sx(e) {
  let t, i, n;
  const s = e[4].tabs, r = u5(s, e, e[3], P2), a = e[4].contents, u = u5(a, e, e[3], I2);
  return {
    c() {
      t = Ee("div"), r && r.c(), i = yi(), u && u.c(), q(t, "class", "svelte-wei49c");
    },
    m(c, h) {
      qe(c, t, h), r && r.m(t, null), me(t, i), u && u.m(t, null), n = !0;
    },
    p(c, [h]) {
      r && r.p && (!n || h & 9) && h5(
        r,
        s,
        c,
        c[3],
        n ? c5(s, c[3], h, wx) : d5(c[3]),
        P2
      ), u && u.p && (!n || h & 9) && h5(
        u,
        a,
        c,
        c[3],
        n ? c5(a, c[3], h, bx) : d5(c[3]),
        I2
      );
    },
    i(c) {
      n || (Ve(r, c), Ve(u, c), n = !0);
    },
    o(c) {
      Ke(r, c), Ke(u, c), n = !1;
    },
    d(c) {
      c && We(t), r && r.d(c), u && u.d(c);
    }
  };
}
function Cx(e, t, i) {
  let { $$slots: n = {}, $$scope: s } = t, { initial: r = void 0 } = t, { selected: a = r } = t;
  const u = Kw();
  function c(h) {
    return function() {
      const p = a;
      i(0, a = h), u("change", { old: p, new: h });
    };
  }
  return e.$$set = (h) => {
    "initial" in h && i(2, r = h.initial), "selected" in h && i(0, a = h.selected), "$$scope" in h && i(3, s = h.$$scope);
  }, [a, c, r, s, n];
}
class Tx extends Xt {
  constructor(t) {
    super(), Yt(this, t, Cx, Sx, Ot, { initial: 2, selected: 0 }, _x);
  }
  get initial() {
    return this.$$.ctx[2];
  }
  set initial(t) {
    this.$$set({ initial: t }), xt();
  }
  get selected() {
    return this.$$.ctx[0];
  }
  set selected(t) {
    this.$$set({ selected: t }), xt();
  }
}
function xx(e) {
  let t, i = '<path fill="currentColor" d="m13.41 12l4.3-4.29a1 1 0 1 0-1.42-1.42L12 10.59l-4.29-4.3a1 1 0 0 0-1.42 1.42l4.3 4.29l-4.3 4.29a1 1 0 0 0 0 1.42a1 1 0 0 0 1.42 0l4.29-4.3l4.29 4.3a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return {
    c() {
      t = zo("svg"), Ui(t, s);
    },
    m(r, a) {
      qe(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Ss(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: Se,
    o: Se,
    d(r) {
      r && We(t);
    }
  };
}
function Ex(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ht(ht({}, t), Fi(n)));
  }, t = Fi(t), [t];
}
class Ax extends Xt {
  constructor(t) {
    super(), Yt(this, t, Ex, xx, Ot, {});
  }
}
function kx(e) {
  let t, i = '<circle cx="4" cy="7" r="1" fill="currentColor"/><circle cx="4" cy="12" r="1" fill="currentColor"/><circle cx="4" cy="17" r="1" fill="currentColor"/><rect width="14" height="2" x="7" y="11" fill="currentColor" rx=".94" ry=".94"/><rect width="14" height="2" x="7" y="16" fill="currentColor" rx=".94" ry=".94"/><rect width="14" height="2" x="7" y="6" fill="currentColor" rx=".94" ry=".94"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return {
    c() {
      t = zo("svg"), Ui(t, s);
    },
    m(r, a) {
      qe(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Ss(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: Se,
    o: Se,
    d(r) {
      r && We(t);
    }
  };
}
function Ix(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ht(ht({}, t), Fi(n)));
  }, t = Fi(t), [t];
}
class Px extends Xt {
  constructor(t) {
    super(), Yt(this, t, Ix, kx, Ot, {});
  }
}
function Mx(e) {
  ws(e, "svelte-1hgrnh8", '.sub2lists-video.svelte-1hgrnh8.svelte-1hgrnh8{display:flex;flex-direction:column;gap:0.5rem;position:relative}#title.svelte-1hgrnh8.svelte-1hgrnh8{font-family:"Roboto", "Arial", sans-serif;font-size:1.4em;font-weight:500;overflow:hidden;display:block;-webkit-line-clamp:2;display:box;display:-webkit-box;-webkit-box-orient:vertical;text-overflow:ellipsis;white-space:normal}#watchlater.svelte-1hgrnh8.svelte-1hgrnh8{opacity:0;transition:opacity ease-in-out 0.15s;background:rgba(10, 10, 10, 0.85);height:30px;padding:2px;border-radius:3px;position:absolute;top:0.5rem;right:0.5rem;border:0;fill:lightgray;cursor:pointer;font-weight:bold;color:white}.sub2lists-video.svelte-1hgrnh8:hover #watchlater.svelte-1hgrnh8{opacity:1}.sub2lists-video.svelte-1hgrnh8 #watchlater[data-added="true"] svg.svelte-1hgrnh8{display:none}.sub2lists-video.svelte-1hgrnh8 #watchlater span.svelte-1hgrnh8{display:none}.sub2lists-video.svelte-1hgrnh8 #watchlater[data-added="true"] span.svelte-1hgrnh8{display:initial}#watchlater.svelte-1hgrnh8 span.svelte-1hgrnh8{margin:0 3px}#thumbnail.svelte-1hgrnh8.svelte-1hgrnh8{position:relative}#thumbnail.svelte-1hgrnh8 img.svelte-1hgrnh8{width:100%}#duration.svelte-1hgrnh8.svelte-1hgrnh8{color:white;position:absolute;right:0.5rem;bottom:0.5rem;background-color:rgba(10, 10, 10, 0.85);padding:3px 5px;border-radius:3px;font-weight:bold}a.svelte-1hgrnh8.svelte-1hgrnh8{text-decoration:none;color:var(--yt-spec-text-primary)}svg.svelte-1hgrnh8.svelte-1hgrnh8{pointer-events:none;width:100%;height:100%}');
}
function Nx(e) {
  let t, i, n, s, r, a, u, c, h, p, m, b, C, k, D, I = e[0].name + "", $, O, F, K;
  return {
    c() {
      t = Ee("div"), i = Ee("a"), n = Ee("div"), s = Ee("button"), s.innerHTML = `<span class="svelte-1hgrnh8">Added!</span> 
				<svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope yt-icon svelte-1hgrnh8"><g class="style-scope yt-icon"><path d="M14.97,16.95L10,13.87V7h2v5.76l4.03,2.49L14.97,16.95z M12,3c-4.96,0-9,4.04-9,9s4.04,9,9,9s9-4.04,9-9S16.96,3,12,3 M12,2c5.52,0,10,4.48,10,10s-4.48,10-10,10S2,17.52,2,12S6.48,2,12,2L12,2z" class="style-scope yt-icon"></path></g></svg>`, r = yi(), a = Ee("img"), c = yi(), h = Ee("span"), p = Dt(e[2]), m = yi(), b = Ee("span"), C = Dt(e[1]), k = yi(), D = Ee("a"), $ = Dt(I), q(s, "id", "watchlater"), q(s, "title", "Add to watch later"), q(s, "class", "svelte-1hgrnh8"), l5(a.src, u = e[3].url) || q(a, "src", u), q(a, "alt", e[1]), q(a, "class", "svelte-1hgrnh8"), q(h, "id", "duration"), q(h, "class", "svelte-1hgrnh8"), q(n, "id", "thumbnail"), q(n, "class", "svelte-1hgrnh8"), q(b, "id", "title"), q(b, "title", e[1]), q(b, "class", "svelte-1hgrnh8"), q(D, "id", "author"), q(D, "href", O = e[0].url), q(D, "class", "svelte-1hgrnh8"), q(i, "href", e[4]), q(i, "class", "svelte-1hgrnh8"), q(t, "class", "sub2lists-video svelte-1hgrnh8");
    },
    m(M, v) {
      qe(M, t, v), me(t, i), me(i, n), me(n, s), me(n, r), me(n, a), me(n, c), me(n, h), me(h, p), me(i, m), me(i, b), me(b, C), me(i, k), me(i, D), me(D, $), F || (K = Vi(s, "click", xc(e[5])), F = !0);
    },
    p(M, [v]) {
      v & 8 && !l5(a.src, u = M[3].url) && q(a, "src", u), v & 2 && q(a, "alt", M[1]), v & 4 && ir(p, M[2]), v & 2 && ir(C, M[1]), v & 2 && q(b, "title", M[1]), v & 1 && I !== (I = M[0].name + "") && ir($, I), v & 1 && O !== (O = M[0].url) && q(D, "href", O), v & 16 && q(i, "href", M[4]);
    },
    i: Se,
    o: Se,
    d(M) {
      M && We(t), F = !1, K();
    }
  };
}
function Rx(e, t, i) {
  let n, { author: s } = t, { title: r } = t, { id: a } = t, { duration: u } = t, { thumbnail: c } = t;
  async function h() {
    this.dataset.added ? (await vx(a), delete this.dataset.added) : (await mx(a), this.dataset.added = "true");
  }
  return e.$$set = (p) => {
    "author" in p && i(0, s = p.author), "title" in p && i(1, r = p.title), "id" in p && i(6, a = p.id), "duration" in p && i(2, u = p.duration), "thumbnail" in p && i(3, c = p.thumbnail);
  }, e.$$.update = () => {
    e.$$.dirty & 64 && i(4, n = `https://www.youtube.com/watch?v=${a}`);
  }, [s, r, u, c, n, h, a];
}
class Lx extends Xt {
  constructor(t) {
    super(), Yt(
      this,
      t,
      Rx,
      Nx,
      Ot,
      {
        author: 0,
        title: 1,
        id: 6,
        duration: 2,
        thumbnail: 3
      },
      Mx
    );
  }
  get author() {
    return this.$$.ctx[0];
  }
  set author(t) {
    this.$$set({ author: t }), xt();
  }
  get title() {
    return this.$$.ctx[1];
  }
  set title(t) {
    this.$$set({ title: t }), xt();
  }
  get id() {
    return this.$$.ctx[6];
  }
  set id(t) {
    this.$$set({ id: t }), xt();
  }
  get duration() {
    return this.$$.ctx[2];
  }
  set duration(t) {
    this.$$set({ duration: t }), xt();
  }
  get thumbnail() {
    return this.$$.ctx[3];
  }
  set thumbnail(t) {
    this.$$set({ thumbnail: t }), xt();
  }
}
function Dx(e) {
  let t, i = '<path fill="currentColor" d="M6.09 19h12l-1.3 1.29a1 1 0 0 0 1.42 1.42l3-3a1 1 0 0 0 0-1.42l-3-3a1 1 0 0 0-1.42 0a1 1 0 0 0 0 1.42l1.3 1.29h-12a1.56 1.56 0 0 1-1.59-1.53V13a1 1 0 0 0-2 0v2.47A3.56 3.56 0 0 0 6.09 19Zm-.3-9.29a1 1 0 1 0 1.42-1.42L5.91 7h12a1.56 1.56 0 0 1 1.59 1.53V11a1 1 0 0 0 2 0V8.53A3.56 3.56 0 0 0 17.91 5h-12l1.3-1.29a1 1 0 0 0 0-1.42a1 1 0 0 0-1.42 0l-3 3a1 1 0 0 0 0 1.42Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return {
    c() {
      t = zo("svg"), Ui(t, s);
    },
    m(r, a) {
      qe(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Ss(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: Se,
    o: Se,
    d(r) {
      r && We(t);
    }
  };
}
function Bx(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ht(ht({}, t), Fi(n)));
  }, t = Fi(t), [t];
}
class Ox extends Xt {
  constructor(t) {
    super(), Yt(this, t, Bx, Dx, Ot, {});
  }
}
function Fx(e) {
  let t, i = '<path fill="currentColor" d="M21.87 11.5c-.64-1.11-4.16-6.68-10.14-6.5c-5.53.14-8.73 5-9.6 6.5a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25c5.53-.14 8.74-5 9.6-6.5a1 1 0 0 0 0-1ZM12.22 17c-4.31.1-7.12-3.59-8-5c1-1.61 3.61-4.9 7.61-5c4.29-.11 7.11 3.59 8 5c-1.03 1.61-3.61 4.9-7.61 5Z"/><path fill="currentColor" d="M12 8.5a3.5 3.5 0 1 0 3.5 3.5A3.5 3.5 0 0 0 12 8.5Zm0 5a1.5 1.5 0 1 1 1.5-1.5a1.5 1.5 0 0 1-1.5 1.5Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return {
    c() {
      t = zo("svg"), Ui(t, s);
    },
    m(r, a) {
      qe(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Ss(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: Se,
    o: Se,
    d(r) {
      r && We(t);
    }
  };
}
function Vx(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ht(ht({}, t), Fi(n)));
  }, t = Fi(t), [t];
}
class Aw extends Xt {
  constructor(t) {
    super(), Yt(this, t, Vx, Fx, Ot, {});
  }
}
function Ux(e) {
  let t, i = '<path fill="currentColor" d="M4.71 3.29a1 1 0 0 0-1.42 1.42l5.63 5.63a3.5 3.5 0 0 0 4.74 4.74l5.63 5.63a1 1 0 0 0 1.42 0a1 1 0 0 0 0-1.42ZM12 13.5a1.5 1.5 0 0 1-1.5-1.5s0-.05 0-.07l1.56 1.56Z"/><path fill="currentColor" d="M12.22 17c-4.3.1-7.12-3.59-8-5a13.7 13.7 0 0 1 2.24-2.72L5 7.87a15.89 15.89 0 0 0-2.87 3.63a1 1 0 0 0 0 1c.63 1.09 4 6.5 9.89 6.5h.25a9.48 9.48 0 0 0 3.23-.67l-1.58-1.58a7.74 7.74 0 0 1-1.7.25Zm9.65-5.5c-.64-1.11-4.17-6.68-10.14-6.5a9.48 9.48 0 0 0-3.23.67l1.58 1.58a7.74 7.74 0 0 1 1.7-.25c4.29-.11 7.11 3.59 8 5a13.7 13.7 0 0 1-2.29 2.72L19 16.13a15.89 15.89 0 0 0 2.91-3.63a1 1 0 0 0-.04-1Z"/>', n = [
    { viewBox: "0 0 24 24" },
    { width: "1.2em" },
    { height: "1.2em" },
    e[0]
  ], s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return {
    c() {
      t = zo("svg"), Ui(t, s);
    },
    m(r, a) {
      qe(r, t, a), t.innerHTML = i;
    },
    p(r, [a]) {
      Ui(t, s = Ss(n, [
        { viewBox: "0 0 24 24" },
        { width: "1.2em" },
        { height: "1.2em" },
        a & 1 && r[0]
      ]));
    },
    i: Se,
    o: Se,
    d(r) {
      r && We(t);
    }
  };
}
function jx(e, t, i) {
  return e.$$set = (n) => {
    i(0, t = ht(ht({}, t), Fi(n)));
  }, t = Fi(t), [t];
}
class Hx extends Xt {
  constructor(t) {
    super(), Yt(this, t, jx, Ux, Ot, {});
  }
}
const Bs = [];
function Wx(e, t = Se) {
  let i;
  const n = /* @__PURE__ */ new Set();
  function s(u) {
    if (Ot(e, u) && (e = u, i)) {
      const c = !Bs.length;
      for (const h of n)
        h[1](), Bs.push(h, e);
      if (c) {
        for (let h = 0; h < Bs.length; h += 2)
          Bs[h][0](Bs[h + 1]);
        Bs.length = 0;
      }
    }
  }
  function r(u) {
    s(u(e));
  }
  function a(u, c = Se) {
    const h = [u, c];
    return n.add(h), n.size === 1 && (i = t(s) || Se), u(e), () => {
      n.delete(h), n.size === 0 && (i(), i = null);
    };
  }
  return { set: s, update: r, subscribe: a };
}
let kw = "svelteStore";
const $x = (e) => {
  if (typeof window === void 0 || !localStorage)
    return;
  const t = localStorage.getItem(e);
  return t === void 0 ? "" : JSON.parse(t);
}, Gx = (e, t) => {
  typeof window === void 0 || !localStorage || localStorage.setItem(e, JSON.stringify(t));
}, qx = (e, t) => (t.subscribe((i) => {
  Gx(e, i);
}), t), zx = (e) => {
  kw = e;
}, Iw = (e, t, i = !0) => {
  const n = `${kw}-${e}`;
  let s = t;
  return i && (s = $x(n) || t), qx(n, Wx(s));
};
zx("sub2lists");
const Tc = Iw("hiddenIDs", []), M2 = Iw("reversedIDs", []);
function N2(e, t) {
  return e.includes(t) ? e.filter((i) => i != t) : [...e, t];
}
function Kx(e) {
  ws(e, "svelte-k9k2i4", "a.svelte-k9k2i4.svelte-k9k2i4{text-decoration:none;color:var(--yt-spec-text-primary)}#title.svelte-k9k2i4.svelte-k9k2i4{display:flex;align-items:center;gap:1rem;font-size:2em;font-weight:500;margin-bottom:0.5rem}button.svelte-k9k2i4.svelte-k9k2i4{all:initial;cursor:pointer;font-size:2rem;display:flex;color:inherit}.right.svelte-k9k2i4.svelte-k9k2i4{margin-left:auto}#hide.svelte-k9k2i4.svelte-k9k2i4{opacity:0.3;transition:opacity ease-in-out 0.15s}#hide.svelte-k9k2i4.svelte-k9k2i4:hover{opacity:1}#videos.svelte-k9k2i4.svelte-k9k2i4{display:grid;gap:1rem;overflow-x:auto;scrollbar-width:thin;grid-auto-columns:250px;grid-auto-flow:column;padding:0.5rem}#videos.svelte-k9k2i4 p.svelte-k9k2i4{font-size:2rem;margin:3rem;grid-column:span 2}");
}
function R2(e, t, i) {
  const n = e.slice();
  return n[13] = t[i], n;
}
function Yx(e) {
  let t, i, n, s, r;
  return i = new Aw({}), {
    c() {
      t = Ee("button"), bi(i.$$.fragment), q(t, "class", "right svelte-k9k2i4"), q(t, "id", "hide"), q(t, "title", "Hide playlist");
    },
    m(a, u) {
      qe(a, t, u), si(i, t, null), n = !0, s || (r = Vi(t, "click", e[6]), s = !0);
    },
    p: Se,
    i(a) {
      n || (Ve(i.$$.fragment, a), n = !0);
    },
    o(a) {
      Ke(i.$$.fragment, a), n = !1;
    },
    d(a) {
      a && We(t), ri(i), s = !1, r();
    }
  };
}
function Xx(e) {
  let t, i, n, s, r;
  return i = new Hx({}), {
    c() {
      t = Ee("button"), bi(i.$$.fragment), q(t, "class", "right svelte-k9k2i4"), q(t, "title", "Show playlist");
    },
    m(a, u) {
      qe(a, t, u), si(i, t, null), n = !0, s || (r = Vi(t, "click", e[6]), s = !0);
    },
    p: Se,
    i(a) {
      n || (Ve(i.$$.fragment, a), n = !0);
    },
    o(a) {
      Ke(i.$$.fragment, a), n = !1;
    },
    d(a) {
      a && We(t), ri(i), s = !1, r();
    }
  };
}
function L2(e) {
  let t;
  return {
    c() {
      t = Ee("p"), t.textContent = "This playlist contains no videos.", q(t, "class", "svelte-k9k2i4");
    },
    m(i, n) {
      qe(i, t, n);
    },
    p: Se,
    d(i) {
      i && We(t);
    }
  };
}
function D2(e) {
  let t, i;
  const n = [e[13]];
  let s = {};
  for (let r = 0; r < n.length; r += 1)
    s = ht(s, n[r]);
  return t = new Lx({ props: s }), {
    c() {
      bi(t.$$.fragment);
    },
    m(r, a) {
      si(t, r, a), i = !0;
    },
    p(r, a) {
      const u = a & 4 ? Ss(n, [q2(r[13])]) : {};
      t.$set(u);
    },
    i(r) {
      i || (Ve(t.$$.fragment, r), i = !0);
    },
    o(r) {
      Ke(t.$$.fragment, r), i = !1;
    },
    d(r) {
      ri(t, r);
    }
  };
}
function Jx(e) {
  let t, i, n, s, r, a, u, c = e[0].name + "", h, p, m, b, C, k, D, I, $, O, F, K, M;
  C = new Ox({});
  const v = [Xx, Yx], H = [];
  function ce(ee, ve) {
    return ee[3] ? 0 : 1;
  }
  D = ce(e), I = H[D] = v[D](e);
  let ae = e[2], Q = [];
  for (let ee = 0; ee < ae.length; ee += 1)
    Q[ee] = D2(R2(e, ae, ee));
  const Xe = (ee) => Ke(Q[ee], 1, 1, () => {
    Q[ee] = null;
  });
  let J = null;
  return ae.length || (J = L2()), {
    c() {
      t = Ee("div"), i = Ee("p"), n = Ee("a"), s = Dt(e[1]), r = Dt(" - "), a = Ee("a"), u = Dt("by "), h = Dt(c), m = yi(), b = Ee("button"), bi(C.$$.fragment), k = yi(), I.c(), $ = yi(), O = Ee("div");
      for (let ee = 0; ee < Q.length; ee += 1)
        Q[ee].c();
      J && J.c(), q(n, "href", e[4]), q(n, "class", "svelte-k9k2i4"), q(a, "href", p = e[0].url), q(a, "class", "svelte-k9k2i4"), q(b, "title", "Reverse playlist order"), q(b, "class", "svelte-k9k2i4"), q(i, "id", "title"), q(i, "class", "svelte-k9k2i4"), q(O, "id", "videos"), q(O, "class", "svelte-k9k2i4");
    },
    m(ee, ve) {
      qe(ee, t, ve), me(t, i), me(i, n), me(n, s), me(i, r), me(i, a), me(a, u), me(a, h), me(i, m), me(i, b), si(C, b, null), me(i, k), H[D].m(i, null), me(t, $), me(t, O);
      for (let Je = 0; Je < Q.length; Je += 1)
        Q[Je].m(O, null);
      J && J.m(O, null), F = !0, K || (M = Vi(b, "click", e[5]), K = !0);
    },
    p(ee, [ve]) {
      (!F || ve & 2) && ir(s, ee[1]), (!F || ve & 16) && q(n, "href", ee[4]), (!F || ve & 1) && c !== (c = ee[0].name + "") && ir(h, c), (!F || ve & 1 && p !== (p = ee[0].url)) && q(a, "href", p);
      let Je = D;
      if (D = ce(ee), D === Je ? H[D].p(ee, ve) : (Oo(), Ke(H[Je], 1, 1, () => {
        H[Je] = null;
      }), Fo(), I = H[D], I ? I.p(ee, ve) : (I = H[D] = v[D](ee), I.c()), Ve(I, 1), I.m(i, null)), ve & 4) {
        ae = ee[2];
        let Ce;
        for (Ce = 0; Ce < ae.length; Ce += 1) {
          const nt = R2(ee, ae, Ce);
          Q[Ce] ? (Q[Ce].p(nt, ve), Ve(Q[Ce], 1)) : (Q[Ce] = D2(nt), Q[Ce].c(), Ve(Q[Ce], 1), Q[Ce].m(O, null));
        }
        for (Oo(), Ce = ae.length; Ce < Q.length; Ce += 1)
          Xe(Ce);
        Fo(), !ae.length && J ? J.p(ee, ve) : ae.length ? J && (J.d(1), J = null) : (J = L2(), J.c(), J.m(O, null));
      }
    },
    i(ee) {
      if (!F) {
        Ve(C.$$.fragment, ee), Ve(I);
        for (let ve = 0; ve < ae.length; ve += 1)
          Ve(Q[ve]);
        F = !0;
      }
    },
    o(ee) {
      Ke(C.$$.fragment, ee), Ke(I), Q = Q.filter(Boolean);
      for (let ve = 0; ve < Q.length; ve += 1)
        Ke(Q[ve]);
      F = !1;
    },
    d(ee) {
      ee && We(t), ri(C), H[D].d(), Gw(Q, ee), J && J.d(), K = !1, M();
    }
  };
}
function Zx(e, t, i) {
  let n, s, r, a, u, c;
  V1(e, Tc, (I) => i(10, u = I)), V1(e, M2, (I) => i(11, c = I));
  let { author: h } = t, { title: p } = t, { id: m } = t, { videos: b = [] } = t;
  function C(...I) {
    return s ? b.slice().reverse() : b;
  }
  function k() {
    p5(M2, c = N2(c, m), c);
  }
  function D() {
    p5(Tc, u = N2(u, m), u);
  }
  return e.$$set = (I) => {
    "author" in I && i(0, h = I.author), "title" in I && i(1, p = I.title), "id" in I && i(7, m = I.id), "videos" in I && i(8, b = I.videos);
  }, e.$$.update = () => {
    e.$$.dirty & 128 && i(4, n = `https://www.youtube.com/playlist?list=${m}`), e.$$.dirty & 2176 && i(9, s = c.includes(m)), e.$$.dirty & 1152 && i(3, r = u.includes(m)), e.$$.dirty & 768 && i(2, a = C(b, s));
  }, [
    h,
    p,
    a,
    r,
    n,
    k,
    D,
    m,
    b,
    s,
    u,
    c
  ];
}
class Qx extends Xt {
  constructor(t) {
    super(), Yt(this, t, Zx, Jx, Ot, { author: 0, title: 1, id: 7, videos: 8 }, Kx);
  }
  get author() {
    return this.$$.ctx[0];
  }
  set author(t) {
    this.$$set({ author: t }), xt();
  }
  get title() {
    return this.$$.ctx[1];
  }
  set title(t) {
    this.$$set({ title: t }), xt();
  }
  get id() {
    return this.$$.ctx[7];
  }
  set id(t) {
    this.$$set({ id: t }), xt();
  }
  get videos() {
    return this.$$.ctx[8];
  }
  set videos(t) {
    this.$$set({ videos: t }), xt();
  }
}
function eE(e) {
  ws(e, "svelte-m4seif", "p.svelte-m4seif{color:var(--yt-spec-text-primary);font-size:2em;font-weight:500;margin-bottom:0.5rem;display:flex;gap:1rem}button.svelte-m4seif{background:transparent;border:1px solid var(--yt-spec-text-primary);padding:0.5rem 1rem;font-size:1.5rem;display:flex;gap:0.5rem;align-items:center;color:inherit;transition:background-color ease-in-out 0.15s;cursor:pointer}button.svelte-m4seif:hover{background-color:var(--yt-spec-brand-background-solid)}");
}
function B2(e, t, i) {
  const n = e.slice();
  return n[6] = t[i], n;
}
function O2(e) {
  return { c: Se, m: Se, d: Se };
}
function F2(e, t) {
  let i, n, s;
  const r = [t[6]];
  let a = {};
  for (let u = 0; u < r.length; u += 1)
    a = ht(a, r[u]);
  return n = new Qx({ props: a }), {
    key: e,
    first: null,
    c() {
      i = W2(), bi(n.$$.fragment), this.first = i;
    },
    m(u, c) {
      qe(u, i, c), si(n, u, c), s = !0;
    },
    p(u, c) {
      t = u;
      const h = c & 4 ? Ss(r, [q2(t[6])]) : {};
      n.$set(h);
    },
    i(u) {
      s || (Ve(n.$$.fragment, u), s = !0);
    },
    o(u) {
      Ke(n.$$.fragment, u), s = !1;
    },
    d(u) {
      u && We(i), ri(n, u);
    }
  };
}
function V2(e) {
  let t, i, n, s, r, a, u, c, h, p;
  return a = new Aw({}), {
    c() {
      t = Ee("p"), i = Dt("Plus "), n = Dt(e[1]), s = Dt(` hidden playlist(s)
		`), r = Ee("button"), bi(a.$$.fragment), u = Dt(`
			Show`), q(r, "class", "svelte-m4seif"), q(t, "class", "svelte-m4seif");
    },
    m(m, b) {
      qe(m, t, b), me(t, i), me(t, n), me(t, s), me(t, r), si(a, r, null), me(r, u), c = !0, h || (p = Vi(r, "click", e[3]), h = !0);
    },
    p(m, b) {
      (!c || b & 2) && ir(n, m[1]);
    },
    i(m) {
      c || (Ve(a.$$.fragment, m), c = !0);
    },
    o(m) {
      Ke(a.$$.fragment, m), c = !1;
    },
    d(m) {
      m && We(t), ri(a), h = !1, p();
    }
  };
}
function tE(e) {
  let t = [], i = /* @__PURE__ */ new Map(), n, s, r, a = e[2];
  const u = (p) => p[6].id;
  for (let p = 0; p < a.length; p += 1) {
    let m = B2(e, a, p), b = u(m);
    i.set(b, t[p] = F2(b, m));
  }
  let c = null;
  a.length || (c = O2());
  let h = e[1] > 0 && !e[0] && V2(e);
  return {
    c() {
      for (let p = 0; p < t.length; p += 1)
        t[p].c();
      c && c.c(), n = yi(), h && h.c(), s = W2();
    },
    m(p, m) {
      for (let b = 0; b < t.length; b += 1)
        t[b].m(p, m);
      c && c.m(p, m), qe(p, n, m), h && h.m(p, m), qe(p, s, m), r = !0;
    },
    p(p, [m]) {
      m & 4 && (a = p[2], Oo(), t = e3(t, m, u, 1, p, a, i, n.parentNode, Qw, F2, n, B2), Fo(), a.length ? c && (c.d(1), c = null) : c || (c = O2(), c.c(), c.m(n.parentNode, n))), p[1] > 0 && !p[0] ? h ? (h.p(p, m), m & 3 && Ve(h, 1)) : (h = V2(p), h.c(), Ve(h, 1), h.m(s.parentNode, s)) : h && (Oo(), Ke(h, 1, 1, () => {
        h = null;
      }), Fo());
    },
    i(p) {
      if (!r) {
        for (let m = 0; m < a.length; m += 1)
          Ve(t[m]);
        Ve(h), r = !0;
      }
    },
    o(p) {
      for (let m = 0; m < t.length; m += 1)
        Ke(t[m]);
      Ke(h), r = !1;
    },
    d(p) {
      for (let m = 0; m < t.length; m += 1)
        t[m].d(p);
      c && c.d(p), p && We(n), h && h.d(p), p && We(s);
    }
  };
}
function iE(e, t, i) {
  let n, s, r;
  V1(e, Tc, (h) => i(5, r = h));
  let { playlists: a = [] } = t, u = !1;
  function c() {
    i(0, u = !u);
  }
  return e.$$set = (h) => {
    "playlists" in h && i(4, a = h.playlists);
  }, e.$$.update = () => {
    e.$$.dirty & 49 && i(2, n = a.filter((h) => u || !r.includes(h.id))), e.$$.dirty & 32 && i(1, s = r.length);
  }, [u, s, n, c, a, r];
}
class nE extends Xt {
  constructor(t) {
    super(), Yt(this, t, iE, tE, Ot, { playlists: 4 }, eE);
  }
  get playlists() {
    return this.$$.ctx[4];
  }
  set playlists(t) {
    this.$$set({ playlists: t }), xt();
  }
}
class sE extends Xt {
  constructor(t) {
    super(), Yt(this, t, null, null, Ot, {});
  }
}
function rE(e) {
  ws(e, "svelte-4svf7z", "#sub2lists-popup *::-webkit-scrollbar{width:9px;height:9px}#sub2lists-popup *::-webkit-scrollbar-track{background:transparent}#sub2lists-popup *::-webkit-scrollbar-thumb{background-color:rgba(155, 155, 155, 0.5);border:transparent}dialog.svelte-4svf7z.svelte-4svf7z{position:fixed;background:var(--yt-spec-general-background-a);color:var(--yt-spec-text-primary);border-color:var(--yt-spec-text-primary);width:90%;height:90%;font-size:1.2rem;padding:0}dialog.svelte-4svf7z .svelte-4svf7z{scrollbar-width:thin;box-sizing:border-box}dialog.svelte-4svf7z.svelte-4svf7z::backdrop{background-color:rgba(0, 0, 0, 0.25)}menu.svelte-4svf7z.svelte-4svf7z{display:flex;border-bottom:1px solid var(--yt-spec-text-primary);font-size:2rem}.tab.svelte-4svf7z.svelte-4svf7z{background-color:transparent;border:none;border-right:1px solid var(--yt-spec-text-primary);padding:1rem 1.5rem;color:inherit;font-size:2rem;cursor:pointer;display:flex;align-items:center;gap:0.5rem}.tab-close.svelte-4svf7z.svelte-4svf7z{border:none;border-left:1px solid var(--yt-spec-text-primary);margin-left:auto;padding:0.5rem;display:grid;place-items:center}.selected.svelte-4svf7z.svelte-4svf7z,menu.svelte-4svf7z button.svelte-4svf7z:hover{background-color:var(--yt-spec-badge-chip-background)}#playlists.svelte-4svf7z.svelte-4svf7z{display:flex;flex-direction:column;gap:3rem;overflow-y:auto;height:100%;padding:2rem 1rem}#playlists.svelte-4svf7z p.svelte-4svf7z{text-align:center;margin-top:5rem;font-size:3rem}.hidden.svelte-4svf7z.svelte-4svf7z{display:none !important}");
}
function oE(e) {
  let t, i, n, s, r, a, u, c, h, p;
  return n = new Px({}), u = new Ax({ props: { height: "3rem", width: "3rem" } }), {
    c() {
      t = Ee("menu"), i = Ee("button"), bi(n.$$.fragment), s = Dt(`
				Playlists`), r = yi(), a = Ee("button"), bi(u.$$.fragment), q(i, "class", "tab svelte-4svf7z"), i.autofocus = !0, er(i, "selected", !1), q(a, "class", "tab tab-close svelte-4svf7z"), q(t, "slot", "tabs"), q(t, "class", "svelte-4svf7z");
    },
    m(m, b) {
      qe(m, t, b), me(t, i), si(n, i, null), me(i, s), me(t, r), me(t, a), si(u, a, null), c = !0, i.focus(), h || (p = [
        Vi(i, "click", function() {
          j2(e[7]("playlists")) && e[7]("playlists").apply(this, arguments);
        }),
        Vi(a, "click", e[0])
      ], h = !0);
    },
    p(m, b) {
      e = m, (!c || b & 32) && er(i, "selected", !1);
    },
    i(m) {
      c || (Ve(n.$$.fragment, m), Ve(u.$$.fragment, m), c = !0);
    },
    o(m) {
      Ke(n.$$.fragment, m), Ke(u.$$.fragment, m), c = !1;
    },
    d(m) {
      m && We(t), ri(n), ri(u), h = !1, pr(p);
    }
  };
}
function aE(e) {
  let t;
  return {
    c() {
      t = Ee("p"), t.textContent = "Error!", q(t, "class", "svelte-4svf7z");
    },
    m(i, n) {
      qe(i, t, n);
    },
    p: Se,
    i: Se,
    o: Se,
    d(i) {
      i && We(t);
    }
  };
}
function lE(e) {
  let t, i;
  return t = new nE({
    props: { playlists: e[2] }
  }), {
    c() {
      bi(t.$$.fragment);
    },
    m(n, s) {
      si(t, n, s), i = !0;
    },
    p(n, s) {
      const r = {};
      s & 4 && (r.playlists = n[2]), t.$set(r);
    },
    i(n) {
      i || (Ve(t.$$.fragment, n), i = !0);
    },
    o(n) {
      Ke(t.$$.fragment, n), i = !1;
    },
    d(n) {
      ri(t, n);
    }
  };
}
function uE(e) {
  let t;
  return {
    c() {
      t = Ee("p"), t.textContent = "Loading...", q(t, "class", "svelte-4svf7z");
    },
    m(i, n) {
      qe(i, t, n);
    },
    p: Se,
    i: Se,
    o: Se,
    d(i) {
      i && We(t);
    }
  };
}
function cE(e) {
  let t, i, n, s, r, a, u = {
    ctx: e,
    current: null,
    token: null,
    hasCatch: !0,
    pending: uE,
    then: lE,
    catch: aE,
    value: 2,
    error: 6,
    blocks: [, , ,]
  };
  return m5(i = e[2], u), r = new sE({}), {
    c() {
      t = Ee("div"), u.block.c(), n = yi(), s = Ee("div"), bi(r.$$.fragment), q(t, "id", "playlists"), q(t, "class", "svelte-4svf7z"), er(t, "hidden", e[5] != "playlists"), q(s, "id", "settings"), q(s, "class", "svelte-4svf7z"), er(s, "hidden", e[5] != "settings");
    },
    m(c, h) {
      qe(c, t, h), u.block.m(t, u.anchor = null), u.mount = () => t, u.anchor = null, qe(c, n, h), qe(c, s, h), si(r, s, null), a = !0;
    },
    p(c, h) {
      e = c, u.ctx = e, h & 4 && i !== (i = e[2]) && m5(i, u) || Zw(u, e, h), (!a || h & 32) && er(t, "hidden", e[5] != "playlists"), (!a || h & 32) && er(s, "hidden", e[5] != "settings");
    },
    i(c) {
      a || (Ve(u.block), Ve(r.$$.fragment, c), a = !0);
    },
    o(c) {
      for (let h = 0; h < 3; h += 1) {
        const p = u.blocks[h];
        Ke(p);
      }
      Ke(r.$$.fragment, c), a = !1;
    },
    d(c) {
      c && We(t), u.block.d(), u.token = null, u = null, c && We(n), c && We(s), ri(r);
    }
  };
}
function hE(e) {
  let t, i, n, s, r;
  return i = new Tx({
    props: {
      initial: "playlists",
      $$slots: {
        contents: [
          cE,
          ({ selected: a }) => ({ 5: a }),
          ({ selected: a }) => a ? 32 : 0
        ],
        tabs: [
          oE,
          ({ select: a, selected: u }) => ({ 7: a, 5: u }),
          ({ select: a, selected: u }) => (a ? 128 : 0) | (u ? 32 : 0)
        ]
      },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      t = Ee("dialog"), bi(i.$$.fragment), q(t, "id", "sub2lists-popup"), q(t, "class", "svelte-4svf7z");
    },
    m(a, u) {
      qe(a, t, u), si(i, t, null), e[4](t), n = !0, s || (r = Vi(t, "close", e[0]), s = !0);
    },
    p(a, [u]) {
      const c = {};
      u & 420 && (c.$$scope = { dirty: u, ctx: a }), i.$set(c);
    },
    i(a) {
      n || (Ve(i.$$.fragment, a), n = !0);
    },
    o(a) {
      Ke(i.$$.fragment, a), n = !1;
    },
    d(a) {
      a && We(t), ri(i), e[4](null), s = !1, r();
    }
  };
}
function dE(e, t, i) {
  const n = () => {
    r.showModal(), i(2, a = fx()), document.body.style.overflow = "hidden";
  }, s = () => {
    r.close(), document.body.style.removeProperty("overflow");
  };
  let r, a = new Promise(() => {
  });
  function u(c) {
    U1[c ? "unshift" : "push"](() => {
      r = c, i(1, r);
    });
  }
  return [s, r, a, n, u];
}
class CE extends Xt {
  constructor(t) {
    super(), Yt(this, t, dE, hE, Ot, { show: 3, hide: 0 }, rE);
  }
  get show() {
    return this.$$.ctx[3];
  }
  get hide() {
    return this.$$.ctx[0];
  }
}
function pE(e) {
  ws(e, "svelte-jlf91o", "a.svelte-jlf91o{text-decoration:none;color:var(--yt-spec-text-primary)}#wrapper.svelte-jlf91o{padding:0 24px;min-width:0;height:var(--paper-item-min-height, 48px);display:flex;align-items:center;color:var(--yt-spec-brand-icon-inactive)}#icon.svelte-jlf91o{width:24px;height:24px;margin-right:24px}svg.svelte-jlf91o{pointer-events:none;display:block;width:100%;height:100%;fill:var(--yt-spec-brand-icon-inactive)}");
}
function fE(e) {
  let t, i, n, s;
  return {
    c() {
      t = Ee("div"), i = Ee("a"), i.innerHTML = `<div id="wrapper" class="svelte-jlf91o"><div id="icon" class="svelte-jlf91o"><svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope yt-icon svelte-jlf91o"><g class="style-scope yt-icon"><path d="M22,7H2v1h20V7z M13,12H2v-1h11V12z M13,16H2v-1h11V16z M15,19v-8l7,4L15,19z" class="style-scope yt-icon"></path></g></svg></div>
			Playlists</div>`, q(i, "href", "/feed/playlists"), q(i, "class", "yt-simple-endpoint style-scope ytd-guide-entry-renderer svelte-jlf91o"), q(i, "id", "endpoint"), q(t, "id", "sub2lists-menuitem"), q(t, "class", "title ytd-guide-entry-renderer");
    },
    m(r, a) {
      qe(r, t, a), me(t, i), n || (s = Vi(i, "click", xc(e[0])), n = !0);
    },
    p: Se,
    i: Se,
    o: Se,
    d(r) {
      r && We(t), n = !1, s();
    }
  };
}
function mE(e) {
  function t(i) {
    G2.call(this, e, i);
  }
  return [t];
}
class TE extends Xt {
  constructor(t) {
    super(), Yt(this, t, mE, fE, Ot, {}, pE);
  }
}
function vE(e) {
  ws(e, "svelte-imddul", ".ytd-mini-guide-renderer.svelte-imddul{background-color:var(--yt-spec-brand-background-solid)}.ytd-mini-guide-renderer.svelte-imddul:hover{background-color:var(--yt-spec-badge-chip-background);outline:none}#wrapper.svelte-imddul{width:24px;height:24px;margin-bottom:6px}svg.svelte-imddul{pointer-events:none;display:block;width:100%;height:100%;fill:var(--yt-spec-brand-icon-inactive)}");
}
function gE(e) {
  let t, i, n, s;
  return {
    c() {
      t = Ee("div"), i = Ee("a"), i.innerHTML = `<div id="wrapper" class="svelte-imddul"><svg viewBox="0 0 24 24" preserveAspectRatio="xMidYMid meet" focusable="false" class="style-scope yt-icon svelte-imddul"><g class="style-scope yt-icon"><path d="M22,7H2v1h20V7z M13,12H2v-1h11V12z M13,16H2v-1h11V16z M15,19v-8l7,4L15,19z" class="style-scope yt-icon"></path></g></svg></div>
		Playlists`, q(i, "id", "endpoint"), q(i, "class", "yt-simple-endpoint style-scope ytd-mini-guide-entry-renderer"), q(t, "id", "sub2lists-menuitem-mini"), q(t, "class", "style-scope ytd-mini-guide-renderer svelte-imddul");
    },
    m(r, a) {
      qe(r, t, a), me(t, i), n || (s = Vi(i, "click", xc(e[0])), n = !0);
    },
    p: Se,
    i: Se,
    o: Se,
    d(r) {
      r && We(t), n = !1, s();
    }
  };
}
function yE(e) {
  function t(i) {
    G2.call(this, e, i);
  }
  return [t];
}
class xE extends Xt {
  constructor(t) {
    super(), Yt(this, t, yE, gE, Ot, {}, vE);
  }
}
export {
  TE as MenuItem,
  xE as MenuItemMini,
  CE as Modal
};
