/** @type {import("@sveltejs/vite-plugin-svelte").Options} */
const config = {
	compilerOptions: {
		accessors: true,
		css: true,
	},
}

export default config
