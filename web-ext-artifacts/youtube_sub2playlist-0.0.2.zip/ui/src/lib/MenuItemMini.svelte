<div id="sub2lists-menuitem-mini" class="style-scope ytd-mini-guide-renderer">
	<a
		id="endpoint"
		class="yt-simple-endpoint style-scope ytd-mini-guide-entry-renderer"
		on:click|preventDefault
	>
		<div id="wrapper">
			<svg
				viewBox="0 0 24 24"
				preserveAspectRatio="xMidYMid meet"
				focusable="false"
				class="style-scope yt-icon"
			>
				<g class="style-scope yt-icon">
					<path
						d="M22,7H2v1h20V7z M13,12H2v-1h11V12z M13,16H2v-1h11V16z M15,19v-8l7,4L15,19z"
						class="style-scope yt-icon"
					/>
				</g>
			</svg>
		</div>
		Playlists
	</a>
</div>

<style>
	.ytd-mini-guide-renderer {
		background-color: var(--yt-spec-brand-background-solid);
	}
	.ytd-mini-guide-renderer:hover {
		background-color: var(--yt-spec-badge-chip-background);
		outline: none;
	}
	#wrapper {
		width: 24px;
		height: 24px;
		margin-bottom: 6px;
	}
	svg {
		pointer-events: none;
		display: block;
		width: 100%;
		height: 100%;
		fill: var(--yt-spec-brand-icon-inactive);
	}
</style>
